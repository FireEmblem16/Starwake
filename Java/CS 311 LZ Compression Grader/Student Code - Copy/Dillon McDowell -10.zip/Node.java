/**
 * This class is for the nodes that are stored in the LZTrie class
 * @author Dillon
 *
 */
public class Node 
{

	public Node[] children = new Node[256];
	public int index;
	public Node parent;
	public String key;
	public String value;
	
	public Node (int index, String key)
	{
		this.index = index;
		this.key = key;
		this.parent = null;
		this.value = "";
	}
	
	public Node(int index, Node parent, String key, String value)
	{
		this.index = index;
		this.parent = parent;
		this.key = key;
		this.value = value;
	}
	
}