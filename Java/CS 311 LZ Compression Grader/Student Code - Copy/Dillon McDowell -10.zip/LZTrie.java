/**
 * This class acts as the dictionary for the LZ project 
 * @author Dillon
 *
 */
public class LZTrie
{
	public Node root;
	public Node duplicate;
	
	public LZTrie(){
		root = new Node(0, null, "root", "root");
		duplicate = new Node(0, "");
	}
}
