import java.util.Scanner;

/**
 * This was a simple main function that I used to test my encode and decode functions.
 * @author Dillon
 *
 */
public class LZMain {

	public static void main(String[] args)
	{
		LZ insta = LZ.getInstance();
		
		Scanner input = new Scanner(System.in);
		
		String tupni = input.nextLine();
		
		String enc = insta.encode(tupni);
		
		String dec = insta.decode(enc);

		System.out.println(enc);
		
		System.out.println(dec);
	
	}

}
