/**
 * This is the class used for the LZ Compression project
 * @author Dillon
 *
 */
public class LZ
{
	/**
	 * These are the variables of this class.
	 */
	private static final LZ instance = new LZ();
	private static LZTrie treeEncode;
	private static LZTrie treeDecode;
	
	private static int indexEncode = 0;
	private static int indexDecode = 1;
	private static int lookingFor = 1;
	
	private static int codewordBits = 0;
	private static String encodedString = "";
	private static String phrase = "";
	
	private static Node current = null;
	private static boolean found = false;
	
	/**
	 * Private constructor that can only be created by this class.
	 */
	private LZ() { indexEncode++; }
	
	
	/**
	 * This function returns the instance of this class so that the public functions can be used.
	 * @return instance - the only version of this class that is available
	 */
	public static LZ getInstance() 
	{
		return instance;
	}
	
	/**
	 * This function will take a phrase and encode it. It will create a string of 0's and 1' before calling
	 * FromBinary() to take it from a string of 0's and 1's to actual binary.
	 * @param uncomp - the string that is needing to be encoded
	 * @return a string of binary that is the encoded version of the input string
	 */
	public static String encode( String uncomp )
	{
		treeEncode = new LZTrie();
		lookingFor = 1;
		current = null;
				
		if(uncomp.isEmpty())
		{
			String ret = "";
			for(int x = 0; x < 32; x++)
				ret+="0";
			
			return FromBinary(ret);
		}
		
		int i = 0;
		while(i < uncomp.length())
		{
			current = treeEncode.root;
			int subStart = i;

			while(i < uncomp.length() && current.children[(int)uncomp.charAt(i)] != null)
			{
				current = current.children[(int)uncomp.charAt(i)];
				i++;
			}
			
			if(i < uncomp.length())
			{

				current.children[(int)uncomp.charAt(i)] = 
						new Node(++indexEncode, 
								current, 
								(Integer.toString(current.index) + uncomp.charAt(i)),
								uncomp.substring(subStart, i+1) );

				i++;
			}
			if(current.value.equals(uncomp.substring(subStart)))
			{
				treeEncode.duplicate = current;
				treeEncode.duplicate.key = String.valueOf(current.key);
				treeEncode.duplicate.index = current.index;
			}
		}
		
		codewordBits = (int)Math.ceil(Math.log(indexEncode)/Math.log(2));
		current = treeEncode.root;
		
		i = 0;
		while(i < 32-Integer.toString(codewordBits, 2).length())
		{
			encodedString += "0";
			i++;
		}
		encodedString += Integer.toString(codewordBits, 2);
	
		while(lookingFor <= indexEncode)
		{
			traverseTreeEncode(treeEncode.root);
		}
		
		if(treeEncode.duplicate != null)
		{
			int y = 0;
			while(y < codewordBits-Integer.toBinaryString( treeEncode.duplicate.index ).length() )
			{
				encodedString +="0";
				y++;
			}
			encodedString += Integer.toBinaryString( treeEncode.duplicate.index );
		}
		
		while(true)
		{
			if((encodedString.length()) % 16 == 0)
				break;
			else
				encodedString += "0";
		}
		
		return FromBinary(encodedString);
	}
	
	/**
	 * This function taken from the conversion.txt file sent by email from omacron@iastate.edu on Oct 8.
	 * @param comp - the binary that needs to be decoded
	 * @return the decoded human-readable string of the original input
	 */
	public static String decode( String comp )
	{
		treeDecode = new LZTrie();
		lookingFor = 1;
		current = null;
		String strComp = ToBinary(comp);
		String codeBits = strComp.substring(0, 32);
		
		int bits = takeBinaryValue(codeBits);
		
		int x = 32;
		indexDecode = 1;
		while(x + bits < strComp.length())
		{
			String key = "";
			if(x + bits < strComp.length() && x + bits + 16 < strComp.length())
			{
				key = String.valueOf(takeBinaryValue(strComp.substring(x, x + bits))) +
						String.valueOf((char)takeBinaryValue(strComp.substring(x + bits, x + bits + 16)));
			}
			else
			{
				key = String.valueOf(takeBinaryValue(strComp.substring(x, x + bits)));
				findIndex(treeDecode.root, Integer.parseInt(key));
			}
			
			if(key.equals("0"))
			{
				break;
			}
			else
			{
				int find = 0;
				if(key.length() > 1)
					find = Integer.parseInt( key.substring(0, key.length()-1) );
				else
					find = Integer.parseInt(key);
				
				if(found == true)
				{
					Node newNode = treeDecode.duplicate;
					newNode.index = indexDecode;
					indexDecode++;
				}
				else
				{
					Node newNode = new Node(indexDecode, key);
					traverseTreeAdd(treeDecode.root, find, newNode);
					indexDecode++;
				}
			}
			x += (bits + 16);
		}
		
		while(lookingFor < indexDecode)
		{
			traverseTreeDecode(treeDecode.root);
		}
		
		return phrase;
	}
	
	/**
	 * This function will find a Node and duplicate it for decoding.
	 * @param n - the Node that you will start the search from
	 * @param find - the index value that you are trying to find
	 */
	private static void findIndex(Node n, int find)
	{
		if(found == true)
			return;
		
		if(n == null)
			return;
		
		if(n.index == find)
		{
			treeDecode.duplicate.index = indexDecode;
			treeDecode.duplicate.value = n.value;
			treeDecode.duplicate.key = n.key;
			treeDecode.duplicate.parent = n.parent;
			found = true;
			return;
		}
		else
		{
			for(int x = 0; x < n.children.length; x++)
			{
				if(found == true)
					return;
				
				findIndex(n.children[x], find);
			}
		}
	}
	
	/**
	 * This function will take in a string of ascii 0's and 1's and return the value that it represents.
	 * @param str - the string of ascii 0's and 1's
	 * @return the value that the string represented
	 */
	private static int takeBinaryValue(String str)
	{
		int bits = 0;
		for(int j = 0; j < str.length(); j++)
		{
			if(str.charAt(j) == '0')
			{
				bits = bits << 1;
			}
			else if(str.charAt(j) == '1')
			{
				bits = bits << 1;
				bits += 0b1;
			}
		}
		return bits;
	}
	
	/**
	 * This function traverses the tree used for decoding and will add a node to it.
	 * @param n - the node you will start traversing from
	 * @param find - the index value you are looking for
	 * @param toAdd - the Node that needs to be added
	 */
	private static void traverseTreeAdd(Node n, int find, Node toAdd)
	{
		if(n == null)
			return;
		
		if(n.index == find && !found)
		{
			char[] nodeKey = toAdd.key.toCharArray();
			n.children[(int)nodeKey[nodeKey.length-1]] = toAdd;
			n.children[(int)nodeKey[nodeKey.length-1]].parent = n;
			
			if(n.value.equals("root") && n.key.equals("root"))
			{
				n.children[(int)nodeKey[nodeKey.length-1]].value += nodeKey[nodeKey.length-1];
			}
			else if(found)
			{
				n.children[(int)nodeKey[nodeKey.length-1]].value = "" + nodeKey[nodeKey.length-1];
			}
			else
			{
				n.children[(int)nodeKey[nodeKey.length-1]].value = n.value + nodeKey[nodeKey.length-1];
			}
			return;
		}
		else
		{
			for(int x = 0; x < n.children.length; x++)
			{		
				traverseTreeAdd(n.children[x], find, toAdd);
			}
		}
		
	}
	
	/**
	 * This function will traverse through a tree and create a string of ascii 0's and 1's from the tree used for encoding.
	 * @param n - the node you will start traversing from
	 */
	private static void traverseTreeEncode(Node n)
	{
		if(n == null)
			return;
		
		if(n.index == lookingFor)
		{
			int y = 0;
			while(y < codewordBits-Integer.toBinaryString( Integer.parseInt(n.key.substring(0, n.key.length()-1)) ).length())
			{
				encodedString += "0";
				y++;
			}
			encodedString += Integer.toBinaryString( Integer.parseInt(n.key.substring(0, n.key.length()-1)) );

			y = 0;
			while(y < 16 - Integer.toBinaryString( (int)n.key.charAt(n.key.length()-1)).length() )
			{
				encodedString += "0";
				y++;
			}
			
			encodedString += Integer.toBinaryString( (int)n.key.charAt(n.key.length()-1) );
			lookingFor++;
			return;
		}
		else
		{
			for(int x = 0; x < n.children.length; x++)
			{
				traverseTreeEncode(n.children[x]);
			}
		}
	}
	
	/**
	 * This function will traverse the tree used for decoding and create a readable phrase from the tree's Nodes
	 * @param n - the node you will start traversing from
	 */
	private static void traverseTreeDecode(Node n)
	{
		if(n == null || lookingFor == indexDecode)
			return;
		
		if(n.index == lookingFor)
		{	
			phrase += n.value;

			lookingFor++;
			return;
		}
		else if(treeDecode.duplicate != null && lookingFor == treeDecode.duplicate.index)
		{
			phrase += treeDecode.duplicate.value;

			lookingFor++;
			return;
		}
		else
		{
			for(int x = 0; x < n.children.length; x++)
			{
				traverseTreeDecode(n.children[x]);
			}
		}
	}
	
	/**
	 * This function taken from the conversion.txt file sent by email from omacron@iastate.edu on Oct 8.
	 * This will take binary and create a string of ascii 0's and 1's from it
	 * @param str - the binary that needs to be converted
	 * @return string that represents the original binary
	 */
	public static String ToBinary(String str)
	{
		final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i++)
		{
			char c = str.charAt(i);
			
			for(int j = 0;j < 16;j++)
				if((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}
		
		return ret;
	}
	
	/**
	 * This function taken from the conversion.txt file sent by email from omacron@iastate.edu on Oct 8.
	 * @param str - a string of ascii 0's ans 1's that needs to become binary
	 * @return the binary value that the original string represented
	 */
	public static String FromBinary(String str)
	{
		final char[] bits = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i += 16)
		{
			char c = 0x0000;
			
			for(int j = 0;j < 16;j++)
				if(str.charAt(i + j) == '1')
						c |= bits[j];
				
				ret += c;
			}
			
			return ret;
	}
}