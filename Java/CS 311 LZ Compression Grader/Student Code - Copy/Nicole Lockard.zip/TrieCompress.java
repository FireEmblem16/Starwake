import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;


public class TrieCompress extends Compress{

	@Override
	public String seperateStirng(String str) {
		Trie trie = new Trie();
		//count to keep track of the key in 
		trie.createTreeFromString(str);
		int z = 4;
		Collection<ReturnObject> ret = getIndexses(trie);
		String s = createCompression(trie.getNumNodes(),ret);
		return s;
	}
	private Collection<ReturnObject> getIndexses(Trie t){
		Collection<ReturnObject> ret = new LinkedList<ReturnObject>();
		for(int i = 1;i<t.getNumNodes()+1;i++){
			ret = t.getIndex(t.root, i, 0,ret);
			
		}
		return ret;
	}
	private String createCompression(int numNode, Collection<ReturnObject> ret){
		
		String s = "";
		if(numNode > 0){
			Iterator<ReturnObject> it = ret.iterator();
			char[] arr = new char[numNode*2];
			int i = 0;
			int[] bitsNeeded = {0,1,2,3,4};
			int length = (int) Math.ceil((Math.log(numNode)/Math.log(2)));
			int numByte = bitsNeeded[(int)(Math.ceil(length/8.0))];
			while (it.hasNext()){
				ReturnObject temp = it.next();
				
				if(numByte<3){
					arr[i]=(char) temp.getParentIndex();
				}else{
					char top = (char) (length>>16);
					char botom = (char) length;
					arr[i]=top;
					i++;
					arr[i]=botom;
				}
				i++;
				if(!temp.getNode().getEndAndRepeat()){
					arr[i]=temp.getNode().getContent();
					i++;
				}
			}

			
			
			int modnum =0;
			if(numByte<3){
				modnum = 2;
			}else{
				modnum = 3;
			}
			s = copressWithChar(length, arr,modnum);

		}else{
			int zero = 0;
			char top = (char) (zero>>16);
			char botom = (char) zero;
			s+=top;
			s+=botom;
		}

		
		return s;
	}
	private String copressWithChar(int length, char[] arr, int modnum) {
		//number of bits still needed to make a complete char
		int bitsNeeded = 16;
		//number of bits we have in the partal char
		int bitsHave = 0;
		//number of bits remaining in the borrowed from char.
		int bitsRemain = 0;
		//number of spaces to shift
		int shift = 16-length;
		//the answer to i%2 where the keys are
		int mod = 0;
		//boolean to indicate weither after adding the key we are still short
		boolean shortBites = false;

		bitsHave = 16-shift;
		bitsNeeded= 16-bitsHave;
		for(int i = 1;i<arr.length;i++){
			shortBites = false;
			char temp;
			if(i%modnum == mod){
				if(length<bitsNeeded){
					temp= (char) (arr[i]<<(bitsNeeded-length));
					bitsHave = bitsHave+length;
					shortBites = true;
				}else{
					
					temp = (char) (arr[i]>>(length-bitsNeeded));
					bitsHave = length-bitsNeeded;
				}
				
			}else{
				
				temp = (char) (arr[i]>>bitsHave);
				bitsRemain = bitsHave;
			}
			arr[i-1] = (char) (arr[i-1]|temp);
			bitsRemain=bitsHave;
			arr[i] = (char) (arr[i]<<16-bitsRemain);
			bitsHave=bitsRemain;
			bitsNeeded=16-bitsHave;
			if(shortBites){
				arr = remove(arr,i);
				if(mod == 0){
					mod = 1;
				}else if(mod == 1 && modnum == 3){
					mod = 2;
				}else{
					mod = 0;
				}
				i--;
			}
		}
		
		String s = createString(arr,length);
		
		return s;
	}
	
	
	private String createString(char[] arr,int length) {
		String s="";
		char top = (char) (length>>16);
		char botom = (char) length;
		s+=top;
		s+=botom;
		for(int i = 0; i<arr.length;i++){			
			s+=arr[i];
		}		
		return s;
	}
	private char[] remove(char[] arr, int index) {
		char[] a = new char[arr.length-1];
		for(int i=0;i<a.length+1;i++){
			if(i==index){
				
			}else{
				if(i>index){
					a[i-1]=arr[i];
				}else{
					a[i]=arr[i];
				}
			}
		}
		return a;
	}
	
}
