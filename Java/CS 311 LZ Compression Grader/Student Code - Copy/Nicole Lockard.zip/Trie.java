import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;


public class Trie {
	public TrieNode root;
	private int numNodes;
	public Trie(){
		root = new TrieNode('\0',0);
		numNodes = 0;
	}
	public void createTreeFromString(String str){
		int count = 1;
		int i = 0;
		Boolean child = false;
		while(i<str.length()){
			TrieNode node = this.root;
			TrieNode parentNode = node;
			char curr = str.charAt(i);
			node = node.isChild(curr);
			if(node != null){
				child = true;
				while(child && i < str.length()-1){
					i = i + 1 ;
					curr = str.charAt(i);
					parentNode = node;
					node = node.isChild(curr);
					if(node == null){
						child = false;
					}
				}
			}
			if(!child){
				TrieNode newNode = new TrieNode(curr, count);
				this.incrementNumNodes();
				parentNode.addChild(newNode);
				count = count+1;
			}
			else{
				TrieNode newNode = new TrieNode(curr, count);
				node.addChild(newNode);
				this.incrementNumNodes();
				newNode.setEndAndRepeat(true);
			}
			i = i + 1;
		}
	}
	public void createFromCharList(ArrayList<Character> ch){
		int index;
		char c;
		Collection<ReturnObject> cr = new LinkedList<ReturnObject>();
		int addingAt =1;
		for(int i=0;i<ch.size();i++){
			index = (int) ch.get(i);
			i++;
			c = ch.get(i);
			if(index>0){
				cr = getIndex(root, index,0,cr);
				Iterator<ReturnObject> it = cr.iterator();
				TrieNode temp = this.insert(it.next().getNode(), (char) c, addingAt);
				addingAt++;
				this.incrementNumNodes();
				if(i == ch.size()-1 && temp.getContent() == '\0'){
					temp.setEndAndRepeat(true);
				}
			}else{
				this.insert(root, (char) c, addingAt);
				addingAt++;
				this.incrementNumNodes();
			}
			cr.clear();
		}
	}
	public TrieNode insert(TrieNode node, char c, int k){
		TrieNode newNode = new TrieNode(c, k);
		node.addChild(newNode);
		return newNode;
	}
	
	public Collection<ReturnObject> getIndex(TrieNode n, int index, int parentIndex,Collection<ReturnObject> arr){
		if(n.getKey() == index){
			ReturnObject temp =  new ReturnObject(n,parentIndex);
			arr.add(temp);
			return arr;
		}
		else{
			Collection<TrieNode> col = n.getChidren();
			Iterator<TrieNode> it = col.iterator();
			while(it.hasNext()){
				TrieNode node = it.next();
				getIndex(node,index, n.getKey(),arr);
			}
			return arr;
		}
	}
	public void incrementNumNodes(){
		this.numNodes ++;
	}
	public int getNumNodes(){
		return this.numNodes;
	}
}
