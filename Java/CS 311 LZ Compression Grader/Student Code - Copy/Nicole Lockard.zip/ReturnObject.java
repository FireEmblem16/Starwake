
public class ReturnObject {
	private TrieNode node;
	private int parentIndex;
	
	public ReturnObject(TrieNode n, int index){
		node = n;
		parentIndex = index;
	}
	
	public int getParentIndex(){
		return this.parentIndex;
	}
	
	public TrieNode getNode(){
		return this.node;
	}
}
