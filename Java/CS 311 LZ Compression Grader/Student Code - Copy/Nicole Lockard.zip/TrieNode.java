import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;


public class TrieNode {
	
	private char content;
	private int key;
	private Collection<TrieNode> children;
	private boolean endAndRepeat;
	
	public TrieNode(char c, int k){
		content = c;
		key = k;
		children = new LinkedList<TrieNode>();
		endAndRepeat = false;
	}
	public void addChild(TrieNode node){
		this.children.add(node);
	}
	public TrieNode isChild(char c){
		Iterator<TrieNode> it = this.children.iterator();
		while(it.hasNext()){
			TrieNode node = it.next();
			if(node.content == c){
				return node;
			}
		}
		return null;
	}
	public Collection<TrieNode> getChidren(){
		return this.children;
	}
	public int getKey(){
		return this.key;
	}
	public char getContent(){
		return this.content;
	}
	public void setEndAndRepeat(boolean v){
		this.endAndRepeat = v;
	}
	public boolean getEndAndRepeat(){
		return this.endAndRepeat;
	}
}
