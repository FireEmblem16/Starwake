import java.util.ArrayList;


public abstract class Decompress {
	public abstract Trie insertIntoTree(ArrayList<Character> ch);
}
