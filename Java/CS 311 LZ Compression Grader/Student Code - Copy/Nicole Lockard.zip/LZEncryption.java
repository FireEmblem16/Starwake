import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

//The only outside sources I used were the wikapedia web page on tries. I used there psuedo code
// to add into my trie.
public class LZEncryption {
	
	private LZEncryption(){
		
		
	}
	/**
	 * encode will compress a string using LZ78
	 * @param uncompressed the string to compress
	 * @return a compressed string
	 * @throws IOException
	 */
	public static String encode(String uncompressed) throws IOException{
		Compress compress = new TrieCompress();
		String compressed = compress.seperateStirng(uncompressed);
		return compressed;
	}
	
	/**
	 * Decode
	 * Decode will uncompress a string that was compressed using LZ78
	 * @param compressed the string you want to uncompress
	 * @return The uncopressed string
	 */
	public static String decode(String compressed){
		Decompress decompress = new TrieDecompress();
		String decompressed = ((TrieDecompress) decompress).decodeString(compressed);
		return decompressed;
	}
	
}
