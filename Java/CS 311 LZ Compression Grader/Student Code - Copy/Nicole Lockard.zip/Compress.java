import java.io.IOException;


public abstract class Compress {
	public abstract String seperateStirng(String str) throws IOException;
	
}
