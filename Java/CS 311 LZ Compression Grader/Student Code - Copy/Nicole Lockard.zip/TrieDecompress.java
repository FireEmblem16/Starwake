import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;


public class TrieDecompress extends Decompress{

	public String decodeString(String s){
		char[] c = s.toCharArray();
		char top = c[0];
		char bottom = c[1];
		int length = 0;
		length = length|top;
		length = length<<16;
		length = length |bottom;
		ArrayList<Character> ch = new ArrayList<Character>();
		if(c.length>2){
			int shift = 16-length;

			char temp = (char)(c[2]>>shift);
			ch.add(temp);
			int key = 2;
			int newlength = length;
			for(int i = 2;i<c.length-1;i++){
				char temp2;
				if(key == 1){
					temp = (char) (c[i]<<newlength);
					if(newlength>(16-length)){
						/*if(shift == 1){
							shift = 2;
						}*/
						temp2=(char) (c[i+1]>>shift);
						temp = (char) (temp|temp2);
						temp = (char) (temp>>16-length);
						ch.add(temp);
					}else{
						temp = (char) (temp>>16-length);
						ch.add(temp);
						i--;
					}
					
					newlength = newlength + length;
					if(newlength>16){
						newlength = newlength-16;
					}
					shift = 16-newlength;

				}else if(key == 2|| key == 3){
					temp = (char)(c[i]<<newlength);
					temp2 = (char)(c[i+1]>>shift);
					ch.add((char)(temp|temp2));
					
				}
				if(key == 1){
					key = 2;
				}else if ((key == 2 && length<17)|| key == 3){
					key = 1;
				}else{
					key = 3;
				}
			}
		}
		
		
		
		Trie t = insertIntoTree(ch);
		s = getFinalString(t);
		
		return s;
	}

	private String getFinalString(Trie t) {
		Collection<ReturnObject> cr = new LinkedList<ReturnObject>();
		ArrayList<ReturnObject> arr = new ArrayList<ReturnObject>();
		String s = "";
		for(int i=1; i<t.getNumNodes()+1;i++){
			cr = t.getIndex(t.root, i,0,cr);
			Iterator<ReturnObject> it = cr.iterator();
			ReturnObject temp = it.next();
			if(temp.getParentIndex()>0){
				cr = t.getIndex(t.root, i,0,cr);
				arr = goUpTree(temp,arr,t);
				int loopTell;
				if(temp.getNode().getEndAndRepeat()){
					loopTell = 0;
				}else{
					loopTell = -1;
				}
				for(int j =arr.size()-1;j>loopTell;j--){
					temp = arr.get(j);
					if(!temp.getNode().getEndAndRepeat()){
						s+=temp.getNode().getContent();
					}
				}
				arr.clear();
			}else{
				s+= temp.getNode().getContent();
			}
			cr.clear();
		}
		return s;
	}
	private ArrayList<ReturnObject> goUpTree(ReturnObject node,ArrayList<ReturnObject> arr,Trie t){
		if(node.getNode().getKey() == 0){
			return arr;
		}else{
			Collection<ReturnObject> cr = new LinkedList<ReturnObject>();
			arr.add(node);
			cr = t.getIndex(t.root, node.getParentIndex(), 0, cr);
			Iterator<ReturnObject> it = cr.iterator();
			ReturnObject temp = it.next();
			if(temp.getNode().getKey() !=0){
				goUpTree(temp,arr,t);
			}
			return arr;
		}
	}

	public Trie insertIntoTree(ArrayList<Character> ch) {
		Trie trie = new Trie();
		trie.createFromCharList(ch);
		return trie;
	}
}
