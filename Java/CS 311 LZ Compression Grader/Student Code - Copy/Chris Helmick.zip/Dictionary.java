/**
 * Author: Chris Helmick
 * Created on 9/28/2014, within "LempelZiv_Compression".
 *
 * Abstract interface to make the transition to part b easier
 */
public interface Dictionary<T>{
	boolean contains(T entry);

	T findEntryAtIndex(int index);

	int findIndexOfEntry(T entry);

	void store(T entry, int index);
}
