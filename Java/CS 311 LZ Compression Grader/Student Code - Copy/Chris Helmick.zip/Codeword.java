/**
 * Author: Chris Helmick
 * Created on 9/27/2014, within "LempelZiv_Compression".
 *
 * Simple wrapper class for storing a "codeword" (an associated index and suffix character)
 *
 */
public class Codeword{
	int index;
	char c;

	public Codeword(int ind, char ch){
		index = ind;
		c = ch;
	}
}
