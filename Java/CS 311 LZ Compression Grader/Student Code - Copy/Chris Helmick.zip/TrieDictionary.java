import java.util.Iterator;
import java.util.Stack;

/**
 * Author: Chris Helmick
 * Created on 9/28/2014, within "LempelZiv_Compression".
 *
 * A dictionary implementation based on the trie data structure.
 */
public class TrieDictionary extends Trie implements Dictionary<String>{

	public TrieDictionary(){
		super(0);
	}

	@Override
	public boolean contains(String s){
		return super.contains(s);
	}

	@Override
	public int findIndexOfEntry(String entry){
		Node n = find(entry);
		if(n == null){
			throw new IllegalArgumentException();
		}
		return n.value;
	}

	@Override
	public String findEntryAtIndex(int index){
		if(index == 0){
			// for pretty-printing while debugging
			return "\\";
		}
		// iterate through the trie to find the node of specified index
		Node entry = null;
		Iterator<Node> iter = getIterator();
		while(iter.hasNext()){
			Node n = iter.next();
			if(n.value == index){
				entry = n;
				break;
			}
		}
		if(entry == null){
			throw new IllegalArgumentException();
		}
		// follow the path of the node back up to the root
		Stack<Character> charStack = new Stack<Character>();
		while(entry.parent != null){
			charStack.push(entry.branch);
			entry = entry.parent;
		}
		// reverse the characters along the way, to get the string that leads to the inputted index
		String path = "";
		while(!charStack.empty()){
			path += charStack.pop();
		}
		return path;
	}

	@Override
	public void store(String entry, int index){
		add(entry, index);
	}

	// for debug/testing purposes
	public String toString(){
		String str = "";
		Iterator<Node> iter = getIterator();
		while(iter.hasNext()){
			Node n = iter.next();
			str += n.value + ": " + n.branch + "\n";
		}
		return str;
	}

}
