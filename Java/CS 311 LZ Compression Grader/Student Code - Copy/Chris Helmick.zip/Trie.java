import java.util.Iterator;

/**
 * Author: Chris Helmick
 * Created on 9/28/2014, within "LempelZiv_Compression".
 *
 * A simple Trie implementation with an included partial-iterator (no remove support, since it's not needed for the project)
 */
public class Trie{
	private Node root;

	public Trie(int rootValue){
		root = new Node(rootValue, '\0', null);
	}

	Node find(String s){
		Node cur = root;
		for(int i = 0; i < s.length(); i++){
			char c = s.charAt(i);
			cur = cur.getChild(c);
			if(cur == null){
				return null;
			}
		}
		return cur;
	}

	boolean contains(String s){
		Node n = find(s);
		return (n != null);
	}

	void add(String s, int val){
		String substr = s.substring(0, s.length() - 1);
		Node prefix = find(substr);
		if(prefix == null){
			throw new IllegalArgumentException();
		}
		char last = s.charAt(s.length() - 1);
		prefix.addChild(last, val);
	}

	Iterator<Node> getIterator(){
		return new TrieIterator();
	}

	private class TrieIterator implements Iterator<Node>{
		Node cursor;

		public TrieIterator(){
			cursor = root;
		}

		// don't care, not going to use it
		public void remove(){
		}

		private Node getNext(){
			Node cur = cursor;
			if(cur.chars.length() > 0){
				// there is a child to go down to
				// go to the first one first
				char c = cur.chars.charAt(0);
				return cur.getChild(c);
			}
			else{
				while(cur.parent != null){
					// go up a level until a new branch can be taken
					char prev = cur.branch;
					cur = cur.parent;
					if(cur == null){
						return null;
					}
					// go forward
					int ind = cur.chars.indexOf(prev) + 1;
					if(ind < cur.chars.length()){
						// it works!!, break out of search loop
						char c = cur.chars.charAt(ind);
						return cur.getChild(c);
					}
				}
				// ran out of trie, no more found
				return null;
			}
		}

		public Node next(){
			cursor = getNext();
			return cursor;
		}

		public boolean hasNext(){
			//return (cursor!=root || (first && root.chars.length()>0));
			return getNext() != null;
		}
	}

}
