import java.util.LinkedList;
import java.util.Stack;

/**
 * Author: Chris Helmick
 * Created on 9/29/2014, within "LempelZiv_Compression".
 *
 * This class takes a string and iterates through the bits one at a time, returning booleans for each successive bit
 *
 */

public class BitBreaker{
	private static final int BITS_PER_CHAR = 16;
	private static final int BITS_PER_INT = 32;

	private String source;
	private int cursor;
	private LinkedList<Boolean> inProgressBits;

	public BitBreaker(String src){
		source = src;
		cursor = 0;
		inProgressBits = new LinkedList<Boolean>();
	}

	private boolean populateQueue(){
		if(cursor >= source.length()){
			return false;
		}
		int nextChar = source.charAt(cursor);
		// shifting mask is buggy in java, so shift the input right,
		// then reverse it to get the left to right bit sequence
		int one = ~(~0 << 1);
		Stack<Boolean> bitStack = new Stack<Boolean>();
		for(int i = 0; i < BITS_PER_CHAR; i++){
			int masked = one & nextChar;
			boolean bit = masked != 0;
			bitStack.push(bit);
			nextChar >>= 1;
		}
		// reverse them
		while(!bitStack.isEmpty()){
			inProgressBits.add(bitStack.pop());
		}
		cursor++;
		return true;
	}

	public Boolean nextBit(){
		if(inProgressBits.isEmpty()){
			if(!populateQueue()){
				throw new IllegalStateException();
			}
		}
		// we have bits in the queue if logic has reached this far
		// grab the first one
		return inProgressBits.remove();
	}

	public boolean hasNextBit(){
		// true if non empty, also true if populateQueue works
		// else false (since both sources are exhausted)
		return !inProgressBits.isEmpty() || populateQueue();
	}

	public int nextInt(int numBits){
		if(numBits > BITS_PER_INT){
			throw new IllegalArgumentException("Bits requested: [" + numBits + "] exceeds limit: [" + BITS_PER_INT + "]");
		}
		while(inProgressBits.size() < numBits){
			if(!populateQueue()){
				throw new IllegalStateException();
			}
		}
		int partial = 0;
		int one = ~(~0 << 1);
		for(int i = 0; i < numBits; i++){
			partial <<= 1;
			// get next bit from queue
			boolean bool = inProgressBits.remove();
			int bit = bool ? one : 0;
			partial |= bit;
		}
		return partial;
	}

	public boolean hasNextInt(int numBits){
		while(inProgressBits.size() < numBits){
			boolean more = populateQueue();
			if(!more){
				return false;
			}
		}
		return true;
	}

}
