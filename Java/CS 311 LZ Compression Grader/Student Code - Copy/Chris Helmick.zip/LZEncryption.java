import java.util.LinkedList;

/**
 * Author: Chris Helmick
 * Created on 9/28/2014, within "LempelZiv_Compression".
 *
 * The main class file.
 */
public class LZEncryption{
	// no instantiation allowed
	private LZEncryption(){
	}

	// consts
	private static final int NUMBER_OF_BITS_PER_CHAR = 16;
	private static final int PRECISION_OF_HEADER_INT = 32;

	public static String encode(String uncompressed){
		LinkedList<Codeword> outputQueue = new LinkedList<Codeword>();
		TrieDictionary trie = new TrieDictionary();
		int count = 1;
		int i;
		int j = 1;
		for(i = 0; i < uncompressed.length(); ){
			for(j = 1; i + j <= uncompressed.length(); j++){
				String substr = uncompressed.substring(i, i + j);
				if(!trie.contains(substr)){
					//LOG(substr);
					// add it in to the new location
					trie.add(substr, count);
					count++;
					// now get it's prefix (parent in this case, but if not a trie, then we
					// wouldn't be able to exploit that, so we have to lookup it's parent in
					// the dictionary, via another substring)
					int parentIndex = trie.findIndexOfEntry(substr.substring(0, substr.length() - 1));
					// and then also get the appended character
					char append = substr.charAt(substr.length() - 1);
					Codeword cw = new Codeword(parentIndex, append);
					// adds to end of queue
					outputQueue.add(cw);
					break;
				}
			}
			i += j;
		}
		if(i < uncompressed.length()){
			throw new RuntimeException("Something went very, very wrong.  ....  PANIC!!!");
		}
		// build the main string
		// count started at 1 not 0, so it's correct as being count instead of count+1
		int indexBits = (int) Math.ceil(Math.log(count)/Math.log(2));

		BitBuilder out = new BitBuilder();
		out.append(indexBits, PRECISION_OF_HEADER_INT);

		while(!outputQueue.isEmpty()){
			// takes from beginning of queue
			Codeword cw = outputQueue.remove();
			out.append(cw.index, indexBits);
			out.append(cw.c, NUMBER_OF_BITS_PER_CHAR);
		}
		// handle the last codeword if needed
		if(i > uncompressed.length()){
			i -= j;// undo last add
			String leftovers = uncompressed.substring(i);
			// get index
			int loInd = trie.findIndexOfEntry(leftovers);
			out.append(loInd, indexBits);
		}

		return out.toString();
	}

	public static String decode(String compressed){
		BitBreaker bitStream = new BitBreaker(compressed);

		if(!bitStream.hasNextInt(PRECISION_OF_HEADER_INT)){
			throw new IllegalArgumentException("Input string is too short.");
		}

		TrieDictionary trieDictionary = new TrieDictionary();
		StringBuilder output = new StringBuilder();
		int count = 1;

		int indexSize = bitStream.nextInt(PRECISION_OF_HEADER_INT);

		boolean done = false;
		while(!done){
			String newEntry = "";
			if(bitStream.hasNextInt(indexSize)){
				int index = bitStream.nextInt(indexSize);
				if(index > 0){
					String entry = trieDictionary.findEntryAtIndex(index);
					newEntry += entry;
				}
			}
			if(bitStream.hasNextInt(NUMBER_OF_BITS_PER_CHAR)){
				char c = (char)bitStream.nextInt(NUMBER_OF_BITS_PER_CHAR);
				newEntry += c;
			}
			else{
				//final round escape
				done = true;
			}
			// add output to string
			output.append(newEntry);
			if(!done){
				// add new entry to dictionary
				trieDictionary.store(newEntry, count);
			}
			count++;
		}

		return output.toString();
	}

}
