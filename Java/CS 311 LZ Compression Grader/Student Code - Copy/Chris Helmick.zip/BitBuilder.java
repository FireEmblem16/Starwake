import java.util.LinkedList;
import java.util.Stack;

/**
 * Author: Chris Helmick
 * Created on 9/28/2014, within "LempelZiv_Compression".
 *
 * This class acts similar to a string builder, but takes bitfields (in the form of ints) and adds them to a bit string
 *
 * the toString method then outputs a 16-bit char (0 padded at the end) of the resultant bitfield
 *
 */
public class BitBuilder{
	private static final int BITS_PER_CHAR = 16;
	private static final int BITS_PER_INT = 32;

	private LinkedList<Boolean> inProgressBits;
	private StringBuilder cached;

	public BitBuilder(){
		cached = new StringBuilder();
		inProgressBits = new LinkedList<Boolean>();
	}

	public void append(int bitfield, int numBitsInField){
		if(numBitsInField > BITS_PER_INT){
			throw new IllegalArgumentException();
		}
		// [ empty ] [ data ]
		// assume left is empty
		Stack<Boolean> bitStack = new Stack<Boolean>();
		// furthest right bit
		char one = ~(~0 << 1);
		for(int i = 0; i < numBitsInField; i++){
			int masked = bitfield & one;
			boolean bit = masked != 0;
			bitStack.push(bit);
			bitfield >>= 1;
		}
		while(!bitStack.isEmpty()){
			append(bitStack.pop());
		}
	}

	public void append(boolean bit){
		// add bit
		inProgressBits.add(bit);
		// push full bytes out as chars on the string
		if(inProgressBits.size() >= BITS_PER_CHAR){
			// transition bits out of queue, into the string as a new char appended to the end
			// build the char
			int partial = 0;
			final int one = ~(~0 << 1);
			for(int i = 0; i < BITS_PER_CHAR; i++){
				// does nothing the first iteration since 0<<1 == 0,
				// but on last iteration we don't want to shift (losing the MSB)
				partial <<= 1;
				int value = inProgressBits.remove() ? one : 0;
				partial |= value;
			}
			// move it to string
			char c = (char)(partial);
			cached.append(c);
		}
	}

	public String toString(){
		// fix end partial bits
		String out = cached.toString();
		if(!inProgressBits.isEmpty()){
			BitBuilder end = new BitBuilder();
			// copy
			for(boolean bit : inProgressBits){
				end.append(bit);
			}
			// fill
			while(end.inProgressBits.size() > 0){
				end.append(false);
			}
			out += end.toString();
		}
		return out;
	}

}
