import java.util.ArrayList;

/**
 * Author: Chris Helmick
 * Created on 9/28/2014, within "LempelZiv_Compression".
 *
 * A node for a trie
 */
public class Node{
	Node parent;

	String chars;
	private ArrayList<Node> children;

	char branch;
	int value;

	public Node(int val, char branchVal, Node par){
		value = val;
		branch = branchVal;
		parent = par;

		chars = "";
		children = new ArrayList<Node>();
	}

	Node getChild(char c){
		int i = chars.indexOf(c);
		if(i < 0 || i >= children.size()){
			return null;
		}
		return children.get(i);
	}

	void addChild(char c, int val){
		Node n = new Node(val, c, this);
		chars += c;
		children.add(n);
	}

}
