import java.util.ArrayList;

// non-instantiable class implementation the Lempel-Ziv (LZ) 
// compression algorithm using a 'trie' data structure for 
// encoding and compressing strings.

// Contains two public static methods:
// public static String encode(String uncompressed)
// public static String decode(String compressed)

/**
 * @author Kip Hoelscher, 2014
 */

///////////////////////////////////////////////////////////////////////////
// class LZEncryption /////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////

//==========================================================================
public class LZEncryption
{
	// The root of the yet-to-be-created 'trie' data structure.
	private static Node root;

	// boolean used for testing.  
	// Controls printing of debug statements to console.
	private static boolean debug = false;


	//==========================================================================
	// private default constructor
	private LZEncryption()
	{
	}


	//==========================================================================
	//	 Main method, used for testing.  
	//	public static void main( String[] args )
	//	{
	//		debug = true;
	//		System.out.println( "result: " + decode( encode( "This is a test." ) ) );
	//		debug = false;
	//	}

	///////////////////////////////////////////////////////////////////////////
	// Encode /////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////

	//==========================================================================
	// Convert and compress a given string using Lempel-Ziv algorithm
	// and a 'trie' data structure.  
	public static String encode( String uncompressed )
	{
		if( uncompressed == null )
		{
			return null;
		}
		if( uncompressed.equals( "" ) )
		{
			return convertFromBinary( "00000000000000000000000000000000" );
		}

		String readableBinary = parseStringToEncode( uncompressed );
		return convertFromBinary( readableBinary );
	}


	//==========================================================================
	// Parses the string to encode, builds the 'trie' data structre,
	// populates lists of words, indices, and suffixes, then converts 
	// the lists into a compressed Java String of human-readable binary.
	private static String parseStringToEncode( String s )
	{
		if( debug )
			System.out.println( "Building Trie from: " + s );

		root = new Node( "" );

		ArrayList<String> words = new ArrayList<String>();
		ArrayList<Integer> indices = new ArrayList<Integer>();
		ArrayList<String> suffixes = new ArrayList<String>();

		buildTrieAndFillLists( s, words, indices, suffixes );

		fixFinalWord( words, indices, suffixes );

		if( debug )
		{
			System.out.println( "words: " + words.toString() );
			System.out.println( "indices: " + indices.toString() );
			System.out.println( "suffixes: " + suffixes.toString() );
		}

		return createEncodedJavaBinaryString( indices, suffixes );
	}


	//==========================================================================
	// Builds the trie data structure from the uncompressed string.
	// Also creates the lists of indices and suffixes but searching the trie.
	private static void buildTrieAndFillLists( String s,
			ArrayList<String> words, ArrayList<Integer> indices,
			ArrayList<String> suffixes )
	{
		String nextWord = new String( "" );
		words.add( nextWord );

		int index = 0;
		while (index < s.length())
		{
			nextWord = getAndAddNextWord( s, index );
			index += nextWord.length();
			words.add( nextWord );
			// add the final char of the phrase to the chars list
			suffixes.add( nextWord.substring( nextWord.length() - 1 ) );
			indices.add( findPrefixIndex( words, nextWord ) );
		}
	}


	//==========================================================================
	// Fix final entry if is a repeat, by setting index to the previous
	// occurrence of the word, and setting the suffix to "".
	private static void fixFinalWord( ArrayList<String> words,
			ArrayList<Integer> ints, ArrayList<String> chars )
	{
		String lastWord = words.get( words.size() - 1 );

		// add a dummy char to the end of the final phrase, so that 
		// findPrefixIndex() will actually search for the whole final phrase.  
		Integer indexOfFinalWord = findPrefixIndex( words, lastWord + "x" );

		// if the final codeword matches a previous codeword
		if( indexOfFinalWord < words.size() - 1 )
		{
			// change the last entries in these two lists
			ints.set( ints.size() - 1, indexOfFinalWord );
			chars.set( chars.size() - 1, "" );
		}
	}


	//==========================================================================
	// scan the list until you find the index of the prefix of word
	private static Integer findPrefixIndex( ArrayList<String> words, String word )
	{
		String prefix = word.substring( 0, word.length() - 1 );
		int index = 0;
		while (!words.get( index ).equals( prefix ))
		{
			index++;
		}
		return new Integer( index );
	}


	//==========================================================================
	// search down the trie one char at a time from the starting index 
	// of the string until a char isn't found.  add a new node with that 
	// char and return the full word that it represents as a string
	private static String getAndAddNextWord( String s, int idx )
	{
		int index = idx;
		StringBuilder sb = new StringBuilder();
		String charToFind = s.substring( index, index + 1 );
		sb.append( charToFind );

		Node parent = root;
		Node child = findAndReturnChildWithString( parent, charToFind );

		// this should return before condition is actually met
		while (index < s.length())
		{
			if( child == null ) // child not found, create it and return
			{
				parent.addChild( charToFind );
				return sb.toString();
			}
			else
			// child found, keep searching
			{
				index++;
				// don't go past end of string.  
				if( ( index + 1 ) > s.length() )
				{
					// don't add a node, just return string
					return sb.toString();
					// TODO Can I fix final word here instead of later?  
				}
				charToFind = s.substring( index, index + 1 );
				sb.append( charToFind );
				parent = child;
				child = findAndReturnChildWithString( child, charToFind );
			}
		}

		// should not reach this
		return sb.toString();
	}


	//==========================================================================
	// search the children of this node for the given string of length one.
	// return the node containing the string if found, else return null 
	private static Node findAndReturnChildWithString( Node node, String s )
	{
		for(Node object : node.children)
		{
			if( object.data.equals( s ) )
			{
				return object;
			}
		}
		return null;
	}


	//==========================================================================
	// Take lists of indices and suffixes to be encoded, and create a 
	// human-readable Java String of ones and zeroes representing the encoded
	// and compressed data.  
	// This includes adding the required 32-bit header signifying index size, 
	// and padded trailing zeroes if needed.  
	private static String createEncodedJavaBinaryString(
			ArrayList<Integer> indices, ArrayList<String> suffixes )
	{
		// determine index size
		int indexSize = computeIndexSize( indices );

		StringBuilder sb = new StringBuilder();

		// add 32-bit representation of index size
		sb.append( stringIntToStringBinary( indexSize + "", 32 ) );

		// add the indices and suffixes
		addBinaryIndicesAndSuffixesToString( indices, suffixes, indexSize, sb );

		// pad the end of the string with required zeroes
		String padded = addPadding( sb );

		return padded;
	}


	//==========================================================================
	// Add binary representations of the indices and suffixes to the encoded string
	private static void addBinaryIndicesAndSuffixesToString(
			ArrayList<Integer> indices, ArrayList<String> suffixes,
			int indexSize, StringBuilder sb )
	{
		String idx;
		String suffix;
		for(int i = 0; i < indices.size(); i++)
		{
			idx = indices.get( i ).toString();
			suffix = suffixes.get( i );

			//			if( debug )
			//				System.out.println( "idx: " + idx + ", suffix: " + suffix );

			sb.append( stringIntToStringBinary( idx, indexSize ) );

			sb.append( convertToBinary( suffix ) );
		}
	}


	//==========================================================================
	// Add the necessary padding to the end of the encoded string so that 
	// its length is a multiple of 16.
	private static String addPadding( StringBuilder sb )
	{
		String noSpaces = sb.toString();
		int paddingNeeded = 16 - noSpaces.length() % 16;
		if( paddingNeeded == 16 )
		{
			paddingNeeded = 0;
		}

		if( debug )
			System.out.println( "paddingNeeded: " + paddingNeeded );

		for(int j = 0; j < paddingNeeded; j++)
		{
			sb.append( "0" );
		}
		String padded = sb.toString();

		if( debug )
			System.out.println( "codesToBinary compact: " + padded );

		return padded;
	}


	//==========================================================================
	// Determine the required size of the encoded indices
	private static int computeIndexSize( ArrayList<Integer> indices )
	{
		int indexSize = (int) Math.ceil( Math.log( indices.size() + 1 )
				/ Math.log( 2 ) );

		return indexSize;
	}


	//==========================================================================
	// Convert a String representation of an int into a binary string of size 'size'.
	// Used to save space in the encoding process when storing indices.
	private static String stringIntToStringBinary( String s, int size )
	{
		int num = Integer.parseInt( s );
		String binNum = Integer.toBinaryString( num );

		StringBuilder sb = new StringBuilder();
		int paddingNeeded = size - binNum.length();
		for(int i = 0; i < paddingNeeded; i++)
		{
			sb.append( "0" );
		}
		sb.append( binNum );

		String padded = sb.toString();

		//		if( debug )
		//			System.out.println( "stringIntToStringBinary, s: " + s + ", num: "
		//					+ num + ", bin: " + binNum + ", padded: " + padded );

		return padded;
	}


	///////////////////////////////////////////////////////////////////////////
	// Decode /////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////

	//==========================================================================
	// Decode an encoded (compressed) string and return the decoded string.
	public static String decode( String compressed )
	{
		if( debug )
			System.out.println( "******** DECODING ********" );

		if( compressed == null )
		{
			return null;
		}
		if( compressed
				.equals( convertToBinary( "00000000000000000000000000000000" ) ) )
		{
			return "";
		}

		String stringBin = convertToBinary( compressed );

		return decodeString( stringBin );
	}


	//==========================================================================
	// Perform the actual decoding work on the string.
	private static String decodeString( String s )
	{
		ArrayList<Integer> indices = new ArrayList<Integer>();
		ArrayList<String> suffixes = new ArrayList<String>();
		ArrayList<String> words = new ArrayList<String>();

		getIndicesAndSuffixes( s, indices, suffixes );

		createWords( indices, suffixes, words );

		return compressStringList( words );
	}


	//==========================================================================
	// Generate the decoded words by looking up prefixes and adding 
	// corresponding suffixes to them.  Then add each word to a list.
	// The prefix of any given word exists ahead of it in the suffix list.
	private static void createWords( ArrayList<Integer> indices,
			ArrayList<String> suffixes, ArrayList<String> words )
	{
		String nextWord = new String( "" );
		words.add( nextWord );

		for(int i = 0; i < indices.size(); i++)
		{
			int nextInt = indices.get( i );
			String suffix = suffixes.get( i );
			nextWord = new String( words.get( nextInt ) + suffix );
			words.add( nextWord );
		}

		if( debug )
		{
			System.out.println( "Words: " + words.toString() );
		}
	}


	//==========================================================================
	// Parse the codewords from the code string and populate 
	// the two arraylists with the indices and suffixes. 
	private static void getIndicesAndSuffixes( String s,
			ArrayList<Integer> indices, ArrayList<String> suffixes )
	{
		// determine the size of the indices by looking at 1st 32 bits.
		String idx32 = s.substring( 0, 32 );
		int idxSize = Integer.parseInt( idx32, 2 );

		// determine how many full codewords are in the string
		// this rounds to floor.  extra will be handled below.
		int numFullWords = ( s.length() - 32 ) / ( 16 + idxSize );

		if( debug )
		{
			System.out.println( "Decoding:    " + s );
			System.out.println( "idx32: " + idx32 + ", idx32.length: "
					+ idx32.length() + ", idxSize: " + idxSize );
			System.out.println( "chars: " + numFullWords );
		}

		int wordSize = 16 + idxSize;

		// fill the array lists
		for(int i = 0; i < numFullWords; i++)
		{
			int startOfIndex = 32 + ( wordSize * i );
			int startOfSuffix = startOfIndex + idxSize;

			indices.add( Integer.parseInt(
					s.substring( startOfIndex, startOfIndex + idxSize ), 2 ) );
			suffixes.add( convertFromBinary( s.substring( startOfSuffix,
					startOfSuffix + 16 ) ) );
		}

		fixFinalWord( s, indices, suffixes, idxSize, numFullWords, wordSize );

		if( debug )
		{
			System.out.println( "indices: " + indices.toString() );
			System.out.println( "suffixes: " + suffixes.toString() );
		}
	}


	//==========================================================================
	// Ensure the final word is decoded correctly.
	// to do this, find how many bits are left over when the decode string 
	// is modded by 16.  if remainder is 0 or smaller than the size of an
	// index, do nothing.  otherwise, parse an index only, add it to 
	// indices, and add "" to suffixes.
	// Bits remaining - index size == padded zeroes.
	private static void fixFinalWord( String s, ArrayList<Integer> indices,
			ArrayList<String> suffixes, int idxSize, int numFullWords,
			int wordSize )
	{
		int remaining = s.length() - 32 - ( numFullWords * wordSize );
		if( remaining > 0 && remaining >= idxSize )
		{
			int idxOfFinalIdx = 32 + ( numFullWords * wordSize );

			Integer finalIndex = Integer.parseInt(
					s.substring( idxOfFinalIdx, idxOfFinalIdx + idxSize ), 2 );

			if( debug )
				System.out.println( "Remaining: " + remaining
						+ ", idxOfFinalIdx: " + idxOfFinalIdx
						+ ", finalIndex: " + finalIndex );

			indices.add( finalIndex );
			suffixes.add( "" );
		}
	}


	//==========================================================================
	// pack an arraylist of strings into a single string with no spaces
	private static String compressStringList( ArrayList<String> codes )
	{
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < codes.size(); i++)
		{
			sb.append( codes.get( i ) );
		}

		if( debug )
		{
			System.out.println( "compressed string: " + sb.toString() );
		}

		return sb.toString();
	}

	///////////////////////////////////////////////////////////////////////////
	// Node Inner class ///////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////

	//=========================================================================
	// Inner class which represents a node in the trie
	static class Node
	{
		String data;
		ArrayList<Node> children = new ArrayList<Node>();
		Node parent;


		//=====================================================================
		// constructor #1
		Node(String s)
		{
			this( s, null );
		}


		//=====================================================================
		// constructor #2
		Node(String s, Node par)
		{
			data = s;
			parent = par;
		}


		//=====================================================================
		// Method to add a new child to this node.  Returns the child.
		Node addChild( String s )
		{
			Node child = new Node( s, this );
			children.add( child );
			return child;
		}
	}


	///////////////////////////////////////////////////////////////////////////
	// Binary Conversion methods by Donald Nye ////////////////////////////////
	///////////////////////////////////////////////////////////////////////////

	//==========================================================================
	/**
	 * @author Donald Nye
	 */
	public static String convertToBinary( String str )
	{
		final char[] masks =
		{ 0x8000, 0x4000, 0x2000, 0x1000, 0x800, 0x400, 0x200, 0x100, 0x80,
				0x40, 0x20, 0x10, 0x8, 0x4, 0x2, 0x1 };
		StringBuilder sb = new StringBuilder();

		for(int i = 0; i < str.length(); i++)
		{
			char c = str.charAt( i );

			for(int j = 0; j < 16; j++)
				if( ( c & masks[j] ) == 0 )
					sb.append( "0" );
				else
					sb.append( "1" );
		}
		return sb.toString();
	}


	//==========================================================================
	/**
	 * @author Donald Nye
	 */
	public static String convertFromBinary( String str )
	{
		final char[] bits =
		{ 0x8000, 0x4000, 0x2000, 0x1000, 0x800, 0x400, 0x200, 0x100, 0x80,
				0x40, 0x20, 0x10, 0x8, 0x4, 0x2, 0x1 };
		StringBuilder sb = new StringBuilder();

		for(int i = 0; i < str.length(); i += 16)
		{
			char c = 0x0000;

			for(int j = 0; j < 16; j++)
				if( str.charAt( i + j ) == '1' )
					c |= bits[j];

			sb.append( c );
		}
		return sb.toString();
	}

}
