import java.util.ArrayList;

public class LZ {

	/**
	 * Constructor of LZ
	 */
	public LZ() {

	}

	///////////////////////////////////////////////////////////////////
	// Encode Part
	///////////////////////////////////////////////////////////////////

	/**
	 * return encode string 
	 * @param uncompressed- String without compressing
	 * @return compress result
	 */
	public String encode(String uncompressed) {
		ArrayList<trie<Integer>> dictionary = new ArrayList<trie<Integer>>();
		trie<Integer> root =  new trie<Integer>(null, 0);
		boolean istailcomplete = true;
		int nodesnum = 0;
		
		int Index = 1;
		trie<Integer> CurrentNode = root;
		trie<Integer> newNode = null;
		if (uncompressed == "") {
			return SecondByte(0) + "";
		}

		for (int i = 0; i < uncompressed.length(); i++) {
			char nextchar = uncompressed.charAt(i);
			trie<Integer> child = CurrentNode.getchildren(nextchar);
			newNode = new trie<Integer>(nextchar, Index);
			if (child == null || CurrentNode.isLeaf()) {
				AddCode(CurrentNode, newNode,dictionary);
				nodesnum = nodesnum + 1;
				CurrentNode = root;
				Index++;
			} else {
				CurrentNode = child;
				if (i == uncompressed.length() - 1) {
					trie<Integer> newtrie = new trie<Integer>('#',child.getContain());
					dictionary.add(newtrie);
					istailcomplete = false;
					nodesnum = nodesnum + 1;
				}
			}
		}
		return ComposeResult(dictionary,istailcomplete,nodesnum);
	}
	
	

	/**
	 * Add PreIndex and Key with given parent and child
	 * @param parent - parent trie node
	 * @param child - child trie node
	 */
	private void AddCode(trie<Integer> parent, trie<Integer> child,ArrayList<trie<Integer>> dictionary) {
		parent.setChild(child.getKey(), child);
		trie<Integer> newtrie = new trie<Integer>(child.getKey(),parent.getContain());
		dictionary.add(newtrie);
	}
	
	
	
	/**
	 * Compose compressed result with given codeword and keyArrayList
	 * @param dictionary - ArrayList store dictionary composed by tries
	 * @return compressed result string
	 */
	private String ComposeResult(ArrayList<trie<Integer>> dictionary, boolean istailcomplete, int nodesnum) {
		int currentIndex = 0;
		String Result = "";
		int length = decidelength(nodesnum);
		int numberofbits = CalculateBits(length, nodesnum,istailcomplete);
		
		String Mask = GenerateMask(numberofbits - 32);
		
		Result = Result + FirstByte(length) + SecondByte(length);
		
		if (length <= 16) {
			for (int i = 0; i < dictionary.size(); i++) {
				if (i == dictionary.size() - 1 && !istailcomplete) {
					
					int preIndexfull = (int) dictionary.get(i).getContain();
					char Index = SecondByte(preIndexfull);
					String preIndex = addpreIndex(Mask, Index, currentIndex,
							(currentIndex + length - 1));
					Mask = AndFunction(Mask, preIndex);
					break;
					
				} else {
					
					int preIndexfull = (int) dictionary.get(i).getContain();
					char Index = SecondByte(preIndexfull);
					String preIndex = addpreIndex(Mask, Index, currentIndex,
							(currentIndex + length - 1));
					Mask = AndFunction(Mask, preIndex);
					currentIndex = currentIndex + length;
					
					
					char key = dictionary.get(i).getKey();
					String keyStr = addpreIndex(Mask, key, currentIndex,
							(currentIndex + 16 - 1));
					Mask = AndFunction(Mask, keyStr);
					currentIndex = currentIndex + 16;
				}
			}
			Result = Result + Mask;
		} else {
			for (int i = 0; i < dictionary.size(); i++) {
				if (i == dictionary.size() - 1 && !istailcomplete) {
					int preIndexfull = (int) dictionary.get(i).getContain();
					char Index = FirstByte(preIndexfull);
					String preIndex = addpreIndex(Mask, Index, currentIndex,
							(currentIndex + length % 16 - 1));
					Mask = AndFunction(Mask, preIndex);
					currentIndex = currentIndex + length % 16;

					char Index2 = SecondByte(preIndexfull);
					String preIndex2 = addpreIndex(Mask, Index2, currentIndex,
							(currentIndex + 16 - 1));
					Mask = AndFunction(Mask, preIndex2);
					currentIndex = currentIndex + 16;
					break;
					
				} else {
					int preIndexfull = (int) dictionary.get(i).getContain();
					char Index = FirstByte(preIndexfull);
					String preIndex = addpreIndex(Mask, Index, currentIndex,
							(currentIndex + length % 16 - 1));
					Mask = AndFunction(Mask, preIndex);
					currentIndex = currentIndex + length % 16;

					char Index2 = SecondByte(preIndexfull);
					String preIndex2 = addpreIndex(Mask, Index2, currentIndex,
							(currentIndex + 16 - 1));
					Mask = AndFunction(Mask, preIndex2);
					currentIndex = currentIndex + 16;

					char key = dictionary.get(i).getKey();
					String keyStr = addpreIndex(Mask, key, currentIndex,
							(currentIndex + 16 - 1));
					Mask = AndFunction(Mask, keyStr);
					currentIndex = currentIndex + 16;
				}
			}
			Result = Result + Mask;
		}
		return Result;
	}
	
	
	
	/**
	 * return a mask string with given number of char, each char contains "0000000000000000"
	 * @param numOfbits - total number of bits with information
	 * @return the smallest mask can contain those information
	 */
	private String GenerateMask(int numOfbits) {
		int numOfchar = 0;
		String result = "";
		
		if (numOfbits % 16 == 0) {
			numOfchar = numOfbits / 16;
		} else {
			numOfchar = numOfbits / 16 + 1;
		}

		for (int i = 0; i < numOfchar; i++) {
			result = result + (char) ('a' & '0' & '_'); // generate "0000000000000000"
		}
		return result;
	}
	
	

	/**
	 * Add certain char with certain start and stop index to String Mask
	 * @param Mask - Mask with the length equal to compressed string
	 * @param preIndex - the char contain the information we want to added
	 * @param Index_Start - the binary start Index of the information 
	 * @param Index_Stop - the binary end Index of the information
	 * @return String Mask with certain information contained in char
	 */
	private String addpreIndex(String Mask, char preIndex, int Index_Start,
			int Index_Stop) {
		String result = "";
		char replacefirstpart = ' ';
		char replacesecondpart = ' ';
		int length = Index_Stop - Index_Start + 1;
		
		if ((Index_Stop) / 16 == (Index_Start) / 16) {
			int charstartIndex = (Index_Start) % 16;
			replacefirstpart = (char) (preIndex << (16 - length - charstartIndex));
			
			int Index = (Index_Start) / 16;
			String pre_Mask = GenerateMask(Index * 16);
			String after_Mask = GenerateMask((Mask.length() - Index - 1) * 16);
			result = pre_Mask + replacefirstpart + after_Mask;
			return result;
		} else {
			int left = 16 - (Index_Start) % 16;
			int leftr = (Index_Stop - Index_Start + 1) - left;
			int Index1 = (Index_Start) / 16;
			
			String pre_Mask = GenerateMask((Index1) * 16);
			String after_Mask = GenerateMask((Mask.length() - (Index1) - 2) * 16);
			replacefirstpart = (char) (preIndex >> leftr);
			replacesecondpart = (char) (preIndex << (16 - leftr));
			result = pre_Mask + replacefirstpart + replacesecondpart
					+ after_Mask;
			return result;
		}
	}

	/**
	 * Add new information to last version mask
	 * @param mask - last version mask
	 * @param add - mask contain new information
	 * @return updated mask
	 */
	private String AndFunction(String mask, String add) {
		String result = "";
		
		if (mask.length() != add.length()) {
			System.out.println("length doesn't match!");
			return null;
		} else {
			for (int i = 0; i < mask.length(); i++) {
				char newchar = (char) ((mask.charAt(i)) | (add.charAt(i)));// Realize the "And" function on String
				result = result + newchar;
			}
		}
		return result;
	}

	
	
	/**
	 * return the length of a integer
	 * @param a - any integer
	 * @return the length of input integer
	 */
	private int decidelength(int a) {
		int length = 0;
		while (a != 0) {
			a = a / 2;
			length = length + 1;
		}
		return length;
	}

	
	
	/**
	 * return the total information bits of compressed string
	 * @param length - length of preIndex
	 * @param nodesnum_1 - number of nodes contained in compressed 
	 * @return total number of bits with information
	 */
	private int CalculateBits(int length, int nodesnum_1,boolean istailcomplete) {
		int tailbitsnumber = 0;
		if (istailcomplete) {
			tailbitsnumber = 16;
		} else {
			tailbitsnumber = 0;
		}
		int numberOfbits = 32 + (length + 16) * (nodesnum_1 - 1) + length
				+ tailbitsnumber;
		return numberOfbits;
	}
	
	

	/**
	 * return least significant 16 bits of a integer
	 * @param a - any integer
	 * @return least significant 16 bit of a integer
	 */
	private char SecondByte(int a) {
		char y = (char) (a);
		return y;
	}

	
	
	/**
	 * return most significant 16 bits of a integer
	 * @param a - any integer
	 * @return most significant 16 bits of a integer
	 */
	private char FirstByte(int a) {
		char x = (char) (a >> 16);
		return x;
	}




	///////////////////////////////////////////////////////////////////
	//Decode Part
	///////////////////////////////////////////////////////////////////
	/**
	 * return decode string
	 * @param encoderesult - compressed result
	 * @return decode result
	 */
	public String Decode(String encoderesult) {
		ArrayList<trie<Integer>> tree = new ArrayList<trie<Integer>>();
		int currentIndex = 0;
		int preIndexInt = 0;
		int count = 0;
		int codewordlength = recomposeint(encoderesult.charAt(0),
				encoderesult.charAt(1));
		currentIndex = currentIndex + 32;
		
		trie<Integer> newtrie = new trie<Integer>(null,0);
		tree.add(newtrie);
		
		while ((currentIndex / 16) <= encoderesult.length()) {
			String preIndex = getchar(encoderesult, currentIndex, (currentIndex
					+ codewordlength - 1));
			currentIndex = currentIndex + codewordlength;
			if (preIndex.length() == 1) {
				preIndexInt = recomposeint((char) ('a' & '0' & '_'),
						preIndex.charAt(0));
			} else {
				preIndexInt = recomposeint(preIndex.charAt(0),
						preIndex.charAt(1));
			}

	
			if ((currentIndex + 16) > 16 * encoderesult.length()) {
				trie<Integer> newtrie1 = new trie<Integer>(null,preIndexInt);
				tree.add(newtrie1);
				break;
			}
			char key = getchar(encoderesult, currentIndex,
					(currentIndex + 16 - 1)).charAt(0);
			currentIndex = currentIndex + 16;
			count = count +1;
			
			trie<Integer> newtrie1 = new trie<Integer>(key,preIndexInt);
			tree.add(newtrie1);
		}
		
		String resultfinal = "";
		for(int i =1; i<tree.size();i++)
		{
			resultfinal = resultfinal+recomposeelement(tree,tree.get(i));
		}
		
		return resultfinal;
	}
	
	
	
	/**
	 * The full version String of every trie
	 * @param tree - sequence of tries 
	 * @param newtrie - the trie need to be recompose
	 * @return the full version String of the input trie
	 */
	private String recomposeelement(ArrayList<trie<Integer>> tree, trie<Integer> newtrie)
	{
		String result = "";
		trie<Integer> currenttrie = newtrie; 
		if(currenttrie.getKey()!=null)
		{
		result = currenttrie.getKey()+result;
		}
		while(currenttrie.getContain()!=0)
		{
			currenttrie = tree.get(currenttrie.getContain());
			result = currenttrie.getKey()+result;
		}
		return result;
	}
	
	

	/**
	 * return integer composed with given most significant and least significant 16 bits
	 * @param first - least significant 16 bits of the integer
	 * @param last - most significant 16 bits of the integer
	 * @return complete integer
	 */
	private int recomposeint(char first, char last) {
		int result = 0;
		int firstMask = first;
		firstMask = firstMask << 16;
		int lastMask = last;
		result = result | firstMask | lastMask;
		return result;
	}

	
	
	/**
	 * return the information stored between certain start index and stop index
	 * @param input - compressed String 
	 * @param Index_Start - the index that information start
	 * @param Index_Stop - the index that information stop
	 * @return the information stored between start index and stop index
	 */
	private String getchar(String input, int Index_Start, int Index_Stop) {
		String result = "";
		if (Index_Start / 16 == Index_Stop / 16) {
			int length = Index_Stop - Index_Start + 1;
			char charsmall = (char) (input.charAt(Index_Start / 16));
			char charsmall2 = (char) (charsmall << (Index_Start%16));
			char charsmall3 = (char) (charsmall2 >> (16 - length));
			result = result + charsmall3;
		} else {
			if ((Index_Start - Index_Stop + 1) <= 16) {
				int LengthChar1 = 16 - Index_Start % 16;
				int LengthChar2 = Index_Stop % 16 + 1;
				char firstchar = (char) (input.charAt(Index_Start / 16));
				char secondchar = (char) (input.charAt(Index_Stop / 16));
				char char2 = (char) (secondchar >> (16 - LengthChar2));
				char char1 = (char) (firstchar << (16 - LengthChar1));
				char char3 = (char) (char1 >> (16 - LengthChar1));
				char char4 = (char) (char3 << LengthChar2);
				char charnew = (char) (char2 | char4);
				result = result + charnew;
			} else {
				int extra = Index_Start - Index_Stop + 1 - 16;
				int LengthChar1 = 16 - Index_Start % 16;
				int LengthChar2 = Index_Stop % 16 + 1;
				char firstchar = (char) (input.charAt(Index_Start / 16));
				char secondchar = (char) (input.charAt(Index_Stop / 16));
				char char2 = (char) (secondchar >> (16 - LengthChar2));
				char char1 = (char) (firstchar << (16 - LengthChar1));
				char char3 = (char) (char1 >> (16 - LengthChar1));
				char char4 = (char) (char3 << LengthChar2);
				char charnew = (char) (char2 | char4);
				char extranew = (char) (input.charAt(Index_Start / 16));
				char extranew2 = (char) (extranew << (Index_Start%16+1));
				char extranew3 = (char) (extranew2 >> (16-extra));
				result = result + extranew3 + charnew;
			}
		}
		return result;
	}
}
