import java.util.*;  
public class trie<C> {
	
	private C contain;
	private Character key;
	private Map<Character,trie<C>> Children;
	
	public trie(Character key,C contain)
	{
		Children = new HashMap<Character,trie<C>>(1);
		this.contain = contain;
		this.key = key;
	}
	
	public void setChild(Character key, trie<C> obj)
	{
		Children.put(key, obj);
	}
		
	public trie<C> getchildren(Character key)
	{
		return Children.get(key);
	}
	
	public boolean isLeaf()
	{
		return Children.isEmpty();
	}
	
	public void setContain(C contain)
	{
		this.contain = contain;
	}
	
	public C getContain()
	{
		return contain;
	}
	
	public Character getKey()
	{
		return this.key;
	}
}
