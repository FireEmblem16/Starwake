public class LZEncryption
{
	public static String encode(String uncompressed)
	{
		Trie t = new Trie();
		
		int charactersRemaining = uncompressed.length();
		
		while(charactersRemaining > 0)
		{
			int substringLength = 1;
			
			int startIndex = uncompressed.length() - charactersRemaining;
			int endIndex = startIndex + substringLength;
			
			String substring = uncompressed.substring(startIndex, endIndex);
			
			// Find the next substring the trie does not have
			while(t.has(substring) > 0) // While the trie has the substring...
			{
				// ...move on to the next one
				substringLength++;
				endIndex++;
				
				// This is the last part of the string and we already have the remaining characters in the trie
				if(endIndex > uncompressed.length())
				{
					substring += "\0";
					break;
				}
				
				substring = uncompressed.substring(startIndex, endIndex);
			}
			
			// Found a substring the trie doesn't have; add it			
			t.add(substring);
			charactersRemaining -= substring.length();
		}
		
		return t.toBytes();
	}
	
	public static String decode(String compressed)
	{
		StringBuilder decompressed = new StringBuilder();
		
		char[] charArr = compressed.toCharArray();
		
		Trie t = new Trie();
		
		for(int i = 2; i < charArr.length; i++) // Skip the first two chars (4 bytes) since they don't really matter
		{
			int index = (int)charArr[i];
			String s = t.get(index); // Get the phrase referred to by the index
			char followingChar = charArr[++i];
			String sum = s + followingChar;
			t.add(sum); // Add the next phrase, combination of the previous code word's index and the next character
			
			decompressed.append(sum);
		}
		
		// If the last character in the string is null, delete it
		if(decompressed.toString().charAt(decompressed.length() - 1) == '\0')
			decompressed.deleteCharAt(decompressed.length() - 1);
		
		return decompressed.toString();
	}
}
