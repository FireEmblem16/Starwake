public class Node
{
	private String m_Key;
	private int m_Value;

	private Node m_Parent;

	private Node m_NextSibling;
	private Node m_FirstChild;

	public Node(String k, int v)
	{
		if (k == null || k.length() > 1)
			throw new IllegalArgumentException("The key must be exactly one character");

		if (v < 0)
			throw new IllegalArgumentException("The value must be greater than or equal to 0");

		m_Key = k;
		m_Value = v;
	}

	public String key()
	{
		return m_Key;
	}

	public int value()
	{
		return m_Value;
	}

	public Node parent()
	{
		return m_Parent;
	}

	/**
	 * Returns the first child of this node. Other children can be accessed by
	 * calling {@link #nextSibling()} on the returned node.
	 * 
	 * @return The first child of this node, or null if this node has no
	 *         children.
	 */
	public Node firstChild()
	{
		return m_FirstChild;
	}

	/**
	 * @return True if this node has children; false otherwise.
	 */
	public boolean hasChildren()
	{
		return !(this.firstChild() == null);
	}

	/**
	 * @return The next sibling in the chain.
	 */
	public Node nextSibling()
	{
		return m_NextSibling;
	}

	/**
	 * @return False if this node has further siblings; true otherwise.
	 */
	public boolean isLastSibling()
	{
		return (m_NextSibling == null);
	}

	/**
	 * @return The last sibling of this node, or the node itself if it has no
	 *         more siblings
	 */
	public Node lastSibling()
	{
		if (this.isLastSibling())
			return this;

		Node n = this.nextSibling();

		while (!n.isLastSibling())
			n = n.nextSibling();

		return n;
	}

	/**
	 * Add a child to this node.
	 * 
	 * @param n
	 *            The new child of this node
	 */
	public void addChild(Node n)
	{
		n.m_Parent = this;

		if (!this.hasChildren())
			m_FirstChild = n;
		else
			this.firstChild().addSibling(n);
	}

	/**
	 * Add a sibling node to the end of the chain.
	 * 
	 * @param n
	 *            The new sibling of this node
	 */
	public void addSibling(Node n)
	{
		if (this.isLastSibling())
			m_NextSibling = n;
		else
			this.lastSibling().addSibling(n);
	}

	/**
	 * Turns this node into the char representation of itself: an
	 * index/character pair consisting of the preceding phrase's index and the
	 * following character (i.e., the index of the parent node and this node's
	 * character). <br />
	 * For example, calling this method on the node representing the base string
	 * plus the letter 'a' would return the char array [0x0000, 'a'].
	 * 
	 * @return A two-element array of Java char values representing this node as
	 *         an LZ codeword.
	 */
	public char[] toChars()
	{
		char[] chars = new char[2];

		if (this.value() == 0)
		{
			chars[0] = 0;
			chars[1] = 0;
		}
		else
		{
			chars[0] = (char) (this.parent().value() & 0x0000ffff); // tough
																	// luck if
																	// there are
																	// > 65535
																	// codewords
			chars[1] = this.key().charAt(0);
		}

		return chars;
	}

	@Override
	public boolean equals(Object other)
	{
		if (this == other)
			return true;

		if (other instanceof Node)
		{
			Node otherNode = (Node) other;
			return (this.key().equals(otherNode.key()) && (this.value() == otherNode.value()));
		}
		else
		{
			return false;
		}
	}

	@Override
	public String toString()
	{
		return "" + this.value() + ": " + this.key();
	}

}