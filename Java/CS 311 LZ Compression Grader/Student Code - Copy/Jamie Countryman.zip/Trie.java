import java.util.ArrayList;

// Trie design inspired by https://www.cs.bu.edu/teaching/c/tree/trie/
public class Trie
{
	private Node m_Root;
	
	private ArrayList<Node> m_Nodes;
	
	private int m_NextIndex;
	
	public Trie()
	{
		m_NextIndex = 0;
		m_Nodes = new ArrayList<Node>();
		
		m_Root = new Node("", nextIndex());
		m_Nodes.add(m_Root);
	}
	
	/**
	 * Add a string to the trie.
	 * @param s The string to be added
	 */
	public void add(String s)
	{
		int substringLength = 0;
		int index = 0;
		
		while(substringLength < s.length())
		{
			// Search the trie for substrings of decreasing size
			index = this.has(s.substring(0, s.length() - substringLength));
			if(index < 0) // Substring not found, try a smaller one
				substringLength++; // Also represents the number of characters missing from the trie
			else // Substring found; we can add the rest of the string as children of the node @ index
				break;
		}
		
		Node node;
		char[] substring;
		
		if(index < 0) // The string is entirely new to this trie
		{
			node = m_Root;
			substring = s.toCharArray();
		}
		else
		{
			node = m_Nodes.get(index);
			substring = s.substring(s.length() - substringLength).toCharArray();
		}
			
		// Add each character as a child of the previous
		for (char c : substring)
		{
			Node n = new Node("" + c, nextIndex());
			node.addChild(n);
			
			m_Nodes.add(n);
			
			node = n;
		}
	}
	
	private int nextIndex()
	{
		return m_NextIndex++;
	}
	
	/**
	 * Returns the string corresponding to a given index.
	 * @param index The index for the desired phrase
	 * @return The phrase corresponding to the given index
	 */
	public String get(int index)
	{		
		StringBuilder sb = new StringBuilder();
		
		Node n = m_Nodes.get(index);
		
		while(n != null)
		{
			sb.append(n.key());
			n = n.parent();
		}
		
		sb.reverse();
		return sb.toString();
	}
	
	/**
	 * Check to see if the trie contains a string.
	 * @param phrase The string in question
	 * @return The index of the given phrase, or -1 if the phrase was not found
	 */
	public int has(String phrase)
	{
		if(phrase.isEmpty())
			return 0;
		
		if(!m_Root.hasChildren())
			return -1;
		
		Node currentNode = m_Root.firstChild();
		
		int foundChars = 0;
		while(currentNode != null)
		{
			char c = phrase.charAt(foundChars);
			
			if(currentNode.key().equals("" + c)) // Found a node with the character c
			{
				foundChars++;
				
				if(foundChars == phrase.length()) // If we found it already, don't keep searching
				{
					break;
				}
				else if(currentNode.hasChildren())
				{
					currentNode = currentNode.firstChild(); // We found the character
					continue; // Move on to the next character with the child of the found node
				}
				else
				{
					break; // Node has no children, so we're either done or the substring isn't here
				}
			}
			else // It wasn't that node
			{
				if(!currentNode.isLastSibling()) // Check the node's next sibling
					currentNode = currentNode.nextSibling();
				else
					break; // Node has no more siblings, so the substring must not be here
			}
		}
		
		if(foundChars == phrase.length()) // Found all the characters we were looking for
			return currentNode.value();
		else
			return -1;
	}
	
	/**
	 * @return The number of nodes in this trie
	 */
	public int nodeCount()
	{
		return m_Nodes.size();
	}
	
	/**
	 * Collapse this trie into its LZ-compressed form.
	 * @return A string consisting of the characters that represent the LZ-compressed string
	 */
	public String toBytes()
	{
		int codewordSize = (int)Math.ceil(Math.log(nodeCount() + 1) / Math.log(2));
		
		StringBuilder result = new StringBuilder();
		result.append(intToChars(codewordSize));
		
		for(Node n : m_Nodes)
		{
			// Don't encode the base string...
			if(n.value() == 0)
				continue;
			
			result.append(n.toChars());
		}
		
		return result.toString();
	}
	
	/**
	 * Convert an int to an array of 2 chars (based on http://stackoverflow.com/questions/1936857/convert-integer-into-byte-array-java).
	 * @param i
	 * @return Big-endian char representation of the integer
	 */
	public static char[] intToChars(int i)
	{
		char[] chars = new char[2]; // Java int is 32 bits, char is 16 bits
		
		chars[0] = (char) (i >> 16);
		chars[1] = (char) (i & 0x0000ffff);
		
		return chars;
	}
}