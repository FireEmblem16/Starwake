import java.util.List;
import java.util.ArrayList;

import javax.jws.soap.SOAPBinding;


/**
 * @author Forrest Scott
 *
 *
 * LZEncrytion supports LZ encoding and decoding of Strings
 * 
 * Note: LZEncryption always builds a Trie regardless of encoding or decoding. 
 * The Trie then is capable of outputing its own encoded or decoded form.
 *
 *
 *
 */
public class LZEncryption {

	//non-instantiable
	private LZEncryption(){}
	
	/**
	 * encode turns a regular UTF-16 string and encodes it to a UTF-16 string
	 * @param uncompressed
	 * @return encodedString
	 */
	public static String encode(String uncompressed){
		//return encoded output.
		return buildTrieFromUncompressed(uncompressed).getEncodedString();
	}
	
	/**
	 * encodeHumanReadable turns a regular UTF-16 string and encodes it, but returns the encode as a human readable
	 * String (useful for debugging).
	 * @param uncompressed
	 * @return encodedHumanString
	 */
	public static String encodeHumanReadable(String uncompressed){
		//return encoded output in human readable form.
		return buildTrieFromUncompressed(uncompressed).getEncodedStringHumanReadable();
		
	}
	
	
	/**
	 * decode turns a encoded UTF-16 and returns a decoded regular string. 
	 * @param compressed
	 * @return decodedString
	 */
	public static String decode(String compressed){

		return buildTrieFromCompressed(compressed).getDecodedString();
	}
	
	
	/**
	 * buildTrieFromUncompressed builds the custom Trie tree from an uncompressed string
	 * @param uncompressed
	 * @return Trie
	 */
	private static Trie buildTrieFromUncompressed(String uncompressed){
		
		//initialize loop variables.		
		Trie 			encodeTree = new Trie();
		TrieNode		lastKnownNode = encodeTree.getRoot();
		TrieNode 		nextNode;		
		char 			currentCharacter;
		
		
		
		
		//Build Trie from the uncompressed string
		for (int i = 0; i < uncompressed.length(); i++){
			currentCharacter = uncompressed.charAt(i);
			//continue down the Trie by finding the child
			nextNode = lastKnownNode.getChildByValue(currentCharacter);
			if(nextNode == null) {
				//if the child doesn't exist, add to the Trie and reset
				encodeTree.generateNode(lastKnownNode, currentCharacter);
				lastKnownNode = encodeTree.getRoot();
			} else {
				//if the child does exist, continue on building the phrase.
				lastKnownNode = nextNode;
			}
		}
		
		//if the last node wasn't reset, it is a tail node
		if (lastKnownNode.getIndex() > 0)
		{
			encodeTree.setTailNode(lastKnownNode.getIndex());
		}
		
		return encodeTree;
	}
	
	
	
	/**
	 * buildTrieFromCompressed builds the custom Trie tree from a compressed String
	 * @param args
	 * @return Trie
	 */
	private static Trie buildTrieFromCompressed(String compressed){
		
		//expand the string to bits, because its easier to process.
		String binaryComp = ToBinary(compressed);
		
		//read the index bit length
		int indexLength = Integer.parseInt(binaryComp.substring(0, 32), 2);
		
		//loop variables
		Trie	decodeTree = new Trie();
		int		currentIndex = 0;

		
		//build trie
		//alread processed the index bits, skip them.
		int i = 32;
		while (i+indexLength < binaryComp.length()){
			//read the index value
			currentIndex = Integer.parseInt(binaryComp.substring(i, i+indexLength), 2);
			i+=indexLength;
			
			//read the phrase character and append a node
			if (i+Trie.UNICODE_LENGTH <= binaryComp.length())
			{
				decodeTree.generateNode(decodeTree.getNodeByIndex(currentIndex),
						Character.toChars(Integer.parseInt(binaryComp.substring(i, i+Trie.UNICODE_LENGTH),2))[0]);
			} else {
				//if there isn't a phrase character, record the tail node. 
				decodeTree.setTailNode(currentIndex);
			}
			i+=Trie.UNICODE_LENGTH;
		}
		return decodeTree;
	}
	
	/**
	 * PROVIDED BY THE TA 
	 * expands a String to its binary value
	 * @param str
	 * @return
	 */
	public static String ToBinary(String str)
	{
		final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i++)
		{
			char c = str.charAt(i);
			
			for(int j = 0;j < 16;j++)
				if((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}
		
		return ret;
	}	

	/**
	 * PROVIDED BY THE TA 
	 * condenses a binary string to a UTF-16 regular String 
	 * @param str
	 * @return
	 */
	public static String FromBinary(String str)
	{
		final char[] bits = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i += 16)
		{
			char c = 0x0000;
			
			for(int j = 0;j < 16;j++)
				if(str.charAt(i + j) == '1')
					c |= bits[j];
			
			ret += c;
		}
		
		return ret;
	}
	
}
