
public class main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//Test Code
		String[] testStrings = {"aabaaabaaaaaabababbbbaba",
								"0a1b1a2a3a3b4b0b8b4",
								"The world is full of sugar!!!!!!!!!!!",
								"Do not meddle in the affairs of wizards, for they are subtle and quick to anger",
								"",
								"a",
								"aaa",
		};
		
		for(String ts : testStrings){
			System.out.print("orgnal: " + ts + "\nencode:" + LZEncryption.encode(ts) + "\nHumnRd: " + LZEncryption.encodeHumanReadable(ts) + "\ndecode: " + LZEncryption.decode(LZEncryption.encode(ts))+"\n\n");
			
		}
	}
		
}
