import java.util.List;
import java.util.ArrayList;


/**
 * TrieNode represents a node in the custom Trie Tree
 * @author Forrest Scott
 *
 */
public class TrieNode {

	private List<TrieNode> children;
	private TrieNode parent;
	private char value;
	private int index;
	
	public TrieNode(int newIndex,char newCharacterV,TrieNode newParent){
		children = new ArrayList<TrieNode>();
		index = newIndex;
		value = newCharacterV;
		parent = newParent;
	}
	
	
	/**
	 * getChildByValue will return a child Node that matches the given value.
	 * If no child exists, return null.
	 * @param searchCharacter
	 * @return null or newNode
	 */
	public TrieNode getChildByValue(char searchCharacter)
	{
		for(TrieNode child : children){
			if(child.getValue() == searchCharacter)
				return child;
		}
		return null;
	}

	
	public char getValue(){
		return value;
	}
	
	public int getIndex(){
		return index;
	}
	
	public TrieNode getParent(){
		if (parent == null) return this;
		return parent;
	}
	
	public void addChild(TrieNode newChild)
	{
		children.add(newChild);
	}
	
	public String getDecodedString()
	{
		if (value == '\0') return "";
		return "" + parent.getDecodedString() + value;
	}
	
}
