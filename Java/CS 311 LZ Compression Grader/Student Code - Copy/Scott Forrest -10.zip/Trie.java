import java.util.List;
import java.util.ArrayList;

import javax.jws.soap.SOAPBinding;
import javax.swing.plaf.synth.SynthOptionPaneUI;

/**
 * Trie Node Tree for encoding/decoding
 * @author Forest Scott
 *
 */
public class Trie {

	/**
	 * Static variable denoting that this Trie is set to support UTF-16 strings
	 */
	static public int UNICODE_LENGTH = 16;
	
	
	/**
	 * Root Node 
	 */
	private TrieNode root;
	
	
	/**
	 * the next Index for a new node (starts at 1)
	 */
	private int nextIndex;
	
	/**
	 * The List that contains all of the nodes 
	 */
	private List<TrieNode> indexLookUpList;
	
	
	/**
	 * If the tailIndex is set, then the last phrase is a repeat of
	 * a previous node. (tail node)
	 */
	private int tailIndex;
	
	
	/**
	 * constructor, set defaults. 
	 */
	public Trie() {
		super();
		root = new TrieNode(0,'\0',null);
		nextIndex = 1;
		tailIndex = 0;
		indexLookUpList = new ArrayList<TrieNode>();
		indexLookUpList.add(root);
	}

	
	/*** GETTERS/SETTERS *****/
	public TrieNode getRoot() {
		return root;
	}
	
	
	public void setTailNode(int newTail){
		tailIndex = newTail;
	}
	
	public TrieNode getNodeByIndex(int index){
		return indexLookUpList.get(index);
	}
	
	
	
	/**
	 * generateNode constructs a new node, links,
	 * and handles appending it to the master list.
	 * @param parent
	 * @param value
	 * @return newTrieNode
	 */
	public TrieNode generateNode(TrieNode parent, char value){
		TrieNode newNode = new TrieNode(nextIndex++,value,parent);
		parent.addChild(newNode);
		indexLookUpList.add(newNode);
		return newNode;
		
	}
	

	
	
	
	/**
	 * getEncodedString returns the encoded string of this Trie
	 * @return encodedString
	 */
	public String getEncodedString() {

		//Trie is built, decode the order into a string
		String bitResult = "";
		String encodeResult = "";
		
		//check for empty Tree
		if (nextIndex<2){
			return LZEncryption.FromBinary("00000000000000000000000000000000");
		}
		
		int numOfBits =  (int) Math.ceil(Math.log(nextIndex) / Math.log(2));
		
		bitResult = String.format("%32s", Integer.toBinaryString(numOfBits)).replace(' ', '0');

		//loop through all but the last node
		for(TrieNode node : indexLookUpList){
			if (node.getIndex() > 0)
			{

				bitResult += String.format("%" + numOfBits +"s",Integer.toBinaryString(node.getParent().getIndex())).replace(' ', '0');
				bitResult += LZEncryption.ToBinary("" + node.getValue());
			}
		}
		
		//format last node
		if(tailIndex > 0){
			bitResult += String.format("%" + numOfBits +"s",Integer.toBinaryString(indexLookUpList.get(tailIndex).getIndex())).replace(' ', '0');
		}
		
		//pad zeros
		int extraPadding = UNICODE_LENGTH - bitResult.length() % UNICODE_LENGTH;
		if (extraPadding == UNICODE_LENGTH) extraPadding = 0;
		for (int i = 0; i<extraPadding;i++){
			bitResult += "0";
		}

		//output
		encodeResult = LZEncryption.FromBinary(bitResult);
		return encodeResult;
		
	}
	
	
	/**
	 * getEncodedStringHumanReadable returns a human readable representation of the
	 * encoded string of this Trie
	 * @return String
	 */
	public String getEncodedStringHumanReadable() {

		
		//check for empty Tree
		if (nextIndex<2){
			return "0";
		}
		
		//Trie is built, decode the order into a string
		int numOfBits =  (int) Math.ceil(Math.log(nextIndex) / Math.log(2));
		String encodedResult = "" + numOfBits + " ";
		//loop through all but the last node
		for(TrieNode node : indexLookUpList){
			if (node.getIndex() > 0)
			{
				encodedResult += "" + node.getParent().getIndex() + ":" + node.getValue() + " ";
			}
		}
		
		//format last node
		if(tailIndex > 0){
			encodedResult += "" + indexLookUpList.get(tailIndex).getIndex();
		}

		//output
		return encodedResult;
		
	}
	
	
	
	
	/**
	 * getDecodedStrings returns the regular decoded String of this Trie
	 * @return decodedString
	 */
	public String getDecodedString(){
		String	 decodeResult = "";		
		
		for(TrieNode node : indexLookUpList){
			if (node.getIndex() > 0)
				decodeResult += node.getDecodedString();
		}
		if(tailIndex > 0){
			decodeResult += indexLookUpList.get(tailIndex).getDecodedString();
		}

		return decodeResult;
	}
	


	

	
}

