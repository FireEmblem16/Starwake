import java.io.UnsupportedEncodingException;
import java.util.ArrayList;


public class LZ {
	public static String encode(String uncompressed)
	{
		TrieTree tree = new TrieTree();
		StringBuilder output = new StringBuilder();
		   int i=0; int j=1;
	          while(j <=uncompressed.length())
	          {
	          	String line = uncompressed.substring(i,j);
	          	if(!tree.searchTree(tree.root, line))
	          	{
	          		tree.insertNode(tree.root,line);
	          		i=j;
	          	}
	          	j++;
	          }
	          for(int k=0; k < paddedzero(digits(tree.size),32);k++)
	          {
	        	  output.append('0');
	          }
	          if(tree.size != 1)
	          {
	          output.append(Integer.toString(digits(tree.size),2));
	          } else output.append(0);
	          for(int  k =1; k < tree.size; k++)
	          {
	        	TrieNode n =  tree.findIndex(tree.root, k);
		          output.append(StringToBin(Character.toChars(n.parent.index)[0],digits(tree.size)));
		          output.append(StringToBin(n.key,16));
	          }
	          while(output.length() % 16 != 0)
	          {
	        	 output.append('0');
	          }
		return output.toString();
	}
	public static String decode(String compressed)
	{
		int start =0;
		TrieTree tree = new TrieTree();
		String s = compressed;
		ArrayList<Integer> prefix = new ArrayList<Integer>();
		ArrayList<Character> key = new ArrayList<Character>();
		int codeIndex = Integer.parseInt(compressed.substring(start,32),2);
		s = s.substring(32);
		while(s.length()> codeIndex + 16)
		{
			
				prefix.add(Integer.parseInt(s.substring(start,codeIndex),2));
				s = s.substring(codeIndex);
				String frst = s.substring(start, 8);
				s = s.substring(8);
				String billy = s.substring(start, start+8);
				s = s.substring(8);
				int ch = Integer.parseInt(billy,2);
				
				key.add((char)ch);
		}
		String list = "";
		System.out.println(prefix.size() + " " +key.size());
		for(int i =0; i < prefix.size() && i < key.size(); i++)
		{
				tree.insertNode(tree.root,key.get(i),prefix.get(i));
		}
		for(int i =0; i < prefix.size() && i < key.size(); i++)
		{
				list+= tree.findWord(tree.root, prefix.get(i), key.get(i));
		}
		
		return list;
	}
	private static String StringToBin(char ch,int size)
	{
	
		
		StringBuilder bin = new StringBuilder();
				for(int i=0; i <= paddedzero(ch,32);i++)
				{
					bin.insert(0,'0');
				}
				bin.append(Integer.toString(ch,2));
				return bin.substring(bin.length()- size);
	}
	private static int paddedzero(int index,int size) {
		if (index == 1)
		{
			return size - 1;
		}
		else if(index == 0)
		{
			return size - 1;
		}
		return  Integer.numberOfLeadingZeros(index - 1) -(32-size);
	}
	private static int digits(int index)
	{
		if(index ==1)
		{
			return 1;
		}
		return 32 -Integer.numberOfLeadingZeros(index -1);
	}
}
