import java.util.ArrayList;


public class TrieNode 
{
	char key;
	int index;
	TrieNode parent;
	ArrayList<TrieNode> children;
	
	public TrieNode(TrieNode parent,char key,int prefix)
	{
		this.parent = parent;
		children = new ArrayList<TrieNode>();
		this.key = key;
		this.index = prefix;
	}

	public String printNode() {
		return "" + parent.index + "" + key;
	}
}
