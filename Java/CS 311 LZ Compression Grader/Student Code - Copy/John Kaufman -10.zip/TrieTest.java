
public class TrieTest {

	
	public static int paddedzero(int index) {
		if (index == 1)
			return 15;
		return  Integer.numberOfLeadingZeros(index - 1) -16;
	}
	
	public static void main(String[] args) 
	{
TrieTree tree = new TrieTree();
      
        
        
        String s = "The world is full of sugar!";//, "aab", "abab", "b", "bb", "aba"};
        // tree.insertNode(tree.root,""+s.charAt(0));
         int i=0; int j=1;
          while(j <=s.length())
          {
          	String billy = s.substring(i,j);
          	if(!tree.searchTree(tree.root, billy))
          	{
          	tree.insertNode(tree.root,billy);
          	i=j;
          	}
          	j++;
          }
        if(tree.searchTree(tree.root,"l"))
        {
        	System.out.println("true");
        }
        else System.out.println("false");
        System.out.println(tree.printTree(tree.root));
      System.out.println(  Integer.toString(13,2));
      System.out.println(Integer.numberOfLeadingZeros(13) -(32-(32 -Integer.numberOfLeadingZeros(tree.size -1))));
     System.out.println( LZ.encode(""));
     System.out.println(LZ.decode(LZ.encode("")));
	}

}
