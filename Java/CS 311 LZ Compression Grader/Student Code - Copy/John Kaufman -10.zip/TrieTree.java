
public class TrieTree 
{
	TrieNode root;
	int size;
	
	public TrieTree()
	{
		root = new TrieNode(null,'\0',0);
		size = 1;
	}
	public void insertNode(TrieNode node, char key, int prefix)
	{
		if(size == 1)
		{
			node.children.add(new TrieNode(node, key,size));
			size++;
			return;
		}
		else if(node.index == prefix)
		{
			node.children.add(new TrieNode(node,key,size));
			size++;
			return;
		}
		else
		{
			for(int i =0; i < node.children.size(); i++)
			{
				if(root.children.get(i).index == prefix)
				{
					insertNode(node.children.get(i),key,prefix);
				}
			}
			return;
		}
	}
	public void insertNode(TrieNode root,String keys)
	{

		if(size == 1)
		{
			root.children.add(new TrieNode(root,keys.charAt(0),size));
			size++;
			return;
		}
		else if(keys.length() == 1)
		{
			root.children.add(new TrieNode(root,keys.charAt(0),size));
			size++;
			return;
		}
		else
		{
			for(int i =0; i < root.children.size(); i++)
			{
				if(root.children.get(i).key == keys.charAt(0))
				{
					insertNode(root.children.get(i),keys.substring(1));
				}
			}
			return;
		}
		
	}
	public boolean searchTree(TrieNode root, String keys)
	{
		TrieNode current = root;
		boolean flag = false;
		if(current.index == 0)
		{
			for(int i = 0; i < current.children.size();i++)
			{
				flag = flag || searchTree(current.children.get(i),keys);
			}
		}
		else if(keys.length() == 1 && current.key == keys.charAt(0))
		{
			return true;
		}
		
		else if(keys.length() > 1)
		{
			for(int i=0; i < root.children.size();i++)
			{
				if(current.key == keys.charAt(0))
				{
					flag = flag || searchTree(current.children.get(i),keys.substring(1));
				}
			}
		}
		return flag;
	}
	public String findWord(TrieNode root,int index, char key)
	{
		StringBuilder word = new StringBuilder();
		word.append(key);
		TrieNode n = findIndex(root,index);
		if(n == null)
		{
			return ""+ key;
		}
		while(n.parent  != null)
		{
			word.insert(0, n.key);
			n = n.parent;
			
		}
		
		return word.toString();
	}
	public TrieNode findIndex(TrieNode root,int index)
	{
		
		
			
			if(root.index == index)
			{
				return root;
			}
			TrieNode found = null;
				for(int i =0; found == null &&i < root.children.size(); i++)
				{
					  found = findIndex(root.children.get(i),index);
				}
			return found;
		}
	
	
	public String printTree(TrieNode root)
	{
		String print ="";
				for(int i=1; i < size; i++)
				{
					print += findIndex(root,i).printNode();
					print += " ";
				}
				return print;
	}

	private boolean isLeaf(TrieNode root)
	{
			return root.children.size() == 0;
	}
	
	
}
