
import java.util.ArrayList;

/**
 * 
 * @author zehua
 *
 */
public class LZ {
	private LZ(){}
	
	public static String encode(String input){
		Trie t = new Trie();
		String encoded = t.encode(input);
		int size = encoded.length();
		int mod = size % 16;
		if (mod != 0 || size == 0){
			for (int i = mod; i < 16; i++) {
				encoded += "0";
			}
		}
		return encoded;
	}
	
	public static String decode(String input){
		Trie t = new Trie();
		String decoded = t.decode(input);
		return decoded;
	}

}

class TrieNode{
	private ArrayList<TrieNode> children;
	private String codeword;
	private int index;
	public TrieNode(String codeword, int index){
		this.codeword = codeword;
		this.index = index;
		children = new ArrayList<TrieNode>();
	}
	public int addChild(TrieNode child){
		children.add(child);
		return this.index;
	}
	public void clean(){
		children = new ArrayList<TrieNode>();
	}
	public int getIndex(){
		return this.index;
	}
	
	public TrieNode getChild(String word){
		for (TrieNode tn : children) {
			if (tn.getWord().equals(word)) {
				return tn;
			}
		}
		return this;
	}
	@Override
	public String toString(){
		return codeword;
	}
	@Override
	public boolean equals(Object obj){
		if (!(obj instanceof TrieNode)) return false;
		if (this == obj) return true;
		
		TrieNode other = (TrieNode)obj;
		return this.codeword.equals(other.codeword);
	}
	public String getWord(){
		return codeword;
	}
	public boolean contains(String word){
		for (TrieNode child : children) {
			if (child.getWord().equals(word)) {
				return true;
			}
		}
		return false;
	}
	public String find(int ind){
		if(this.index == ind) return this.codeword;
		for (TrieNode child : children) {
			String code = child.find(ind);
			if (!code.equals("")) {
				return code;
			}
		}
		return "";
	}
}

class Trie{
	private TrieNode root;
	private int index;
	public Trie(){
		index = 0;
		root = new TrieNode("", index++);
		fronts = new ArrayList<Integer>();
		ends = new ArrayList<String>();
	}
	private ArrayList<Integer> fronts;
	private ArrayList<String> ends;
	public String encode(String words){
		root.clean();
		index = 1;
		fronts.clear();
		ends.clear();
		int start = 0;
		int len = 0;
		while(start < words.length()){
			start += len;
			len = 1;
			while(start + len <= words.length()){
				String sub = words.substring(start, start + len);
				if (!this.contains(sub)) {
					addWord(sub);
					break;
				}
				len++;
			}
			if (start + len > words.length()) {
				if (start < words.length()){
					String word = words.substring(start);
					TrieNode current = root;
					for (int i = 0; i <= word.length(); i++) {
						String sub = word.substring(0, i);
						current = current.getChild(sub);
					}
					fronts.add(current.getIndex());
					ends.add("0000000000000000");
				}
				break;
			}
			
		}
		int bits = (int)Math.ceil(Math.log(index) / Math.log(2));
		String result = toBinString(bits, 32);
		for (int i = 0; i < fronts.size(); i++) {
			result += toBinString(fronts.get(i), bits);
			result += ends.get(i);
		}
		return result;
		
	}
	
	public String decode(String code){
		String bits = code.substring(0, 32);
		int bit = Integer.parseInt(bits, 2);
		root.clean();
		index = 1;
		int start = 32;
		String text = "";
		while(bit + 16 + start <= code.length()){
			String front = code.substring(start, start + bit);
			start += bit;
			String end = code.substring(start, start + 16);
			start += 16;
			int ind = Integer.parseInt(front, 2);
			String p = root.find(ind);
			char c = (char) Integer.parseInt(end, 2);
			p = p + c;
			addWord(p);
			text += p;
		}
		return text;
	}
	private void addWord(String word){
		TrieNode current = root;
		for (int i = 0; i < word.length(); i++) {
			String sub = word.substring(0, i);
			current = current.getChild(sub);
		}
		fronts.add(current.addChild(new TrieNode(word, index++)));
		ends.add(toBinString((int) word.charAt(word.length() - 1), 16));
		
	}
	
	private boolean contains(String word){
		TrieNode current = root;
		for (int i = 0; i < word.length(); i++) {
			String sub = word.substring(0, i);
			if(current.contains(sub))
				current = current.getChild(sub);
		}
		return current.contains(word);
		
	}
	
	private String toBinString(int x, int len){
		String bin = Integer.toBinaryString(x);
		String result = "";
		for (int i = 0; i < len-bin.length(); i++) {
			result+= "0";
		}
		return result + bin;
	}
}



