


/**
 * a Node that will be inside a Trie
 * @author Daniel McDonough
 *
 */
public class Node {

	private String stringData;
	private int pos;
	private Node parent;
	private Node left;
	private Node right;
	
	//create a node with null left and right
	public Node(String stringData, int pos)
	{
		this.stringData = stringData;
		this.pos = pos;
		left = null;
		right = null;
	}
	
	//create a node that has a reference to the given Node as its parent
	public Node(String stringData, int pos, Node parent)
	{
		this.stringData = stringData;
		this.pos = pos;
		left = null;
		right = null;
		this.parent = parent;
	}
	
	public String getStringData()
	{
		return stringData;
	}
	
	public int getPos()
	{
		return pos;
	}
	
	public Node getParent()
	{
		return parent;
	}
	
	public void setLeft(Node left)
	{
		this.left = left;
	}
	
	public void setRight(Node right)
	{
		this.right = right;
	}
	
	public Node getRight()
	{
		return right;
	}
	
	public Node getLeft()
	{
		return left;
	}
	
	
}
