

//I consulted http://oldwww.rasip.fer.hr/research/compress/algorithms/fund/lz/lz78.html

import java.util.Scanner;


public class LZ {
	
	

	private LZ()
	{
	}
	
	public static String encode(String uncompressed)
	{
		
		Trie t = new Trie();
		String P = "";
		char c;
		int i = 0;
		String code = "";
		if(uncompressed.equals(""))
		{
			return "00000000000000000000000000000000";
		}
		c = uncompressed.charAt(i);
		t.add("" + c);
		i++;
		code += "0" + "zx" + c;
		
		while(i < uncompressed.length())
		{
			c = uncompressed.charAt(i);
			if(t.contains(P + c))
			{
				P += c;
				i++;
			}
			else
			{
				t.add(P + c);
				if(P.equals(""))
				{
					code += "zx" + "0" + "zx" + c;
				}
				else
				{
					Node x = t.nodeContaining(P);
					code += "zx" + x.getPos() + "zx" + c;
				}
				i++;
				P = "";
			}
		}
		if(P.length() > 0)
		{
			int x = t.nodeContaining(P).getPos();
			code += "zx" + x;
		}
		return codeToBinary(code, t);
		
	}
	
	private static String codeToBinary(String code, Trie t)
	{
		String result = "";
		//calculate log base 2 of size of Trie
		Integer codeSize = (int)Math.ceil(Math.log(t.getSize()  + 1) / Math.log(2));
		//add binary string to result
		result += Integer.toBinaryString(codeSize);
		//pad with 0s so that binary codesize is 32 bits
		for(int i = result.length(); i < 32; i++)
		{
			result = "0" + result;
		}
		
		Scanner s = new Scanner(code);
		s.useDelimiter("zx");
		//while scanner has more inputs
		while(s.hasNext())
		{
			//if next input is an int
			if(s.hasNextInt())
			{
				int x = s.nextInt();
				String temp = Integer.toBinaryString(x);
				for(int i = temp.length(); i < codeSize; i++)
				{
					temp = "0" + temp;
				}
				result = result + temp;
			}
			//if next input is a char
			else
			{
				//read char
				String temp = s.next();
				//cast into char
				Character c = temp.charAt(0);
				//convert to binary
				int x = (int)c.charValue();
				String binary = Integer.toBinaryString(x);
				//extend to 16 bits
				for(int i = binary.length(); i < 16; i++)
				{
					binary = "0" + binary;
				}
				result = result + binary;
			}
		}
		//pad with 0s if not a multiple of 16
		while(result.length() % 16 != 0)
		{
			result = result + "0";
		}
		
		return result;
	}
	
	public static String decode(String compressed)
	{
		Trie t = new Trie();
		String result = "";
		if(compressed.equals(""))
			return "";
		int codeword = Integer.parseInt(compressed.substring(0, 32),2);
		int i = 32;
		String W;
		
		while(i + codeword + 16 <= compressed.length())
		{
			//first get the bits representing the codeword
			String codeNum = compressed.substring(i, i + codeword);
			i += codeword;
			//turn into int
			int code = Integer.parseInt(codeNum, 2);
			W ="";
			//add code to result
			if(code != 0)
			{
				String z = t.getWord(code);
				result += z;
				W = z;
			}
			//interpret the next 16 bits as a char
			String charact = compressed.substring(i, i + 16);
			i += 16;
			String temp = FromBinary(charact);
			char toAdd = temp.charAt(0);
			result += toAdd;
			t.add(W + toAdd);
		}
		//if there are bits left, they are either padding 0s or a codeword
		String remaining = compressed.substring(i, i + codeword);
		//interpret it as an int
		int code = Integer.parseInt(remaining);
		if(code != 0)
		{
			result += t.getWord(code);
		}
		
		return result;
	}
	
	private static String FromBinary(String str)
	{
		final char[] bits = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i += 16)
		{
			char c = 0x0000;
			
			for(int j = 0;j < 16;j++)
				if(str.charAt(i + j) == '1')
					c |= bits[j];
			
			ret += c;
		}
		
		return ret;
	}
		
	
}
