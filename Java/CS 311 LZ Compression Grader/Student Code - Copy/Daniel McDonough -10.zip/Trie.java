

/**
 * Trie data structure
 * @author Daniel McDonough
 *
 */

public class Trie {
	private Node root;
	private int pos;
	private String word;
	
	public Trie()
	{
		root = null;
		pos = 0;
	}
	
	
	public Node getRoot()
	{
		return root;
	}
	
	public boolean isEmpty()
	{
		return(root == null);
	}
	
	public int getSize()
	{
		return pos;
	}
	
	public boolean contains(String str)
	{
		int i = 0;
		Node x = root;
		String data = x.getStringData();
		while(i < str.length())
		{
			//if the characters in question match
			if(data.charAt(i) == str.charAt(i))
			{
				if(data.equals(str))
				{
					return true;
				}
				//go to the right
				else
				{
					x = x.getRight();
					if(x == null)
						return false;
					data = x.getStringData();
					i++;
				}
			}
			else
			{
				x = x.getLeft();
				if(x == null)
					return false;
				data = x.getStringData();
			}
		}
		return false;
	}
	
	public Node nodeContaining(String str)
	{
		int i = 0;
		Node x = root;
		String data = x.getStringData();
		while(i < str.length())
		{
			//if the character in question match
			if(data.charAt(i) == str.charAt(i))
			{
				if(data.equals(str))
				{
					return x;
				}
				else
				{
					x = x.getRight();
					data = x.getStringData();
					i++;
				}
			}
			else
			{
				x = x.getLeft();
				data = x.getStringData();
			}		
		}
		return null;
	}
	
	public String getWord(int pos)
	{
		getWordHelper(root, pos);
		return word;
	}
	
	private void getWordHelper(Node x, int pos)
	{
		if(x.getPos() == pos)
		{
			word = x.getStringData();
		}
		if(x.getLeft() != null)
		{
			getWordHelper(x.getLeft(), pos);
		}
		if(x.getRight() != null)
		{
			getWordHelper(x.getRight(), pos);
		}
	}
	
	public void add (String x)
	{
		int index = 0;
		if(root == null)
		{
			pos++;
			root = new Node(x, pos);
		}
		else
		{
			Node curr = root;
			while(curr != null)
				//if string match (at least so far), go to the right
			if(x.substring(0, curr.getStringData().length()).equals(curr.getStringData()))
			{
				//if right child of current node is null, add node at that spot
				if(curr.getRight() == null)
				{
					pos++;
					Node z = new Node(x, pos, curr);
					curr.setRight(z);
					curr = null;
				}
				else
				{
					curr = curr.getRight();
				}
			}
			//if string is not a match, go left
			else
			{
				//if left child of current node is null, add node at that spot
				if(curr.getLeft() == null)
				{
					pos++;
					Node z = new Node(x, pos, curr);
					curr.setLeft(z);
					curr = null;
				}
				else
				{
					curr = curr.getLeft();
				}
			}
		}
	}
	
	
	
	

}
