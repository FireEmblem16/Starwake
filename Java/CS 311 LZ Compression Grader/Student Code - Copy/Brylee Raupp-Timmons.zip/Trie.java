import java.util.ArrayList;

/**
 * @author Brylee Raupp-Timmons
 * 
 *         This class represents a Trie tree used as a dictionary to store
 *         phrases found in uncompressed and compressed strings of a LZ78
 *         Encryption algorithm
 */
public class Trie {

	/* Instantiate Properties */

	// Root is the root of the Trie represented as a empty string
	private TrieNode root;

	// numOfPhrases represents how many different phrases have been stored in
	// the Trie so far
	private int numOfPhrases;

	// endOfSubstrings stores the node corresponding to the end of a phrase
	private ArrayList<TrieNode> endOfSubstrings;

	/**
	 * Initializes a new Trie with a empty string root and no children.
	 */
	public Trie() {
		root = new TrieNode((char) 0, null, 0);
		numOfPhrases = 0;
		endOfSubstrings = new ArrayList<TrieNode>();
		endOfSubstrings.add(root);
	}

	/**
	 * Gets the number of phrases in the Trie
	 * 
	 * @return An int representing how many phrases are in the Trie
	 */
	public int getNumOfPhrases() {
		return numOfPhrases;
	}

	/**
	 * Passes the node corresponding to the end of the substring, represented by
	 * the index passed in, into a recursive method that builds the desired
	 * substring
	 * 
	 * @param substringIndex
	 *            The substring index corresponding to the phrase to get
	 * @return The substring represented by the given substringIndex
	 */
	public String getSubstring(int substringIndex) {
		// Retrieves the substring denoted by the given substringIndex in
		// reversed order
		String substringInReverse = recursiveSubstringBuilder(endOfSubstrings
				.get(substringIndex));

		// Reverse the traversed substring into its correct forward substring
		// and return
		return new StringBuffer(substringInReverse).reverse().toString();
	}

	/**
	 * 
	 * @param node
	 * @return
	 */
	private String recursiveSubstringBuilder(TrieNode node) {
		if (node == root) {
			return "";
		}
		return node.getCharacter()
				+ recursiveSubstringBuilder(node.getParent());
	}

	/**
	 * Checks if the given starting node has a child representing the given
	 * character
	 * 
	 * @param character
	 *            The character that represents the child we are checking for
	 * @param startingNode
	 *            The node to check for a child in
	 * @return The child node if it exists; otherwise, the startingNode
	 */
	public TrieNode checkNodeForChild(char character, TrieNode startingNode) {
		TrieNode child = startingNode.getChild((int) character);
		if (child != null) {
			return child;
		} else {
			return startingNode;
		}
	}

	/**
	 * Gets the Root of the Trie Tree
	 * 
	 * @return The Trie Tree root
	 */
	public TrieNode getRoot() {
		return root;
	}

	/**
	 * Adds a new child representing the given character to the given parent
	 * 
	 * @param character
	 *            The character that the new child node represents
	 * @param parent
	 *            The parent to add the child to
	 */
	public void addChildToNode(char character, TrieNode parent) {
		// Increase number of phrases
		numOfPhrases++;

		// Add this node to the array list of nodes representing the ends of
		// different phrases
		endOfSubstrings.add(parent.setChild(character, numOfPhrases));
	}

	/**
	 * Gets the node representing the end of the substring identified by the
	 * given index
	 * 
	 * @param index
	 *            The phrase index to get the end node of
	 * @return The node representing the end of the substring
	 */
	public TrieNode getNodeAtSubstringIndex(int index) {
		return endOfSubstrings.get(index);
	}
}

/**
 * @author Brylee Raupp-Timmons
 * 
 *         This class represents a Trie Node used in a Trie tree
 */
class TrieNode {

	/* Instantiate Properties */

	// An array of nodes representing links to a node's children
	private TrieNode[] children;

	// The character value that a node represents
	private char character;

	// The node's parent node
	private TrieNode parent;

	// The index representing which phrase this node is the end of
	private int substringIndex;

	/**
	 * Initializes a new Node, as a child of the given parent, representing the
	 * given character and the end of a phrase identified by the given index
	 * 
	 * @param character
	 *            The character this node represents
	 * @param parent
	 *            The parent of this node
	 * @param substringIndex
	 *            The phrase index this node is the end of
	 */
	public TrieNode(char character, TrieNode parent, int substringIndex) {
		children = new TrieNode[256];
		this.character = character;
		this.parent = parent;
		this.substringIndex = substringIndex;
	}

	/**
	 * Gets the child corresponding to the given index
	 * 
	 * @param index
	 *            The index of the child to get
	 * @return The child at the given index
	 */
	public TrieNode getChild(int index) {
		return children[index];
	}

	/**
	 * Gives this node a new child representing the given character and phrase
	 * index
	 * 
	 * @param character
	 *            The character that the new child represents
	 * @param substringIndex
	 *            The substring index that the new child represents the end of
	 * @return The new child node that was created
	 */
	public TrieNode setChild(char character, int substringIndex) {
		TrieNode newChild = new TrieNode(character, this, substringIndex);
		children[(int) character] = newChild;
		return newChild;
	}

	/**
	 * Get the character that the node represents
	 * 
	 * @return The character that the node represents
	 */
	public char getCharacter() {
		return character;
	}

	/**
	 * Gets the node's parent
	 * 
	 * @return The node's parent
	 */
	public TrieNode getParent() {
		return parent;
	}

	/**
	 * Get the substring index that this node represents the end of
	 * 
	 * @return The substring index that this node represents the end of
	 */
	public int getSubstringIndex() {
		return substringIndex;
	}
}
