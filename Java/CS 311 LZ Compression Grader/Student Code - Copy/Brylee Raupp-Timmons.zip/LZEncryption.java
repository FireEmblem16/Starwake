import java.util.ArrayList;

/**
 * @author Brylee Raupp-Timmons
 * 
 *         This class implements static functions used to compress and
 *         uncompress Strings using the LZ78 encryption algorithm.
 */
public class LZEncryption {

	/**
	 * Encodes an uncompressed string
	 * 
	 * @param uncompressed
	 *            The uncompressed string to encode
	 * @return The compressed encoded string
	 */
	public static String encode(String uncompressed) {
		// Checks for a null or empty string
		if ((uncompressed == null) || (uncompressed.equals(""))) {
			return String.format("%32s", Integer.toBinaryString(0)).replace(
					' ', '0');
		}

		// ArrayList to store the parts of every codeword
		ArrayList<String> encodedString = new ArrayList<String>();

		// Create uncompressed char array for char-by-char reading
		char[] uncompressedCharArray = uncompressed.toCharArray();

		// Create a new Trie tree with a null root
		Trie trie = new Trie();

		/*
		 * Iterates through the chars checking for or adding to existing
		 * substrings as it goes
		 */
		for (int j = 0, i = 0; i < uncompressedCharArray.length; i = (j + 1)) {

			// Always start at the root when searching for a phrase
			TrieNode endOfSubstring = trie.getRoot();

			/*
			 * Iterates through the chars until the end of the string is reached
			 * or a new phrase is created
			 */
			for (j = i; j < uncompressedCharArray.length; j++) {

				// The current character to check if in a possible phrase
				char currentChar = uncompressedCharArray[j];

				/*
				 * Check if the current "end of the substring" node has a child
				 * pertaining to the current character
				 * 
				 * newEndOfSubstring will be the node pertaining to the child if
				 * one exists; otherwise, new will equal the old node.
				 */
				TrieNode newEndOfSubstring = trie.checkNodeForChild(
						currentChar, endOfSubstring);

				// If a child did not exist
				if (endOfSubstring == newEndOfSubstring) {

					// Add the current char as a new child node to the previous
					// endOfSubstring resulting in the creation of a new
					// phrase
					trie.addChildToNode(currentChar, endOfSubstring);

					// Add to the non-binary encoded string
					encodedString.add(endOfSubstring.getSubstringIndex() + "");
					encodedString.add(currentChar + "");

					// Continue on to create the next possible phrase
					break;
				} else {

					// If a child was found, save the new end of substring and
					// continue to the next loop checking the next char to see
					// if the phrase continues
					endOfSubstring = newEndOfSubstring;

					// This condition occurs if the end of the uncompressed
					// string ends with a phrase equal to a previous phrase
					if (j + 1 >= uncompressedCharArray.length) {

						// Add to the non-binary encoded string
						encodedString.add(endOfSubstring.getSubstringIndex()
								+ "");
					}
				}
			}
		}

		// Determine the codeword length needed to represent all the phrase
		// indexes
		int codewordLength = (int) Math
				.ceil(Math.log10(trie.getNumOfPhrases() + 1) / Math.log10(2));

		/*
		 * Iterates through each codeword in the non-binary encoding string and
		 * converts them into binary in order to create a compressed binary
		 * string
		 */
		String compressedString = "";
		for (int i = 0; i < encodedString.size(); i++) {

			if ((i % 2) == 0) {
				// Convert the string versions of the codewords into binary of
				// the appropriate number of bits needed to portray the phrase
				// indexes
				compressedString += String.format(
						"%" + codewordLength + "s",
						Integer.toBinaryString(Integer.parseInt(encodedString
								.get(i)))).replace(' ', '0');
			} else {

				compressedString += String.format(
						"%16s",
						Integer.toBinaryString((int) encodedString.get(i)
								.charAt(0))).replace(' ', '0');
			}
		}

		// buffer the end of the output with 0's until the total string has a
		// 16-bit boundary (i.e. until the total number of bits is a multiple of
		// 16)
		while ((compressedString.length() % 16) != 0) {
			compressedString += "0";
		}

		// Add the 32-bit binary integer, representing how long each codeword
		// is, to the beginning of the compressed string
		compressedString = String.format("%32s",
				Integer.toBinaryString(codewordLength)).replace(' ', '0')
				+ compressedString;

		return compressedString;
	}

	/**
	 * Decodes a compressed string
	 * 
	 * @param compressed
	 *            The compressed string to decode
	 * @return The uncompressed decoded string
	 */
	public static String decode(String compressed) {

		/*
		 * According to the Homework 4 document, we're assuming here that the
		 * given compressed string is always valid
		 */

		// Decode the first 32 bits of the compressed string to obtain the
		// length of each codeword
		int codewordLength = Integer.parseInt(compressed.substring(0, 32), 2);

		// Cut off the first 32 bits of the compressed string for easier reading
		// since the codewordLength has already been determined
		compressed = compressed.substring(32);

		// If the number of index bits is 0, the encoded string must have been
		// an empty string
		if (codewordLength == 0) {
			return "";
		}

		String uncompressedString = "";

		// Create a new Trie tree with a null root
		Trie trie = new Trie();

		/*
		 * Iterates through the compressed string creating new TrieNodes from
		 * the phrase indexes and building the uncompressed string
		 */
		for (int i = 0; i < compressed.length(); i += (codewordLength + 16)) {

			if (!compressed.substring(i).contains("1")) {
				break;
			}

			// Get the substring node index that the current phrase uses as it's
			// prefix
			int substringIndex = Integer.parseInt(
					compressed.substring(i, i + codewordLength), 2);

			// Build the uncompressed string as you go
			uncompressedString = uncompressedString
					+ trie.getSubstring(substringIndex);

			if (!compressed.substring(i + codewordLength).contains("1")) {
				break;
			}

			// Get the new character of the current phrase
			char character = (char) Integer.parseInt(
					compressed.substring(i + codewordLength, i + codewordLength
							+ 16), 2);

			// Build the uncompressed string as you go as well as add the new
			// substring in the Trie
			trie.addChildToNode(character,
					trie.getNodeAtSubstringIndex(substringIndex));
			uncompressedString = uncompressedString + character;
		}
		return uncompressedString;
	}

	/**
	 * Private constructor used to prevent LZEncryption instantiation
	 */
	private LZEncryption() {
		// DO NOTHING. CLASS WILL USED BY STATIC REFERENCES
	}
}