package projectOne;

import java.util.LinkedList;


public class Node 
{
	
	String data; // Stores data of Node
	boolean isLast; // Tells if it is the final character in Substring
	int count; // Number of levels down the string is
	LinkedList<Node> childrenList; // Children of the node
	
	
	// Class Constructor
	public Node(String s) {
		data = s;
		isLast = false;
		count = 0;
		childrenList = new LinkedList<Node>();
	}
	
	// Child of Node
	public Node child(String s) {
		if(childrenList != null) {
			for(Node n: childrenList) {
				if(n.data.equals(s)) {
					return n;
				}
			}
		}
		
		return null;
	}

}
