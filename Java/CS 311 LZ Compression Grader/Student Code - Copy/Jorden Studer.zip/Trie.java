package projectOne;

import java.util.LinkedList;

public class Trie {
	
	private Node root;
	private int key;

	public Trie() {
		root = new Node("");
		key = 1;
	}
	
	public void insertNode(String word) {
		if(searchNodes(word) == true) return; // Return if word is already in Trie
		
		Node curNode = root;
		
		for(int i=0; i < word.length(); i++) {
			
			String c = word.substring(i,i+1);
			Node child = curNode.child(c);
			
			if(child != null) { 
				curNode = child;
			}
			else {
				curNode.childrenList.add(new Node(c));
				curNode = curNode.child(c);
			}

		}
		
		curNode.count = key++;
		curNode.isLast = true;
	}
	

	public boolean searchNodes(String word) {
		
		Node curNode = root;
		
		for(int i=0; i < word.length(); i++) {
			
			String c = word.substring(i,i+1);
			
			if(curNode.child(c) == null) { // If there is no child with that letter
				return false;
			}
			else {
				curNode = curNode.child(c);
			}
		}
		
		if(curNode.isLast == true) {
			return true;
		}

		return false;
	}
	
	public int returnNodeCode(String word) {
		
		Node curNode = root;
		
		for(int i=0; i < word.length(); i++) {
			String c = word.substring(i,i+1);
			
			curNode = curNode.child(c);
		}
		
		return curNode.count;
	}
	
}
