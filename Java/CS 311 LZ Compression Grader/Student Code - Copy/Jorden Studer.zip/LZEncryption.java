package projectOne;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream.GetField;
import java.util.Scanner;


public class LZEncryption {
	
	private LZEncryption() {
		// Does nothing?
	}
	
	/*
	 * Encodes the string using a Trie
	 */
	public static String encode(String s) {
		
		Trie dict = new Trie();
		
		String phrase = new String();
		int parentKey;
		
		// START OF FIRST ENCODE TO SEE HOW MANY POSSIBLE SUBSTRINGS THERE ARE
		
		Trie tempDict = new Trie();
		int count = 0;
		
		for(char c: s.toCharArray()) {
			parentKey = tempDict.returnNodeCode(phrase);
			phrase += c;
			
			if(!tempDict.searchNodes(phrase)) {
				tempDict.insertNode(phrase);
				phrase = "";
				count++;
			}
		}
		
		if(!phrase.isEmpty()) {
			count++;
		}
		
		int dictSize = calculateBits(count);
		String bitNum = numOfPrefixBits(dictSize);
		String outputCode = bitNum;
		// START OF SECOND ENCODE TO ACTUALLY DO THE ENCODE
		
		phrase = "";
		parentKey = 0;
	
		for(char c: s.toCharArray()) {
			parentKey = dict.returnNodeCode(phrase);
			phrase += c;
			if(!dict.searchNodes(phrase)) { // If the phrase is not in the dictionary
				
				String parentKeyBinary = Integer.toBinaryString(parentKey);
				outputCode += binaryRepresent(parentKeyBinary.length(), dictSize, parentKeyBinary);
				String characterAsciiBinary = Integer.toBinaryString((int)c);
				outputCode += binaryRepresent(characterAsciiBinary.length(), 16, characterAsciiBinary);
				dict.insertNode(phrase);
				phrase = "";
			}
		}
		
		if(!phrase.isEmpty()) {
			String endBinary = Integer.toBinaryString(dict.returnNodeCode(phrase));
			outputCode += binaryRepresent(endBinary.length(), dictSize, endBinary);
		}
		
		if(outputCode.length() % 16 != 0) { // If it is not divisible by 32 want to pad with 0s. 
			int remainder = outputCode.length() % 16;
			for(int i = 0; i < 16 - remainder; i++) {
				outputCode += "0";
			}
		}

		outputCode = FromBinary(outputCode);

		return outputCode;
	}
	
	
	/**
	 * Takes the input string, converts it to binary so it is easier to work with for me. Take the first 32 bits out of the string and then process
	 * the string through until there is just the possible last value left and then padding. Once it hits that spot it will output the value and then
	 * stop the decode. It creates the same Trie in decoding, except for decode purposes I use an array to store the index values. 
	 */
	public static String decode(String s) {
		
		s = ToBinary(s); // send it to binary to start the decode
		
		Trie dict = new Trie();
		
		String phrase = new String();
		int parentKey = 0;
		
		String numIndexBitsString = s.substring(0,32); // Binary string of how many bits index is made of
		int numIndexBits = Integer.parseInt(numIndexBitsString, 2);

		s = s.substring(32); // Remove the first 32 bits from the input since they don't matter anymore
		
		String[] charList = new String[1000];
		int index = 0;
		
		while(!s.isEmpty()) {
			String indexValue = s.substring(0,numIndexBits);
			s = s.substring(numIndexBits); // Remove the index bits
			
			if(s.length() >= 16) { // If the length > 16 keep going because it is no padding
				String characterValue = s.substring(0, 16);
				int characterAsciiValue = Integer.parseInt(characterValue, 2);
				characterValue = new Character((char)characterAsciiValue).toString();
				
				s = s.substring(16); // Remove the character bits
				
				if(Integer.parseInt(indexValue,2) == 0) { // If index is 0, no parent
					dict.insertNode(characterValue);
					index++;
					charList[index] = characterValue;
					phrase += characterValue;
					
				}
				else {
					int indexNum = Integer.parseInt(indexValue,2);
					String indexChar = charList[indexNum];
					String newString = indexChar + characterValue;
					dict.insertNode(newString);
					index++;
					charList[index] = newString;
					phrase += newString;
				}
				
			}
			else {
				s = ""; // set s to empty so it will exit the while loop
				int indexNum = Integer.parseInt(indexValue,2);
				if(charList[indexNum] != null) {
					phrase += charList[indexNum];
				}
			}

		}
		
		
		return phrase;
	}
	
	/**
	 * Represents of a value
	 */
	private static String binaryRepresent(int length, int numBits, String input) {
		
		if(length < numBits) {
			for(int j = length; j < numBits; j++) {
				input = '0' + input;
			}
		}
		
		return input;
	}

	
	/*
	 * This method will get the size of the dictionary
	 * from a supplied text file that contains the size of the
	 * dictionary so the program can know how many bits to use.
	 * 
	 * Program assumes the text file is correct with one integer
	 * at the start of the text file that contains the size
	 */
	private static int calculateBits(int size) {
		
		return (int)Math.ceil(Math.log(size+1)/Math.log(2));
	}
	
	private static String numOfPrefixBits(int num) {
		
		String bitValue;
		bitValue = Integer.toBinaryString((int)num);
		
		if(bitValue.length() < 32) {
			for(int i=bitValue.length(); i<32; i++) {
				bitValue = '0' + bitValue;
			}
		}
		
		return bitValue;
	}
	
	// GIVEN A STRING OF 0s and 1s THIS WILL REPRESENT IN ACTUAL BINARY
	// CODE CREDIT: DON VIA BLACKBOARD ANNOUNCEMENT
	// ** THIS IS NOT MY CODE **
	private static String ToBinary(String str)
	{
		final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i++)
		{
			char c = str.charAt(i);
			
			for(int j = 0;j < 16;j++)
				if((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}
		
		return ret;
	}	

	// GIVEN A STRING OF BINARY THIS WILL REPRESENT IT IN 0s AND 1s
	// CODE CREDIT: DON VIA BLACKBOARD ANNOUNCEMENT
	// ** THIS IS NOT MY CODE **
	private static String FromBinary(String str)
	{
		final char[] bits = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i += 16)
		{
			char c = 0x0000;
			
			for(int j = 0;j < 16;j++)
				if(str.charAt(i + j) == '1')
					c |= bits[j];
			
			ret += c;
		}
		
		return ret;
	}
}
