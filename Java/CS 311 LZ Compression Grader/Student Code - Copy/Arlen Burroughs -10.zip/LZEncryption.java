import java.util.ArrayList;

public class LZEncryption {
	
	private LZEncryption(){}
	
	public static String encode(String uncompressed)
	{	
		System.out.println("Encode: "+uncompressed);
		String encoded = "";
		
		Trie t = new Trie();
		
		// add entire string to tree (trie).
		while(uncompressed.length()>0){
			uncompressed = t.findNextPhrase(uncompressed);
		}
		
		int prefixBitNum = (int) Math.ceil(Math.log(t.nodeCount+1)/Math.log(2.0));
		encoded = Integer.toBinaryString(prefixBitNum);
		
		// begin encoded string with 32 bit prefix bit count.
		while(encoded.length()<32)
			encoded = "0"+encoded;
		
		// add prefix and value for each node in the Trie.
		// scan ArrayList of nodes (ordered by addition to the tree) and encode.
		// NOTE: another way to do this is by scanning the tree for the node index.
		int i = 1;
		if(t.lastRepeat)t.nodeCount = t.nodeCount+1;
		while(i<=t.nodeCount){
			
			Node toEncode = t.getNode(i);
			// convert prefix number to binary string.
			String prefix = ""+Integer.toBinaryString(toEncode.pref);
			while(prefix.length()<prefixBitNum){
				prefix = "0"+prefix;
			}
			
			// convert value to 16 bit binary string.
			String valueAsBin="";
			if(toEncode.value != '\u0000'){
				valueAsBin = Integer.toBinaryString(toEncode.value);
				while(valueAsBin.length()<16){
					valueAsBin = "0"+valueAsBin;
				}
			}
			encoded = encoded + prefix+valueAsBin;
			i++;
		}
		
		// add remaining 0's to be divisible by 16
		while(encoded.length()%16 != 0)
			encoded = encoded + "0";
		
		return encoded;
	}
	
	public static String decode(String compressed)
	{
		System.out.println("Decode: " + compressed);
		Trie t = new Trie();
		
		//read num of bits for prefix nums
		int prefBitCount = Integer.parseInt(compressed.substring(0, 32), 2);
		compressed = compressed.substring(32);//remove first 32 bits.
		
		// read in all prefixes and values.
		while(compressed.length()>prefBitCount){
			int prefNum = Integer.parseInt(compressed.substring(0, prefBitCount), 2);

			if(compressed.length()< prefBitCount+16){// last is a repeat
				t.nodeList.add(new Node(prefNum, '\u0000'));
				break;
			}
			
			compressed = compressed.substring(prefBitCount+8);// remove unnecessary
			char val = (char) Integer.parseInt(compressed.substring(0, 8), 2);// read value
			compressed = compressed.substring(8);// remove what was just read
			
			t.nodeList.add(new Node(prefNum, val));
			// another way is to add to tree structure, instead of arraylist
			// by finding the parent node indicated by prefNum.
		}
		
		String decoded = "";
		// for each prefix/value pair, write to decoded string.
		// another way is to use the actual trie structure.
		for(int i = 0 ; i < t.nodeList.size() ; i++){
			if(t.nodeList.get(i).pref !=0)
			{	// read parents values in trie.
				String valTrace = "";
				int tmp = i;
				int pref;
				while(t.nodeList.get(tmp).pref !=0){
					pref = t.nodeList.get(tmp).pref - 1;
					valTrace = t.nodeList.get(pref).value+valTrace;
					tmp = pref;
				}
				decoded = decoded + valTrace;
			}
			decoded = decoded + t.nodeList.get(i).value;// write this value.
		}
		
		return decoded;
	}
	
	public static void main(String[] args){
		System.out.println("CS 311 - HW4 - Arlen Burroughs\n");
		String returned = "";
		
		//TODO
		//returned = LZEncryption.encode("");
		//returned = LZEncryption.encode("The world is full of sugar!");
		//returned = LZEncryption.encode("Sugar! Sugar! Sugar! Sugar! Sugar! Sugar! Sugar! Sugar!");

		//returned = LZEncryption.decode("0000000000000000000000000000011000000000000000010001000000000000000001101111000000000000000010000000000000000000011011100000100000000001110100000011000000000110110100000000000000011001010000000000000001100100001000000000000110110000011100000000001000000000000000000001101001000100000000000010000000000000000000011101000000000000000001101000001010000000000110000100000000000000011001100100000000000001100001001011000000000111001000000000000000011100110000110000000001101111010000000000000010000000000000000000011101110010110000000001111010000000000000000110000100000000000000011100100010000000000001110011000000000000000010110000001100000000011001100000100000000001110010000011000000000111010000111000000000011001010000000000000001111001000011000000000110000101100100000000011001010000110000000001110011000000000000000111010100000000000000011000100011010000000001101100001111000000000110111000100000000000001000000000000000000001110001100100000000000110100100000000000000011000110000000000000001101011011110000000000110111110000100000000011011100000000000000001100111000111000000000111001000000000000000001011100000000000");
		
		System.out.println("Output: "+returned);
	}
}

class Trie{
	Node root = new Node(0, '\u0000', null);// null root. empty. lambda.
	int nodeCount = 0;
	String codeWordOutput = "";
	String encodedOutput = "";
	ArrayList<Node> nodeList = new ArrayList<Node>();
	boolean lastRepeat = false;
	
	/**
	 * Finds the first char in 'input' that is not found in Trie and creates a note.
	 * @param input The string to parse using the current trie structure.
	 * @return The substring of what still needs to be parsed.
	 */
	public String findNextPhrase(String input) {
		
		boolean foundPhrase = false;
		
		Node parent = root;
		int keysFound = 0;
		while(!foundPhrase)
		{
			if(keysFound == input.length())
			{	// all input chars found in tree. it's the last phrase.
				foundPhrase = true;
				nodeList.add(new Node(nodeCount+1, '\u0000', parent));
				lastRepeat = true;
				break;
			}
			
			ArrayList<Node> currChildren = parent.children;
			
			if(currChildren.size()==0)
			{ 	// no child nodes exist for this node. Add one with this value.
				parent.addChild(new Node(++nodeCount, input.charAt(keysFound), parent));
				nodeList.add(new Node(nodeCount, input.charAt(keysFound), parent));
				codeWordOutput = codeWordOutput + parent.index + input.charAt(keysFound);
				return input.substring(keysFound+1);
			}
			
			// scan through children to see if current char is already in a child node.
			for(int i = 0 ; i < currChildren.size(); i++)
			{
				if(currChildren.get(i).value == input.charAt(keysFound))
				{	// This char is found. Continue while loop.
					parent = currChildren.get(i);
					keysFound++;
					break;
				}
				else if(i==currChildren.size()-1)
				{	// on last child & value not found. create a new child.
					parent.addChild(new Node(++nodeCount, input.charAt(keysFound), parent));
					nodeList.add(new Node(nodeCount, input.charAt(keysFound), parent));
					codeWordOutput = codeWordOutput +parent.index + input.charAt(keysFound);
					keysFound++;
					foundPhrase = true;
					break;
				}
			}
		}
		
		return input.substring(keysFound);// return what was not found.
	}

	public Node getNode(int i) {
		// if I didn't use a supplementary ArrayList, I would scan the tree here
		// and return the node with index i.
		return nodeList.get(i-1);
	}
}

class Node{
	Integer index;
	char value;
	String codeWord;
	int pref;
	Node parent = null;
	ArrayList<Node> children = new ArrayList<Node>();
	
	public Node(Integer ind, char val, Node parentNode){
		index = ind;
		value = val;
		parent = parentNode;
		
		if(ind != 0){
			pref = parent.index;
			codeWord = ""+pref+value;
		}
	}
	
	public Node(int prefNum, char val) {
		pref = prefNum;
		value = val;
	}

	public void addChild(Node child){
		children.add(child);
		//System.out.println("  - child added: "+child.printAncestors()+"\n");
	}

	public String printAncestors() {
		
		String toReturn = "";
		Node current = this;
		while(current.value != '\u0000'){
			toReturn = " -> "+current.value+"("+current.codeWord+", "+current.index+")"+toReturn;
			current = current.parent;
		}
		toReturn = "root"+toReturn;
		return toReturn;
	}
	
}