import java.util.LinkedList;
import java.util.List;

public class LZ 
{
	private LZ() {}
	
	/**
	 * Encodes a String of ASII characters and creates a biary String of 1s and 0s
	 * @param uncompressed
	 * @return
	 */
	public static String encode(String uncompressed)
	{
		TrieTree tree = new TrieTree();
		boolean leftOverChars = false;
		List<IntPair> pairs = new LinkedList<IntPair>();
		
		if (uncompressed == null || uncompressed.equals(""))
		{
			return generateBitString(0, 32);
		}
		else
		{
			int length = uncompressed.length();
			char[] characters = uncompressed.toCharArray();
			int i;
			for (i=0; i<length; i++)
			{
				Node current = tree.getRoot();
				char charFromString = characters[i];
				
				while (current.nodeContainsElement(charFromString))
				{
					current = current.getChildNode(charFromString);
					
					i++;
							
					if (i < length)
					{
						charFromString = characters[i];
					}
					else
					{
						leftOverChars = true;
						break;
					}
				}
				
				Integer firstHalf;
				Integer secondHalf;
				
				if(!leftOverChars)
				{
					tree.addNode(current, charFromString);
					firstHalf = current.getNumber();
					secondHalf = (int) charFromString;		
				}
				else
				{
					firstHalf = current.getNumber();//was get parent
					secondHalf = null;	
				}
				
				pairs.add(new IntPair(firstHalf, secondHalf));
			}
			
			int bitCount = getBitCount(tree.getNodeCount());
			
			return createEncoded(pairs, bitCount);
		}
		
	}
	
	/**
	 * Decoded a binary String of 1s and 0s into a String of ASII chars
	 * @param compressed
	 * @return
	 */
	public static String decode(String compressed)
	{
		TrieTree tree = new TrieTree();
		String decoded = "";
		String front = compressed.substring(0, 32);
		int dictionarySize = Integer.parseInt(front, 2);
		int segSize = 16+dictionarySize;
		
		for (int i=32; i<compressed.length(); i+=segSize)
		{
			try
			{
				String dictionaryIndex = compressed.substring(i, i+dictionarySize);
				String charBits = compressed.substring(i+dictionarySize, i+dictionarySize+16);
				
				int nodeNumber = Integer.parseInt(dictionaryIndex, 2);
				int charNumber = Integer.parseInt(charBits, 2);
				char charCharacter = (char) charNumber;
				
				Node current = tree.getNodeByNumber(nodeNumber);
				Node child = tree.addNode(current, charCharacter);
				decoded += tree.printUpFromNode(child);	
			}
			catch (Exception e)
			{
				String dictionaryIndex = compressed.substring(i, i+dictionarySize);
				int nodeNumber = Integer.parseInt(dictionaryIndex, 2);
				Node current = tree.getNodeByNumber(nodeNumber);
				decoded += tree.printUpFromNode(current);
				break;
			}
		}
		
		return decoded;
	}
	
	/**
	 * Takes a integer, and formats it into a binary String of 1's and 0's with X bits in total.
	 * @param number: Inteer to convert to bit String
	 * @param bits: Number of bits the String should be
	 * @return
	 */
	private static String generateBitString(int number, int bits)
	{
		return String.format("%"+bits+"s", Integer.toBinaryString(number)).replace(" ", "0");
	}
	
	/**
	 * Returns the bit count, detering the value of the 32bit number for the encoded String
	 * @param nodeCount
	 * @return
	 */
	private static int getBitCount(int nodeCount)
	{
		return (int) Math.ceil(Math.log(nodeCount) / Math.log(2));
	}
	
	/**
	 * Takes the pairs of prefixes and suffixes (List<IntPair> pairs )and creates the encoded String
	 * @param pairs: prefixes and suffixes
	 * @param bitCountForFirstHalves: Value for leading 32bit number
	 * @return: The encoded String.
	 */
	private static String createEncoded(List<IntPair> pairs, int bitCountForFirstHalves)
	{
		String first32 = generateBitString(bitCountForFirstHalves, 32);
		String encoded = ""+first32;
		
		for(IntPair pair: pairs)
		{
			encoded += generateBitString(pair.getInt1(), bitCountForFirstHalves);
			
			if (pair.getInt2() != null)
			{
				encoded += generateBitString(pair.getInt2(), 16);
			}
		}
		
		int curLength = encoded.length();
		int zeroCount = 16 - (curLength % 16);
		encoded += generateBitString(0, zeroCount);
		
		return encoded;
	}
	
}
