/**
 * Class to represent a node of a tree.
 * Each node has arra of children nodes, a parent node,
 * a value which keeps track of the char value it stores,
 * and nimber, which keeps track of the order in which the 
 * nodes are added. The root is number 0 and the first child
 * added to the root is 1
 * @author mjj
 *
 */
public class Node 
{
	
	private Node[] childrenNodes;
	private Node parent;
	private char value;
	private int number;
	
	public Node(char val, int num) {	
		super();
		value = val;
		number = num;
		childrenNodes = new Node[256];
	}
		
	public Node(int num) {
		super();
		childrenNodes = new Node[256];
		number = num;
	}


	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	
	public char getValue() {
		return value;
	}
	
	public int getNumber() {
		return number;
	}
	
	public Node getChildNode(char c)
	{
		int index = c;
		return childrenNodes[index];
	}
	
	public Node[] getAllChildren()
	{
		return childrenNodes;
	}
	
	/**
	 * Creates a new child node and returns it.
	 * @param value
	 * @param number
	 * @return
	 */
	public Node addChildNode(char value, int number)
	{
		Node newChild = new Node(value, number);
		newChild.setParent(this);
		childrenNodes[value] = newChild;
		return newChild;
	}
	
	/**
	 * Checks to see if a currnet node has a child node with the
	 * specified passed value.
	 * @param value
	 * @return
	 */
	public boolean nodeContainsElement(char value)
	{
		for (Node n: childrenNodes)
		{
			if(n == null )
			{
				continue;
			}
			
			if(n.getValue() == value)
			{
				return true;
			}
		}
		return false;
	}

}
