/**
 * Helper class to keep track of the numbers for created the encoded String
 * int1: X Bit number that keeps track of parent node number (prefix)
 * int2: 16 Bit ASII number in integer form (suffix)
 * @author mjj
 *
 */
public class IntPair 
{
	private Integer int1;
	private Integer int2;
	
	public IntPair(Integer int1, Integer int2) {
		super();
		this.int1 = int1;
		this.int2 = int2;
	}

	public Integer getInt1() {
		return int1;
	}

	public Integer getInt2() {
		return int2;
	}
}
