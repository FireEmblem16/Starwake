import java.util.Stack;

/**
 * Class Object that represents a Trie Tree
 * The tree is initialized with a root. 
 * Each node n the tree (including root) may have 256 possible
 * children.
 * @author mjj
 *
 */
public class TrieTree 
{
	private Node root = new Node(0);
	private int nodeCount = 1;

	/**
	 * Adds a new child node with value c to the specified node
	 * that was pass
	 * @param node: Node that is recieving child
	 * @param c: char value of new child
	 * @return: Newly created child node
	 */
	public Node addNode(Node node, char c) 
	{
		Node result = node.addChildNode(c, nodeCount);
		
		if (result != null)
		{
			nodeCount++;
		}
		
		return result;
	}

	public Node getRoot()
	{
		return root;
	}

	/**
	 * Checks to see is the root node
	 * @param c
	 * @return
	 */
//	public boolean containsNode(char c) {
//		return root.nodeContainsElement(c);
//	}
	
	public int getNodeCount()
	{
		return nodeCount;
	}
	
	/**
	 * Returns the Node with Node Number equal
	 * to the parameter number passed.
	 * If node does no exist, will return null;
	 * @param number: Node number ou are looking for
	 * @return
	 */
	public Node getNodeByNumber(int number)
	{
		Stack<Node> myStack = new Stack<Node>();
		Node current = root;
		myStack.push(current);
		while (!myStack.isEmpty())
		{
			current = myStack.pop();
			if (current.getNumber() == number)
			{
				return current;
			}
			else
			{
				for (Node n: current.getAllChildren())
				{
					if (n != null)
					{
						myStack.push(n);
					}			
				}
			}
		}
		return null;
	}

	/**
	 * From the current Node, it will create a String of all of the char
	 * values from current node, traversing upward until reaching the root
	 * @param current: current node
	 * @return: String of chars, (Higher up chars appear first in String, 
	 * 		current Node's char value will be last value in String
	 */
	public String printUpFromNode(Node current) 
	{
		String result = "";
		Node parent = current.getParent();
		while (parent != null)
		{
			result = ""+current.getValue() + result;
			current = current.getParent();
			parent = current.getParent();
		}
		return result;
	}
	
	/**
	 * IGNORE, TESTING PURPOSE ONLY
	 * Helper method to print the tree
	 */
	public void printTree()
	{
		printTreeRecurs(root);
	}
	
	/**
	 * IGNORE, TESTING PURPOSE ONLY
	 * Private helper method to assist in printing tree
	 * @param current
	 */
	private void printTreeRecurs(Node current)
	{
		if(current == null)
		{
			return;
		}
		for (Node n: current.getAllChildren())
		{
			if (n != null)
			{
				System.out.println("Number: " + n.getNumber() + " Value: " +n.getValue());
			}
			printTreeRecurs(n);
			
		}
	}

}
