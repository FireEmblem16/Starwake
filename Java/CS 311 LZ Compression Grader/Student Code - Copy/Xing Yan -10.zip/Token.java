
public class Token {

	int index;
	
	Byte b;
	
	public Token(int index, Byte b) {
		this.index = index;
		this.b = b;
	}
}
