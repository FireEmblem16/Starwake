
public abstract class Dictionary {

	protected int size = 0;
	
	protected Buffer buffer;
	
	/**
	 * For encoding
	 */
	public abstract Token nextToken();
	
	/**
	 * For decoding
	 */
	public abstract void nextWord(int idx);
	
	public int size() {
		return size;
	}

	public abstract void grow(Token token);
}
