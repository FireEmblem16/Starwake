import java.io.EOFException;


public class Archiver {

	private Buffer inputBuffer;

	private Buffer outputBuffer;

	private Dictionary dict;

	private int indexBits;

	byte[] encode(byte[] input) {
		inputBuffer = new Buffer(input);
		outputBuffer = new Buffer();
		return doEncode();
	}

	private byte[] doEncode() {
		dict = new Trie(inputBuffer);
		
		// first pass get the size of the dictionary
		while (true) {
			Token token = dict.nextToken();
			if (token == null || token.b == null) {
				break;
			}
		}

		indexBits = indexBits(dict.size());
		dict = new Trie(inputBuffer);
		outputBuffer.writeBits(32, indexBits);
		
		while (true) {
			Token token = dict.nextToken();
			if (token == null)
				break;

			outputBuffer.writeBits(indexBits, token.index);
			if (token.b != null) {
				outputBuffer.writeBits(16, (token.b & 0xFF));
			}
		}
		outputBuffer.sync();
		return outputBuffer.content();
	}

	byte[] decode(byte[] input) {
		inputBuffer = new Buffer(input);
		outputBuffer = new Buffer();
		return doDecode();
	}

	private byte[] doDecode() {
		dict = new Trie(outputBuffer);
		try {
			indexBits = (int) inputBuffer.readBits(32);
		} catch (EOFException e) {
			throw new RuntimeException("Input format is illegal");
		}

		if (indexBits == 0) {
			// empty input
			return new byte[0];
		}

		while(true) {
			Token token = nextToken();
			if(token == null) {
				break;
			}
			
			dict.nextWord(token.index);
			if(token.b != null) {
				dict.grow(token);
			}
		}
		
		return outputBuffer.content();
	}

	private Token nextToken() {
		int idx;
		try {
			idx = (int) inputBuffer.readBits(indexBits);
		} catch (EOFException e) {
			return null;
		}
		
		try {
			char b = (char) inputBuffer.readBits(16);
			if(b > 255) {
				throw new UnsupportedOperationException("Character exceeds 8 bits");
			}
			return new Token(idx, (byte) b);
		} catch (EOFException e) {
			return new Token(idx, null);
		}
	}

	private int indexBits(long size) {
		int ret = 0;
		while (size > 0) {
			size >>= 1;
			ret++;
		}
		return ret;
	}
}
