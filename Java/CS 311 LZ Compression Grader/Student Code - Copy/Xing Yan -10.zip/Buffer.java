import java.io.EOFException;
import java.util.ArrayList;

public class Buffer {
	/**
	 * Buffer size in bits
	 */
	private static final int BUFFER_BIT_SIZE = 128;

	private static final int HALF_BUFFER_BIT_SIZE = 64;

	/**
	 * Size in bits
	 */
	private long bitSize;

	/**
	 * Size in bytes
	 */
	private int byteSize;

	/**
	 * If the stream is not backed by a file, the full content is loaded in this
	 * byte array.
	 */
	private byte content[];
	/**
	 * Pointer for the content.
	 */
	private int curByte;

	private long globalCurBit;

	private int localCurBit;

	private int localLimitBit;

	private byte buffer[] = new byte[BUFFER_BIT_SIZE];

	ArrayList<Byte> sizableContent = new ArrayList<>();

	/**
	 * Construct an ouput BitStream backed by in-memory byte array.
	 */
	public Buffer() {
	}

	public byte[] content() {
		byte ret[] = new byte[sizableContent.size()];
		for (int i = 0; i < sizableContent.size(); ++i) {
			ret[i] = sizableContent.get(i);
		}
		return ret;
	}

	public Buffer(byte content[]) {
		this.content = content;
		bitSize = content.length * 8;
		byteSize = content.length;
	}

	public void reset() {
		localCurBit = 0;
		localLimitBit = 0;
		globalCurBit = 0;
		curByte = 0;
	}

	/**
	 * Support at most writing 64 bits at once.
	 */
	public void writeBits(int len, long value) {
		if (len > 64)
			throw new RuntimeException();

		if (space(localCurBit, localLimitBit) >= HALF_BUFFER_BIT_SIZE) {
			drainBuffer();
		}

		long mask = 1;
		for (int i = len - 1; i >= 0; --i) {
			buffer[localLimitBit++] = (byte) (((value & (mask << i)) != 0) ? 1
					: 0);
			if (localLimitBit >= BUFFER_BIT_SIZE)
				localLimitBit = 0;
		}
	}

	/**
	 * Support at most reading 64 bits at once.
	 */
	public long readBits(int len) throws EOFException {
		if (len > 64)
			throw new RuntimeException();

		long ret = 0;
		if (space(localCurBit, localLimitBit) < len) {
			feedBuffer();
		}

		for (int i = len - 1; i >= 0; --i) {
			ret |= (buffer[localCurBit++] << i);
			if (localCurBit == BUFFER_BIT_SIZE)
				localCurBit = 0;
			globalCurBit++;
			if (globalCurBit > bitSize)
				throw new EOFException();
		}
		return ret;
	}

	/**
	 * Feed a constant 64 bits into the buffer, big endian
	 */
	private void feedBuffer() {
		if (curByte >= byteSize) {
			return;
		}
		long holder = 0;
		int i = 7;
		for (; i >= 0;) {
			long temp = content[curByte++] & 0xFFL;
			holder |= (temp << (i-- * 8));
			if (curByte >= byteSize) {
				break;
			}
		}

		long mask = 1;
		for (int j = HALF_BUFFER_BIT_SIZE - 1; j >= (i + 1) * 8; --j) {
			byte temp = (byte) (((holder & (mask << j)) != 0) ? 1 : 0);
			buffer[localLimitBit++] = temp;
			if (localLimitBit == BUFFER_BIT_SIZE)
				localLimitBit = 0;
		}
	}

	/**
	 * Drain a constant 64 bits into the content, big endian
	 */
	private void drainBuffer() {
		long holder = 0;
		for (int i = HALF_BUFFER_BIT_SIZE - 1; i >= 0; --i) {
			long temp = buffer[localCurBit++];
			holder |= (temp << i);
			if (localCurBit == BUFFER_BIT_SIZE)
				localCurBit = 0;
		}

		// System.out.println(Long.toBinaryString(holder));
		for (int j = 0; j < 8; ++j) {
			sizableContent.add((byte) ((holder << (j * 8)) >>> (7 * 8)));
		}
	}

	private int space(int start, int end) {
		int sp = end - start;
		if (sp < 0) {
			sp = (sp + BUFFER_BIT_SIZE) % BUFFER_BIT_SIZE;
		}
		return sp;
	}

	/**
	 * Write left-over bits into the backing content, the last partial byte is
	 * padded with 0s.
	 */
	public void sync() {
		int leftOver = space(localCurBit, localLimitBit);
		while (leftOver > 0) {
			byte holder = 0;
			for (int i = 7; i >= 0; --i) {
				holder |= (buffer[localCurBit++] << i);
				if (localCurBit == BUFFER_BIT_SIZE)
					localCurBit = 0;
				leftOver -= 1;
				if (leftOver == 0)
					break;
			}
			sizableContent.add(holder);
		}
	}

	public byte readByte() {
		return content[curByte++];
	}

	public void writeByte(byte b) {
		sizableContent.add(b);
	}

	public boolean hasNextByte() {
		return curByte < byteSize;
	}
}
