import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

public class Trie extends Dictionary {
	/**
	 * Lambda node
	 */
	private Node root = new Node(size, (byte) 0, null);

	private List<Node> table = new ArrayList<Node>();

	public Trie(Buffer buf) {
		buffer = buf;
		buffer.reset();
		table.add(root);
	}

	private int nodePosition(byte b) {
		return b + 128;
	}

	@Override
	public Token nextToken() {
		Node cursor = root;
		byte b = 0;
		int pos = 0;
		int idx = 0;
		while (true) {
			if (buffer.hasNextByte()) {
				b = buffer.readByte();
				pos = nodePosition(b);
			} else {
				if (idx > 0) {
					size++;
					return new Token(idx, null);
				} else {
					return null;
				}
			}
			if (cursor.child(pos) == null) {
				cursor.putChild(pos, new Node(++size, b, cursor));
				return new Token(idx, b);
			}
			cursor = cursor.child(pos);
			idx = cursor.index;
		}
	}

	@Override
	public void nextWord(int idx) {
		Node leaf = table.get(idx);
		Deque<Byte> stack = new ArrayDeque<Byte>();
		while (leaf.index != 0) {
			stack.push(leaf.b);
			leaf = leaf.parent;
		}

		while (!stack.isEmpty()) {
			buffer.writeByte(stack.pop());
		}
	}

	public void grow(Token token) {
		Node leaf = table.get(token.index);
		Node child = new Node(++size, token.b, leaf);
		leaf.putChild(nodePosition(token.b), child);
		table.add(child);
		buffer.writeByte(token.b);
	}
}
