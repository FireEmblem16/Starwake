
public class Node {

	byte b;

	private Node children[];

	Node parent;

	int index;

	public Node(int idx, byte b, Node parent) {
		index = idx;
		this.b = b;
		this.parent = parent;
		children = new Node[256];
	}

	public void putChild(int nodePosition, Node child) {
		children[nodePosition] = child;
	}

	public Node child(int pos) {
		return children[pos];
	}

}