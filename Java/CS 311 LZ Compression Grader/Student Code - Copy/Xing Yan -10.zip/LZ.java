
/**
 * A utility class that implements Lempel-Ziv compression and decompression
 * algorithm.
 * 
 * @author Xing Yan
 */
public class LZ {

	private static Archiver arc = new Archiver();

	/**
	 * @param uncompressed
	 *            Treated as 8 bit byte sequence, although String class in java
	 *            is backed by 16 bit char sequence.
	 */
	public static String encode(String uncompressed) {
		
		// convert input String to byte array
		byte input[] = new byte[uncompressed.length()];
		char a[] = uncompressed.toCharArray();
		for (int i = 0; i < a.length; ++i) {
			if (a[i] > 255) {
				throw new IllegalArgumentException("Invalid input");
			}
			input[i] = (byte) a[i];
		}

		byte output[] = arc.encode(input);

		// convert output byte array back to String
		StringBuilder sb = new StringBuilder();
		int i = 0;
		while(i < output.length -1) {
			int hold = 0;
			hold |= ((output[i] & 0xFF) << 8);
			hold |= (output[i + 1] & 0xFF);
			sb.append((char) hold);
			i += 2;
		}
		
		// last byte
		if(i < output.length) {
			sb.append((char) ((output[i] & 0xFF) << 8));
		}
		return sb.toString();
	}

	/**
	 * Input string is converted to byte arrays in big endian representation.
	 */
	public static String decode(String compressed) {
		// convert input String to byte array
		byte input[] = new byte[compressed.length() * 2];
		char a[] = compressed.toCharArray();
		int id = 0;
		for (int i = 0; i < a.length; ++i) {
			char c = a[i];
			
			// high byte first
			input[id++] = (byte) (c >>> 8);
			
			// low byte
			input[id++] = (byte) (c & 0xFF);
		}
		
		byte output[] = arc.decode(input);
		
		// convert back to string
		StringBuilder sb = new StringBuilder();
		for(byte b : output) {
			sb.append((char) b);
		}
		return sb.toString();
	}
}
