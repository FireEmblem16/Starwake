
import java.util.ArrayList;
import java.util.List;

public class LZEncryption {

	static String leftover = "";
	//number of code words
	static int codewords = 0;
	//string of tail characters
	static String tailString;
	//list of all the nodes in the trie
	static ArrayList<Node> nodes = new ArrayList<Node>();
	
	
	private LZEncryption(){}
	/**
	 * 
	 * @param uncompressed the uncompressed string to be encoded
	 * @return the encoded binary string
	 */
	public static String encode(String uncompressed)
	{
		if(uncompressed.equals("")) return "00000000000000000000000000000000";
		nodes = new ArrayList<Node>();
		
		codewords = 0;
		leftover = "";
		String compressed = "";
		Node head = new Node();
		head.pref = null;
		head.phrase = null;
		head.index = 0;
		//head node
		Node check = head;
		int index = 0;
		
		//create the trie structure
		while(index<uncompressed.length())
		{
			String cur = "" + uncompressed.charAt(index);
			index = findPlace(head, ++index, uncompressed, cur);
		}
		
		//number of bits for codeword
		int bitsInCode = (int) Math.ceil(Math.log(codewords+1)/Math.log(2));
		
		//padding bits 0s for 32 bit binary for num of bits in codeword
		for(int i = 0; i < 32 - Integer.toBinaryString(bitsInCode).length(); i++)
			compressed+="0";
		
		compressed+=Integer.toBinaryString(bitsInCode);
		
		//end padding 0's
		int padding = 16 - (bitsInCode*codewords)%16;
		
		for(int i = 0; i < nodes.size(); i++)
		{
			if(i==(nodes.size()-1) && nodes.get(i).phrase == tailString)
			{
				compressed+=binaryize(nodes.get(i).index,bitsInCode);
				compressed+="0000000000000000";
			}
			else
			{
				compressed+=binaryize(nodes.get(i).pref.index,bitsInCode);
				compressed+=binaryize(nodes.get(i).phrase.charAt(nodes.get(i).phrase.length()-1),16);
			}
		}
		
		for(int i = 0; i < padding; i++)
		{
			compressed +="0";
		}
		
		return compressed;
	}
	
	
	/**
	 * 
	 * @param compressed the compressed string to be decoded
	 * @return the decoded string
	 */
	public static String decode(String compressed)
	{
		String uncompressed = "";
		nodes = new ArrayList<Node>();
		int charbits = 16;
		
		Node head = new Node();
		head.pref = null;
		head.phrase = "";
		head.index = 0;
		
		int incodeLength = Integer.parseInt(compressed.substring(0, 32), 2);
		int curIndex = 32;
		String prefIndex = "";
		String phrase = "";
		int nodeIndex = 0;
		String tail = "";
		
		//create the trie
		while(curIndex < compressed.length())
		{
			Node cur = new Node();
			prefIndex = compressed.substring(curIndex, curIndex+incodeLength);
			curIndex+=incodeLength;
			nodeIndex = Integer.parseInt(prefIndex, 2) - 1;
			
			if(nodeIndex < 0)
				cur.pref = head;
			else
				cur.pref = nodes.get(nodeIndex);
			
			if(curIndex+charbits >= compressed.length())break;
			
			phrase = compressed.substring(curIndex, curIndex+charbits);
			curIndex+=charbits;
			
			if(curIndex >= compressed.length())break;
			
			cur.index = nodes.size();
			cur.phrase = cur.pref.phrase+(char)Integer.parseInt(phrase, 2);
			
			nodes.add(cur);
		}
		
		//build the uncompressed string
		for(int i = 0; i < nodes.size(); i++)
		{
			uncompressed += nodes.get(i).phrase;
		}
		
		return uncompressed;
	}

	
	/**
	 * 
	 * @param n Node who's children are being checked to see if they contain the prefix (check)
	 * @param index the index of the next character to be added to the prefix
	 * @param uncompressed the full uncompressed string
	 * @param check the prefix being checked to see if its contained in n's children
	 * @return the index of next char to be looked at
	 */
	private static int findPlace(Node n, int index, String uncompressed, String check)
	{
		if(index > uncompressed.length())
		{
			leftover = check;
			return index;
		}
		if(n.children.size() == 0)
		{
			Node add = new Node();
			add.phrase = check;
			add.pref = n;
			n.children.add(add);
			nodes.add(add);
			codewords++;
			add.index = codewords;
			
			return index;
		}
		for(int i = 0; i< n.children.size(); i++)
		{
			if(n.children.get(i).phrase.equals(check))
			{
				if(index < uncompressed.length())
				{
					check+=uncompressed.charAt(index);
				}
				else
				{
					Node tail = new Node();
					tail.pref = n;
					tail.index = n.children.get(i).index;
					tail.phrase = check;
					tailString = check;
					nodes.add(tail);
				}
				
				index++;
				return findPlace(n.children.get(i), index, uncompressed, check);
			}
		}
		
		Node add = new Node();
		add.phrase = check;
		add.pref = n;
		n.children.add(add);
		nodes.add(add);
		codewords++;
		add.index = codewords;
		
		return index;
	}
	
	/**
	 * 
	 * @param value the int value to be converted into binary
	 * @param bits the number of bits in the binary
	 * @return the binary string
	 */
	private static String binaryize(int value, int bits)
	{
		String binaryized = "";
		String temp = Integer.toBinaryString(value);
		
		for(int i = 0; i < bits-temp.length(); i++)
		{
			binaryized+="0";
		}
		
		binaryized+=temp;
		
		return binaryized;
		
	}
	
}

/**
 * 
 * @author andrewwallace
 *
 *	pref: reference to node containing the prefix
 *	phrase: the phrase contained in the node
 *	index of the node
 *	children: children nodes
 *
 */
class Node
{
	public Node pref;
	public String phrase;
	int index;
	public ArrayList<Node> children = new ArrayList<Node>();
}
