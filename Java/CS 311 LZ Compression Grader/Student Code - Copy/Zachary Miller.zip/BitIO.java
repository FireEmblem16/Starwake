import java.util.ArrayList;
import java.util.LinkedList;

public class BitIO {

	private static ArrayList<Character> charList;
	private static char charUnderConstruction;
	private static char bitUnderConstruction;
	
	public static String createStringFromTuples(int dictionarySize, LinkedList<Tuple> tuples) {
		/* Handle the empty string. */
		int numBitsPerCode = 0;
		if (dictionarySize == 2) {
			numBitsPerCode = 1;
		} else if (dictionarySize > 2) {
			numBitsPerCode = (int) Math.ceil(Math.log(dictionarySize) / Math.log(2));
		}
		
		charList = new ArrayList<Character>();
		charUnderConstruction = 0x0000;
		bitUnderConstruction = 0;
		writeBits(32, numBitsPerCode);
		
		Integer code = 0;
		Character ch = 0;
		Tuple t = null;
		while (tuples.isEmpty() == false) {
			t = tuples.removeFirst();
			code = t.getCode();
			if (code != null) {
				writeBits(numBitsPerCode, code);
			}
			ch = t.getCharacter();
			if (ch != null) {
				writeBits(16, ch);
			}
		}
		
		String compressed = new String(getChars());
		charList = null;
		charUnderConstruction = 0x0000;
		bitUnderConstruction = 0;
		return compressed;
	}
	
	public static void writeBits(int numBits, int value) {
		if (numBits > 32) {
			throw new IllegalArgumentException("You can write at most 32 bits at a time.");
		} else if (value > ((int) (Math.pow(2,numBits) - 1))) {
			throw new IllegalArgumentException("The number of bits to write must be large enough to hold value.");
		}
		
		for (int i = 0; i < numBits; i++) {
			int valueOfNextBit = ((value >> (numBits - 1 - i)) & 0x00000001);
			charUnderConstruction |= createMask(bitUnderConstruction, valueOfNextBit);
			bitUnderConstruction += 1;
			if (bitUnderConstruction == 16) {
				charList.add(charUnderConstruction);
				charUnderConstruction = 0x0000;
				bitUnderConstruction = 0;
			}
		}
	}
	
	private static char createMask(int pos, int value) {
		char temp = (char) value;
		temp <<= (15 - pos);
		return temp;
	}
	
	private static char[] getChars() {
		int size = charList.size();
		char[] array;
		if (bitUnderConstruction != 0) {
			size += 1;
			array = new char[size];
			for (int i = 0; i < size - 1; i++) {
				array[i] = charList.get(i);
			}
			array[size - 1] = charUnderConstruction;
		} else {
			array = new char[size];
			for (int i = 0; i < size; i++) {
				array[i] = charList.get(i);
			}
		}
		
		return array;
	}
	
	private static char chars[];
	private static int bitToRead;
	private static int bitsRead;
	
	public static LinkedList<Tuple> createTuplesFromString(String toDecode) {
		chars = toDecode.toCharArray();
		bitToRead = 0;
		bitsRead = 0;
		int numBitsPerCode = readBits(32);
		bitsRead = 32;
		
		LinkedList<Tuple> tuples = new LinkedList<Tuple>();
		
		int totalBits = chars.length * 16;
		while (bitsRead + numBitsPerCode < totalBits) {
			
			int code = readBits(numBitsPerCode);
			bitsRead += numBitsPerCode;
			Tuple t = new Tuple(code, null);
			if (bitsRead + 16 < totalBits) {
				char ch = (char) readBits(16);
				bitsRead += 16;
				t.setCharacter(ch);
			}
			
			tuples.add(t);
		}
		
		chars = null;
		bitToRead = 0;
		bitsRead = 0;
		return tuples;
	}
	
	private static int readBits(int numBits) {
		if (numBits > 32) {
			throw new IllegalArgumentException("You can read at most 32 bits at a time.");
		} else if (bitToRead + numBits > chars.length * 16) {
			throw new ArrayIndexOutOfBoundsException("Not enough unread bits in array of bytes.");
		} 
		
		int value = 0x00000000;
		for (int i = 0; i < numBits; i++) {
			value <<= 1;
			value |= ((chars[bitToRead/16]) >> (15 - (bitToRead%16))) & 0x00000001;
			bitToRead += 1;
		}
		
		return value;
	}
	
}
