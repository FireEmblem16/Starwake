public interface LZDictionary {

	/* 
	 * Returns true if the given prefix was added to the dictionary.
	 * Otherwise false.
	 */
	public boolean addPrefix(String prefix);
	
	/*
	 * Returns the code for the given prefix.
	 * If the prefix does not exist in the dictionary, -1 is returned.
	 */
	public int getPrefixCode(String prefix);
	
	/*
	 * Returns the prefix for the given code.
	 * If the prefix does not exist in the dictionary, null is returned.
	 */
	public String getPrefix(int id);
	
	/*
	 * Returns the size of the dictionary.
	 */
	public int size();
	
}
