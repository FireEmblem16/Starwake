import java.util.ArrayList;
import java.util.HashMap;
import java.util.Stack;

public class TrieDictionary implements LZDictionary {

	/* 
	 * The root node of the trie.
	 */
	private TrieNode root;
	
	/*
	 * The unique ID given to the prefix that was most recently added to the Trie.
	 */
	private int nextPrefixID;
	
	/*
	 * An index of TrieNodes, each of which makes up the last character of a prefix.
	 * Ordered by the prefixId of the TrieNodes. Thus the root TrieNode is the first element
	 * of index, and the TrieNode with newestPrefixID is the last.
	 */
	private ArrayList<TrieNode> index;
	
	/*
	 * Initializes the Trie. The root node has no parent, contains the empty string, and has the prefixId 0.
	 */
	public TrieDictionary() {
		this.nextPrefixID = 0;
		this.index = new ArrayList<TrieNode>();
		int id = nextPrefixID++;
		this.root = new TrieNode(null, "", id);
		this.index.add(id, root);
	}
	
	/* 
	 * Returns true if the given prefix was added to the dictionary.
	 * Otherwise false.
	 */
	@Override
	public boolean addPrefix(String prefix) {
		if (prefix == null || prefix.equals("")) {
			return false;
		}
		
		TrieNode current = root;
		int i = 0;
		for (i = 0; i < prefix.length() - 1; i++) {
			current = current.getChild(Character.toString(prefix.charAt(i)));
			if (current == null) {
				throw new IllegalArgumentException("A string can only be added as a prefix if each of its prefixes are already in the dictionary.");
			}
		}
		
		if (current.getChild(Character.toString(prefix.charAt(i))) == null) {
			int id = nextPrefixID++;
			TrieNode child = current.addChild(id, Character.toString(prefix.charAt(i)));
			index.add(child);
			return true;
		}
		
		return false;
	}

	/*
	 * Returns the code for the given prefix.
	 * If the prefix does not exist in the dictionary, -1 is returned.
	 */
	@Override
	public int getPrefixCode(String prefix) {
		TrieNode current = root;
		TrieNode next = null;
		for (char c : prefix.toCharArray()) {
			next = current.getChild(Character.toString(c));
			if (next == null) {
				return -1;
			}
			current = next;
		}
		return current.getPrefixID();
	}

	/*
	 * Returns the prefix for the given code.
	 * If the prefix does not exist in the dictionary, null is returned.
	 */
	@Override
	public String getPrefix(int id) {
		if (id > index.size()) {
			return null;
		}
		
		TrieNode current = index.get(id);
		Stack<String> stack = new Stack<String>();
		String prefix = "";
	
		while (current != null) {
			stack.push(current.getKey());
			current = current.getParent();
		}
		
		while (stack.isEmpty() == false) {
			prefix += stack.pop();
		}
		
		return prefix;
	}
	
	@Override
	public int size() {
		return nextPrefixID;
	}
	
	/*
	 * Inner class representing each node of the trie.
	 */
	private class TrieNode {
		
		/*
		 * The parent node of this TrieNode.
		 */
		private TrieNode parent;
		
		/*
		 * A hashmap containing the child nodes of this TrieNode.
		 */
		private HashMap<String, TrieNode> children;
		
		/*
		 * The character (stored as a string) which this TrieNode represents.
		 */
		private String key;
		
		/*
		 * The unique identifier for this TrieNode.
		 */
		private int prefixID;
		
		/*
		 * Initializes the TrieNode to have the given parent, key, and prefixID.
		 */
		private TrieNode(TrieNode parent, String key, int prefixID) {
			this.parent = parent;
			this.key = key;
			this.prefixID = prefixID;
			this.children = new HashMap<String, TrieNode>();
		}
		
		/*
		 * Returns the parent of this TrieNode.
		 */
		private TrieNode getParent() {
			return parent;
		}
		
		/*
		 * Returns the key of this TrieNode.
		 */
		private String getKey() {
			return key;
		}
		
		/*
		 * Returns the prefixID of this TrieNode.
		 */
		private int getPrefixID() {
			return prefixID;
		}
		
		/*
		 * Adds a child TrieNode with the given key and prefixID to this TrieNode.
		 */
		public TrieNode addChild(int prefixID, String key) {
			TrieNode child = new TrieNode(this, key, prefixID);
			children.put(key, child);
			return child;
		}
		
		/*
		 * Returns the child of this TrieNode who has the given key.
		 */
		public TrieNode getChild(String key) {
			return children.get(key);
		}
		
	}

}
