import java.util.LinkedList;

public class LZEncryption {
	
	private LZEncryption() {}
	
	public static String encode(String uncompressed) {
		return compressString(new TrieDictionary(), uncompressed);
	}
	
	public static String decode(String compressed) {
		return uncompressString(new TrieDictionary(), compressed);
	}
	
	protected static String compressString(LZDictionary dictionary, String toEncode) {
		LinkedList<Tuple> tuples = new LinkedList<Tuple>();
		String prefix = "";
		int code;
		
		for (char c : toEncode.toCharArray()) {
			prefix += Character.toString(c);
			if (dictionary.addPrefix(prefix) == true) {
				 code = dictionary.getPrefixCode(prefix.substring(0,prefix.length() - 1));
				 tuples.add(new Tuple(code, c));
				 prefix = "";
			}
		}
		
		if (prefix != "") {
			code = dictionary.getPrefixCode(prefix);
			tuples.add(new Tuple(code, null));
		}
		return BitIO.createStringFromTuples(dictionary.size(), tuples);
	}
	
	protected static String uncompressString(LZDictionary dictionary, String toDecode) {
		LinkedList<Tuple> tuples = BitIO.createTuplesFromString(toDecode);
		String decoded = "";		
		String prefix = "";

		for (Tuple t : tuples) {
			if (t.getCharacter() == null) {
				decoded += dictionary.getPrefix(t.getCode());
				break;
			}
			
			prefix = (dictionary.getPrefix(t.getCode()) + t.getCharacter());
			dictionary.addPrefix(prefix);
			decoded += prefix;
		}
		
		return decoded;
	}

}
