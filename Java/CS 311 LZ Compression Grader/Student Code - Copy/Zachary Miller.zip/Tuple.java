/* Class used to store Lookup Code / Character combos. */
public class Tuple {

	Integer code;
	Character ch;
	
	public Tuple(Integer code, Character ch) {
		this.code = code;
		this.ch = ch;
	}
	
	public void setCode(Integer code) {
		this.code = code;
	}
	
	public Integer getCode() {
		return code;
	}
	
	public void setCharacter(Character ch) {
		this.ch = ch;
	}
	
	public Character getCharacter() {
		return ch;
	}

}
