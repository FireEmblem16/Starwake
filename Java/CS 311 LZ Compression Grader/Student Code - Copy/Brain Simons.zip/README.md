## LZ78 Compression Algorithm
ComS 311 programming assignment
