import java.util.ArrayList;


public class Trie {
	private Node root = new Node('\0', 0, null);
	private int codewords = 0;
	public Trie(){
		
	}
	public int getNumCodewords(){
		return codewords;
	}
	
	public String getStringForCodeword(int codeword) throws Exception{
		if(codeword == 0) return "";
		Node current = root;
		ArrayList<Node> q = root.children;
		boolean found = false;
		for(int i = 0; i < q.size(); i++){
			current = q.get(i);
			if(current.codeword==codeword){
				found = true;
				break;				
			}
			q.addAll(current.children);
		}
		if(!found){
			throw new Exception("Codeword not found : "+codeword);
		}
		String ret = "";
		Node parent = current.getParent();
		ret = current.data + ret;
		while(parent != null){
			if(parent.data == '\0'){
				ret =""+ ret;
				parent = parent.getParent();
			}
			else{
				ret = parent.data+ ret;
				parent = parent.getParent();
			}
		}
		return ret;
	}
	
	public boolean containsString(String s){
		Node current = root;
		for(int i = 0; i < s.length();i++){
			if(current.containsChild(s.charAt(i))){
				current = current.getChild(s.charAt(i));
			}
			else{
				return false;
			}
		}
		return true;
	}
	
	public int addString(String s) throws Exception{
		Node current = root;
		if(!containsString(s.substring(0, s.length()-1))){
			throw new Exception("Cannot add string: " + s);
		}
		for(int i = 0; i < s.length()-1;i++){
			if(current.containsChild(s.charAt(i))){
				current = current.getChild(s.charAt(i));
			}
			else{
				throw new Exception("Cannot add string: " + s);
			}
		}
		int code = current.codeword;
		codewords++;
		current.addChild(s.charAt(s.length()-1), codewords);
		
		return code;
	}
	

	public int getCodeword(String s) throws Exception {
		Node current = root;
		for(int i = 0; i < s.length();i++){
			if(current.containsChild(s.charAt(i))){
				current = current.getChild(s.charAt(i));
			}
			else{
				throw new Exception("Cannot find codeword for " + s);
			}
		}
		return current.codeword;
	}
	
	private class Node{
		private char data;
		private int childCount = 0;
		public int codeword;
		private Node parent;
		public ArrayList<Node> children = new ArrayList<Node>();
		public Node(char s, int c, Node p){
			data = s;
			codeword = c;
			parent = p;
		}
		
		public void addChild(char c, int code) throws Exception{
			if(childCount >= 256){
				throw new Exception("Trie children overflow");
			}
			Node n = new Node(c, code, this);
			children.add(n);
			childCount++;
		}
		
		private boolean containsChild(char c){
			for(int i = 0; i < children.size();i++){
				if(children.get(i).data == c){
					return true;
				}
			}
			return false;
		}
		
		private Node getChild(char c){
			for(int i = 0; i < children.size();i++){
				if(children.get(i).data == c){
					return children.get(i);
				}
			}
			return null;
		}
		public Node getParent(){
			return parent;
		}
		
		
	}

}
