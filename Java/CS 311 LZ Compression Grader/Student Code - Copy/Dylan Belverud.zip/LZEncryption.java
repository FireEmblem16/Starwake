import java.util.ArrayList;


public class LZEncryption {
		
	
	private LZEncryption(){

	}
	
	public String encode(String uncompressed) throws Exception{
		Trie dict = new Trie();
		String out = "";
		int current = 0;
		int next = current+1;
		ArrayList<Integer> codewords  = new ArrayList<Integer>();
		String chars = "";
		
		while(next <= uncompressed.length()){
			String sub = uncompressed.substring(current, next);
			if(dict.containsString(sub)){
				next++;
			}
			else{
				int temp = dict.addString(sub);
				codewords.add(temp);
				chars += sub.charAt(sub.length()-1);
				current = next;
				next = current+1;
			}
		}
		if(next - current > 1){
			codewords.add(dict.getCodeword(uncompressed.substring(current)));
		}
		int needed = this.neededBitsForCodeword(dict.getNumCodewords());
		
		out += this.intToBinaryString(needed, 32);
		for(int i = 0; i < codewords.size(); i++){
			out += this.intToBinaryString(codewords.get(i), needed);
			if(i < chars.length()){
				out += this.intToBinaryString(chars.charAt(i), 16);
			}
		}
		int rem =16 - (out.length() %16);
		if(!(rem >= 16)){
			out += intToBinaryString(0,rem);
		}
		return FromBinary(out);		
	}
	
	public String decode(String compressed) throws Exception{
		compressed = ToBinary(compressed);
		Trie dict = new Trie();
		if(compressed.length() < 33){
			throw new Exception("String is not long enough to be a legal compression");
		}
		String sub = compressed.substring(0, 32);
		int codewordBits = binaryStringToInt(sub);
		int i = 32;
		String out = "";
		while(i+codewordBits < compressed.length()){
			int code = binaryStringToInt(compressed.substring(i, i+codewordBits));
			i += codewordBits;
			String temp = dict.getStringForCodeword(code);
			out+=temp;
			if(!(i + 16 > compressed.length())){
				char c  = (char) binaryStringToInt(compressed.substring(i,i+16));
				i += 16;
				dict.addString(temp+c);
				out+=c;
			}
			
			
		}
		
		return out;	
	}
	
	private int neededBitsForCodeword(int num){
		int i = 0;
		while(Math.pow(2, i) < num){
			i++;
		}
		return i;
	}
	
	private int binaryStringToInt(String in){
		int j = 0;
		int sum = 0;
		for(int i = in.length()-1; i >=0; i--){
			if(in.charAt(i)=='1'){
				sum+=Math.pow(2, j);
			}
			j++;
		}
		return sum;
	}
	
	private String intToBinaryString(int toBin, int offset){
		String out = "";
		while(toBin >0){
			out = toBin %2 + out;
			toBin /= 2;
			if(out.length() >= offset){
				return out;
			}
		}
		for(int i = out.length(); i < offset; i++){
			out = "0" + out;
		}
		return out;
	}
	
	//CODE PROVIDED BY DON NYE THE T.A. GUY
	public static String FromBinary(String str)
	{
		final char[] bits = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i += 16)
		{
			char c = 0x0000;
			
			for(int j = 0;j < 16;j++)
				if(str.charAt(i + j) == '1')
					c |= bits[j];
			
			ret += c;
		}
		
		return ret;
	}
	
	//CODE PROVIDED BY DON NYE THE T.A. GUY	
	public static String ToBinary(String str)
	{
		final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i++)
		{
			char c = str.charAt(i);
			
			for(int j = 0;j < 16;j++)
				if((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}
		
		return ret;
	}
}
