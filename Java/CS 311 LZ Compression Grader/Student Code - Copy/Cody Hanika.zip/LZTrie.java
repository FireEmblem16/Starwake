import java.util.Arrays;
import java.util.LinkedList;

/**
 * A trie data structure specialized for the LZ compression algorithm
 * @author Cody Hanika
 *
 */
public class LZTrie implements LZDictionary{

	private int size;
	private TrieNode rootNode;
	
	public LZTrie() {
		this.size = 1;
		this.rootNode = new TrieNode(LZDictionary.LAMBDA, 0, null);		
	}
	
	@Override
	public void add(String newString) {
		TrieNode parentNode = rootNode;
		for (int i = 0; parentNode.children[newString.charAt(i)] != null; ++i) {
			parentNode = parentNode.children[newString.charAt(i)];
		}
		char newChar = newString.charAt(newString.length() - 1);
		parentNode.children[newChar] = new TrieNode(newChar, this.size, parentNode);
		++this.size;
	}

	@Override
	public int indexOf(String searchString) {
		int i;
		TrieNode currentNode = rootNode;
		for (i = 0; i < searchString.length() && currentNode.children[searchString.charAt(i)] != null; ++i) {
				currentNode = currentNode.children[searchString.charAt(i)];
		}
		if (i == searchString.length()) {
			return currentNode.index;
		} else {
			return -1;
		}
	}

	@Override
	public int newWordIndex(String searchString, int startIndex) {
		TrieNode currentNode = rootNode;
		int newCharIndex;
		for (newCharIndex = startIndex; newCharIndex < searchString.length() && 
				currentNode.children[searchString.charAt(newCharIndex)] != null; ++newCharIndex) {
			currentNode = currentNode.children[searchString.charAt(newCharIndex)];
		}
		return newCharIndex;
	}
	
	@Override
	public String getString(int index) {
		if (index == 0) {
			return "";
		}
		// BFS
		LinkedList<TrieNode> queue = new LinkedList<TrieNode>();
		queue.add(this.rootNode);
		TrieNode indexNode = rootNode;
		while(!queue.isEmpty()) {
			TrieNode current = queue.removeFirst();
			if (current.index == index) {
				indexNode = current;
				break;
			}
			for(TrieNode node : current.children) {
				if (node != null) {
					queue.addLast(node);
				}
			}
		}
		if (indexNode.equals(rootNode)) {
			return null;
		}
		StringBuilder builder = new StringBuilder();
		TrieNode parent = indexNode;
		while (parent != rootNode) {
			builder.append(parent.value);
			parent = parent.parent;
		}
		builder = builder.reverse();
		return builder.toString();
	}

	@Override
	public int size() {
		return this.size;
	}
	
	/**
	 * Structure for each node 
	 */
	private static class TrieNode {
		public char value;
		public int index;
		public TrieNode[] children;
		public TrieNode parent;
		
		public TrieNode(char value, int index, TrieNode parent) {
			this.index = index;
			this.value = value;
			this.children = new TrieNode[256];
			this.parent = parent;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + Arrays.hashCode(children);
			result = prime * result + index;
			result = prime * result
					+ ((parent == null) ? 0 : parent.hashCode());
			result = prime * result + value;
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			TrieNode other = (TrieNode) obj;
			if (!Arrays.equals(children, other.children))
				return false;
			if (index != other.index)
				return false;
			if (parent == null) {
				if (other.parent != null)
					return false;
			} else if (!parent.equals(other.parent))
				return false;
			if (value != other.value)
				return false;
			return true;
		}
	}
}
