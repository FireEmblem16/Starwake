/**
 * 
 * @author Cody Hanika
 *
 */
public interface LZDictionary {
	
	/**
	 * Used to represent empty string
	 */
	public static final char LAMBDA = (char) 0;
	
	/**
	 * Add the the newString to the dictionary. This method assumes that the string
	 * newString.substring(0, newString.length() - 2) is already in the dictionary
	 * @param newString
	 */
	public void add(String newString);
	
	/**
	 * Returns the integer index of the searchString in the dictionary
	 * @param searchString
	 * @return The integer index of the searchString in the dictionary, or -1 if it is not found
	 */
	public int indexOf(String searchString);
	
	/**
	 * Returns the first index in the string &gt startIndex in which the substring from startIndex
	 * to this returned index creates a word that is not in the dictionary
	 * @param searchString
	 * @param startIndex
	 * @return The index of the first character that creates a new word, or -1 if no new word is created 
	 * when reaching the end of the string
	 */
	public int newWordIndex(String searchString, int startIndex);	
	
	/**
	 * Returns the string that matches the given index
	 * @param index
	 * @return -1 if the string is not present
	 */
	public String getString(int index);
	
	
	/**
	 * The number of strings in the dictionary
	 * @return
	 */
	public int size();
	
	
	public static class LZItem {
		int index;
		char value;
		public LZItem(int index, char value) {
			this.index = index;
			this.value = value;
		}
	}
}
