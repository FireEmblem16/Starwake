import java.util.LinkedList;
import java.util.List;

/**
 * Provides methods implementing the Lempel-Ziv Compression Algorithm.
 * @author Cody Hanika
 */
public class LZEncryption {
	
	private LZEncryption() {
		// Non-instantiable
	}
	
	public static String encode(String uncompressed) {
		List<CompressionItem> compressList = new LinkedList<CompressionItem>();
		LZDictionary dict = new LZTrie();
		int currentIndex = 0;
		int newIndex = 0;
		boolean lastIsJustPrefix = false;
		// build list of compression items
		while (currentIndex < uncompressed.length()) {
			newIndex = dict.newWordIndex(uncompressed, currentIndex);
			int prefixIndex = dict.indexOf(uncompressed.substring(currentIndex, newIndex));
			// if newIndex == uncompressed.length() then the last substring of uncompressed is just a repeated prefix
			if (newIndex == uncompressed.length()) {
				compressList.add(new CompressionItem(prefixIndex, LZDictionary.LAMBDA));
				lastIsJustPrefix = true;
			} else {
				compressList.add(new CompressionItem(prefixIndex, uncompressed.charAt(newIndex)));
				dict.add(uncompressed.substring(currentIndex, newIndex + 1));
			}
			currentIndex = newIndex + 1;
		}
		// build output string
		int indexSize = (int)Math.ceil(Math.log(dict.size()) / Math.log(2));
		// bitCount = 32 + # of prefixes * (size of prefix + 16 bits for each char)
		int bitCount = 32 + compressList.size() * (16 + indexSize) - (lastIsJustPrefix ? 16 : 0);
		int padding = bitCount % 16 == 0 ? 0 : 16 - (bitCount % 16);
		bitCount += padding;
		byte[] outputBytes = new byte[bitCount / 8];
		int i = 0;
		for (int j = 0; j < 32; ++j) {
			if ((indexSize << j & 0x80000000) == 0x80000000) {
				outputBytes[i / 8] |= 1 << (7 - (i % 8)); 
			}
			++i;
		}
		for (CompressionItem compItem : compressList) {
			for (int j = 0; j < indexSize; ++j) {
				if ((compItem.prefixIndex << (32 - indexSize + j) & 0x80000000) == 0x80000000) {
					outputBytes[i / 8] |= 1 << (7 - (i % 8)); 
				}
				++i;
			}
			if (compItem.value == LZDictionary.LAMBDA) {
				continue;
			}
			for (int j = 0; j < 16; ++j) {
				if ((compItem.value << j & 0x8000) == 0x8000) {
					outputBytes[i / 8] |= 1 << (7 - (i % 8)); 
				}
				++i;
			}
		}
		return StringFromBytes(outputBytes);
	}
	
	/**
	 * Decodes an LZ-encoded string. Assumes the string is correctly encoded.
	 * @param compressed
	 * @return
	 */
	public static String decode(String compressed) {
		// build compression item list and dictionary
		List<CompressionItem> compressionList = new LinkedList<CompressionItem>();
		LZDictionary dict = new LZTrie();
		byte[] compBytes = BytesFromString(compressed);
		int indexSize = (compBytes[0] << 24) | (compBytes[1] << 16) | (compBytes[2] << 8) | compBytes[3];
		for (int i = 32; (compBytes.length * 8 - i) > indexSize;) {
			int prefixIndex = 0;
			char value = 0;
			for (int j = 0; i < compBytes.length * 8 && j < indexSize; ++j) {
				prefixIndex |= (getBitAt(compBytes, i) ? 1 : 0) << (indexSize - 1 - j);
				++i;
			}
			if ((compBytes.length * 8 - i) < 16) {
				compressionList.add(new CompressionItem(prefixIndex, LZDictionary.LAMBDA));
				break;
			}
			for (int j = 0; j < 16; ++j) {
				value |= (char) ((getBitAt(compBytes, i) ? 1 : 0) << (16 - 1 - j));
				++i;
			}
			compressionList.add(new CompressionItem(prefixIndex, value));
			dict.add(dict.getString(prefixIndex) + value);
		}

		// reconstruct string
		StringBuilder decodedString = new StringBuilder();
		for (CompressionItem compItem : compressionList) {
			String compItemString = compItem.value == LZDictionary.LAMBDA ? 
					dict.getString(compItem.prefixIndex) : dict.getString(compItem.prefixIndex) + compItem.value;
			decodedString.append(compItemString);
		}
		return decodedString.toString();
	}
	
	private static boolean getBitAt(byte[] arr, int i) {
		return ((arr[i / 8] << i % 8) & 0x80) == 0x80;
	}
	
	/**
	 * @author Don Nye
	 */
	public static String StringFromBytes(byte[] b) {
		final char[] masks = {0x8000, 0x4000, 0x2000, 0x1000, 0x800, 0x400, 0x200, 0x100, 0x80, 0x40, 0x20, 0x10, 0x8, 0x4, 0x2, 0x1};
		String ret = "";
		for (int i = 0; i < b.length; i += 2) {
			char c = 0x0;
			for (int j = 0; j < 16; j++) {
				c |= ((b[i + j / 8] << (j < 8 ? 8 : 0)) & masks[j]);
			}
			ret += c;
		}
		return ret;
	}
	
	/**
	 * @author Don Nye
	 */
	public static byte[] BytesFromString(String str) {
		if (str == null || str.equals(""))
			return new byte[0];
		byte[] ret = new byte[str.length() << 1];
		for (int i = 0; i < str.length(); i++) {
			ret[i << 1] = (byte) ((str.charAt(i) >> 8) & 0xFF);
			ret[(i << 1) + 1] = (byte)(str.charAt(i) & 0xFF);
		}
		return ret;
	}
	
	private static class CompressionItem {
		int prefixIndex;
		char value;
		
		public CompressionItem(int prefixIndex, char value) {
			this.prefixIndex = prefixIndex;
			this.value = value;
		}
	}
}
