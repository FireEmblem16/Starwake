
public class Pair {
	private int index;
	private String value;
	
	public Pair(int ind, String val){
		setIndex(ind);
		setValue(val);
	}

	public String getValue() {
		return value;
	}

	private void setValue(String value) {
		this.value = value;
	}

	public int getIndex() {
		return index;
	}

	private void setIndex(int index) {
		this.index = index;
	}
}
