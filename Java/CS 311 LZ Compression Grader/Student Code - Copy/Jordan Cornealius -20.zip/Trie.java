
import java.util.ArrayList;

public class Trie {
	private int index;
	private String value;
	private Trie parent;
	private ArrayList<Trie> children;
	
	public Trie(int index, String value, Trie parent){
		this.index = index;
		this.value = value;
		this.setParent(parent);
		children = new ArrayList<Trie>();
	}
	
	public void addChild(int index, String value){
		children.add(new Trie(index, value, this));
	}
	
	public String getVal(int index){
		String ret = "";
		if(index == this.index){
			return ret + value;
		}else{
			for(int i = 0; i < children.size(); i++){
				ret = children.get(i).getVal(index);
				if(ret != "") return value + ret;
			}
			return ret;
		}
	}
	
	public Trie getTrie(int index){
		if(index == this.index) return this;
		Trie ret = null;
		for(int i = 0; i < children.size(); i++){
			ret = children.get(i).getTrie(index);
			if(ret != null) return ret;
		}
		return ret;
	}
	
	public Trie childHasVal(String val){
		Trie ret = null;
		if(children != null){
			for(int i = 0; i < children.size(); i++){
				if(val.compareTo(children.get(i).getValue()) == 0){
					return children.get(i);
				}
			}
		}
		return ret;
	}

	private String getValue() {
		return value;
	}

	public Trie getParent() {
		return parent;
	}

	public int getIndex(){
		return index;
	}
	
	private void setParent(Trie parent) {
		this.parent = parent;
	}
}
