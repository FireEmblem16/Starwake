
import java.util.ArrayList;

public class LZ {
	private LZ(){
		
	}
	
	public static String encode(String uncompressed){
		String compressed = "";
		Trie head = new Trie(0, "", null);
		ArrayList<Pair> pairs = new ArrayList<Pair>();
		int index = 0;
		Trie temp = null;
		int indsize = 0;
		
		for(int i = 0; i < uncompressed.length(); i++){
			temp = head.childHasVal("" + uncompressed.charAt(i)) ;
			if(temp == null){
				index++;
				head.addChild(index, "" + uncompressed.charAt(i));
				pairs.add(new Pair(0, "" + uncompressed.charAt(i)));
			}else{
				if(i < uncompressed.length()-1){
					i++;
					while(temp.childHasVal("" + uncompressed.charAt(i)) != null && i < uncompressed.length()-1){
						temp = temp.childHasVal("" + uncompressed.charAt(i));
						i++;
					}
					index++;
					temp.addChild(index, "" + uncompressed.charAt(i));
					pairs.add(new Pair(temp.getIndex(), "" + uncompressed.charAt(i)));
				}else{
					pairs.add(new Pair(temp.getParent().getIndex(), "" + uncompressed.charAt(i)));
				}
			}
		}
		
		while(index > 0){
			indsize++;
			index /= 2;
		}
		compressed += BinStringUtil.BinStringFromInt(indsize, 32);
		for(int i = 0; i < pairs.size(); i++){
			compressed += BinStringUtil.BinStringFromInt(pairs.get(i).getIndex(), indsize);
			compressed += BinStringUtil.ToBinary("" + pairs.get(i).getValue());
		}
		while(compressed.length() % 16 != 0) compressed += "0";
		compressed = BinStringUtil.FromBinary(compressed);
		return compressed;
	}
	
	public static String decode(String compressed){
		String uncompressed = "";
		Trie head = new Trie(0, "", null);
		ArrayList<Pair> pairs = new ArrayList<Pair>();		
		String indSizeStr = "";
		String indStr;
		String valStr;
		String val;
		int ind;
		int indSize;
		int index = 0;
		
		compressed = BinStringUtil.ToBinary(compressed);
		
		for(int i = 0; i < 32; i++){
			indSizeStr += compressed.charAt(i);
		}
		indSize = BinStringUtil.BinStringToInt(indSizeStr);
		for(int i = 32; i < compressed.length();){
			indStr = "";
			valStr = "";
			for(int j = 0; j < indSize && i < compressed.length(); j++){
				indStr += compressed.charAt(i);
				i++;
			}
			for(int j = 0; j < 16 && i < compressed.length(); j++){
				valStr += compressed.charAt(i);
				i++;
			}
			if(i >= compressed.length()) break;
			ind = BinStringUtil.BinStringToInt(indStr);
			val = BinStringUtil.FromBinary(valStr);
			pairs.add(new Pair(ind, val));
			index++;
			head.getTrie(ind).addChild(index, val);
		}
		for(int i = 0; i < pairs.size(); i++){
			uncompressed += head.getVal(pairs.get(i).getIndex()) + pairs.get(i).getValue();
		}
		
		return uncompressed;
	}

}
