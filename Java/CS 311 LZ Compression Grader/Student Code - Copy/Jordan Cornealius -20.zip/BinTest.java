
import static org.junit.Assert.*;

import org.junit.Test;

public class BinTest {

	@Test
	public void testBinStringFromInt() {
		int i, j, k;
		String si, sj, sk;
		
		i = 7;
		si = "111";
		
		j = 9;
		sj = "1001";
		
		k = 11;
		sk = "1011";
		
		assertEquals(BinStringUtil.BinStringFromInt(i), si);
		assertEquals(BinStringUtil.BinStringFromInt(j), sj);
		assertEquals(BinStringUtil.BinStringFromInt(k), sk);
	}

	@Test
	public void testBinStringToInt() {
		int i, j, k;
		String si, sj, sk;
		
		i = 5;
		si = "101";
		
		j = 15;
		sj = "1111";
		
		k = 21;
		sk = "10101";
		
		assertEquals(BinStringUtil.BinStringToInt(si), i);
		assertEquals(BinStringUtil.BinStringToInt(sj), j);
		assertEquals(BinStringUtil.BinStringToInt(sk), k);
	}

}
