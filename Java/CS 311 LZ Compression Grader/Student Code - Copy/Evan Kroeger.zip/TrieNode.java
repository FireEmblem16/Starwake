//@author Evan Kroeger
//Trie class. Each node contains a character, 
//links to nodes in its branch, 
//bool to signify if the node has no children, 
//and an index which indicates what phrase it belongs to.
public class TrieNode
{
	char c;
	TrieNode[] links;
	TrieNode parent;
	boolean end;
	int index;
	
	public TrieNode(char c, boolean end, int index)
	{
		this.c = c;
		links = new TrieNode[256];
		this.end = end;
		this.index = index;
		this.parent = null;
	}
	
	
}
