// @author Evan Kroeger
// LZ78 compression encoding/decoding
// References used on the LZ78 method:
//	http://oldwww.rasip.fer.hr/research/compress/algorithms/fund/lz/lz78.html
//	http://cis.cs.technion.ac.il/Done_Projects/Projects_done/VisionClasses/DIP_1998/Lossless_Compression/node17.html
//


import java.util.ArrayList;

public class LZ {

	private LZ() {

	}

	// dictionary, last node traversed, number of phrases
	private static TrieNode dict;
	private static TrieNode last;
	private static int index = 1;

	public static String encode(String uncompressed) {
		// lambda
		if (uncompressed.equals("")) {
			return "00000000000000000000000000000000";
		}
		// reset dictionary
		dict = new TrieNode('\0', false, 0);
		char[] arr = uncompressed.toCharArray();
		String prefix = "";
		String compressed = "";
		char lastc = ' ';

		// cycle through input string
		for (int i = 0; i < arr.length; i++) {
			// if prefix + current char is in dictionary, concat c to p
			char current = arr[i];
			if (searchDict(prefix + current)) {
				prefix += current;
				lastc = current;
			} else {
				//word is not in dict
				//mark integer with '' and binary encode char
				String codeword = "'"
						+ last.index
						+ "'"
						+ ("0000000000000000" + Integer.toBinaryString(current))
								.substring(Integer.toBinaryString(current)
										.length());
				compressed += codeword;
				insertWord(prefix + current);
				prefix = "";
			}

		}

		//number of bits to represent integers
		int num = (int) Math.ceil((Math.log(index + 1) / Math.log(2)));

		//padding
		String padding = "";
		for (int i = 0; i < num; i++) {
			padding += "0";
		}
		
		//go through string and represent each index by the proper number of bits
		String fin = "";
		char[] com = compressed.toCharArray();
		int flag = -1;
		for (int i = 0; i < com.length; i++) {
			//look for ints inside single quotes
			if (com[i] == '\'') {
				if (flag != -1) {
					String tmp = "";
					for (int j = flag + 1; j < i; j++) {
						tmp += com[j];
					}
					//convert to proper number of bits
					int toConv = Integer.parseInt(tmp);
					String bin = (padding + Integer.toBinaryString(toConv))
							.substring(Integer.toBinaryString(toConv).length())
							+ padding.substring(0, i - flag);
					fin += bin;
					i += (i - flag);
					flag = -1;
				} else {
					//flag marks reading of index, and position
					flag = i;
				}
			} else {
				//add char if not dealing with index
				if (flag == -1)
					fin += com[i];
			}
		}

		// handle remaining prefix (case that last phrase wasnt unique)
		if (!prefix.equals("")) {
			fin += (padding + Integer
					.toBinaryString(last.links[getAscii(lastc)].index))
					.substring(Integer.toBinaryString(
							last.links[getAscii(lastc)].index).length());
			int z = 0;
			while(z < fin.length()%16)
			{
				fin += "0";
				z++;
			}
		} else {
			//ensure string is divisible by 16
			int z = 0;
			while(z < fin.length()%16)
			{
				fin += "0";
				z++;
			}
		}

		//32 bit encoding of number of bits
		String n = Integer.toBinaryString(num);
		if (n.length() < 32) {
			for (int i = n.length(); i < 32; i++) {
				n = "0" + n;
			}
		}

		return n + fin;
	}

	public static String decode(String compressed) {
		// reset dictionary
		dict = new TrieNode('\0', false, 0);
		char[] arr = compressed.toCharArray();
		String uncompressed = "";
		ArrayList<String> aL = new ArrayList<String>();
		ArrayList<Integer> iL = new ArrayList<Integer>();
		
		//iL.add(0);

		int bitLength = Integer.parseInt(compressed.substring(0, 32), 2);

		// cycle through grabbing the
		for (int i = 32; i < arr.length; i += (bitLength + 16)) {
			if (!(i + (bitLength + 16) > arr.length)) {
				// code word is next bitLength bits
				String a = new String(arr, i, bitLength);
				int ind = Integer.parseInt(a, 2);
				// next char is next 16 bits
				String b = new String(arr, i + bitLength, 16);
				int chari = Integer.parseInt(b, 2);
				char c = new Character((char) chari);
				if(ind == 0)
				{
					aL.add("" + c);
					uncompressed += c;
					insertWord("" + c);
				} else {
					if(!iL.contains(ind))
					{
						iL.add(ind);
					}
					aL.add("" + aL.get(ind-1) + c);
					// concat & add word to dict
					String w = "" + aL.get(ind - 1) + c;
					uncompressed += w;
					insertWord(w);
				}
			} else {
				//leftover phrase
				String a = new String(arr, i, bitLength);
				int ind = Integer.parseInt(a, 2);
				if(ind != 0)
				{
					uncompressed += aL.get(ind - 1);
				}
			}
		}

		return uncompressed;
	}

	// searches the dictionary for the word s
	private static boolean searchDict(String s) {
		// start at root
		char[] arr = s.toCharArray();
		TrieNode node = dict;
		int count = 0;

		// loop through all chars of String s
		for (int i = 0; i < arr.length; i++) {
			// if current node is empty, string is not in dictionary
			if (node == null) {
				return false;
			}
			// mark the last node traversed
			last = node;
			// move to next node and increment nodes traveled
			node = node.links[getAscii(arr[i])];
			count++;
		}

		// if current node is null and we've reached the end OR current node
		// isn't the end of its branch, false
		if ((node == null && count == arr.length)
				|| (node != null && !node.end)) {
			return false;
		}

		// word was found
		return true;
	}

	// inserts the given word into the dictionary
	private static void insertWord(String word) {
		// get array and start at gamma node
		char[] arr = word.toCharArray();
		TrieNode node = dict;

		for (int i = 0; i < arr.length; i++) {
			char c = arr[i];
			// if there is no branch for the current character
			if (node.links[getAscii(c)] == null) {
				// new node to be added, determine if node.end should be true or
				// false
				// sets current node.end to false, since new node(s) being added
				if (i == arr.length - 1) {
					TrieNode n = new TrieNode(c, true, index);
					n.parent = node;
					node.links[getAscii(c)] = n;
				} else {
					node.end = false;
					TrieNode n = new TrieNode(c, false, index);
					n.parent = node;
					node.links[getAscii(c)] = n;
				}
				// increment number of phrases added
				index++;
			}
			// get next node
			node = node.links[getAscii(c)];
		}
	}

	// returns ASCII value of character c, used for indexing
	private static int getAscii(char c) {
		return (int) c;
	}

	// converts from binary string to proper binary, given
	private static String toBinary(String str) {
		final char[] masks = { 0x8000, 0x4000, 0x2000, 0x1000, 0x800, 0x400,
				0x200, 0x100, 0x80, 0x40, 0x20, 0x10, 0x8, 0x4, 0x2, 0x1 };
		String ret = "";

		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);

			for (int j = 0; j < 16; j++)
				if ((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}

		return ret;
	}

	// converts from proper binary to binary string, given
	private static String fromBinary(String str) {
		final char[] bits = { 0x8000, 0x4000, 0x2000, 0x1000, 0x800, 0x400,
				0x200, 0x100, 0x80, 0x40, 0x20, 0x10, 0x8, 0x4, 0x2, 0x1 };
		String ret = "";

		for (int i = 0; i < str.length(); i += 16) {
			char c = 0x0000;

			for (int j = 0; j < 16; j++)
				if (str.charAt(i + j) == '1')
					c |= bits[j];

			ret += c;
		}

		return ret;
	}
}
