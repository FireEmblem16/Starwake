/**
 * @author Cody Lougee
 */
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Trie class used to store phrases in the LZ algorithm. Uses a map interface since dictionary is outdated. Key is a string index. Value is the phrase.
 */
public class TrieDictionary implements Map<String, String>
{
	Node root;
	private int size=0;
	
	public TrieDictionary()
	{
		root = new Node(null, 0, '\0'); //Insert lambda
		size++;
	}
	
	@Override
	public void clear() //Won't need this
	{
		recursiveClear(root);		
	}

	@Override
	public boolean containsKey(Object arg0) //arg0 should be a string
	{
		Set<String> keys = keySet();
		Iterator<String> it = keys.iterator();
		while(it.hasNext())
		{
			if(it.next().equals(arg0))
			{
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean containsValue(Object arg0) 
	{
		Collection<String> vals = values();
		Iterator<String> it = vals.iterator();
		while(it.hasNext())
		{
			if(it.next().equals(arg0))
			{
				return true;
			}
		}
		return false;
	}

	@Override
	public Set<java.util.Map.Entry<String, String>> entrySet()//Don't need
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String get(Object arg0) 
	{
		ArrayList<Node> nodes = enumerateNodes(root);	
		
		for(int i=0;i<nodes.size();i++)
		{
			Node tmp = nodes.get(i);
			if(Integer.toString(tmp.index).equals(arg0))
			{
				return tmp.getPhrase();
			}
		}
		return null;
	}
	
	/**
	 * Gets the key provided a value. Custom method used for LZ.
	 * @param value
	 * @return
	 * The key if it exists. Null otherwise.
	 */
	public String getKey(String value)
	{
		ArrayList<Node> nodes = enumerateNodes(root);
		
		for(int i=0;i<nodes.size();i++)
		{
			Node tmp = nodes.get(i);
			if(tmp.getPhrase().equals(value))
			{
				return Integer.toString(tmp.index);
			}
		}
		return null;	
	}

	@Override
	public boolean isEmpty() 
	{
		if(size==0)
		{
			return true;
		}
		return false;
	}

	@Override
	public Set<String> keySet() 
	{
		HashSet<String> keys = new HashSet<String>(enumerateKeys(root));
		return keys;
	}

	@Override
	public String put(String arg0, String arg1) 
	{
		Node tmp = root;
		boolean containsPrefix = false;
		
		for(int i=0;i<arg1.length();i++)
		{
			containsPrefix = false;
			for(int j=0;j<tmp.children.size();j++)
			{
				if(tmp.children.get(j).data == arg1.charAt(i))//If a child contains the next char in the sequence
				{
					tmp = tmp.children.get(j);
					containsPrefix = true;
					break;
				}
			}
			if(!containsPrefix)
			{
				new Node(tmp, Integer.parseInt(arg0),arg1.charAt(arg1.length()-1));
				break;
			}
		}
		size++;
		return arg1;
	}

	@Override
	public void putAll(Map<? extends String, ? extends String> arg0) //Don't need
	{
		// TODO Auto-generated method stub	
	}

	@Override
	public String remove(Object arg0) 
	{
		ArrayList<Node> nodes = enumerateNodes(root);	
		
		for(int i=0;i<nodes.size();i++)
		{
			Node tmp = nodes.get(i);
			if(Integer.toString(tmp.index).equals(arg0))
			{
				tmp.parent.children.remove(tmp);
				tmp.parent.children.addAll(tmp.children);
				size--;
				return tmp.getPhrase();
			}
		}
		return null;
	}

	@Override
	public int size() 
	{
		return size;
	}

	@Override
	public Collection<String> values() 
	{
		ArrayList<Node> tmp =  enumerateNodes(root);
		ArrayList<String> value = new ArrayList<String>();
		for(int i=0;i<tmp.size();i++)
		{
			value.add(tmp.get(i).getPhrase());
		}
		return value;
	}
	
	/**
	 * Enumerates all the node object in the Trie
	 * @param parent
	 * @return
	 */
	private static ArrayList<Node> enumerateNodes(Node parent)
	{
		ArrayList<Node> children = new ArrayList<Node>();
		children.add(parent);	
		if(parent.children.isEmpty())//Leaf node
		{			
			return children;
		}
		//recursively call for each child
		for(int i=0;i<parent.children.size();i++)
		{
			children.addAll(enumerateNodes(parent.children.get(i)));
		}
		return children;
	}
	
	/**
	 * Enumerates all the keys in the Trie.
	 * @param parent
	 * @return
	 */
	private static ArrayList<String> enumerateKeys(Node parent)
	{
		ArrayList<String> children = new ArrayList<String>();
		children.add(Integer.toString(parent.index));
		if(parent.children.isEmpty())//Leaf node
		{			
			return children;
		}
		//recursively call for each child
		for(int i=0;i<parent.children.size();i++)
		{
			children.addAll(enumerateKeys(parent.children.get(i)));
		}
		return children;
	}
	
	/**
	 * Recursive clears a tree.
	 * @param parent
	 */
	private static void recursiveClear(Node parent)
	{		
		parent.parent = null;
		if(parent.children.isEmpty())//Leaf node
		{	
			return;
		}
		//recursively call for each child
		for(int i=0;i<parent.children.size();i++)
		{
			recursiveClear(parent.children.get(i));
		}
		parent.children.clear();	
	}
}