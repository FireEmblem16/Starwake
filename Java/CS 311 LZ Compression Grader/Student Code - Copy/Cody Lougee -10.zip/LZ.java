/**
 * @author Cody Lougee
 * 
 * Acknowledgment: I used the binary string conversion methods provided by Don on blackboard that was posted on October 8 2014. From conversion.txt file
 */
import java.util.Scanner;

public class LZ 
{
	
	private LZ()
	{
		
	}
	//Build the binary representation in a string first then convert it down
	public static String encode(String uncompressed)
	{
		StringBuilder codeBuilder = new StringBuilder(""),
					  phraseBuilder = new StringBuilder(""),
					  encoded = new StringBuilder("");
		Scanner codeScanner;
		int numBits = 1, //Used to store number of code bits
			index = 1;//Keeps track of the insertion index
		TrieDictionary trie = new TrieDictionary(); //Automatically adds lambda
		
		if(uncompressed == "")//Empty string
		{
			return "00";//32 bits of 0's
		}
		else
		{
			for(int i=0;i<uncompressed.length();i++)
			{
				phraseBuilder.append(uncompressed.charAt(i));//Read input one char at a time
				if(!trie.containsValue(phraseBuilder.toString()))//No phrase like current one stored in trie
				{
					String prefixIndex = "0";
					if(phraseBuilder.length() > 1)//Deeper than a child of root so prefix is not empty string
					{
						prefixIndex = trie.getKey(phraseBuilder.toString().substring(0, (phraseBuilder.length()-1)));//Get key of prefix
					}
					
					codeBuilder.append( " C" + prefixIndex + " " + toNBits(Integer.toBinaryString(uncompressed.charAt(i)),16));//Add the encoding. Don't know number of bits codewords are yet.
					trie.put(Integer.toString(index), phraseBuilder.toString());
					index++;
					phraseBuilder.delete(0, phraseBuilder.length());
				}
				else if(i == (uncompressed.length()-1) && phraseBuilder.length() > 0)//Last phrase is a repeat. Add index name
				{
					codeBuilder.append(" C" + trie.getKey(phraseBuilder.toString()));
				}
				//Continue otherwise	
			}
			numBits = (int) Math.ceil(Math.log10((double)(index)) / Math.log10(2.0)); //Number of code bits = ceil(log2(n))
			
			codeScanner = new Scanner(codeBuilder.toString());
			encoded.append(toNBits(Integer.toBinaryString(numBits),32)); //Give 32 bit representation of the number of bits in code
			while(codeScanner.hasNext())
			{
				String code = codeScanner.next();
				if(code.contains("C"))//Codeword
				{
					//if the string contains "C" (codeword indicator) then
					//get the substring after C, parse that to an integer, then convert it to binary string, then make the binary string the correct length
					encoded.append(toNBits(Integer.toBinaryString(Integer.parseInt(code.substring(1))), numBits)); 
				}
				else//Value
				{
					encoded.append(code);
				}
			}
			codeScanner.close();	
		}		
		if(encoded.length()%16 != 0)//Make a multiple of 16 bits
		{
			int encodedLength = (16-(encoded.length()%16));
			for(int i=0;i<encodedLength;i++ )
			{
				encoded.append("0");
			}
		}
		return FromBinary(encoded.toString());
	}
	
	//Convert the binary to a string then print the output
	public static String decode(String compressed)
	{
		String binaryString = ToBinary(compressed);
		if(binaryString.length() < 32)
		{
			System.out.println("The decode string is less than 32 bits long.");
			return null;
		}
		StringBuilder decoded = new StringBuilder(""),
					  phraseBuilder = new StringBuilder("");
		String prefix, //Stores prefix value for determining parent
			   phrases = binaryString.substring(32);//Gets the code and phrases part
		int codeLength = Integer.parseInt(binaryString.substring(0, 32),2); //get the number of code bits in base 2
		int i=0, index=1;
		TrieDictionary trie = new TrieDictionary(); //Automatically adds lambda
		
		while(i<phrases.length())
		{
			phraseBuilder.delete(0, phraseBuilder.length());
			//Get code
			for(int j=0;j<codeLength && i<phrases.length();j++,i++)//Do code length times
			{
				phraseBuilder.append(phrases.charAt(i));			
			}
			prefix = Integer.toString(Integer.parseInt(phraseBuilder.toString(),2));//convert binary string to int, then int to string
			if(!prefix.equals("0"))//Append nothing if lambda
			{
				decoded.append(trie.get(prefix)); //Add prefix if not an empty string
			}
			phraseBuilder.delete(0, phraseBuilder.length());
			if(i<phrases.length() && ((phrases.length()-1)-i) >= 16 )//Last part could be extra bits.
			{
				//Get letter
				for(int k=0;k<16 && i<phrases.length();k++,i++) //do 16 times to get all 16 bits of the letter
				{
					phraseBuilder.append(phrases.charAt(i));
				}
				trie.put(Integer.toString(index), (trie.get(prefix) + (char)Integer.parseInt(phraseBuilder.toString(), 2)));
				index++;
				decoded.append((char)Integer.parseInt(phraseBuilder.toString(), 2));
			}			
		}		
		return decoded.toString();
	}
	
	/**
	 * Returns a number in N bits. Used for codewords.
	 * @param binary
	 * The string represented in binary
	 * @param numBits
	 * The number of bits the result should be extended to
	 * @return
	 * The original binary string represented in numBits bits
	 */
	private static String toNBits(String binary, int numBits)
	{
		String value = binary;
		StringBuilder extend = new StringBuilder("");
		if(binary.length() < numBits)
		{
			for(int i=(numBits-binary.length());i>0;i--)
			{
				extend.append("0");
			}
			extend.append(binary);
			value = extend.toString();
		}
		return value;
	}
	
	//Below two methods were provided by Don on Blackboard
	
	public static String ToBinary(String str)
	{
		final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i++)
		{
			char c = str.charAt(i);
			
			for(int j = 0;j < 16;j++)
				if((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}		
		return ret;
	}	

	public static String FromBinary(String str)
	{
		final char[] bits = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i += 16)
		{
			char c = 0x0000;
			
			for(int j = 0;j < 16;j++)
				if(str.charAt(i + j) == '1')
					c |= bits[j];
			
			ret += c;
		}		
		return ret;
	}	
}