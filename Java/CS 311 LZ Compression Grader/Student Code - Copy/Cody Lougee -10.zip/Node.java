/**
 * @author Cody Lougee
 */
import java.util.ArrayList;

/**
 *Node class used to represent phrases in the Trie. Contains an index, a char value, a parent reference, and a list of children.
 */
public class Node 
{
	ArrayList<Node> children;
	Node parent = null;
	int index;
	char data;
	
	public Node(Node prnt, int ind, char value)
	{
		parent = prnt;
		if(prnt != null)
		{
			parent.children.add(this);
		}
		index= ind;
		data = value;
		children = new ArrayList<Node>();
	}
	
	/**
	 * Gets the full phrase from this node.
	 * @return
	 * The phrase this node represents.
	 */
	public String getPhrase()
	{
		StringBuilder phrase = new StringBuilder("");
		phrase.append(data);
		Node tmp = parent;
		while(tmp != null && tmp.data != '\0')
		{
			phrase.append(tmp.data);
			tmp = tmp.parent;
		}
		phrase.reverse();
			
		return phrase.toString();
	}
	
	public void addChild(Node child)
	{
		children.add(child);
	}
}