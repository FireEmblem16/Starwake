import java.util.LinkedList;

/**
 * Colin Duffy
 * LZ78 Implementation
 **/
public final class LZ {
	public static String encode(String uncompressed) 
	{
		//Shortcut for the empty string
		if(uncompressed.equals(""))
		{
			return LZ.FromBinary("00000000000000000000000000000000");
		}
		
		CodewordBuilder cb = new CodewordBuilder(uncompressed);;

		return cb.Encode();
	}
	
	public static String decode(String compressed)
	{
		//Get the binary representation of the compressed string
		String compBin = LZ.ToBinary(compressed);
		
		//Get the number of bits that represent the prefix index
		int code_length = Integer.parseInt(compBin.substring(0, 32), 2);
		
		//Initialize the decompressed string to the empty string
		String uncompressed = "";
		
		//List that stores the suffixes
		LinkedList<String> suffixes = new LinkedList<String>();
		
		//Start after the number representing the number of bits in the prefix
		//Increments the prefix size + 16 bits for the suffix
		for(int i = 32; i < compBin.length(); i += code_length+16)
		{
			//We ran into the padded bits that make the string divisible by 16
			if(compBin.length() - i < code_length + 16)
				break;
			
			//Starting index of the suffix
			int suffix_start = i + code_length;
			
			//Prefix code
			int code = Integer.parseInt(compBin.substring(i, i+code_length), 2);
			int suffix = Integer.parseInt(compBin.substring(suffix_start, suffix_start+16), 2);
			
			//First time we have seen the suffix, prefix is the empty string
			if(code == 0)
			{
				suffixes.add((char)suffix + "");
				uncompressed += (char)suffix + "";
			}else
			{
				//Add the prefix and suffix to uncompressed
				suffixes.add(suffixes.get(code-1) + (char) suffix);
				uncompressed += suffixes.get(code-1) + (char) suffix;
			}
		}
		
		return uncompressed;
	}
	
	/*
	 * This function is courtesy of Donald Nye
	 * */
	public static String ToBinary(String str)
	{
		final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i++)
		{
			char c = str.charAt(i);
			
			for(int j = 0;j < 16;j++)
				if((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}
		
		return ret;
	}
	
	/*
	 * This function is courtesy of Donald Nye
	 * */
	public static String FromBinary(String str)
	{
		final char[] bits = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i += 16)
		{
			char c = 0x0000;
			
			for(int j = 0;j < 16;j++)
				if(str.charAt(i + j) == '1')
					c |= bits[j];
			
			ret += c;
		}
		
		return ret;
	}
	

	


	
	/*I studied the library found at http://neobio.sourceforge.net to develop my implementation of a Trie*/
	
	/**
	 * Builds the dictionary of codewords
	 * */
	public static class CodewordBuilder
	{
		//Reference to the initial code {0, ""}
		protected Codeword root_code;

		//Number of codewords
		protected int num_codes;
		//Reference to the root trie node {root_code}
		protected Trie root_trie;

		public CodewordBuilder (String input)
		{
			Trie root_node, current_node, new_node = null;
			Codeword current_code, last_code, new_code;

			char c;

			// create root codeword and the root node of the trie
			root_code = new Codeword ();
			root_trie = root_node = new Trie (root_code);
			num_codes = 1;

			current_node = root_node;
			last_code = root_code;

			// read characters from the input
			for(int i = 0; i < input.length(); i++)
			{
				c = input.charAt(i);
				
				// walk down the trie
				new_node = current_node.spellDown(c);

				if (new_node != null)
				{
					current_node = new_node;
				}
				else
				{
					current_code = (Codeword) current_node.getData();
					new_code = new Codeword (current_code, num_codes, c);

					current_node.add (new_code, c);

					last_code.setNext (new_code);
					last_code = new_code;

					current_node = root_node;

					num_codes++;
				}
			}
	

			if (new_node != null)
			{
				last_code.setNext((Codeword) new_node.getData());
				num_codes++;
			}
	
		}
		
		public String Encode()
		{
			//Skip the empty node
			Codeword codeword = root_code.next;
			
			//Number of bits for the prefix
			int code_size = Integer.toBinaryString(num_codes).length();
			//Initilize the zipped string
			String zipped = Integer.toBinaryString(code_size);
			
			//Number of 0's to add to the before the code_size
			int numAdd = 32 - zipped.length();
			
			for(int i = 0; i < numAdd; i++)
				zipped = 0 + zipped;
			
			for(int i = 1; i < num_codes; i++)
			{
				String code = Integer.toBinaryString(codeword.prefix.index);
				
				int len = code.length();
				//Build the prefix
				for(int k = 0; k < code_size-len; k++){
					code = 0 + code;
				}
				
				//Get the suffix
				String ch = Integer.toBinaryString(codeword.suffix);
				if (ch.length() < 8) {
		            ch = "000000000".substring(0, 8 - ch.length()).concat(ch);
		        } else {
		            ch = ch.substring(ch.length() - 8);
		        }
				
				ch = "00000000" + ch;
				zipped += code + ch;
				codeword = codeword.next;
			}
			
			//How many 0's to add to make the string length divisible by 16
			int padding = 16 - (zipped.length() % 16);
			for(int i = 0; i < padding; i++)
			{
				 zipped += "0";
			}
			
			return  LZ.FromBinary(zipped);
		}
	}

	public static class Codeword
	{
		//Reference to the prefix
		public Codeword prefix;
		
		//Reference to the next codeword
		public Codeword next;

		//Index of the codeword
		public int index;

		//How many characters (prefix + 1)
		public int length;

		public char suffix;

		//Creates the initial codeword {0, ""}
		public Codeword ()
		{
			this.prefix = null;
			this.next = null;
			this.index = 0;
			this.length = 0;
			this.suffix = 0;
		}

		//Creates new codeword {prefix, suffix}
		public Codeword (Codeword prefix, int index, char suffix)
		{
			this.prefix = prefix;
			this.index = index;
			this.suffix = suffix;
			this.length = prefix.length + 1;
		}
		
		//Set the next codeword
		public void setNext (Codeword next)
		{
			this.next = next;
		}

	}
	/*
	 * Represents a trie node
	 * I modified trie that is found in the neobio library
	 * */
	public static class Trie
	{
		//Reference to son
		public Trie son;
		//Edge to son
		public char to_son;
		//Reference to sibling , i.e. on the same level
		public Trie sibling;
		
		public char to_sibling;
		
		//Data in node
		public Codeword	data;
		//Found in neobio
		public Trie (Codeword data)
		{
			this.son = null;
			this.sibling = null;
			this.data = data;
		}
		//Found in neobio
		public Codeword getData ()
		{
			return data;
		}

		//Add new node to the trie
		//Found in neobio
		public Trie add (Codeword data, char c)
		{
			if (son == null)
			{
				son = new Trie (data);
				to_son = c;
				return son;
			}
			else
			{
				return son.addSibling (data, c);
			}
		}
		
		public Trie addSibling (Codeword data, char c)
		{
			if (sibling == null)
			{
				sibling = new Trie (data);
				to_sibling = c;
				return sibling;
			}
			else
			{
				return sibling.addSibling (data, c);
			}
		}
	
		public Trie spellDown (char c)
		{
			if (son == null) return null;
			//Check the edge to the son
			if (to_son == c)
				return son;
			else
				return son.spellRight(c); //Check the sibling
		}
	
		public Trie spellRight (char c)
		{
			if (sibling == null) return null;
			//Check the sibling
			if (to_sibling == c)
				return sibling;
			else//Check the next sibling
				return sibling.spellRight(c);
		}
	}
}


