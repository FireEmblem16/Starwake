import java.util.ArrayList;
import java.util.Scanner;

public class Main
{
	public static void main(String args[]){
		
		String encoded = encode("00110010001");
		decode(encoded);

	}
	
	static String encode(String uncompressed)
	{
		char left = '0';
		node head = new node(0);
		int i = 1;
		String toRet = "0";
		Scanner s = new Scanner(uncompressed);
		node curr = head;
		int n = 0;
		while(n<uncompressed.length())
		{
			char c = uncompressed.charAt(n);
			if(c == left)
			{
				if(curr.hasLeft()) curr = curr.left;
				else 
				{
					curr.left = new node(i);
					i++;
					toRet += " " + curr.num() + c;
					curr = head;
				}
			}
			else
			{
				if(curr.hasRight()) curr = curr.right;
				else 
				{
					curr.right = new node(i);
					i++;
					toRet += " " + curr.num() + c;
					curr = head;
				}
			}
			n++;
		}
		s.close();
		System.out.println(toRet);
		return toRet;
		
	}
	
	static String decode(String compressed){
		String toRet = "";
		ArrayList<String> list = new ArrayList<String>();
		Scanner s = new Scanner(compressed);
		while(s.hasNext())
		{
			list.add(s.next());
		}
		list.set(0, "");
		for(int i = 1; i<list.size(); i++)
		{			
			String a = list.get(i);
			int b = (int) (a.charAt(0) - '0');
			String mid = (list.get(b));
			mid += a.charAt(1);
			toRet += mid;
			list.set(i, mid);
		}
		return toRet;
	}

}
