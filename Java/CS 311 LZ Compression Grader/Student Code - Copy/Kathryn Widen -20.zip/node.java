
public class node
{
	int num;
	public node left;
	public node right;
	
	public node(int number){
	num = number;
	left = null;
	right = null;
	}

	int num()
	{
		return num;
	}
	
	boolean hasLeft(){
		if(left == null) return false;
		return true;
	}
	
	boolean hasRight(){
		if(right == null) return false;
		return true;
	}

}
