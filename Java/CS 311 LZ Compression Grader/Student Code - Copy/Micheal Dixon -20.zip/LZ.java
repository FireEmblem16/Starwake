import java.io.IOException;
import java.util.ArrayList;
import java.util.BitSet;

import LZtestcase.BinStringUtil;
import LazyCollection.LZTrie;
import LazyCollection.LazyCollection;
import LazyCollection.LazyNode;



public class LZ {
	private LZ(){
		//Can't construct me
	}
	
	public static String encode(String uncompressed) throws Exception{
		
		LazyCollection LZC=new LZTrie();
		char curchar;
		int charindex=0;
		boolean haslastcodeword = false; //Whether or not the final codeword was already in the tree
		int lastcodeindex = 0; //The index of the final codeword, if it was already in the tree
		
		ArrayList<String> codewords= new ArrayList<String>(); //
		String binstring="";
		int indexsize; //The number of bits needed to represent the index
		
		while(charindex<uncompressed.length()){ 		//While there is string left to decode
			curchar=uncompressed.charAt(charindex);
			LazyNode child = LZC.getCurrent().childAt(curchar);	//See if the node we are looking at has the current character as a child node
			if(child != null){
				//Go down the tree to the child
				LZC.setCurrent(child);
				haslastcodeword=true;
			}else{
				//This string is not in the tree
				 LZC.add(curchar);
				 String curcharstring=Integer.toBinaryString((int) (curchar));//0:1 representation of the char
				 while(curcharstring.length()<16){ //Stick zeroes on the front until we have a 32 bit string
					 curcharstring="0".concat(curcharstring);
				}
				 //This line adds the binary value of the prefix's index (with no leading zeroes) 
				 // followed by the binary value of the character in exactly 16 bits
				 codewords.add(Integer.toBinaryString( LZC.getCurrent().getIndex() ).concat(curcharstring)); //I am so sorry
				 LZC.setCurrent(LZC.getRoot());
				 haslastcodeword=false;
			}
			charindex++;
		}
		
		//we have a prefix already in the tree as our final codeword
		if(haslastcodeword){
			 lastcodeindex=LZC.getCurrent().getIndex();
		}
		
		if(LZC.getSize()>0){ //special case for "", because spaghetti code is easier than fixing things
			indexsize=(int) Math.ceil( Math.log(LZC.getSize()+1) / Math.log(2));
			binstring=Integer.toBinaryString(indexsize);
		}else{
			indexsize=0;
			binstring="";
		}
		
		if(binstring.length()>32)
			throw new IOException(); //Tree is too damn big
		
		while(binstring.length()<32){ //Stick zeroes on the front until we have a 32 bit string
			binstring="0".concat(binstring);
		}
		
		charindex=0; 
		//concatanate all the codewords together
		while(charindex<codewords.size()){

			while(codewords.get(charindex).length()<indexsize+16){ //Stick zeroes on the front until we have an indexsize+16 bit string (the proper codeword length)
				codewords.set(charindex, "0".concat(codewords.get(charindex)) );
			}
			
			binstring=binstring.concat(codewords.get(charindex));
			charindex++;
		}
		
		//stick the index of the final prefix on
		if(haslastcodeword)
			binstring=binstring.concat(Integer.toBinaryString(lastcodeindex));

		while(binstring.length()%16!=0){
			binstring=binstring.concat("0");
		}
		
		return BinStringUtil.FromBinary(binstring);
	}
	
	
	public static String decode(String compressed){
		LazyCollection LZC=new LZTrie();
		String decoded="";
		
		String binstring=BinStringUtil.ToBinary(compressed);
		int indexsize=Integer.valueOf(binstring.substring(0, 32), 2);
		binstring=binstring.substring(32);
		
		int charindex=0;
		int index=0;
		char curchar;
		
		//generate the trie, and construct 
		while(binstring.length()>=indexsize+16){
			
			index=Integer.valueOf(binstring.substring(0, indexsize) , 2);
			binstring=binstring.substring(indexsize);
			
			curchar=(char)(int)Integer.valueOf(binstring.substring(0, 16),2); //lol java #1
			binstring=binstring.substring(16);
			
			LZC.setCurrent(LZC.getAtIndex(index));
			LZC.add(curchar);
			
			LazyNode teemp=LZC.getAtIndex(index);
			String temp=teemp.parentage();
			decoded=decoded.concat(temp);
			decoded=decoded+curchar;
		}
		
		//Add on the prefix for a final, lone index
		if(binstring.length()>=indexsize && indexsize>0){
			index=Integer.valueOf(binstring.substring(0, indexsize) , 2);

			LazyNode teemp=LZC.getAtIndex(index);
			String temp=teemp.parentage();
			decoded=decoded.concat(temp);
		}
			
			
		return decoded;
	}
	

}
