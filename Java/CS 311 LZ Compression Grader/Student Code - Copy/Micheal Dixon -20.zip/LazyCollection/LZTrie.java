package LazyCollection;

public class LZTrie extends LazyCollection {
	
	
	public LZTrie(){
		root= new LZTrieNode('\0',0,null);
		current=root;
		size=0;
	}
	
	@Override
	public void add(char newchar) {
		size++;
		current.add(newchar,size);
	}
}
