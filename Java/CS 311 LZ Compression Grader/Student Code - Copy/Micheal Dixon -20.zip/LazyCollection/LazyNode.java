package LazyCollection;

public abstract class LazyNode {

	public abstract LazyNode childAt(char curchar);

	public abstract int getIndex();

	public abstract void add(char newchar, int size);

	public abstract int numChildren();

	public abstract LazyNode getChild(int n);
	
	public abstract String parentage();

}
