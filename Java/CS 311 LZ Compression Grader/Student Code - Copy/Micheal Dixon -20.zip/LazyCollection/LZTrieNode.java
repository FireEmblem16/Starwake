package LazyCollection;

import java.util.ArrayList;

public class LZTrieNode extends LazyNode{
	public char value;
	public int index;
	public LZTrieNode parent;
	public ArrayList<LZTrieNode> children = new ArrayList<LZTrieNode>();

	public LZTrieNode(char value, int index, LZTrieNode parent) {
		this.value=value;
		this.index=index;
		this.parent=parent;
	}

	public LazyNode childAt(char curchar) {	
	// Returns the child node for which value=curchar, or null if no such child exists
		for(int i=0;i<children.size();i++){
			if(children.get(i).value == curchar){
				return children.get(i);
			}
		}
		return null;
	}

	@Override
	public int getIndex() {
		return index;
	}

	@Override
	public void add(char newchar, int size) {
		children.add(new LZTrieNode(newchar,size,this));
	}

	@Override
	public int numChildren() {
		return children.size();
	}

	@Override
	public LazyNode getChild(int n) {
		return children.get(n);
	}

	@Override
	public String parentage() {
	// Returns the prefix string associated with this node
		String result="";
		LZTrieNode cur=this;
		
		while(cur.parent!= null){
			result=cur.value+result;
			cur=cur.parent;
		}
		
		return result;
	}
}
