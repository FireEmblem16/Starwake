package LazyCollection;

public abstract class LazyCollection {
	protected LazyNode root;
	protected LazyNode current;
	protected int size;
	
	public LazyCollection(){
	}
	
	public abstract void add(char curchar);

	public LazyNode getCurrent() {
		return current;
	}

	public void setCurrent(LazyNode currentin) {
		current=currentin;
	}

	public LazyNode getRoot() {
		return root;
	}
	
	public LazyNode getAtIndex(int index) {
		return getAtIndexRecur(index,root);
	}
	

	public LazyNode getAtIndexRecur(int index, LazyNode itr) {
		if(index<itr.getIndex()){
			return null;
		}
		else if(index==itr.getIndex()){
			return itr;
		}
		else{
			for(int n=0; n<itr.numChildren();n++){
				LazyNode rec=getAtIndexRecur(index,itr.getChild(n));
				if(rec!=null)
					return rec;
			}
			return null;
		}
			
	}
		
	public int getSize() {
		return size;
	}
}
