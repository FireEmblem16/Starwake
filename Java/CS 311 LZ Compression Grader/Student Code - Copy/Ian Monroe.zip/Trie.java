import java.util.AbstractMap;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

public class Trie {
	
	static char EMPTY_CHAR;
	
	Node rootNode;
	
	public Trie(){
		rootNode = new Node(EMPTY_CHAR,0);
	}

	public void put(String key,int position){
		Node prefixNode = prefix(key);
		if(prefixNode!=null){
			Node newNode = new Node(lastChar(key),position);
			prefixNode.addChild(newNode);
		}
	}
	
	public int get(String key){
		int position = 0;
		Node prefixNode = prefix(key);
		char suffix = lastChar(key);
		if(prefixNode!=null){
			Node currentNode = prefixNode.childWithSuffix(suffix);
			if(currentNode!=null) position = currentNode.position;
		}
		return position;
	}
	
	private Node prefix(String key){
		return key.isEmpty() ? rootNode : prefix(rootNode, key);
	}
	
	/**
	 * Gets prefix node of given key. Disregards if key actually exists. Only cares if theoretical prefix of key exists.
	 * @param currentNode Node to check for key
	 * @param key Key to were trying to find prefix of. Does not need to exist
	 * @return Prefix node if it exists, null otherwise
	 */
	private Node prefix(Node currentNode,String key){
		if(currentNode==null || key.length()==1){
			return currentNode;
		}else{
			Node nextNode = currentNode.childWithSuffix(key.charAt(0)); 
			return prefix(nextNode,key.substring(1));
		}
	}
	
	public boolean containsKey(String key){
		Node prefixNode = prefix(key);
		return prefixNode==null ? false : prefixNode.childWithSuffix(lastChar(key))!=null;
	}
	
	public boolean containsValue(int value){
		for(Map.Entry<String, Integer> entry : entrySet()){
			if(entry.getValue()==value) return true;
		}
		return false;
	}
	
	public Set<Map.Entry<String, Integer>> entrySet(){
		Set<Map.Entry<String, Integer>> result = new HashSet<>();
		for(Node childNode : rootNode.children) addToSet(childNode, result);
		return result;
	}
	
	private void addToSet(Node node,Set<Map.Entry<String, Integer>> set){
		Map.Entry<String, Integer> entry =
				new AbstractMap.SimpleEntry<String,Integer>(node.getKey(), node.position);
		set.add(entry);
		if(!node.children.isEmpty()) for(Node child : node.children){
			addToSet(child, set);
		}
	}
	
	private char lastChar(String s){
		return s.isEmpty() ? EMPTY_CHAR : s.charAt(s.length()-1);
	}
	
	public int size(){
		return size(rootNode) - 1;
	}
	
	private int size(Node node){
		int size = 1;
		for(Node child : node.children){
			size += size(child);
		}
		return size;
	}
	
	public void print(){
		rootNode.print();
	}
	
	public class Node{
		
		Node parent;
		LinkedList<Node> children;
		char suffix;
		int position;
		
		public Node(char suffix,int position) {
			this.suffix = suffix;
			this.position = position;
			children = new LinkedList<Node>();
		}
		
		public boolean addChild(Node child){
			child.parent = this;
			return children.add(child);
		}
		
		public Node childWithSuffix(char suffix){
			for(Node child : children)
				if(child.suffix==suffix) return child;
			return null;
		}
		
		public void print(){
			System.out.println(suffix+" "+position);
			if(!children.isEmpty()) for(Node child : children) child.print();
		}
		
		public String getKey(){
			return (parent==rootNode || parent==null)
					? suffix+"" : parent.getKey()+suffix;
		}
		
	}
	
}
