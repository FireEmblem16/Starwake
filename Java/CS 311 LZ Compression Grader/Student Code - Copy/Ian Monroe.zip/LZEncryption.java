import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.Map.Entry;


public class LZEncryption {
		
	public static String encode(String uncompressed){
				
		Trie dictionary = new Trie();
		int startIndex = 0;
		int endIndex = 1;
		int tokenCount = 0;
		String currentToken;
		
		while(endIndex<=uncompressed.length()){
			// Grab the next potential token from uncompressed
			currentToken = uncompressed.substring(startIndex, endIndex);
			
			/*
			 * Then slowly increase the token until we find something we haven't seen yet
			 * or until we hit the end
			 */
			while(dictionary.containsKey(currentToken) && (++endIndex<=uncompressed.length())){
				currentToken = uncompressed.substring(startIndex, endIndex);
			}
			
			/*
			 * Here we grab the codeword (prefix index, last letter) for the current token
			 * We check tokenHasBeenSeen just to ensure that the potential last codeword of uncompressed
			 * string might not have a real suffix
			 */
			boolean tokenHasBeenSeen = dictionary.containsKey(currentToken);
			String prefix = tokenHasBeenSeen ? currentToken : currentToken.substring(0, currentToken.length()-1);
			String suffix = tokenHasBeenSeen ? "" : currentToken.charAt(currentToken.length()-1)+"";
			//System.out.println(dictionary.get(prefix)+" "+suffix);
			
			/*
			 * Put the codeword into the dictionary and increment the startIndex
			 * and endIndex to prepare the next potential token
			 */
			dictionary.put(prefix+suffix, ++tokenCount);
			startIndex += currentToken.length();
			endIndex = startIndex + 1;
		}
		//System.out.println(encodeDictionary(dictionary));
		return encodeDictionary(dictionary);
	}
	
	private static String encodeDictionary(Trie dictionary){
		StringBuilder compressed = new StringBuilder();
		int bitsRequired = bitsRequired(dictionary.size());
		
		// Add the beginning 32 bits to specify size
		compressed.append(intToBinString(bitsRequired,32));
		
		// This piece of crap is sorting the entry set returned from the dictionary
		LinkedList<Entry<String, Integer>> sortedTrie =
				new LinkedList<>(dictionary.entrySet());
		Collections.sort(sortedTrie,new Comparator<Entry<String, Integer>>() {
			@Override
			public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
				return Integer.compare(o1.getValue(), o2.getValue());
			}
		});
		
		// For each entry, add the codeword to translated bits
		for(Entry<String, Integer> entry : sortedTrie){			
			String key = entry.getKey();
			// Ignore the root entry (empty string)
			if(entry.getValue()>0){
				char suffix = entry.getKey().charAt(key.length()-1);
				int position = dictionary.get(entry.getKey().substring(0, entry.getKey().length()-1));
				compressed.append(codewordToBinString(position,suffix,bitsRequired));
			}
		}
		
		// Pad the string to be multiple of 16 bits
		while( (compressed.length()%16) != 0 ){
			compressed.append("0");
		}
		
		//System.out.println(compressed.toString());
		return binStringToByteString(compressed.toString());
	}
	
	private static int bitsRequired(int size){
		return (int) Math.ceil( (Math.log(size+1)/Math.log(2)) );
	}
	
	private static String intToBinString(int value,int bits){
		String result = String.format("%"+bits+"s", Integer.toBinaryString(value))
				.replace(' ', '0');
		return result;
	}
	
	private static String codewordToBinString(int position,char suffix,int bitsRequired){
		String indexBin = intToBinString(position,bitsRequired);
		String suffixBin = intToBinString(Character.valueOf(suffix), 16);
		return indexBin+suffixBin;
	}
	
	private static String binStringToByteString(String binString){
		StringBuilder byteString = new StringBuilder();
		for(int i=0;i<binString.length();i+=8){
			String charBinString = binString.substring(i, i+8);
			char charByte = (char) binStringToInt(charBinString);
			byteString.append(charByte);
		}
		return byteString.toString();
	}
	
	
	
	
	
	
	
	public static String decode(String byteString){
		String compressed = byteStringToBinString(byteString);
		Trie dictionary = new Trie();
		int bitsRequired = binStringToInt(compressed.substring(0, 32));
		int bitsInCodeword = bitsRequired + 16;

		int startIndex = 32;
		int endIndex = startIndex + bitsInCodeword;
		int value = 0;
		while(endIndex<=compressed.length()){
			String codewordBinString = compressed.substring(startIndex, endIndex);
			Pair<Integer,Character> codeword = binStringToCodeword(codewordBinString, bitsRequired);
			String key = getKeyForValue(codeword.first.intValue(), dictionary) + codeword.second;
			dictionary.put(key, ++value);
			startIndex += bitsInCodeword;
			endIndex = startIndex + bitsInCodeword;
		}
		//System.out.println(decodeDictionary(dictionary));
		return decodeDictionary(dictionary);
	}
	
	private static String decodeDictionary(Trie dictionary){
		StringBuilder uncompressed = new StringBuilder();
		
		// This piece of crap is sorting the entry set returned from the dictionary
		LinkedList<Entry<String, Integer>> sortedTrie =
				new LinkedList<>(dictionary.entrySet());
		Collections.sort(sortedTrie,new Comparator<Entry<String, Integer>>() {
			@Override
			public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
				return Integer.compare(o1.getValue(), o2.getValue());
			}
		});
		
		// For each entry, add the codeword to translated bits
		for(Entry<String, Integer> entry : sortedTrie){
			uncompressed.append(entry.getKey());
		}
		
		return uncompressed.toString();
	}
	
	private static String getKeyForValue(int value,Trie dictionary){
		for(Entry<String, Integer> entry : dictionary.entrySet()){
			if(entry.getValue()==value){
				return entry.getKey();
			}
		}
		return "";
	}
	
	private static int binStringToInt(String binary){
		return Integer.parseInt(binary, 2);
	}
	
	private static Pair<Integer,Character> binStringToCodeword(String binary,int bitsRequired){
		int position = binStringToInt(binary.substring(0, bitsRequired));
		char suffix = (char) binStringToInt(binary.substring(bitsRequired));
		return new Pair<Integer, Character>(position, suffix);
	}
	
	private static String byteStringToBinString(String byteString){
		StringBuilder binString = new StringBuilder();
		for(int i=0;i<byteString.length();i++){
			int charValue = byteString.charAt(i);
			String currentByte = intToBinString(charValue, 8);
			binString.append(currentByte);
		}
		return binString.toString();
	}
	
	static class Pair<K,V>{
		
		K first;
		V second;
		
		Pair(K first,V second){
			this.first = first;
			this.second = second;
		}
	}

}
