package hw4;

import java.util.ArrayList;

public class LZ {
	
	public static String encode(String uncompressed)
	{
		if(uncompressed.length() == 0)
		{
			return ""; // empty string (lambda)
		}
		
		Trie trie = new Trie();
		
		// break down string into nodes, add them to the tree
		int i = 0;
		String prev = "";
		ArrayList<String> previousChunks = new ArrayList<String>();
		while(i < uncompressed.length())
		{
			trie.addNode(prev);
		}
		
		return uncompressed;
		
	}
	
	public static String decode(String compressed)
	{
		if(compressed.length() == 0)
		{
			return ""; // empty string (lambda)
		}
		return compressed;
		
	}
	
	private LZ(){}
	
	
	
	
	
	/**
	 * Implementation of the Trie data structure, consisting of a head node and the
	 * accompanying tree of nodes.
	 * @author erik
	 *
	 */
	protected class Trie
	{
		TrieNode head;
		
		protected void addNode(String value)
		{
			TrieNode cursor = head;
			int index = 0;
			while(index+1 < value.length())
			{
				cursor = cursor.getNodeAtChar(value.charAt(index));
				index++;
			}
		}
		
		public Trie()
		{
			head = new TrieNode(""); // head is empty string
		}
		
		
		/**
		 * Simple node for Trie data structure, supporting 256 (ASCII) children
		 * @author erik
		 *
		 */
		protected class TrieNode
		{
			protected TrieNode[] children = new TrieNode[256];
			protected String value;
			protected TrieNode(String value)
			{
				this.value = value;
			}
			
			/**
			 * Returns the node for the given character from this node.  If it does not exist, create it and return that new node.
			 * @param index
			 * @return
			 */
			protected TrieNode getNodeAtChar(char index)
			{
				for(int i = 0; i < children.length; i++)
				{
					if(children[i] != null)
					{
						if(children[i].value.charAt(children[i].value.length()-1) == index) // the last char of the string
						{
							return children[i];
						}
					}
				}
				// did not find it, must be a new node
				int i = 0;
				while(children[i] != null && i < children.length)
				{
					i++;
				}
				
				if(i == 255)
				{
					// out of space in the array.  HOW COULD DIS HAPPEN
					return null;
				}
				
				children[i] = new TrieNode(value + index);
				return children[i];
			}
		}
	}

}
