import java.util.ArrayList;


public class LZ {

	public static String encode(String uncompressed){
		String encoded = "";
		//number of bits required to print codewords
		int codewordBits;
		//the number of bits in our output string
		int outputSize;
		Trie trie = new Trie();
		//create a Trie out of the uncompressed string
		trie.createTree(uncompressed);
		//get the node list representation of the trie
		ArrayList<TrieNode> nodeList = trie.getNodeList();
		//if the final node doesn't have a parent, then it was never added to the Trie, so it doesn't count
		//for the purposes of the codeword size
		if(nodeList.get(nodeList.size() - 1).getValue() == null){
			codewordBits = 32 - Integer.numberOfLeadingZeros(nodeList.size() - 1);
			outputSize = 32 + (nodeList.size()- 1) * (16 + codewordBits);
		}
		else{
			codewordBits = 32 - Integer.numberOfLeadingZeros(nodeList.size());
			outputSize = 32 + (nodeList.size() - 1) * (16 + codewordBits);
		}
		//int numChars = (int) Math.ceil(outputSize / 16);
		String numCodeBits = Integer.toBinaryString(codewordBits);
		
		//print out 32 bit integer of the size of the codewords
		for(int i = 0; i < 32 - numCodeBits.length(); i++){
			encoded += '0';
		}
		encoded += Integer.toBinaryString(codewordBits);

		/**
		 * for codeWords:
		 * divide index by two until less than 2. store it has a char array of 0's and 1's
		 * go through and print zeros until we get to codeWordBits - char arr size.
		 * then print out the char array. i.e. index = 3, cwbits = 4.
		 * print out 00(leading zeros), 11(char arr)
		 */
		//go through our list, and create the string to return
		for(int i = 1; i < nodeList.size(); i++){
			//empty string case input == lambda
			if(nodeList.size() == 1){
				return null;
			}
			TrieNode current = nodeList.get(i);
			//print out the index in binary
			for(int z = 0; z < codewordBits - Integer.toBinaryString(current.getParent().getIndex()).length(); z++){
				encoded += '0';
			}
				encoded += Integer.toBinaryString(current.getParent().getIndex());
			//debug statements
			//System.out.println(current.getParent().getIndex());
			
			//print out the value of the node as a 16 bit representation of a char
			if(current.getParent() != null && current.getValue() != null){
				//System.out.println(current.getParent().getIndex() + " " +  current.getValue());
				String binaryRep = Integer.toBinaryString(current.getValue());
				for(int j = 0; j < 16 - binaryRep.length(); j++){
					encoded += '0';
				}
				encoded += binaryRep;
				//System.out.println("As binary: "+ binaryRep);
			}
			
			//debug
			//System.out.println(encoded + " length: " + encoded.length());
		}
		//if length of string is not a multiple of 16, then add trailing zeros to make it
		if(outputSize % 16 != 0){
			int extra = outputSize % 16;
			for(int k = 0; k < 16 - extra; k++){
				encoded += '0';
			}
		}
		return StringConverter.FromBinary(encoded);
	}
	public static String decode(String compressed){
		String decoded = "";
		ArrayList<TrieNode> nodeList = new ArrayList<TrieNode>();
		Trie trie = new Trie();
		String binary = StringConverter.ToBinary(compressed);
		int codeWordSize = 0;
		for(int i = 0; i < 32; i++){
			char x =  binary.charAt(i);
			if(x == '1')
			codeWordSize += Math.pow(2, 31 - i);
		}
		int count = 32;
		while(count + codeWordSize < binary.length()){

			int index = 0;
			for(int j = 0; j < codeWordSize; j++){
				if(binary.charAt(j + count) == '1')
				index += Math.pow(2, codeWordSize - 1 - j);
			}
			count += codeWordSize;
			int value = 0;
			//we ran out of bits, so either our last index is in the string, or not
			if(count >= binary.length() - 15){
				//if index is greater than zero, than it means it denotes something we've already
				//seen before so we add it to our list. if it is zero, then it must not be included in the tree, since
				//if it was, then it would make a new node off the root, and therefore require a character
				if(index > 0){
					TrieNode node = new TrieNode(index, null, null);
					nodeList.add(node);
				}
				break;
			}
			for(int k = 0; k < 16; k++){
				if(binary.charAt(k + count) == '1')
				value += Math.pow(2,  15 - k);
			}
			count += 16;
			TrieNode node = new TrieNode(index, (char) value, null);
			nodeList.add(node);
		}
		//go through our list, and add them to the list
		int index = 0;
		//will keep track of where are trie nodes are, so the node with index
		//0 is at spot 0, and so on
		ArrayList<TrieNode> sortedNodes = new ArrayList<TrieNode>();
		sortedNodes.add(trie.getRoot());
		for(TrieNode node : nodeList){
			trie.addNode(node, index, sortedNodes);
			index++;
		}
		//go through the list, and print out the strings for each codeword using our trie
		for(TrieNode node : nodeList){
			String str = trie.generateStringFromIndex(node.getIndex(), nodeList);
			decoded += str;
		}
		return decoded;
	}
}
