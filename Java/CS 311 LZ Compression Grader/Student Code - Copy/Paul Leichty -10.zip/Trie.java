import java.util.ArrayList;

/**
 * class that models the Trie data structure. constructor auto generates 
 * the root as an empty string with index 0.
 * @author Paul
 *
 */
public class Trie {
//root node
private TrieNode root;
//number of nodes in trie
private int size;
//pointers to nodes
private ArrayList<TrieNode> NodeList;
/**
 * creates a new trie with the root node of lambda (no data, no parent)
 */
	public Trie(){
		TrieNode root = new TrieNode(0, null, null);
		this.setRoot(root);
		this.setSize(1);
		NodeList = new ArrayList<TrieNode>();
		NodeList.add(root);
	}

	public TrieNode getRoot() {
		return root;
	}

	public void setRoot(TrieNode root) {
		this.root = root;
	}
	public ArrayList<TrieNode> getNodeList(){
		return this.NodeList;
	}
	/**
	 * creates the Trie given a string input
	 * @param input
	 * @return
	 */
	public boolean createTree(String input){
		if(input.length() == 0){
			return true;
		}
		else{
			for(int i = 0; i < input.length(); i++){
				String str = new String();
				str += input.charAt(i);
				while(contains(str)){
					//if we are at the end of our string, then we need to create a new 
					//entry in our arrayList to designate the final characters left. These will
					//not have additional space in our trie, so it has no parent or character.
					if(i == input.length() - 1){
						createNode(str, size++, true);
						return true;
					}
					str += input.charAt(++i);
				}
			createNode(str, size++, false);
			}
		}
		return true;
	}
	/*
	 * creates a node in the tree given the specific string and index
	 * this function uses the searchChildren function to travel through the tree to
	 * find out where to put the new node
	 */
	private void createNode(String str, int i, boolean end) {
		TrieNode currentNode = this.root;
		for(int j = 0; j < str.length(); j++){
			char value = str.charAt(j);
			if(searchChildren(value, currentNode) != null){
				currentNode = searchChildren(value, currentNode);
			}

		}
		TrieNode node;
		//case where we are at the end of the input string, and we already have this node in our trie
		//we will not put this node into our tree, but we will include it in our list
		//for the purposes of our output
		if(end){
			node = new TrieNode(i, null, currentNode);
		}
		else{
			node = new TrieNode(i, str.charAt(str.length() - 1), currentNode);
			currentNode.addChild(node);
		}
		NodeList.add(node);
	}
/**
 * see if the tree contains a node that matches the input string
 * @param str
 * @return
 */
	public boolean contains(String str){
		TrieNode currentNode = this.root;
		for(int i = 0; i < str.length(); i++){
			char value = str.charAt(i);
			if(searchChildren(value, currentNode) == null){
				return false;
			}
			else{
				currentNode = searchChildren(value, currentNode);
			}
		}

		return true;
	}
	/**
	 * go through tree and find if a node matches the string
	 * @param value
	 * @return
	 */
	private TrieNode searchChildren(char value, TrieNode parent) {
		for(TrieNode children : parent.getChildren()){
			if(children.getValue() == value){
				return children;
			}
		}
		return null;
	}
/**
 * from an index of a node, generate the string from populating up
 */
	public String generateStringFromIndex(int index, ArrayList<TrieNode> nodeList){
		String str = "";
		TrieNode current = nodeList.get(index);
		if(current.getValue() != null){
			str += current.getValue();
		}
		while(current != this.root){
			current = current.getParent();
			if(current.getValue() != null)
			str += current.getValue();
		}
		StringBuilder sb = new StringBuilder();
		sb.append(str);
		return sb.reverse().toString();
	}
	/**
	 * add the node to the tree in the correct place
	 * @param node
	 */
	public void addNode(TrieNode node, int newIndex, ArrayList<TrieNode> nodeList){
		TrieNode parent = nodeList.get(node.getIndex());
		parent.addChild(node);
		node.setParent(parent);
		node.setIndex(newIndex);
		nodeList.add(node);
	}
	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}
}
