import java.util.ArrayList;
public class TrieNode {
private Character value;
private int index;
private ArrayList<TrieNode> children;
private TrieNode parent;
public TrieNode(int index, Character value, TrieNode parent){
	this.value = value;
	this.index = index;
	this.children = new ArrayList<TrieNode>();
	this.parent = parent;
}
public void addChild(TrieNode node){
	this.children.add(node);
}
public Character getValue() {
	return value;
}

public void setValue(char value) {
	this.value = value;
}

public int getIndex() {
	return index;
}

public void setIndex(int index) {
	this.index = index;
}

public ArrayList<TrieNode> getChildren() {
	return children;
}

public void setChildren(ArrayList<TrieNode> children) {
	this.children = children;
}
public TrieNode getParent() {
	return parent;
}
public void setParent(TrieNode parent) {
	this.parent = parent;
}
}
