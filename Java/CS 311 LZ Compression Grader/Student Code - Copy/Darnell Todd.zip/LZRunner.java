import java.util.Scanner;

public class LZRunner {

	private static final String TheWorldIsFullOfSugar = "";

	public static void main(String... args) {

		Scanner in = new Scanner(System.in);

		System.out.println("Enter a uncompressed string");
		String compressed = LZ.encode("abcdefghijklmnopqrstuvwxy7abbababba");

		String uncompressed = LZ.decode(compressed);
		System.out.println(uncompressed);

	}

}

// TEST STRINGS UNCOMPRESSED
// aaaaaaaaaaaaaaaaaaaaaaaaaa
// The world is full of sugar!
// 112123123412345123456123 
// 1234567890!@#$%^&*()
// aabbbccccdddddeeeeeefffffffffffff

