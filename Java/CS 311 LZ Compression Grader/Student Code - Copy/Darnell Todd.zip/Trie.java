import java.util.List;
import java.util.ArrayList;



public class Trie {
	private Node root;
	private int size;
	private List<String> keyset;
	
	public Trie(){
		size = 0;
		root = new Node(null,size);
		keyset = new ArrayList<String>();
		keyset.add("");
	}
	
	public boolean addWord(String s){
		Node cur = root;
		for(char c : s.toCharArray()){
			Node prev = cur;
			cur = cur.getChild(c);
			if(cur == null){
				cur = prev.addChild(c);
			}
		}
		if(cur != null){
			keyset.add(s);
		}
		return false;
	}
	
	public ArrayList<String> getKeys(){
		return (ArrayList<String>) keyset;
	}
	
	
	public boolean contains(String s){
		return null != getNode(s);
	}
	
	public Node getNode(String s){
		Node cur = root;
		for(char c : s.toCharArray()){
			cur = cur.getChild(c);
			if(cur == null){
				return null;
			}
			
		}
		return cur;
	}
	
	
	
	public class Node{
		private Node[] children;
		private Node parent;
		private int codeword;
		
		
		public Node(Node parent, int index){
			this.parent = parent;
			this.codeword = index;
			children = new Node[256];
		}
		
		public Node getChild(char c){
			int i = (int)c;
			if(i < 0 || i > 255){
				return null;
			}
			return children[i];
		}
		
		
		
		public int getCodeWord(){
			return codeword;
		}
		
		public Node addChild(char c){
			int i = (int)c;
			if(children[i] == null){
				
				children[i] = new Node(this, size);
				size++;
				return children[i];
			}
			return null;
		}
	}

	public String get(char key) {
		
		return keyset.get(key);
	}

	public int size() {
		return size ;	
	}
}
