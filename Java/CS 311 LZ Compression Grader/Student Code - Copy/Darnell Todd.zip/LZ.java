public class LZ {
	private static String LAMBDA = "";
	private static int CSIZE = 16;

	private LZ() {/* LEAVE EMPTY */
	}

	public static String encode(String uncompressed) {
		Trie trie = new Trie();
		int n = uncompressed.length();
		String phrase = LAMBDA;
		String compressed = LAMBDA;
		for (int i = 0; i < n; i++) {
			char c = uncompressed.charAt(i);
			if (trie.getNode(phrase + c) != null) {
				phrase = phrase + c;
			} else {
				trie.addWord(phrase + c);
				char codeword = (char) trie.getNode(phrase).getCodeWord();
				char suffex = c;

				compressed = compressed + codeword + suffex;
				phrase = LAMBDA;
			}
		}
		if (!LAMBDA.equals(phrase)) {
			char codeword = (char) trie.getNode(phrase).getCodeWord();
			compressed = compressed + codeword;
		}
	
		return squeeze(trie.size(), compressed);
	}

	private static String squeeze(int size, String compressed) {

		int keywordsize = log2(size);
		String squeezed = LAMBDA;
		char keyword;
		char suffex;
		char cur = (char) (keywordsize << 12);
		int bitpos = 4;
		for (int i = 0; i < compressed.length(); i++) {

			if (i % 2 == 0) {
				keyword = compressed.charAt(i);
				int move = (CSIZE - keywordsize) - bitpos;

				cur = (char) (cur | (move < 0 ? keyword >> move
						: keyword << move));

				bitpos = (bitpos + keywordsize);
				if (bitpos >= CSIZE) {
					squeezed += cur;
					bitpos %= CSIZE;
					move = CSIZE - bitpos;
					cur = (char) (keyword << move);
				}
			} else {
				suffex = compressed.charAt(i);
				cur = (char) (cur | (suffex >> bitpos));
				squeezed += cur;

				if (bitpos != 15) {
					cur = (char) (suffex << (CSIZE - bitpos));
				} else {
					cur = (char) (suffex << (bitpos));
				}

			}

		}

		if (cur != 0) {
			squeezed += cur;
		}

		return squeezed;
	}

	private static int clearOldBits(char cur, int bitpos) {
		int zeroOnes = (int) Math.pow(2, (CSIZE - bitpos)) - 1;
		return cur & zeroOnes;
	}

	private static int log2(int x) {
		double a = Math.log(x);
		double b = Math.log(2);
		double c = a / b;
		return (int) Math.ceil(c);
	}

	private static void printBinary(String tag, String tobin) {
		String bin = "";
		for (char c : tobin.toCharArray()) {
			String binc = Integer.toString(c, 2);

			for (int i = binc.length(); i < 16; i++)
				binc = "0" + binc;
			bin += " " + binc;
		}
		System.out.println(tag + " " + bin + " " + tobin);
	}

	public static String decode(String compressed) {
		
		int n = compressed.length();
		int totalBits = n * 16;
		int bitpos = 4;
		Trie trie = new Trie();
		String uncompressed = LAMBDA;
		String prefex = null;
		char suffex;
		int charpos = 0;
		int keywordsize = compressed.charAt(0) >> 12;
		boolean getkey = true;
		int prevkey = -1;
		while (bitpos < totalBits) {
			if (getkey) {
				char cur = compressed.charAt(charpos);
				int key = clearOldBits(cur, bitpos % CSIZE);
				int move = (bitpos % CSIZE) + keywordsize;
				if (move < CSIZE) {
					key = key >> (CSIZE - move);
					
				} else if (move > CSIZE) {
					key = key << (move - keywordsize);
					charpos++;
					char prevcur = cur;
					if (charpos < compressed.length()) {
						cur = compressed.charAt(charpos);
						int newkey;
						if (bitpos % CSIZE != 15) {
							newkey = key | cur >> (bitpos - 1 % CSIZE);
						} else {
							newkey = key
									| cur >> ((bitpos % CSIZE) - (keywordsize));
						}
						key = newkey;
					}

				} else {
					charpos++;
				}

				prevkey = key;

				prefex = trie.get((char) key);
				uncompressed = uncompressed + prefex;
				bitpos += keywordsize;
				
				if (totalBits - bitpos < CSIZE) {
					return uncompressed;
				}
			} else {
				char cur = compressed.charAt(charpos);

				suffex = (char) (cur << bitpos % CSIZE);

				charpos++;
				if (charpos >= compressed.length()) {
					return uncompressed + suffex ;
				}
				char prevcur = cur;
				cur = compressed.charAt(charpos);

				char suffex2 = (char) (cur >> (CSIZE - (bitpos % CSIZE)));
				suffex = (char) (suffex | suffex2);

				if (suffex < 255 && suffex >= 0) {
					uncompressed = uncompressed + suffex;
					trie.addWord(prefex + suffex);
					bitpos += CSIZE;
				} else {
					uncompressed = uncompressed + "o";
					trie.addWord(prefex + 'o');
					bitpos += CSIZE;
				}
			}
			getkey = !getkey;
		}

		return uncompressed;

	}

}
