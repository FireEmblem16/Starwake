import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

/**
 * 
 * @author Jonathan Krueger
 * 
 * Project: Homework 4 - Lempel-Ziv compression
 *
 */

public class LZ {
	private LZ(){}
	
	private static Node rootNode; // Root node never changes since we will need it to return to our base
	private static Node currentNode;
	
	private static int index; // What our current index value is for stored nodes
	
	private static ArrayList<Character> charList; // Holds string characters for ease of access and control
	
	private static Queue<Node> nodeQueue; // Queue's nodes for easier string creations for encode and decode
	
	private static String bitString; // A helpful string that helps hold and parse bits for conversions
	
	private static int codeLength; // Length of a code segment
	
	/* ---------------------------- Encode + Decode ---------------------------------- */
	public static String encode(String uncompressed)
	{
		// Clear all used class variables
		rootNode = new Node(0, (char) 0, null);
		currentNode = rootNode;
		
		index = 0;
		
		charList = new ArrayList<Character>();
		nodeQueue = new LinkedList<Node>();
		
		for(char c : uncompressed.toCharArray())
		{
			charList.add(c);		// Adds the characters to an array list so that we can control the characters a lot easier
		}
		
		treeCharactersEncode();

		codeLength = (int) Math.ceil(Math.log10(index)/Math.log10(2)); // Calculate the number of bits we will need to represent the code word
		
		buildStringFromQueueEncode();

		return convertBitsToString();	
	}
	
	public static String decode(String decompressed)
	{
		// Clear all used class variables
		rootNode = new Node(0, (char) 0, null);
		currentNode = rootNode;
		
		index = 0;
		
		bitString = "";
		nodeQueue = new LinkedList<Node>();
		
		
		//Grab each character in the incoming string and convert it to a string, pad the string to 16 bits long with leading 0's and add it to our bitString
		for(char c : decompressed.toCharArray())
		{
			String tempString = Integer.toBinaryString((int)c);
			
			while(tempString.length() < 16)
			{
				tempString = "0" + tempString;
			}
			
			bitString += tempString;
		}
		
		String codeWord = bitString.substring(0, 32); // Grab the codeword from the front of the string
		
		bitString = bitString.substring(32); // Trim codeword from front of string
		
		codeLength = Integer.parseInt(codeWord, 2); // This will construct the integer for the code length from the first two characters
		
		treeCharactersDecode();
		
		return buildStringFromQueueDecode();
	}
	
	/* ---------------------------- Encode Functions --------------------------------- */		
	
	// Converts sets of 16 bits into characters for the output string
	private static String convertBitsToString() {
		String workingString;
		String finalString = "";
		
		while(bitString.length() > 0)
		{
			workingString = bitString.substring(0, 16);		// Grabs the first 16 bits of the string
			bitString = bitString.substring(16);			// Trims the first 16 bits off the string
			
			finalString += (char) Integer.parseInt(workingString, 2);	// Converts the 16 bits using a binary parse to an integer, then cast to a character
		}		
		
		return finalString;
	}

	//Builds the bit string from the queued nodes and parent indexes
	private static void buildStringFromQueueEncode() {
		bitString = "";
		
		while(!nodeQueue.isEmpty())
		{
			Node tempNode = nodeQueue.remove();
			
			String tempCodeString = Integer.toBinaryString(tempNode.parentNode.index); // Retrieve needed parent index
			String tempBitString = Integer.toBinaryString((int)tempNode.letter); // Retrieve our node's letter
			
			while(tempCodeString.length() < codeLength)
			{
				tempCodeString = "0" + tempCodeString;	// Pads the start of the code string with 0's so that it is long enough
			}
			
			while(tempBitString.length() < 8)
			{
				tempBitString = "0" + tempBitString; // Pads the start of the character bit string so that it is 8 bits long
			}
			
			bitString += tempCodeString + tempBitString; // Adds the code number and bit string to the end of the string
		}
		
		while(bitString.length() % 16 != 0)
		{
			bitString += "0"; // Increase the trailing zeroes on the string of bits such that we can fit it all into a set of characters 
		}
		
		String leadingSizeString = Integer.toBinaryString(codeLength); // Setup the string bit representation for the codeLength digit
		
		while(leadingSizeString.length() < 32) // Pad the code length string with leading 0's so that it is 32 bits long
		{
			leadingSizeString = "0" + leadingSizeString;
		}
		
		bitString = leadingSizeString + bitString;
		
	}

	// Adds nodes from the input characters to the tree
	private static void treeCharactersEncode()
	{
		while(charList.size() != 0)
		{
			char tempCh = charList.remove(0); // Grabs the leading character
			
			Node tempNode = currentNode.checkChildren(tempCh); // Checks if there is a node with the char in it, return null if there is no child character
			
			if(tempNode == null)
			{
				nodeQueue.add(currentNode.addChild(tempCh, ++index));  // If there is not a child with that character let's add the child, and then queue it up for ease of output
				currentNode = rootNode;  // Reset to the rootNode
			}
			else
			{
				currentNode = tempNode;		// If the child exist move to that node and re-loop
			}
		}
		
		if(currentNode != rootNode)
		{
			nodeQueue.add(currentNode);				// This checks if we didn't add the last node to the queue, in case it ends on an already set node
		}
	}
	
	/* ---------------------------- Decode Functions --------------------------------- */
	
	// Pulls characters from the bit string and puts them into the trie
	private static void treeCharactersDecode()
	{		
		while(bitString.length() > (codeLength + 8))
		{
			String indexBits = bitString.substring(0, codeLength); // Grabs the code from the front for the index bits
			bitString = bitString.substring(codeLength); // Trim the code from the front of the string
			
			String characterBits = bitString.substring(0, 8); // Grab the 8 bits of the character
			bitString = bitString.substring(8);	// Trim the character from the front of the team
			
			int prefixIndex = Integer.parseInt(indexBits, 2); // Parse index bits into an integer.
			char character = (char)Integer.parseInt(characterBits, 2); // Parse the character bits into an integer, then cast to a character
			
			Node toAddTo = findIndex(prefixIndex, rootNode);  // Find the node we need to add the character to
			nodeQueue.add(toAddTo.addChild(character, ++index)); // Adds the child to the tree, and then queues the node for ease of processing
		}
		
	}
	
	// Finds the given index recursively
	private static Node findIndex(int prefixIndex, Node nodeToCheck) {
		if(nodeToCheck.index != prefixIndex)
		{
			for(Node c : nodeToCheck.characterNodes) // Loops through each child node looking for the right node
			{
				Node foundNode = findIndex(prefixIndex, c); 
				
				if(foundNode != null)
				{
					return foundNode;
				}
			}
		}
	
		else	// If the nodeToCheck has the index sought, we return the node
		{
			return nodeToCheck;
		}
		
		return null; // This should never be reached
		
	}

	// Builds a string from the queued nodes and decodes them into an actual string
	private static String buildStringFromQueueDecode()
	{
		String finalString = "";
		
		while(!nodeQueue.isEmpty())
		{
			Node workingNode = nodeQueue.remove(); // Pop a node off the top of the queue and construct the necessary string
			
			String workingString = "";
			
			while(workingNode.index != 0)
			{
				workingString = workingNode.letter + workingString; // Construct the string up the line starting with last character
				workingNode = workingNode.parentNode;
			}
			
			finalString += workingString; // Append node to the end of the final string
			
		}
		
		return finalString;
	}
}
