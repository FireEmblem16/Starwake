import java.util.ArrayList;

/**
 * 
 * @author Jonathan Krueger
 * 
 * Project: Homework 4 - Lempel-Ziv compression
 *
 */

public class Node {
	public int index;						// Helps track our progression and placement for encoding and decoding respectively
	public char letter; 					// This is the node letter, it helps for placing in encoding
	
	public Node parentNode; 				// A node should always know its parent so we can decode much easier
	public ArrayList<Node> characterNodes; 	// A node could branch out and have many post-fix characters
	
	public Node(int index, char letter, Node parentNode)
	{
		this.index = index;  
		this.letter = letter; 
		
		this.parentNode = parentNode; 
		characterNodes = new ArrayList<Node>(); 
	}
	
	
	// Checks the children of the node for the current character
	public Node checkChildren(char toFind)
	{
		for(Node n : characterNodes)		// Loop through all the nodes in the list
		{
			if(n.letter == toFind)			// If a letter has already been added as a child, return that child node
			{
				return n;					
			}
		}
		
		return null;						// If the character is not found return null
	}
	
	public Node addChild(char toAdd, int index)
	{
		characterNodes.add(new Node(index, toAdd, this)); 		// Add a new child node to this node with the parameters set
		return characterNodes.get(characterNodes.size() - 1);	// Return the new node to the caller
	}
}
