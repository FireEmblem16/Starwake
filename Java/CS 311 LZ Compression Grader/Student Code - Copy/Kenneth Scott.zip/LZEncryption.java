import java.util.BitSet;
import java.util.Stack;



public class LZEncryption {
	
	private LZEncryption() {
	}
	
	public static void main(String[] args) {}
	
	public static String encode(String uncompressed) {
		char[] input = uncompressed.toCharArray();
		TrieNode root = new TrieNode(0, null, 0, null);
		String encoding = new String();
		int curLoc = 0;
		int wordIndex = 1; // Start at 1, since root gets index 0
		Stack<String> tempStack = new Stack<String>();
		
		// build Trie first time to find dictionary size:
		while (curLoc < input.length) { //
			TrieNode nextEntry = findNextWord(curLoc, wordIndex++, input, root);
			TrieNode checkable = nextEntry;
			while (checkable.getIndex() != 0) {
				tempStack.push(checkable.getCharacter());
				checkable = checkable.getParent();
			}
			curLoc = curLoc + tempStack.size();
			tempStack.clear();
		}
		
		// wordIndex is now the dictionary size
		int dictionarySize = wordIndex;
//		System.out.println("Dictionary size: " + dictionarySize);
		int bitsForIndexEncoding = Integer.toBinaryString(dictionarySize).length();
//		System.out.println("Number of index bits: " + bitsForIndexEncoding);
		
		// create a bitset:
		BitSet bitset = new BitSet();
		int pointerBitSetEnd = 0;
		
		// encode 32 bits of index size:
		String binaryIndexSize = buildBinaryString(bitsForIndexEncoding, 32);
		writeToBitSet(binaryIndexSize, bitset, pointerBitSetEnd);
		pointerBitSetEnd += binaryIndexSize.length();
		
		// reinitialize variables:
		root = new TrieNode(0, null, 0, null);
		curLoc = 0;
		wordIndex = 1;
		// build Trie second time and encode:
		while (curLoc < input.length) {
			TrieNode nextEntry = findNextWord(curLoc, wordIndex++, input, root);
			
			// use above TrieNode to create each encoding
			if (nextEntry.getIndex() == wordIndex - 1) {
				// encode index reference:
				String theIndexEncoding = buildBinaryString(nextEntry.getPrefixIndex(), bitsForIndexEncoding);
				writeToBitSet(theIndexEncoding, bitset, pointerBitSetEnd);
				pointerBitSetEnd += theIndexEncoding.length();
				// encode character bits:
				char[] nextCharacter = nextEntry.getCharacter().toCharArray();
				String theCharEncoding = buildBinaryString(nextCharacter[0], 16);
				writeToBitSet(theCharEncoding, bitset, pointerBitSetEnd);
				pointerBitSetEnd += theCharEncoding.length();
			} else { // off track; assume findNextWord() returned an existing TrieNode
				// NOTE: the following is meant to guard against last-entry-repeat: (careful with indices)
				// encode index reference:
				String theIndexEncoding = buildBinaryString(nextEntry.getIndex(), bitsForIndexEncoding);
				writeToBitSet(theIndexEncoding, bitset, pointerBitSetEnd);
				pointerBitSetEnd += theIndexEncoding.length();
			}
			
			// for increasing curLoc only:
			TrieNode checkable = nextEntry;
			while (checkable.getIndex() != 0) {
				tempStack.push(checkable.getCharacter());
				checkable = checkable.getParent();
			}
			curLoc = curLoc + tempStack.size();
			tempStack.clear();
		}
		
		// pad the ending, multiple of 16 bits
		while ((pointerBitSetEnd) % 16 != 0) { // depends on pointer having been incremented past last element
			pointerBitSetEnd++;
		}
		byte[] bytes = flipBytes(bitset.toByteArray());
		byte[] paddedBytes = new byte[pointerBitSetEnd / 8];
		System.arraycopy(bytes, 0, paddedBytes, 0, bytes.length);
		
		char[] chars = bytesToChars(paddedBytes);
		
		// ASSIGN TO ENCODING:
		encoding = new String(chars);
		
		return encoding;
	}
	
	
	public static String decode(String compressed) {
		char[] input = compressed.toCharArray();
		TrieNode root = new TrieNode(0, null, 0, null);
		String decoding = "";
		int counter = 0;
		int wordIndex = 1;
		int bitsForIndexing = 0;
		int bitsForCharacter = 16;
		String onesAndZeroes = "";
		
		// interpret number of bits for index recording:
		for (int i = 0; i < 2; i++) {
			bitsForIndexing = bitsForIndexing << 16;
			char sixteen = input[i];
			bitsForIndexing |= sixteen;
		}
		counter = 32;
		
		// Convert input to String of "1" and "0":
		onesAndZeroes = "";
		for (char character : input) {
			onesAndZeroes += buildBinaryString(character, 16);
		}
		
		// Don't bother reading if all that remain are 0's
		int lastOne = onesAndZeroes.lastIndexOf('1');
		
		char[] binaryChars = onesAndZeroes.toCharArray();
		
		int wordSize = bitsForIndexing + bitsForCharacter;
		WordDictionary.eraseAll();
		WordDictionary.getInstance().addEntry(0, root);
		while (counter < lastOne) {
			decoding += decodeNextWord(counter, bitsForIndexing, bitsForCharacter, wordIndex++, binaryChars, root);
			counter += wordSize;
		}
		
		return decoding;
	}
	
	private static TrieNode findNextWord(int location, int indexForWord, char[] input, TrieNode root) {
		if (location >= input.length) {
			return null; // Redundant safety measure
		}
		
		String word = "";
		TrieNode current = root;
		TrieNode previous;
		int i = location;
		String letter;
		
		do {
			letter = String.valueOf(input[i++]);
			previous = current;
			current = current.getBranch(letter);
			word = word.concat(letter);
		} while (i < input.length && current != null);
		
		if (current == null) {
			TrieNode newTrieNode = new TrieNode(indexForWord, letter, previous.getIndex(), previous);
			previous.addBranch(newTrieNode);
			return newTrieNode;
		}
		else { // reached end of input without adding new letter
			return current;
		}
	}
	
	private static String buildBinaryString(int decimalNumber, int decDesiredNumBits) {
		String temp = "";
		for(int i = 0; i < decDesiredNumBits; i++) {
			int tempInt = 1 << i;
			
			if((decimalNumber & tempInt) != 0) {
				temp = "1" + temp;
			} else {
				temp = "0" + temp;
			}
		}
		
		return temp;
	}
	
	private static void writeToBitSet(String encodingToWrite, BitSet theBitSet, int endPointer) {
		for (int i = 0; i < encodingToWrite.length(); i++) {
			if (encodingToWrite.charAt(i) == '1') {
				theBitSet.set(endPointer++);
			} else {
				endPointer++;
			}
		}
	}
	
	private static byte[] flipBytes(byte[] array) {
		byte[] flipped = new byte[array.length];
		
		for (int i = 0; i < array.length; i++) {
			byte temp = 0;
			byte byteToFlip = array[i];
			
			for (int j = 0; j < 8; j++) {
				temp = (byte) (temp << 1);
				int movedJ = 1 << j;
				
				if ((byteToFlip & movedJ) != 0) {
					temp += 1;
				}
			}
			flipped[i] = temp;
		}
		return flipped;
	}
	
	/**
	 * @param bytes Should have bytes.length % 2 = 0
	 * @return
	 */
	private static char[] bytesToChars(byte[] bytes) {
		int bytesSize = bytes.length;
		char[] chars = new char[bytesSize/2];

		for (int i = 0; i < bytesSize/2; i++) {
			char c;
			byte leftByte = bytes[2*i];
			byte rightByte = bytes[2*i + 1];
			
			int holder = (0x00FF & leftByte);
			holder = (holder << 8);
			holder |= (0x00FF & rightByte);
			
			c = (char) holder;
			chars[i] = c;
		}
		return chars;
	}
	
	private static String decodeNextWord(int pointer, int bitsForIndex, int bitsForChar, int indexForWord, char[] input, TrieNode root) {
		int index = 0;
		String retval = "";
		WordDictionary dictionary = WordDictionary.getInstance();
		
		// interpret index value:
		for (int i = 0; i < bitsForIndex; i++) {
			index = index << 1;
			if (input[pointer++] == '1') {
				index += 1;
			}
		}
		
		// the parent that has the corresponding index
		TrieNode entry = root;
		
		if (index != 0) {
			entry = dictionary.getEntry(index);
			Stack<String> letters = new Stack<String>();

			TrieNode checkable = entry;
			while (checkable.getIndex() != 0) {
				letters.push(checkable.getCharacter());
				checkable = checkable.getParent();
			}
			while (!letters.isEmpty()) {
				retval += letters.pop();
			}
		}
		
		if (pointer + bitsForChar > input.length) { // no character to encode, presumably
			return retval;
		}
		
		// read character to an int
		int character = 0;
		for (int i = 0; i < bitsForChar; i++) {
			character = character << 1;
			if (input[pointer++] == '1') {
				character += 1;
			}
		}
		
		if (character != 0) { // should only be zero for perhaps the last entry
			String stringCharacter = String.valueOf((char) character);
			// add new word to dictionary:
			dictionary.addEntry(indexForWord, new TrieNode(indexForWord, stringCharacter, index, entry));
			// add character to word
			retval += stringCharacter;
		}
		
		return retval;
	}
	
}