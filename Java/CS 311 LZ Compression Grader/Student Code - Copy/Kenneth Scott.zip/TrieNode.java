import java.util.ArrayList;
import java.util.List;


class TrieNode {
	private int index;
	private int prefixIndex;
	private TrieNode parent;
	private String character;
	private List<TrieNode> children;
	
	public TrieNode(int index, String character, int prefixIndex, TrieNode parent) {
		this.index = index;
		this.character = character;
		this.prefixIndex = prefixIndex;
		this.parent = parent;
		children = new ArrayList<TrieNode>();
	}
	
	public int getIndex() {
		return index;
	}
	
	public int getPrefixIndex() {
		return prefixIndex;
	}
	
	public String getCharacter() {
		return character;
	}
	
	public TrieNode getBranch(String nextLetter) {
		for (TrieNode child : children) {
			if (child.getCharacter().equals(nextLetter)) {
				return child;
			}
		}
		
		return null;
	}
	
	public void addBranch(TrieNode child) {
		children.add(child);
	}

	public TrieNode getParent() {
		return parent;
	}

	public void setParent(TrieNode parent) {
		this.parent = parent;
	}
}