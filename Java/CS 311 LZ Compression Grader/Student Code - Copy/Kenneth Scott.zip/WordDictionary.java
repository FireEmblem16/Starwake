import java.util.ArrayList;
import java.util.List;


public class WordDictionary { // yes, it's a HashMap, not a Dictionary
	
	private static WordDictionary instance;
	private List<TrieNode> table;
	
	private WordDictionary() {
		table = new ArrayList<TrieNode>();
	}
	
	public static WordDictionary getInstance() {
		if (instance == null) {
			instance = new WordDictionary();
		} 
		return instance;
	}
	
	public void addEntry(int index, TrieNode newEntry) {
		instance.table.add(index, newEntry);
	}
	
	public TrieNode getEntry(int index) {
		return instance.table.get(index);
	}
	
	public static void eraseAll() {
		getInstance().table.clear();
	}

}
