/**
 * Static methods for converting primitive types to binary strings and vice versa
 * Example compression pseudocode
 *     integer -> toBinary(int) -> queue of bits -> popPrimitive(char) -> char[]
 * Example decompression pseudocode
 *     char[] -> toBinary(char) -> queue of bits -> popPrimitive(int) -> integer
 * Created by Brandon on 10/11/2014.
 */
public class BitComp {
    /**
     * Converts any primitive type (where SIZE <= Integer.SIZE) to a binary string
     * Binary string will be length of bits
     * @param primitive To convert
     * @param bits Length of string
     * @return Converted binary string
     */
    public static String toBinary(int primitive, int bits) {
        // Convert to a string of bits
        // WARNING, will convert to a signed int (with extra 1's for negative). And will remove unneccesary 0's
        String bit_string = Integer.toBinaryString(primitive);

        // If there are more bits then the size, then remove the extra signed bits
        if(bit_string.length() > bits) {
            int length = bit_string.length();
            bit_string = bit_string.substring(length - 16, length);
        }

        // If there are less bits, add empty bits
        while(bit_string.length() < bits) {
            bit_string = '0' + bit_string;
        }

        System.out.println("Expand (" + (char)primitive + "|" + primitive + ") to (" + bit_string + ")");

        return bit_string;
    }

    /**
     * Removes specified # of bits from StringBuilder and places them into an int.
     * Cast int to desired type. e.g. "(char) popPrimitive(binary, 16)" will get a character
     * @param binary_string String of bits to remove from.
     * @param bits Bit length of output type
     * @param force If true, will add trailing 0's to fill integer. WILL NOT FILL IF STRING ALREADY EMPTY
     * @return Integer value, or -1 if there was not enough bits in string.
     */
    public static int popPrimitive(StringBuilder binary_string, int bits, boolean force) {
        if(binary_string.length() == 0) //If string is empty
            return -1;
        else if(binary_string.length() >= bits) { //If string has enough bits
            String substring = binary_string.substring(0, bits);
            binary_string.delete(0, bits);
            int parsed_value = Integer.parseInt(substring, 2);

            System.out.println("Reduce (" + substring + ") to (" + (char)parsed_value + "|" + parsed_value + ")");

            return parsed_value;
        }
        else if (force) { //If string doesn't have enough bits, but wants to force it
            int remaining = bits - binary_string.length();

            // Add 0's so binary_string.length() == 8
            for(int i = 0; i < remaining; i++)
                binary_string.append('0');
            return popPrimitive(binary_string, bits, false);
        }
        return -1; //There isn't enough bits left to remove integer
    }


}