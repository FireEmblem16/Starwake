/**
 * Uses BitComp library to LZ compress a string
 * Created by Brandon on 10/9/2014.
 */
public class LZCompressor {
    public static final int TABLESIZE = 32;
    public static final int BITMASK = 0x1;

    // Stack containing bits that need to be added to compressed_queue string. MSB is at top of stack
    // One character is used to store a single bit.
    StringBuilder bit_queue;

    // Already compressed_queue section
    StringBuilder compressed_queue;
    int index_bit_size;

    public LZCompressor(int index_bit_size) {
        bit_queue = new StringBuilder();
        compressed_queue = new StringBuilder();
        this.index_bit_size = index_bit_size;

        bit_queue.append(BitComp.toBinary(index_bit_size, TABLESIZE));

        // Keep compressing until maximum number of characters have been
        // removed from bit_queue and moved to compressed_queue
        while(popCharToString(bit_queue, compressed_queue, false));
    }

    public String addEntry(CompList<Character> compList) {
        String index_value_bitstring = BitComp.toBinary(compList.index, index_bit_size);
        if(compList.value != null)
                index_value_bitstring += BitComp.toBinary(compList.value, Character.SIZE);

        bit_queue.append(index_value_bitstring);

        // Try to pop out bits ASAP, to keep size of bit_queue minimized
        popCharToString(bit_queue, compressed_queue, false);

        return index_value_bitstring;
    }


/*
    private void pop(boolean force) {
        // If there are no bits, ignore
        if(bit_queue.length() == 0)
            return;

        while(bit_queue.length() >= Character.SIZE) {
            String char_of_bits = bit_queue.substring(0, Character.SIZE);
            bit_queue.delete(0, Character.SIZE);
            char parsed_char = (char) Integer.parseInt(char_of_bits, 2);

            System.out.println("Compression: Compress (" + char_of_bits + ") to (" + parsed_char + ")");

            compressed_queue.append(parsed_char);
        }

        // If force, pop any remaining bits, filling end of character with 0's
        if(force) {
            int remaining = Character.SIZE - bit_queue.length();

            // Add 0's so bit_queue.length() == 8
            for(int i = 0; i < remaining; i++)
                bit_queue.append('0');
            pop(false);
        }
    }
*/
    public String toString() {
        while(popCharToString(bit_queue, compressed_queue, true));

        String compressed = compressed_queue.toString();
        System.out.println("Compression: Raw compressed (" + compressed + ")");
        for(char value: compressed.toCharArray())
                System.out.println(String.format("Compression: 0x%04X", (int)value));
        return compressed;
    }

    /**
     * Helper method that will try to take character bits out of source and convert to character type
     * @param source Bit String with characters
     * @param destination Converted string
     * @param force If true, will trail 0's if there aren't enough bits for an entire character
     * @return True if was able
     */
    public static boolean popCharToString(StringBuilder source, StringBuilder destination, boolean force) {
        int popped = BitComp.popPrimitive(source, Character.SIZE, force);
        if (popped != -1) {
            destination.append((char) popped);
            return true;
        }
        return false;
    }
}

    /*
    public void add(int next) {
        for(int i = 0; i < Integer.SIZE; i++) {
            int masked = (next >> i) & BITMASK;
            bit_queue.add((byte) masked);
        }
        pop();
    }

    public void add(char next) {
        for(int i = 0; i < Character.SIZE; i++) {
            int masked = (next >> i) & BITMASK;
            bit_queue.add((byte) masked);
        }
        pop();
    }
    */