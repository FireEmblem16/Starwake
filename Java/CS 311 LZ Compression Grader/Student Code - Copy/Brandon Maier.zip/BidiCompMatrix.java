/**
 * Bi-directional Compressed Matrix
 * List property: Values are lists containing Comparable objects. BidiList compares lists when storing them.
 * Bi-directional property: Index maps to list of values. List of values maps to an index.
 * Created by Brandon on 10/8/2014.
 */
public interface BidiCompMatrix <V extends Comparable> {

    /**
     * Starting at first element of iterable, eats (removes) series of elements that match a list in Map.
     * Eats the frist unique element it finds, and extends Matrix with unique element.
     * The LempelZiv.Entry can be exchanged for the set of elements that were eaten.
     * @param values Iterable to eat from.
     * @return LempelZiv.CompLIst of next unique list. If there are no more unique elements, returns null value.
     */
    public CompList<V> eatNext(Iterable<V> values);

    /**
     * Gets list pointed to by this entry. Index in CompList must already exist.
     * @param compList A compList, where the index exists
     * @return Full list if successful, else null
     */
    public Iterable<V> addCompList(CompList<V> compList);

    /**
     * Adds a value at index. Equivalent to adding an entry with (BidiList.get(index) + value)
     * @return
     */
    public int add(int index, V value);

    public int bitSizeOfIndex();
}