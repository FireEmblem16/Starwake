/**
 * Uses BitComp library to decompress a LZ string
 * Created by Brandon on 10/10/2014.
 */
public class LZDecompressor {
    int table_size;
    StringBuilder bit_queue;
    StringBuilder compressed;

    public LZDecompressor(String compressed) {
        if(compressed.length() < 3)
            throw new StringIndexOutOfBoundsException("Compressed string should be at least two characters for table");
        this.compressed = new StringBuilder(compressed);

        bit_queue = new StringBuilder();


        // Convert char to a binary string, then add them to bit_queue
        getChar();
        getChar();

        // Pop an integer off bit_queue
        this.table_size = BitComp.popPrimitive(bit_queue, Integer.SIZE, false);

        System.out.println("Tablesize (" + table_size + ")");
    }

    public CompList<Character> getEntry() {
        boolean hasNext = true;
        while(bit_queue.length() < table_size + Character.SIZE && hasNext) {
            hasNext = getChar();
        }

        int index = BitComp.popPrimitive(bit_queue, table_size, false);

        if(index == -1)
            return null;

        int value = BitComp.popPrimitive(bit_queue, Character.SIZE, false);
        if(value == -1) {
            return new CompList<Character>(index, null);
        }
        else
            return new CompList<Character>(index, (char) value);



    }

    public boolean getChar() {
        if(compressed.length() == 0)
            return false;
        char table_one = compressed.charAt(0);
        compressed.deleteCharAt(0);
        bit_queue.append(BitComp.toBinary(table_one, Character.SIZE));
        return true;
    }


}
