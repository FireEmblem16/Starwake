import java.io.FileNotFoundException;

/**
 * Tester for LZ
 * Created by Brandon on 10/9/2014.
 */
public class Test {
    public static void main(String [ ] args) throws FileNotFoundException {
        String content = "Do not meddle in the affairs of wizards, for they are subtle and quick to anger.";//new Scanner(new File("yes.txt")).useDelimiter("\\Z").next();
        String compressed = LZ.encode(content);
        System.out.println(compressed);
        String uncompressed = LZ.decode(compressed);
        System.out.println(uncompressed);

        // aabaabb -> 0: (,) 1:a(0, a) 2:ab(1, b) 3:aa(1, a) 4:b(0, b) 5:b(4,)
        /*
        LZCompressor compress = new LZCompressor(4);



        CompList<Character> one = new CompList<Character>(0, (char)0x00C8);
        CompList<Character> two = new CompList<Character>(1, (char)0x22C8);
        compress.addEntry(one);
        compress.addEntry(two);
        String compressed = compress.toString();
        System.out.println(compressed);

        LZDecompressor decompress = new LZDecompressor(compressed);
        System.out.println(decompress.getEntry().toString());
        System.out.println(decompress.getEntry().toString());
        */

        /*
        char char_ascii = 0x00C8;
        char char_utf = 0x22C8;
        compress.addIndex(0);
        compress.addChar(char_ascii);
        compress.addIndex(1);
        compress.addChar(char_utf);
        System.out.println(compress.toString());
        */


        /*
        System.out.println(char_utf);
        String string_binary = Integer.toBinaryString(char_utf);
        System.out.println(string_binary);
        //Integer.
        //System.out.println();
        //char repeat = Integer.decode(test);
        //byte byte_ascii = -128;
        //System.out.println(Integer.toBinaryString(byte_ascii));

        String string_utf = ""+(char)0x22C8 + (char)0x33C8;
        System.out.println(string_utf);
        byte[] array_byte = string_utf.getBytes();
        for(byte elem: array_byte)
            System.out.println(elem);

        System.out.println(char_ascii + ": " + compress.addChar(char_ascii));
        System.out.println(char_utf + ": " + compress.addChar(char_utf));

        */
    }
}
