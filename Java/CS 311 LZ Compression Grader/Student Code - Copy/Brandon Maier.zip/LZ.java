import java.util.LinkedList;

/**
 * Created by Brandon on 9/24/2014.
 */
public class LZ {
    public static String encode(String uncompressed) {
        // Convert String to a useful object type
        LinkedList<Character> uncompressed_list = convertString(uncompressed);
        BidiCompMatrix<Character> matrix = new TrieList<Character>();

        // Store compacted strings
        LinkedList<CompList<Character>> compactedLists = new LinkedList<CompList<Character>>();

        while (!uncompressed_list.isEmpty()) {
            // Match next compacted string in uncompressed. eatNext will automatically remove characters
            CompList<Character> newCompList = matrix.eatNext(uncompressed_list);

            compactedLists.add(newCompList);

        }

        // Fetched all characters

        LZCompressor compressor = new LZCompressor(matrix.bitSizeOfIndex());
        String compressed_binary = "";
        for (CompList<Character> comp_list : compactedLists) {
            System.out.println(comp_list.toString());
            compressor.addEntry(comp_list);
        }

        return compressor.toString();
    }

    public static String decode(String compressed) {
        BidiCompMatrix<Character> matrix = new TrieList<Character>();

        LZDecompressor decompressor = new LZDecompressor(compressed);

        StringBuilder uncompressed = new StringBuilder();

        CompList<Character> entry = decompressor.getEntry();
        while(entry!= null && !(entry.value == null && entry.index == 0)) {
            Iterable<Character> string = matrix.addCompList(entry);
            for(Character letter: string) {
                uncompressed.append(letter);
            }
            entry = decompressor.getEntry();
        }

        return uncompressed.toString();
    }

    /**
     * Create an arraylist of Characters from string.
     * @param string String
     * @return ArrayList
     */
    public static LinkedList<Character> convertString(String string) {
        char[] primitive_arr = string.toCharArray();
        LinkedList<Character> array = new LinkedList<Character>();
        for(char prim: primitive_arr) {
            array.add(new Character(prim));
        }
        return array;
    }
}

