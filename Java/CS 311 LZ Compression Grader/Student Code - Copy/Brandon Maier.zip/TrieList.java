import java.util.*;

/**
 * Created by Brandon on 9/24/2014.
 * A combination Trie and List
 * Trie's values are indices in list, and List's values are nodes in Trie.
 * Allows index lookup by value with Trie, and value lookup by index with ArrayList
 */
public class TrieList<T extends Comparable> implements BidiCompMatrix<T> {


    @Override
    public CompList<T> eatNext(Iterable<T> values) {
        Iterator<T> iter = values.iterator();
        Node parent = root;
        while(iter.hasNext()) {
            T elem = iter.next();   //Get next element
            iter.remove();          //Delete every element from source
            Node child = parent.findChild(elem);
            if(child == null) {     //Element doesn't exist
                child = newNode(parent, elem);  //Add it
                return new CompList<T>(parent.index, child.value);
            }
            else {  //Element does exist, continue looking for unique
                parent = child;
            }
        }
        // No more elements
        return new CompList<T>(parent.index, null);
    }

    @Override
    public Iterable<T> addCompList(CompList<T> compList) {
        // Get Node pointed to by index
        Node node = list.get(compList.index);

        // Create stack for storing
        LinkedList<T> values = new LinkedList<T>();


        if(compList.value != null) {
            // Add the value to bottom of stack
            values.add(compList.value);

            // Create node for the new element
            newNode(node, compList.value);
        }

        // Add all elements above the index
        // While the parent of this node isn't null. (If at root, will end without adding value of root)
        while(node.parent != null) {
            values.add(node.value);
            node = node.parent;
        }



        // Reverse order
        Collections.reverse(values);

        return values;
    }

    @Override
    public int add(int index, T value) {
        return 0;
    }

    @Override
    public int bitSizeOfIndex() {
        return (int) Math.ceil(Math.log(list.size() + 1)/Math.log(2));
    }

    /**
     * Private node class for building Trie
     */
    private class Node {
        public Node parent;
        public ArrayList<Node> children;
        public T value;
        public int index;

        public Node(Node parent, T value, int index) {
            this.parent = parent;
            if(parent != null)
                parent.children.add(this);
            this.children = new ArrayList<Node>();
            this.value = value;
            this.index = index;
        }

        /**
         * Checks for a child who's value is equal
         * @param search Child's value
         * @return Child if success, null if failure
         */
        public Node findChild(T search) {
            // For every child node
            for(Node node: children) {
                // Check if that child is equal to the search query
                if(node.value.compareTo(search) == 0)
                    return node;
            }
            return null;
        }
    }

    // Root of tree
    private Node root;

    // List where indice refers to order added
    ArrayList<Node> list;

    public TrieList() {

        list = new ArrayList<Node>();

        // Root of trie is an empty node
        root = newNode(null, null);
    }

    private Node newNode(Node parent, T value) {
        Node node = new Node(parent, value, list.size());
        list.add(node);
        return node;
    }

    /**
     * Finds index of leaf (where n=depth of leaf) in trie who's value matches the first 'n' items in queue.
     * Removes elements from queue if they were in trie
     * @param queue List of value to start searching at
     * @return index of leaf
     */
    public int findNew(Queue<T> queue) {
        Node parent = root;
        Node child = parent.findChild(queue.peek());
        while(child != null) { // While the next element in queue exists in trie
            queue.remove(); // Remove from queue
            parent = child;
            child = parent.findChild(queue.peek()); // Check if next element in queue exists in trie
        }

        return parent.index;
    }

    public int getID(Queue value) {
        return 0;
    }

    /**
     * Fetchs Stack<elem> that represents this node in a trie
     * @param index
     * @return
     */
    public Stack<T> getValues(int index) {
        Node node = list.get(index);

        Stack<T> values = new Stack<T>();

        // While the parent of this node isn't null. (If at root, will end without adding value of root)
        while(node.parent != null) {
            values.add(node.value);
            node = node.parent;
        }

        return values;
    }

    public int addLeaf(int index, T elem) {
        Node leaf = newNode(list.get(index), elem);
        return leaf.index;
    }

    /**
     * Finds deepest matching value in Iterator
     * @param keys
     * @return
     */
    public int indexOfKey(Iterable<T> keys) {
        Node node = root;
        Node child;
        for(T key: keys) {
            child = node.findChild(key);
            //if(child == null)
            //    return node.getIndex();
        }
        return 0;
    }


}
