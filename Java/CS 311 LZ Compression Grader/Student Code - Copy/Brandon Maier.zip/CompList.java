import java.util.Queue;

/**
 * CompressedLists in my BidiCompMatrix
 * NOTE: The index refers to the sub-list containing everything but the last element
 * The last element is the value.
 * Created by Brandon on 10/9/2014.
 */
public class CompList<V> {
    int index;
    V value;

    CompList(int index, V value) {
        this.index = index;
        this.value = value;
    }

    public boolean isEmpty() {
        if(index == 0 && value == null)
            return true;
        else
            return false;
    }

    public String toString() {

        String output = "Index (" + index + ")";
        if (value != null)
            output += " Value (" + value.toString() + ")";
        return output;
    }
}