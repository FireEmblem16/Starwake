import static org.junit.Assert.*;

import org.junit.Test;


public class Tests {

	@Test
	public void testLambda() {
		assertEquals(LZEncryption.encode(""), "0");
	}

}
