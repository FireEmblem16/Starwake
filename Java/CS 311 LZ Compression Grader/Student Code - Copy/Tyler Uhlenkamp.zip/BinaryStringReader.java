
public class BinaryStringReader {
	private int currentCharIndex;
	private int currentPos;
	private String str;
	
	static final int bitsPerChar = 16;
	static final int bitsPerInt = 32;

	public BinaryStringReader(String s) {
		str = s;
		currentCharIndex = 0;
		currentPos = bitsPerChar - 1;
	}
	
	public int get(int numBits) {
		int res = 0;
		int curBit = numBits - 1;
		
		while(curBit >= 0) {
			int mask = (int) str.charAt(currentCharIndex);
			mask = (mask >> currentPos) & 1;
			res |= (mask << curBit);
			
			curBit--;
			currentPos--;
			
			if(currentPos == -1) {
				currentCharIndex++;
				currentPos = bitsPerChar - 1;
			}
		}
		
		return res;
	}
	
	public boolean hasBits(int numBits) {
		int bitsRemaining = (str.length() - currentCharIndex - 1) * bitsPerChar;
		bitsRemaining += currentPos + 1;
		
		return bitsRemaining >= numBits;
	}
}
