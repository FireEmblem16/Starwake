
public class LZTrie implements LZDictionary {
	private TrieNode root;
	private int size;
	
	private class TrieNode {
		private int index;
		private TrieNode[] children;
		
		public TrieNode(int i) {
			index = i;
			children = new TrieNode[256];
		}
		
		public int getIndex() {
			return index;
		}
		
		public boolean hasChild(char c) {
			return children[c] != null;
		}
		
		public TrieNode getChild(char c) {
			return children[c];
		}
		
		public void addChild(char c, int i) {
			children[c] = new TrieNode(i);
		}
	}
	
	public LZTrie() {
		root = new TrieNode(0);
		size = 1;
	}
	
	
	/**
	 * Given a string and a starting position, adds the longest substring starting at the given position to the dictionary 
	 * and returns an object containing the index of the new phrase and the index of the last character added 
	 */
	public AddResult add(String s, int startPos) {
		int i = startPos;
		TrieNode node = root;
		
		while(i < s.length() && node.hasChild(s.charAt(i))) {
			node = node.getChild(s.charAt(i));
			i++;
		}
		
		if(i < s.length()) {
			node.addChild(s.charAt(i), size++);
		}
		
		return new AddResult(node.getIndex(), i);
	}
	
	/**
	 * Number of phrases in the Trie, including empty string
	 */
	public int getSize() {
		return size;
	}

	/**
	 * Returns the phrase string at the given index
	 */
	@Override
	public String getStringByIndex(int index) {
		if(index >= size) return null;
		return getStringByIndex(index, root, "");
	}
	
	public String getStringByIndex(int index, TrieNode node, String cur) {
		if(node == null) return null;
		
		if(node.index == index) {
			return cur;
		}
		else {
			for(int i = 0; i < node.children.length; i++) {
				String res = getStringByIndex(index, node.children[i], cur+(char)(i));
				if(res != null) {
					return res;
				}
			}
			return null;
		}
	}
}
