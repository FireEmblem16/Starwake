import java.util.ArrayList;


public class LZEncryption {
	private LZEncryption(){}

	public static String encode(String uncompressed) {
		LZDictionary dict = new LZTrie();
		
		ArrayList<CompressionFrame> frames = buildFrames(uncompressed, dict);
		
		int bitsPerFrame = (int) Math.ceil(Math.log(dict.getSize()) / Math.log(2));
		
		return compressFrames(frames, bitsPerFrame); 
	}

	public static String decode(String compressed) {
		StringBuilder b = new StringBuilder();
		BinaryStringReader reader = new BinaryStringReader(compressed);
		
		LZDictionary dict = new LZTrie();

		int bitsPerIndex = reader.get(32);
		while(reader.hasBits(bitsPerIndex + 16)) {
			int index = reader.get(bitsPerIndex);
			int append = reader.get(16);
			String phrase = dict.getStringByIndex(index);			
			String add = phrase + (char) append;
			b.append(add);
			dict.add(add, 0);
		}
		
		if(reader.hasBits(bitsPerIndex)) {
			int index = reader.get(bitsPerIndex);
			String add = dict.getStringByIndex(index);
			b.append(add);
		}
		
		return b.toString();
	}
	
	private static String compressFrames(ArrayList<CompressionFrame> frames, int bitsPerIndex) {

		BinaryStringBuilder b = new BinaryStringBuilder();
		b.write(bitsPerIndex,  32);
		
		for(CompressionFrame f : frames) {
			b.write(f.index, bitsPerIndex);
			if(f.includeChar)
				b.write(f.next, 16);
		}
		
		return b.getString();
	}
	
	private static ArrayList<CompressionFrame> buildFrames(String uncompressed, LZDictionary dict) {
		ArrayList<CompressionFrame> frames = new ArrayList<CompressionFrame>();
		int index = 0;
				
		if(uncompressed.equals("")) {
			frames.add(new CompressionFrame(0, false));
		}
		
		while(index < uncompressed.length()) {
			AddResult ar = dict.add(uncompressed, index);
			index = ar.finalPosition;
			
			CompressionFrame nextFrame = new CompressionFrame(ar.index, false);
			
			if(index < uncompressed.length()) {
				nextFrame.setChar(uncompressed.charAt(index));
			}
			
			index++;
			
			frames.add(nextFrame);
		}
		
		return frames;
	}

	private static void printFrames(ArrayList<CompressionFrame> frames) {
		int i = 1;
		for(CompressionFrame f : frames) {
			System.out.println(i + " " + f.index + " " + f.next + " " + f.includeChar);
			i++;
		}		
	}
}
