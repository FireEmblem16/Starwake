import java.util.Random;


public class BinaryStringBuilder {
	private StringBuilder b;
	private char currentChar;
	private int currentPos;
	
	static final int bitsPerChar = 16;
	static final int bitsPerInt = 32;
	
	public BinaryStringBuilder() {
		b = new StringBuilder();
		currentChar = 0;
		currentPos = bitsPerChar-1;
	}
	
	public void write(int i, int numBits) {
		numBits -= 1;
		while(numBits >= 0) {
			int mask = (i >> numBits) & 1;
			currentChar |= (mask << currentPos);
			numBits--;
			currentPos--;
			
			if(currentPos == -1) {
				commitCurrent();
			}
		}
	}
	
	private void commitCurrent() {
		b.append(currentChar);
		currentChar = 0;
		currentPos = bitsPerChar-1;
	}
	
	public String getString() {
		if(currentPos == (bitsPerChar - 1)) {
			// We're goooood. Don't bother writing any more
		}
		else {
			write(0, currentPos + 1);
		}
		return b.toString();
	}
}

