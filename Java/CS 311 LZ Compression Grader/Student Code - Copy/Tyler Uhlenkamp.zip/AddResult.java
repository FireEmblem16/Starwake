
public class AddResult {
	/*
	 * The index of the added phrase
	 */
	public int index;
	
	/* 
	 * The index (withinin the uncompressed string) of the last character in the added phrase 
	 */
	public int finalPosition;
	
	public AddResult(int i, int n) {
		index = i;
		finalPosition = n;
	}
}
