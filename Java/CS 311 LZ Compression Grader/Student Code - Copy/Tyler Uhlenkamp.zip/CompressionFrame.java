
public class CompressionFrame {
	public int index;
	public char next;
	public boolean includeChar;
	
	public CompressionFrame(int i, char c, boolean includec) {
		index = i;
		next = c;
		includeChar = includec;
	}
	
	public CompressionFrame(int i, boolean includec) {
		index = i;
		includeChar = includec;
	}
	
	public void setChar(char c) {
		next = c;
		includeChar = true;	
	}
}
