
public interface LZDictionary {
	public AddResult add(String s, int startPos);
	public int getSize();
	public String getStringByIndex(int index);
}
