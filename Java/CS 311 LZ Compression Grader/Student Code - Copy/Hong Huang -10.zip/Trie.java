import java.util.ArrayList;
import java.util.List;

public class Trie {
	static final int NUM = 256;

    // trie node
	// next: different characters lead to different next nodes
	// value: store the parsing Id
	static class Node {

		Node[] next = new Node[NUM];
		int value = 0;
	}
	
	//the riit if the trie
	Node root = new Node();

	/*
	 * Take an example from the pdf
	x= a ab aa aba aaa aab ababbbb aba
    z=0a 1b 1a 2a 3a 3b 4b 0b 8b 4
    
    then the parsingIds would be the list {0,1,1,2,3,3,4,0,8,4}
    and the endCharacters would be the list {a,b,a,a,a,b,b,b,b}
    
    */
	List<Integer> sq = new ArrayList<Integer>(); 
	List<Character> cs = new ArrayList<Character>();

	/*
	 * convert the parsingIds and endCharacters to binary string representation
	 */
	String convert() {   
		int n = sq.size();
        
		int bs;
		if(n<=1){
			bs=0;
		}else{
			bs = Integer.toBinaryString(n-1).length();
		}
		
		 
        
		int z=32+(bs + 16) * sq.size();
		if(cs.size()<sq.size()){
			z-=16;
		}
		
		if(z%16!=0)
		    z=z+16-z%16;
		
		
		char t[] = new char[z];
        
		for(int i=0;i<z;i++){
			t[i]='0';
		}
		
		int j=32;
		String g=Integer.toBinaryString(bs);
		for (int u = 1; u <= g.length(); u++) {
			t[j - u] = g.charAt(g.length() - u);
		}
		
		
		for (int i = 0; i < sq.size(); i++) {
			int a = sq.get(i);

			 g = Integer.toBinaryString(a);

			 j =32+ (bs + 16) * i + bs;

			for (int u = 1; u <= g.length(); u++) {
				t[j - u] = g.charAt(g.length() - u);
			}

			if (i < cs.size()) {
				a = cs.get(i);

				g = Integer.toBinaryString(a);

				j = 32+(bs + 16) * (i + 1);

				for (int u = 1; u <= g.length(); u++) {
					t[j - u] = g.charAt(g.length() - u);
				}
			}

		}
		
		

		return new String(t);
	}

	/*
	 * convert the binary string representation to parsingIds and endCharacters
	 */

	void convert(String s){
		int b=Integer.parseInt(s.substring(0, 32), 2);
		int n=(s.length()-32)/(b+16);
		int r=(s.length()-32)%(b+16);
		for(int i=0;i<n;i++){
			int x=0;
			if(b!=0)
			   x=Integer.parseInt(s.substring(32+(b+16)*i, 32+(b+16)*i+b),2);
			int y=Integer.parseInt(s.substring(32+(b+16)*i+b, 32+(b+16)*(i+1)),2);
			sq.add(x);
			cs.add((char)y);
		}
		
		if(r!=0 && Integer.parseInt(s.substring(s.length()-r),2)!=0)
		{
//			System.out.println(s.length());
//			System.out.println(s.length()-r);
//			System.out.println(s.length()-r+b);
			int x=Integer.parseInt(s.substring(s.length()-r,s.length()-r+b),2);
			sq.add(x);
		}
		
		
		
	}

	
	
	/**
	 * 
	 * @param s
	 * encode the string s as parsingIds and endCharacters
	 * for example if s=a ab aa aba aaa aab ababbbb aba
	 *  then the parsingIds would be the list {0,1,1,2,3,3,4,0,8,4}
        the endCharacters would be the list {a,b,a,a,a,b,b,b,b} 
	 */
	void encode(String s) {
		int count = 0;
		int i = 0;
		while (i < s.length()) {
			Node r = root;

			while (true) {
				char c = s.charAt(i++);
				// int t=c;

				if (r.next[c] == null) {

					Node n = new Node();
					n.value = ++count;
					r.next[c] = n;
					sq.add(r.value);

					cs.add(c);

					break;

				} else {
					r = r.next[c];
				}

				if (i == s.length()) {
					sq.add(r.value);

					return;
				}
			}

		}
	}
	
	
	/*
	 * decode the  parsingIds and endCharacters to original string
	 */
	String decode() {
		String a[] = new String[sq.size() + 1];
		String s = "";
		a[0] = "";

		for (int i = 0; i < sq.size(); i++) {
			a[i + 1] = a[sq.get(i)];
			if (i < cs.size()) {
				a[i + 1] += cs.get(i);
			}

			s += a[i + 1];
		}

		return s;
	}


}
