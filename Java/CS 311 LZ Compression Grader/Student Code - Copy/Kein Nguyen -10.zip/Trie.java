import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Trie {
	TrieNode root;
	int trieOrder;
	public Trie() {
		root = new TrieNode();
		root.order = 0;
		trieOrder = 1;
	}
	
	public void add(String prefix, Character c) {
		TrieNode current = root;
		for (int i=0; i<prefix.length(); i++) {
			current = current.mapping.get(prefix.charAt(i));
		}
		current.add(c);
	}
	
	public boolean contain(String randomString) {
		TrieNode current = root;
		for (int i=0; i<randomString.length(); i++) {
			if (current.mapping.get(randomString.charAt(i)) == null) {
				return false;
			}
			current = current.mapping.get(randomString.charAt(i));
		}
		return true;
	}
	
	public int getPrefixIndex(String randomString) {
		TrieNode current = root;
		for (int i=0; i<randomString.length(); i++) {
			current = current.mapping.get(randomString.charAt(i));
		}
		return current.order;
 	}
	
	public String add(int prefix, char c) {
		return addHelper(prefix, c, root, "");
	}
	
	private String addHelper(int prefix, char c, TrieNode node, String res) {
		if (node.order == prefix) {
			node.add(c);
			return res + c;
		} else if (node.mapping.isEmpty()) {
			return "";
		} else {
			String value = "";
			Iterator<Map.Entry<Character, TrieNode>> iter = node.mapping.entrySet().iterator();
			while (iter.hasNext()) {
				Map.Entry<Character, TrieNode> entry = iter.next();
				TrieNode next = entry.getValue();
				value = addHelper(prefix, c, next, res + entry.getKey());
				if (!value.equals("")) {
					break;
				}
			}
			return value;
		}
	}
	
	public String stringAt(int prefix) {
		if (prefix == 0) {
			return "";
		}
		return stringAtHelper(prefix, root, "");
	}
	
	private String stringAtHelper(int prefix, TrieNode node, String res) {
		if (node.order == prefix) {
			return res;
		} else if (node.mapping.isEmpty()) {
			return "";
		} else {
			String value = "";
			Iterator<Map.Entry<Character, TrieNode>> iter = node.mapping.entrySet().iterator();
			while (iter.hasNext()) {
				Map.Entry<Character, TrieNode> entry = iter.next();
				TrieNode next = entry.getValue();
				value = stringAtHelper(prefix, next, res + entry.getKey());
				if (!value.equals("")) {
					break;
				}
			}
			return value;
		}
	}
	
	private class TrieNode {
		public int order;
		public HashMap<Character, TrieNode> mapping;
		
		public TrieNode() {
			mapping = new HashMap<Character, TrieNode>();
			order = 0;
		}
		
		public void add(Character c) {
			if (mapping.get(c) == null) {
				TrieNode newNode = new TrieNode();
				newNode.order = trieOrder;
				mapping.put(c, newNode);
				trieOrder++;
			}
		}
	}
	
	public static void main(String[] args) {
		HashMap<Character, Integer> hm = new HashMap<>();
		hm.put('c', 3);
		hm.put('a', 1);
		System.out.println(hm.get('c'));
		System.out.println(hm.get('b') == null);
	}
}
