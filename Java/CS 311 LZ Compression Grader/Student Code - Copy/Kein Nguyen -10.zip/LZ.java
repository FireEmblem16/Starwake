public class LZ {
	private LZ() {}
	
	public static String encode(String uncompessed) {
		StringBuilder res = new StringBuilder();
		//ArrayList<String> phrases = new ArrayList<String>();
		int count = 0;
		Trie trie = new Trie();
		int startIndex = 0;
		int currentIndex = 0;
		while (currentIndex < uncompessed.length()) {
			if (!trie.contain(uncompessed.substring(startIndex, currentIndex+1))) {
				trie.add(uncompessed.substring(startIndex, currentIndex), uncompessed.charAt(currentIndex));
				//phrases.add(uncompessed.substring(startIndex, currentIndex+1));
				count++;
				startIndex = currentIndex + 1;
			} 
			currentIndex++;
		}
		if (startIndex < uncompessed.length()) {
			count++;
			//phrases.add(uncompessed.substring(startIndex));
		}
		
		int numBits = (int)Math.ceil(Math.log(count+1)/Math.log(2));
		//System.out.println("numBits: " + numBits);
		//System.out.println(phrases.toString());
		res.append(numberToBinary(numBits, 32));
		trie = new Trie();
		startIndex = 0;
		currentIndex = 0;
		while (currentIndex < uncompessed.length()) {
			if (!trie.contain(uncompessed.substring(startIndex, currentIndex+1))) {
				trie.add(uncompessed.substring(startIndex, currentIndex), uncompessed.charAt(currentIndex));
				int index = trie.getPrefixIndex(uncompessed.substring(startIndex, currentIndex));
				res.append(numberToBinary(index, numBits));
				res.append(characterToBinary(uncompessed.charAt(currentIndex)));
				startIndex = currentIndex + 1;
			}
			currentIndex++;
		}
		if (startIndex < uncompessed.length()) {
			int lastIndex = trie.getPrefixIndex(uncompessed.substring(startIndex)); 
			res.append(numberToBinary(lastIndex, numBits));
		}
		while (res.length() % 16 != 0) {
			res.append('0');
		}
		return res.toString();
	}
	
	public static String decode(String compressed) {
		if (compressed.length() < 32) {
			System.out.println("invalid input");
			return null;
		}
		String startBits = compressed.substring(0, 32);
		int runner = 32;
		int numBitsForPrefix = binaryToNumber(startBits);
		int numBitsEachCodeWord = numBitsForPrefix + 16;
		//System.out.println("string length: "+compressed.length());
		//System.out.println("numBitsForPrefix: "+numBitsForPrefix);
		//System.out.println("numBitsEachCodeWord: "+numBitsEachCodeWord);
		Trie trie = new Trie();
		StringBuilder res = new StringBuilder();
		while (runner + numBitsEachCodeWord <= compressed.length()) {
			int prefix = binaryToNumber(compressed.substring(runner, runner+numBitsForPrefix));
			char c = binaryToCharacter(compressed.substring(runner+numBitsForPrefix,
														runner+numBitsForPrefix+16));
			//System.out.println("prefix: "+prefix);
			//System.out.println("character: "+c);
			String decodedWord = trie.add(prefix, c);
			//System.out.println(decodedWord);
			res.append(decodedWord);
			runner += numBitsEachCodeWord;
		}
		if (compressed.length() - runner + 1 >= numBitsForPrefix) {
			int prefix = binaryToNumber(compressed.substring(runner, runner+numBitsForPrefix));
			String decodedPrefix = trie.stringAt(prefix);
			res.append(decodedPrefix);
		}
		return res.toString();
	}
	
	private static String numberToBinary(int n, int numBits) {
		StringBuilder sb = new StringBuilder();
		int count = 0;
		while (n>0) {
			if (n%2==1) {
				sb.append('1');
			} else {
				sb.append('0');
			}
			n /= 2;
			count++;
		}
		while (count < numBits) {
			sb.append('0');
			count++;
		}
		return sb.reverse().toString();
	}
	
	private static String characterToBinary(char c) {
		StringBuilder sb = new StringBuilder();
		int num = c - '\0';
		return numberToBinary(num, 16);
	}
	
	private static int binaryToNumber(String binary) {
		int res = 0;
		int runner = 0;
		while (runner < binary.length()) {
			if (binary.charAt(runner) == '0') {
				runner++;
				//System.out.println("track: " + runner);
			} else {
				break;
			}
		}
		while (runner < binary.length()) {
			//System.out.println("calculate: "+runner);
			if (binary.charAt(runner) == '1') {
				res = res*2 + 1;
			} else {
				res = res*2;
			}
			runner++;
		}
		return res;
	}
	
	private static char binaryToCharacter(String binary) {
		int code = binaryToNumber(binary);
		return (char)code;
	}
	public static void main(String[] args) {
//		System.out.println(numberToBinary(11, 6));
//		System.out.println(characterToBinary('a'));
//		String a = "ha";
//		System.out.println(a.substring(0,0).equals(""));
//		System.out.println(encode("abc"));
		String test = "00000000000000000000000000000101" + 
				"000000000000001010100000000000000001101000" +
				"000000000000001100101000000000000000100000" +
				"000000000000001110111000000000000001101111" +
				"000000000000001110010000000000000001101100"+
				"000000000000001100100001000000000001101001"+
				"000000000000001110011001000000000001100110" +
				"000000000000001110101010000000000001101100"+
				"001000000000001101111000000000000001100110"+
				"001000000000001110011011010000000001100111"+
				"000000000000001100001001110000000000100001"+
				"000000000000";
		
		String test2 = "00000000000000000000000000000101" +
				"000000000000001010011000000000000001110101"+
				"000000000000001100111000000000000001100001"+
				"000000000000001110010000000000000000100001"+
				"000000000000000100000000010000000001110101"+
				"000110000000001100001001010000000000100001"+
				"001110000000001010011000100000000001100111"+
				"001000000000001110010001100000000000100000"+
				"010000000000001100111011010000000000100001"+
				"010110000000001110101010010000000001110010"+
				"011100000000001010011011000000000001100001"+
				"010100000000000100000011110000000001100001"+
				"101010000000001010011101000000000001110010"+
				"00110000";
//		System.out.println(encode("The world is full of sugar!").equals(test));
//		System.out.println(encode("Sugar! Sugar! Sugar! Sugar! Sugar! Sugar! Sugar! Sugar!").equals(test2));
//		System.out.println(encode("").equals("00000000000000000000000000000000"));
		//System.out.println(binaryToNumber("00000000000000000000000000011101"));
//		int i = 65;
//		char c = (char)i;
//		System.out.println(c);
//		System.out.println(binaryToCharacter("0000000001110101"));
//		Trie trieTest = new Trie();
//		System.out.println(trieTest.add(0, 'a'));
//		System.out.println(trieTest.add(0, 'b'));
//		System.out.println(trieTest.add(0, 'g'));
//		System.out.println(trieTest.add(2, 'c'));
//		System.out.println(trieTest.add(2, 'd'));
//		System.out.println(trieTest.add(2, 'e'));
//		System.out.println(trieTest.add(2, 'f'));
//		System.out.println(trieTest.add(7, 'i'));
//		System.out.println(trieTest.stringAt(0));
		System.out.println(decode(test));
		System.out.println(decode("00000000000000000000000000000000"));
		System.out.println(decode(test2));
	}
}
