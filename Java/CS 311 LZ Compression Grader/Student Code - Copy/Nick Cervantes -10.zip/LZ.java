import java.util.ArrayList;
import java.util.HashMap;

/**
 * ComS 311 LZ Compression Project
 * 
 * @author Nick
 */
public class LZ {
	
	/**
	 * Private constructor so it cannot be constructed externally
	 */
	private LZ() {
	}
	
	/**
	 * The head of every Trie, or Lambda
	 */
	private static TrieNode dictionary;

	/**
	 * Method for compressing a given string using LZ Compression
	 * 
	 * @param uncompressed
	 * @return
	 */
	public static String encode(String uncompressed) {
		/* Declare the initial variables */
		ArrayList<TrieNode> nodes = new ArrayList<TrieNode>();
		dictionary = new TrieNode(0, (char) 0, null);
		TrieNode temp = dictionary;
		int index = 0;
		
		/* Check to make sure the given string is not null */
		if (uncompressed != null) {
			/* Iterate through each character of the string */
			for (int i = 0; i < uncompressed.length(); ++i) {
				/* If the current node has the current character, move on to it */ 
				if(temp.getChildren()[uncompressed.charAt(i)] != null) {
					temp = temp.getChildren()[uncompressed.charAt(i)];
				} 
				/* Otherwise it does not have the current character yet */
				else {
					/* Add the current character to the Trie */
					temp.insertChild(++index, uncompressed.charAt(i));
					/* Also store it in the ArrayList for quick access later */
					nodes.add(temp.getChildren()[uncompressed.charAt(i)]);
					/* Reset the temp node to Lambda */
					temp = dictionary;
				}
			}
			/* Add the last node to the ArrayList in case it is not unique */
			nodes.add(temp);
		}

		/* Find the number of bits in the codeword */
		int numCodeWordBits = (int) Math.ceil((Math.log(index + 1)) / Math.log(2));
		/* Create the binary string */
		String binary = createBinaryString(numCodeWordBits, nodes);
		/* Return the converted binary string */
		return FromBinary(binary);
	}

	/** 
	 * Method for decompressing a string compressed using LZ Compression
	 * 
	 * @param compressed
	 * @return
	 */
	public static String decode(String compressed) {
		/* Declare the initial variables */
		HashMap<Integer, TrieNode> nodes = new HashMap<Integer, TrieNode>();
		dictionary = new TrieNode(0, (char) 0, null);
		nodes.put(0, dictionary);
		int key = 1;
		StringBuilder sb = new StringBuilder();
		
		/* Convert the given string to a binary string */
		String binary = ToBinary(compressed);
		/* Parse the number of codeword bits from the string */
		int numCodeWordBits = Integer.parseInt(binary.substring(0, 32), 2);
		
		/* Iterate through the remaining bits of the string */
		for (int i = 32; i < binary.length(); i += (numCodeWordBits + 16)) {
			/* If we can read both the codeword and character */
			if((i + numCodeWordBits + 16) <  binary.length()) {
				/* Parse both the current codeword and character from the string */
				int index = Integer.parseInt(binary.substring(i, i + numCodeWordBits), 2);
				char data = (char) Integer.parseInt(binary.substring(i + numCodeWordBits, i + numCodeWordBits + 16), 2);
				
				/* Get the node for the codeword parsed and insert the character in the Trie */
				TrieNode node = nodes.get(index);
				node.insertChild(key, data);
				
				/* Get the newly inserted node, and store it in the HashMap for quick access later */
				TrieNode temp = node.getChildren()[data];
				nodes.put(key++, temp);
				
				/* Append the perf string */
				sb.append(temp.getPrefString());
			} 
			/* Otherwise we are at the end of the string */
			else {
				/* Parse the remainder of the string */
				int index = Integer.parseInt(binary.substring(i, i + numCodeWordBits), 2);
				
				/* If the codeword is not just padded 0's */
				if(index != 0) {
					/* Get the node and append its perf string */
					TrieNode node = nodes.get(index);
					sb.append(node.getPrefString());
				}
			}
		}
		
		/* Return the decompressed string */
		return sb.toString();
	}
	
	/**
	 * Helper method used to create a properly formatted binary string
	 * 
	 * @param numCodeWordBits
	 * @param nodes
	 * @return
	 */
	private static String createBinaryString(int numCodeWordBits, ArrayList<TrieNode> nodes) {
		/* Declare the initial variables */
		StringBuilder sb = new StringBuilder();
		sb.append("%");
		sb.append(numCodeWordBits);
		sb.append("s");
		String format = sb.toString();

		/* Append the number of code word bits to the beginning */
		sb = new StringBuilder();
		sb.append(String.format("%32s", Integer.toBinaryString(numCodeWordBits)).replace(' ', '0'));

		/* Remove nodes from the ArrayList and append them to the string */
		while (!nodes.isEmpty()) {
			TrieNode node = nodes.remove(0);
			/* If this is the last node */
			if(nodes.isEmpty()) {
				/* If it is not dictionary, then the last node is not unique */
				if(!(node.equals(dictionary))) {
					/* Append only the codeword to the string */
					sb.append(String.format(format,Integer.toBinaryString(node.getIndex())).replace(' ', '0'));
				}
			} 
			/* Otherwise it is not the last node */
			else {
				/* Append both the codeword and character to the string */
				sb.append(String.format(format,Integer.toBinaryString(node.getParent().getIndex())).replace(' ', '0'));
				sb.append(String.format("%16s",Integer.toBinaryString(node.getData())).replace(' ', '0'));
			}
		}

		/* While the string is not a multiple of 16 */
		while (sb.length() % 16 != 0) {
			/* Pad 0's onto the end */
			sb.append('0');
		}

		/* Return the finished binary string */
		return sb.toString();
	}

	/** 
	 * Given method for converting to a binary string
	 * 
	 * @param str
	 * @return
	 */
	public static String ToBinary(String str) {
		final char[] masks = { 0x8000, 0x4000, 0x2000, 0x1000, 0x800, 0x400,
				0x200, 0x100, 0x80, 0x40, 0x20, 0x10, 0x8, 0x4, 0x2, 0x1 };
		String ret = "";

		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);

			for (int j = 0; j < 16; j++)
				if ((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}

		return ret;
	}

	/** 
	 * Given method for converting from a binary string
	 * 
	 * @param str
	 * @return
	 */
	public static String FromBinary(String str) {
		final char[] bits = { 0x8000, 0x4000, 0x2000, 0x1000, 0x800, 0x400,
				0x200, 0x100, 0x80, 0x40, 0x20, 0x10, 0x8, 0x4, 0x2, 0x1 };
		String ret = "";

		for (int i = 0; i < str.length(); i += 16) {
			char c = 0x0000;

			for (int j = 0; j < 16; j++)
				if (str.charAt(i + j) == '1')
					c |= bits[j];

			ret += c;
		}

		return ret;
	}
}
