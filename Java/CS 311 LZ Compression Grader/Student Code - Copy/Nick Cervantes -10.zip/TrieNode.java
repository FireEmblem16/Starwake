/**
 * My TrieNode data type
 * 
 * @author Nick
 */
public class TrieNode {
	/**
	 * The codeword for the TrieNode 
	 */
	private int index;
	
	/**
	 * The character of the TrieNode 
	 */
	private char data;
	
	/**
	 * Reference to its parent TrieNode
	 */
	private TrieNode parent;
	
	/**
	 * The array of its children
	 */
	private TrieNode[] children;
	
	/**
	 * The constructor for my TrieNode
	 * 
	 * @param index
	 * @param data
	 * @param parent
	 */
	public TrieNode(int index, char data, TrieNode parent) {
		/* Assign the given values to the private variables */
		this.index = index;
		this.data = data;
		this.parent = parent;
		
		/* Initialize the array to a size of 256 */
		this.children = new TrieNode[256];
	}
	
	/**
	 * Returns the codeword of the TrieNode 
	 * 
	 * @return
	 */
	public int getIndex() {
		/* Return the index */
		return this.index;
	}
	
	/**
	 * Returns the character of the TrieNode 
	 * 
	 * @return
	 */
	public char getData() {
		/* Return the data */
		return this.data;
	}
	
	/**
	 * Returns the reference to the parent TrieNode 
	 * 
	 * @return
	 */
	public TrieNode getParent() {
		/* Return the parent */
		return this.parent;
	}
	
	/**
	 * Returns the array of children TrieNodes
	 * 
	 * @return
	 */
	public TrieNode[] getChildren() {
		/* Return the children */
		return this.children;
	}
	
	/**
	 * Inserts a new child into the Trie 
	 */
	public void insertChild(int index, char data) {
		/* Insert the new node at the index of the character */
		this.children[data] = new TrieNode(index, data, this);
	}
	
	/**
	 * Returns the pref string of the node, include its character 
	 * 
	 * @return
	 */
	public String getPrefString() {
		/* Declare the initial variables */
		StringBuilder sb = new StringBuilder();
		TrieNode temp = this;
		
		/* While we are not at the root */
		while (temp.getParent() != null) {
			/* Prepend the character of the temp node */
			sb.insert(0, temp.data);
			/* Set the temp node to its parent */
			temp = temp.getParent();
		}
		
		/* Return the pref string */
		return sb.toString();
	}
}
