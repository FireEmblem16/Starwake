/**
 * @author Franklin Nelson
 */
public class LZEncryption
{
	/**
	 * Compresses the string using LZ-78.
	 * @param uncompressed string to be compressed
	 * @return Binary representation of compressed string
	 */
	public static String encode(String uncompressed)
	{
		Trie trie = new Trie(uncompressed.replaceAll("(.)(?=.*?\\1)", "").length());
		
		// The compressed string
		String compressed = "";
		
		// The current prefix
		String prefix = "";
		
		// The number of bits used by the largest codeWord
		int codeWordLength = Integer.toBinaryString(uncompressed.length()).length();
		
		for(int i = 0, j = 1; i < uncompressed.length(); i++)
		{
			// Character at index 'i' of uncompressed string, with upper 8 bits cleared
			char character = (char) (uncompressed.charAt(i) & 0xFF);
			
			// Does this character already exist in the trie?
			if(trie.getNode(String.valueOf(character)) != null)
			{
				prefix += uncompressed.charAt(i);
			}
			else
			{
				// The codeWord is 0
				if(prefix.isEmpty())
				{
					if(compressed.isEmpty())
					{
						for(byte k = 0; k < codeWordLength; k++)
						{
							compressed += "0";
						}
					}
					else
					{
						compressed += compressed.substring(0, codeWordLength);
					}
				}
				else
				{
					// Binary representation of index
					String codeWordString = Integer.toBinaryString(Integer.parseInt(trie.getIndex()));
					
					compressed += compressed.substring(0, codeWordLength - codeWordString.length()) + codeWordString;
				}
				
				// Binary representation of character
				String binaryString = Integer.toBinaryString(character);
				
				compressed += "00000000" + compressed.substring(0, 8 - binaryString.length()) + binaryString;
				
				trie.addNode(String.valueOf(character), String.valueOf(j++));
				prefix = "";
				
				trie.setFirst();
			}
		}
		
		// The codeWord at end of compressed string
		if(!prefix.isEmpty())
		{
			String codeWordString = Integer.toBinaryString(Integer.parseInt(trie.getIndex()));
			
			compressed += compressed.substring(0, codeWordLength - codeWordString.length()) + codeWordString;
		}
		
		compressed = "000000000000000000000000" + compressed.substring(0, 8 - Integer.toBinaryString(codeWordLength).length()) + (Integer.toBinaryString(codeWordLength)) + compressed;
		
		if(compressed.length() % 16 != 0)
		{
			compressed += compressed.substring(0, 16 - compressed.length() % 16);
		}
		
		return compressed;
	}
	
	/**
	 * Decompresses the string using LZ-78.
	 * @param compressed string to be decompressed
	 * @return Unicode representation of decompressed string
	 */
	public static String decode(String compressed)
	{
		// Whitespace in the string is removed
		compressed = compressed.replaceAll("\\s+", "");
		
		Trie trie = new Trie(compressed.replaceAll("(.)(?=.*?\\1)", "").length());
		
		// This is the root node for an empty string
		trie.addNode("", "0");
		
		String uncompressed = "";
		String prefix = "";
		
		// Max number of bits needed to read a codeWord
		byte codeWordBits = Byte.parseByte(compressed.substring(24, 32), 2);
		
		for(int i = 32, j = 1; i < compressed.length(); j++)
		{
			// Computes binary into an integer
			int codeWord = Integer.parseInt(compressed.substring(i, i += codeWordBits), 2);
			i += 8;
			
			// A codeWord is found at the end of string input
			if(i + 8 > compressed.length())
			{
				// If codeWord isn't referencing root node
				if(codeWord != 0)
				{
					// There is a prefix that exists in the dictionary
					if(trie.getNode(String.valueOf(codeWord)) != null)
					{
						uncompressed += trie.getIndex();
					}
				}
				
				// End of string input
				break;
			}
			
			String binary = compressed.substring(i, i += 8);
			
			// If codeWord isn't referencing root node
			if(codeWord != 0)
			{
				// The node corresponding to codeWord
				Trie.TrieNode node = trie.getNode(String.valueOf(codeWord));
				
				// There is a prefix that exists in the dictionary
				if(node != null)
				{
				 	prefix = trie.getIndex() + (char) (Short.parseShort(binary, 2) & 0xFF);
				 	trie.setFirst();
				}
				else // The prefix wasn't found
				{
					prefix = String.valueOf(uncompressed.charAt(codeWord)) + String.valueOf((char) (Short.parseShort(binary, 2) & 0xFF));
				}
			}
			else
			{
				prefix = String.valueOf((char) (Short.parseShort(binary, 2) & 0xFF));
			}
			
			uncompressed += prefix;
			
			// Index and string are reversed here so trie checks by index
			trie.addNode(String.valueOf(j), prefix);
		}
		
		return uncompressed;
	}
}