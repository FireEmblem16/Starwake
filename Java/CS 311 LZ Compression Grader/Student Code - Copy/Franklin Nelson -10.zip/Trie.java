import java.util.HashMap;
import java.util.TreeMap;

/**
 * Trie data structure
 * @see <a href="https://github.com/Jake00/LZ78/blob/master/src/compress/Trie.java">Class derived from here</a>
 */
public class Trie
{
	private HashMap<CharSequence, TrieNode> root;
	private TrieNode rootNode;
	private int maxCount, dictionaryCount;
	private boolean first, isFull;
	
	/**
	 * Constructs a trie dictionary.
	 * @param maxbits used for storing elements in trie
	 */
	public Trie(int maxbits)
	{
		root = new HashMap<CharSequence, TrieNode>();
		
		maxCount = (1 << maxbits) - 1;
		dictionaryCount = 0;
		
		first = true;
		isFull = false;
	}
	
	/**
	 * Adds a node to trie with specified data and index.
	 * @param data in this node
	 * @param index of node in trie
	 */
	public void addNode(String data, String index)
	{
		// Is this the root?
		if(first)
		{
			root.put(data, new TrieNode(data, index));
		}
		
		// Is there space available?
		else if(!isFull)
		{
			rootNode.addNode(data, index);
			
			// Is there still space for more nodes?
			if(++dictionaryCount >= maxCount)
			{
				isFull = true;
			}
		}
	}
	
	/**
	 * Retrieves a node containing the data input.
	 * @param data to search for
	 * @return TrieNode containing specified data
	 */
	public TrieNode getNode(String data)
	{
		// Is this the root?
		if(first)
		{
			// Does the root have a node with the data?
			if(root.containsKey(data))
			{
				first = false;
				
				return rootNode = root.get(data);
			}
		}
		
		else
		{
			TrieNode node = rootNode.getNode(data);
			
			// Does this node exist?
			if(node != null)
			{
				return rootNode = node;
			}
		}
		
		return null;
	}
	
	/**
	 * Sets the root node as current node.
	 */
	public void setFirst()
	{
		first = true;
	}
	
	/**
	 * Retrieves data from current node.
	 * @return Data from node
	 */
	public String getData()
	{
		return rootNode.data;
	}
	
	/**
	 * Gets index of current node.
	 * @return Index of node
	 */
	public String getIndex()
	{
		if(first)
		{
			return "0";
		}
		
		return rootNode.index;
	}
	
	/**
	 * Node for trie data structure
	 * @see <a href="https://github.com/Jake00/LZ78/blob/master/src/compress/TrieNode.java">Class derived from here</a>
	 */
	public class TrieNode
	{
		private TreeMap<CharSequence, TrieNode> children;
		private String data, index;
		
		/**
		 * Constructs a new node for trie dictionary.
		 * @param data in this node
		 * @param index of node in trie
		 */
		private TrieNode(String data, String index)
		{
			children = new TreeMap<CharSequence, TrieNode>();
			
			this.data = data;
			this.index = index;
		}
		
		/**
		 * Adds a node to trie with specified data and index.
		 * @param data in this node
		 * @param index of node in trie
		 */
		private void addNode(String data, String index)
		{
			children.put(data, new TrieNode(data, index));
		}
		
		/**
		 * Retrieves a node containing the data input.
		 * @param data to search for
		 * @return TrieNode containing specified data
		 */
		private TrieNode getNode(String data)
		{
			if(children.containsKey(data))
			{
				return children.get(data);
			}
			
			return null;
		}
	}
}