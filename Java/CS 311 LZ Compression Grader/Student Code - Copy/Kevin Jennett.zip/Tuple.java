public class Tuple {

	private int index;
	private Character value;
	
	public Tuple(int ind, Character c) {
		
		index = ind;
		value = c;
		
	}
	
	public int getIndex() {
		
		return index;
		
	}
	
	public Character getValue() {
		
		return value;
		
	}
	
}