import java.util.ArrayList;
import java.util.BitSet;

public class LZEncryption {

	private LZEncryption() {
		
	}
	
	/**
	 * Encodes a string of ASCII characters (values 0-255) using an LZ algorithm.
	 * @param uncompressed String to encode.
	 * @return Compressed string.
	 */
	
	public static String encode(String uncompressed) {
		
		Trie t = new Trie();
		ArrayList<Tuple> codes = new ArrayList<Tuple>();
		int count = 0;
		boolean nullTrunc = false;
		
		// Loops over uncompressed string and builds the Trie.
		for (int i = 0; i < uncompressed.length(); i++) {
			
			int end = i + 1;
			
			//Finds next String that the Trie does not contain.
			while (end <= uncompressed.length() - 1 && t.contains(uncompressed.substring(i, end))) {
				
				end++;
				
			}
			
			//Pulls that substring out of the uncompressed string and adds it to the Trie.
			String adding = uncompressed.substring(i, end);
			boolean added = t.add(adding);
			
			// If the string was added to the Trie, we know it's a new string and a full code (index + character pairing).
			if (added) {
				
				// Gets the node and adds the parent index and the character value of this node to the set of codes.
				// Increases the count.
				Node n = t.getNodeOfString(adding);
				codes.add(new Tuple(n.getParent().getIndex(), n.getVal()));
				count++;
				
			} else {
				
				// If the string wasn't added to the Trie, it's the end of the uncompressed string and this string has been seen before, so it only needs an index.
				// Get the node that this string would have been.
				// Add the index of this actual code and give it a null character value.
				// Set nullTrunc, so I know this happened.
				Node n = t.getNodeOfString(adding);
				codes.add(new Tuple(n.getIndex(), null));
				nullTrunc = true;
				
			}
			
			// Change i.
			i = end - 1;
			
		}
		
		// Calculate the number of bits needed to store the index value.
		int bits = (int) Math.ceil((Math.log(t.getIndex())/Math.log(2)));
		
		StringBuilder sb = new StringBuilder();
		
		// Byte array to store the 32 bit integer specifying the number of bits needed to store the index.
		byte[] s = new byte[4];
		s[0] = (byte) ((bits >> 24) & 0xff);
		s[1] = (byte) ((bits >> 16) & 0xff);
		s[2] = (byte) ((bits >> 8) & 0xff);
		s[3] = (byte) (bits & 0xff);
		
		// Calculating the number of bits needed to store the compressed data.
		int bitSetSize = (count * (bits + 16));
		
		// If nullTrunc (we ended on a String that was already present in the Trie), we need only specify the index, so add enough bits for that.
		if (nullTrunc) {
			
			bitSetSize += bits;
			
		}
		
		// Making it a multiple of 16.
		bitSetSize = bitSetSize + (16 - (bitSetSize % 16));
		
		// Creating a bitSet.
		BitSet bitSet = new BitSet(bitSetSize);
		int currentBit = 0;
		
		// Iterating over the codes (index, character value) pairs.
		for (Tuple code : codes) {
			
			int ind = code.getIndex();
			Character ch = code.getValue();
			
			// Setting the corresponding bits in the BitSet based on the index of that code.
			for (int i = 0; i < bits; i++, currentBit++) {
				
				if (((ind >> (bits - i - 1)) & 0x00000001) == 1) {
					
					bitSet.set(currentBit);
					
				}
				
			}
			
			// Making sure this is the nullTrunc ending value
			if (ch != null) {
			
				// Setting the corresponding bits of the BitSet to the values in the character.
				for (int i = 0; i < 16; i++, currentBit++) {
				
					char c = (char)ch;
					if ((c & ((0x0001) << (15 - i))) > 0) {
					
						bitSet.set(currentBit);
					
					}
				
				}
			
			}
			
		}
		
		// Creating and setting the values of the byte array.  Had some trouble with toByteArray() of bitSet.
		byte[] bytes = new byte[bitSetSize / 8];
		
		for (int i = 0; i < bitSetSize; i++) {
			
			if (bitSet.get(i)) {
				
				bytes[i / 8] |= (0x01 << (8 - (i % 8) - 1));
				
			}
			
		}
		
		// Writing the 32 bit integer that specifies bits needed to store the indexes.
		char c = 0;
		c |= (s[0] << 8);
		c |= s[1];
		sb.append(c);
		c = 0;
		c |= (s[2] << 8);
		c |= (s[3]);
		sb.append(c);
		
		// Iterating over the bytes.
		for (int i = 0; i < bytes.length; i++) {
			
			// First 8 bits of a character.
			if (i % 2 == 0) {
				
				// 0 out the character and bitwise or it with the byte shifted left.
				c = 0;
				c |= ((bytes[i] << 8) & 0xff00);
				
			// Second 8 bits of a character.
			} else {
				
				// Bitwise or the character with the next byte and append it to the stringbuilder.
				c |= (bytes[i] & 0x00ff);
				sb.append(c);
				
			}
			
		}
		
		// Makes sure to add the last character.
		if (bytes.length % 2 == 1) {
			
			sb.append(c);
			
		}
		
		// Return compressed string.
		return sb.toString();
		
	}
	
	/**
	 * Decodes a String.
	 * @param compressed String to decode.
	 * @return uncompressed String.
	 */
	public static String decode(String compressed) {
		
		Trie t = new Trie();
		
		// Calculate size of bit set to store the compressed string.
		int bitSetSize = compressed.length() * 16;
		BitSet bs = new BitSet(bitSetSize);
		
		int bitPos = 0;
		
		//Masks used from the code snippet given by Donald Nye in the announcements
		final char[] masks = { 0x8000, 0x4000, 0x2000, 0x1000, 0x800, 0x400,
				0x200, 0x100, 0x80, 0x40, 0x20, 0x10, 0x8, 0x4, 0x2, 0x1 };
		
		// Grabs the bits of the compressed String and puts them in the BitSet.  Makes the BitSet a representation of the String.
		for (int i = 0; i < compressed.length(); i++) {
			
			char c = compressed.charAt(i);

			for (int j = 0; j < 16; j++, bitPos++) {
			
				if ((c & masks[j]) != 0) {
				
					bs.set(bitPos);
					
				}
			
			}
			
		}
		
		int bits = 0;
		
		// Iterate over the first 32 bits so I know how many bits are needed to store the indexes.
		for (int i = 0; i < 32; i++) {
			
			if (bs.get(i)) {
				
				bits |= (0x00000001 << (32 - i - 1));
				
			}
			
		}
		
		String output = "";
		
		// Iterate over the remaining bits.
		for (int i = 32; i < bitSetSize; i = i + (bits + 16)) {
			
			// Grab the number of bits that specify the index.
			BitSet ind = bs.get(i, i + bits);
			
			int index = 0;
			
			// Iterate over those bits.
			for (int j = 0; j < bits; j++) {
				
				// Modify the int index to represent the value.
				if (ind.get(j)) {
				
					index |= (0x00000001 << (bits - j - 1));
					
				}
				
			}
			
			// Get the next 16 bits to store the character.
			BitSet val = bs.get(i + bits, i + bits + 16);
			
			char cha = 0;
			
			// Used to know if the last code was a null trunc code.
			boolean trunc = false;
			
			if (bitSetSize - i - bits >= 16) {
			
				// Iterate over the character bits.
				for (int j = 0; j < 16; j++) {
				
					// Grab the character bit data and modify the character as needed.
					if (val.get(j)) {
					
						cha |= (0x0001 << (16 - j - 1));
					
					}
				
				}
			
			} else {
				
				trunc = true;
				
			}
			
			// If this code wasn't truncated.
			if (!trunc) {
				
				// Creates a string using the parent index and the character value of the code.
				// Adds this string to the Trie.
				// Adds the string to the output because it is the next seen value.
				String ofCode = t.strOfIndex(index) + cha;
				t.add(ofCode);
				output = output + ofCode;
				
			} else {
				
				// If it's a truncated code, just add the string of the index to the output.  Adding it is useless.
				output = output + t.strOfIndex(index);
				
			}
			
		}
		
		// Return uncompressed string.
		return output;
		
	}
	
}