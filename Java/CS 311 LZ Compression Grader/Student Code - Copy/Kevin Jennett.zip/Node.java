public class Node {

	// Parent node.
	Node parent;
	// Value of this node.
	Character val;
	// 256 possible children of values [0..255]
	Node[] children = new Node[256];
	// Index of this node after being added to the Trie.
	int index;
	
	/**
	 * Constructor for a node object.
	 * @param c The value at this node.
	 * @param ind The index of this node when it was added to the Trie.
	 * @param p The parent node of this node.
	 */
	public Node(Character c, int ind, Node p) {
		
		val = c;
		index = ind;
		parent = p;
		
	}
	
	/**
	 * Grabs the array containing all possible children of this node.
	 * @return A node array of size 256 containing children or null values if that child does not exist.
	 */
	public Node[] getChildren() {
		
		return children;
		
	}
	
	/**
	 * Grabs the character value of this node.
	 * @return The character value of this node, a Character.
	 */
	public Character getVal() {
		
		return val;
		
	}
	
	/**
	 * Grabs the index of this node, identifying when it was added to the Trie.
	 * @return the index of this node.
	 */
	public int getIndex() {
		
		return index;
		
	}
	
	/**
	 * Grabs the parent of this node.
	 * @return Parent of node.
	 */
	public Node getParent() {
		
		return parent;
		
	}
	
	/**
	 * Attempts to create a child of this node with the given character and index.
	 * @param c The character to be added, if possible.
	 * @param ind The index of the child, if created.
	 * @return true if the child is created, false otherwise.
	 */
	public boolean add(Character c, int ind) {
		
		char ch = (char)c;
		
		// Checks to see if the child exists.
		if (children[ch] == null) {
			
			// If not, create a new child and return true.
			children[ch] = new Node(c, ind, this);
			return true;
			
		} else {
			
			// If child exists, return false.
			return false;
			
		}
		
	}
	
	/**
	 * Gets the node of the given index.
	 * @param ind Index of the node we wish to find.
	 * @return the Node object of the given index.
	 */
	public Node getNodeWithIndex(int ind) {
		
		// If the index of this node is the given index, return this node.
		if (index == ind) {
			
			return this;
			
		// If the index of this node is greater than the given index, return null because the children of this node must have a greater index.
		} else if (index > ind) {
			
			return null;
			
		} else {
			
			// If the index of this node is less than the given index, iterate over all the children of this node.
			for (int i = 0; i < 256; i++) {
				
				// If the child exists.
				if (children[i] != null) {
					
					// Check to see if it can get the node with the given index.
					Node n = children[i].getNodeWithIndex(ind);
					
					// If it can, return the node.
					if (n != null) {
						
						return n;
						
					}
					
				}
				
			}
			
			// If, after looking through the children of this node, it still can't find it, return null.
			// This node failed to find it.
			return null;
			
		}
		
	}
	
}