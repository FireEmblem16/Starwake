public class Trie {
	
	// Root of the Trie.
	private Node head;
	// Current size of the tree.
	private int index;
	
	/**
	 * Constructor
	 */
	public Trie() {
		
		head = new Node(null, 0, null);
		index = 1;
		
	}
	
	/**
	 * Adds a String to the Trie if every prefix of the string is already in the Trie.
	 * @param s The String to add.
	 * @return true on success, false otherwise.
	 */
	public boolean add(String s) {
		
		// Start at head.
		Node n = head;
		
		// Iterate over the String.
		for (int i = 0; i < s.length(); i++) {
			
			// If the current node has a child node with the corresponding character value.
			if (n.getChildren()[s.charAt(i)] != null) {
				
				// Set the current node to that child node.
				n = n.getChildren()[s.charAt(i)];
				
			// If it doesn't have the right child.
			} else {
				
				// If we are at the end of the String.
				if (i == s.length() - 1) {
					
					// Add the character as a child to the end of the current node.
					// Increment index and return true on success.
					n.add((Character)s.charAt(i), index);
					index++;
					return true;
					
				// If we aren't at the end of the String, we ran into a prefix that is not in the Trie, so we can't add the String.
				} else {
					
					// False on failure.
					return false;
					
				}
				
			}
			
		}
		
		// String is already in the Trie, can't add it again.
		return false;
		
	}
	
	/**
	 * Gets the number of Strings in the Trie.
	 * @return number of Strings in the Trie.
	 */
	public int getIndex() {
		
		return index;
		
	}
	
	/**
	 * Follows the path of a String and returns the index of that String.
	 * @param s String to get index of.
	 * @return Index of String s.
	 */
	public int getIndexOfString(String s) {
		
		// Start at head.
		Node n = head;
		
		// Iterate over the String.
		for (int i = 0; i < s.length(); i++) {
			
			// If the child corresponding to the current character value in the string exists for the current node, make current node that child.
			if (n.getChildren()[s.charAt(i)] != null) {
				
				n = n.getChildren()[s.charAt(i)];
				
			// If the child does not exist, the String is not in the Trie.
			} else {
				
				return -1;
				
			}
			
		}
		
		return n.getIndex();
		
	}
	
	/**
	 * Checks to see if the String is in the Trie.
	 * @param s String to locate.
	 * @return true if the string is in the Trie, false otherwise.
	 */
	public boolean contains(String s) {
		
		// Start at head.
		Node n = head;
		
		// Iterate over the String.
		for (int i = 0; i < s.length(); i++) {
			
			// If the correct child exists.
			if (n.getChildren()[s.charAt(i)] != null) {
				
				// Set that child to be the current Node.
				n = n.getChildren()[s.charAt(i)];
				
			// If the correct child does not exist.
			} else {
				
				// Failure.
				return false;
				
			}
			
		}
		
		// String was found.
		return true;
		
	}
	
	/**
	 * Returns the Node of the given String.
	 * @param s String of the node.
	 * @return the Node object for the given String.
	 */
	public Node getNodeOfString(String s) {
		
		// Start at head.
		Node n = head;
		
		// Iterate over the length of the String.
		for (int i = 0; i < s.length(); i++) {
			
			// If the correct child exists.
			if (n.getChildren()[s.charAt(i)] != null) {
				
				// Set current node to be the correct child.
				n = n.getChildren()[s.charAt(i)];
				
			} else {
				
				// If the child does not exist, failure.
				return null;
				
			}
			
		}
		
		// Correct node found, return the node.
		return n;
		
	}
	
	/**
	 * Gets the node of the given index.
	 * @param ind Index of the node you wish to get.
	 * @return Node object of the index given.
	 */
	public Node getNodeWithIndex(int ind) {
		
		// If the current index of the tree is less than the index they want, we can't get the node as it does not exist.
		if (ind > index) {
			
			return null;
			
		}
		
		// Grabs this node using the node.getNodeWithIndex function.
		return head.getNodeWithIndex(ind);
		
	}
	
	/**
	 * Gets the String associated with the given index.
	 * @param ind Index you wish to grab the string of.
	 * @return The string of the given index.
	 */
	public String strOfIndex(int ind) {
		
		// Grab the node for the given index.
		Node n = getNodeWithIndex(ind);
		
		// If the node is null (does not exist), return the empty string.
		if (n == null) {
			
			return "";
			
		}
		
		// Build string.
		// Iterate over the nodes until the parent of a node is non-existent (hit index 0, or the root of the Trie).
		StringBuilder sb = new StringBuilder();
		while (n.getParent() != null) {
			
			// Protects from grabbing the null value at the root of the Trie.
			if (n.getVal() != null) {
				
				// Append the value of the node to the stringbuilder.
				// Make the current node the parent of the current node.
				sb.append((char)n.getVal());
				n = n.getParent();
				
			}
			
		}
		
		// Because we appended on the way up, reverse the string and return it.
		sb.reverse();
		return sb.toString();
		
	}
	
}