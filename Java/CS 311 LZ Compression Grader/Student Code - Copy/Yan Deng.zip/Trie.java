/**
 * A trie is a binary tree used to store a set of strings. Each node in 
 * the trie represents one of the strings in the set, by examining the 
 * path from the root to that node.
 * 
 * @author Yan Deng
 *
 */

public class Trie {
	
	public Trie(char c) {
		
		charValue = c;
		if (c == '\0')
			stringValue = "";
	}
	
	/**
	 * Get the children node which contains the desired character
	 * @param c
	 * @return
	 */
	public Trie getChild(char c) {
		
		int idx = (int)c;
		if (children == null)
			return null;
		
		if (c > 0xFF)
		{
			System.out.println(String.format("Illegal character detected:%c(0x%x)", c, (int)c));
		}
		return children[idx];
	}
	
	/*
	 * 
	 */
	public Trie addChild(char c, int stringIndex) {
		
		if (c == '\0')
			throw new IllegalArgumentException("Can't add empty string to Trie except for the root");
		
		if (children == null)
			children = new Trie[255];
		
		int idx = (int)c;
		if (children[idx] != null)
			throw new IllegalArgumentException("Trie node already exist");
		
		children[idx] = new Trie(c);
		children[idx].parent = this;
		children[idx].stringIndex = stringIndex;
		children[idx].stringValue = this.stringValue + c;
		
		return children[idx];
	}
	
	/**
	 * @return the charValue
	 */
	public char getCharValue() {
		return charValue;
	}
	/**
	 * @return the stringValue
	 */
	public String getStringValue() {
		return stringValue;
	}
	/**
	 * @return the parent
	 */
	public Trie getParent() {
		return parent;
	}
	/**
	 * @return the children
	 */
	public Trie[] getChildren() {
		return children;
	}
	/**
	 * @return the index
	 */
	public int getIndex() {
		return stringIndex;
	}
	/**
	 * @param index the index to set
	 */
	public void setIndex(int index) {
		this.stringIndex = index;
	}

	private char	charValue; //'\0' represent the empty string
	private String	stringValue; // the string representation walking from root to this node	
	private Trie 	parent;
	private Trie[] 	children; // null means leaf
	private int		stringIndex; // index in the original input string
}
