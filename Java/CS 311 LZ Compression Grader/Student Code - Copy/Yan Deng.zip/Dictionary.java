/**
 * @author Yan Deng
 *
 */

public class Dictionary {
	public Dictionary() {
		throw new UnsupportedOperationException("Not implemented yet");
	}
}
