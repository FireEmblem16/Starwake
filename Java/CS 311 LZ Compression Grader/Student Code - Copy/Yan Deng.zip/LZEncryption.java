/**
 * The LZ compression algorithm works as follows on input string x. It parses 
 * x into consecutive substrings, termed phrases, no two of which are equal to 
 * each other (except that possibly the last phrase is equal to a previous phrase). 
 * Each phrase is assigned a codeword, another string which represents the phrase 
 * in the compressed output string, and the codewords are simply concatenated together 
 * to create the output.
 * 
 * @author Yan Deng
 *
 */

import java.nio.charset.Charset;
import java.util.ArrayList;

public class LZEncryption {

	public static boolean _debugmode = false;
	
	/**
	 * Instruct the LZ class to use dictionary for its underlying compression
	 * engine
	 */
	public void useDictionary() {
		compressEngine = LZCompressEngine.LZCompressEngineDictionary;
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	/**
	 * Instruct the LZ class to use trie for its underlying compression engine
	 */
	public void useTrie() {
		compressEngine = LZCompressEngine.LZCompressEngineTrie;
	}
	
	public static String encode(String uncompressed) {
		
		int index = 0;
		ArrayList<CodeWord> codewordBlock = new ArrayList<CodeWord>();

		if (compressEngine == LZCompressEngine.LZCompressEngineTrie)
		{
			rootNode = new Trie('\0');		
			rootNode.setIndex(index);
		}
		else
		{
			throw new UnsupportedOperationException("Not implemented yet");
		}
		
		Trie prefixNode = rootNode;
		
		for (int i = 0; i < uncompressed.length(); ++i)
		{
			char c = uncompressed.charAt(i);

			if (compressEngine == LZCompressEngine.LZCompressEngineTrie)
			{
				Trie nextNode = prefixNode.getChild(c);
				
				if (nextNode == null)
				{
					prefixNode.addChild(c, ++index);
					CodeWord codeword = new CodeWord(prefixNode.getIndex(), c);
					codewordBlock.add(codeword);
					prefixNode = rootNode;
				}
				else
				{
					prefixNode = nextNode;
				}
			}
			else
			{
				throw new UnsupportedOperationException("Not implemented yet");
			}	
		}
		
		// Finalize the last block
		if (prefixNode != rootNode)
		{
			CodeWord codeword = new CodeWord(prefixNode.getIndex(), '\0');
			codewordBlock.add(codeword);
		}
		
		String output = convertToBinary(codewordBlock);
	
		return output;
	}
	
	public static String decode(String compressed) {
		
		byte[] rawBytes = ConvertStringToByteArray(compressed);
		
		BitOperation bitOp = new BitOperation(rawBytes);
		ArrayList<CodeWord> codewordBlock = new ArrayList<CodeWord>();
		int bits = bitOp.readNextInt();

		while (true) 
		{
			try
			{
				CodeWord codeword = new CodeWord();
				codeword.code = bitOp.readNextInt(bits);
				codeword.setWord(bitOp.readNextChar());
				codewordBlock.add(codeword);

			}
			catch (IllegalStateException e)
			{
				break;
			}
		}
		
		int index = 0;
		if (compressEngine == LZCompressEngine.LZCompressEngineTrie)
		{
			rootNode = new Trie('\0');		
			rootNode.setIndex(index);
		}
		else
		{
			throw new UnsupportedOperationException("Not implemented yet");
		}
		
		String decompressed = "";
		for (CodeWord codeword : codewordBlock) 
		{
			Trie prefixNode = findPrefTrieForCodeWord(codeword, rootNode);
			
			if (codeword.word == '\0')
			{
				decompressed += prefixNode.getStringValue();
			}
			else
			{
				Trie node = prefixNode.addChild(codeword.word, ++index);
				decompressed += node.getStringValue();
			}
		}
		
		return decompressed;
	}
	
	private static Trie findPrefTrieForCodeWord(CodeWord codeword, Trie parentNode)
	{
		Trie node = parentNode;
		if (node.getIndex() == codeword.code)
			return node;
		
		if (node.getChildren() == null)
			return null;
		
		for (Trie child : node.getChildren())
		{
			if (child == null) continue;
				
			if (child.getIndex() <= codeword.code)
			{
				Trie grandChild = findPrefTrieForCodeWord(codeword, child);
				if (grandChild != null)
				{
					return grandChild;
				}
			}
		}
		
		return null;
	}
	
	private static String convertToBinary(ArrayList<CodeWord> codewordBlock) {
		
		int count = codewordBlock.size();
		int bits = 0;
		
		if (count == 0) 
		{
			return new String(new byte[4]);
		}
		
		// Calculate how many bits we need for the index part
		while (count > 0) {
			count >>= 1;
			++bits;
		}
			
		//System.out.println(String.format("\nCodeWord block size:%d", codewordBlock.size()));
		
		// 32bit for header
		// bits is the code size
		// 8 is the word size
		// codewordBlock.size() is the number of codeword
		// extra 7 bit to ensure it will round up
			
		int size = (32 + (bits + 16) * codewordBlock.size() + 7) >>> 3;
		BitOperation bitOp = new BitOperation(size);
		
		// First add the number of bits to the first 4-byte as header
		bitOp.appendBits(bits, 32);
		int i = 0;
		for (CodeWord codeword : codewordBlock)
		{
			if (i++ == 19)
			{
				i = 0;
			}
			bitOp.appendBits(codeword.code, bits);
			bitOp.appendChar(codeword.word);
		}
		
		return bitOp.toString();
	}
	
	/**
	 * Convert the 16-bit encoded String into a byte array
	 * @param str
	 * @return
	 */
	private static byte[] ConvertStringToByteArray(String str) {
		
		//System.out.println("Convert String To Char Array");
		int length = str.length();
		byte[] result = new byte[length * 2];
		
		for (int i = 0; i < length; ++i) {
			char c = str.charAt(i);
			
			//System.out.print(String.format("0x%04x ", (int)c));
			result[i * 2] = (byte) ((c & 0xFFFF) >>> 8);
			result[i * 2 + 1] = (byte) (c & 0x00FF);
		}
		
		return result;
	}
	
	private LZEncryption() {}

	private enum LZCompressEngine {
		LZCompressEngineTrie,
		LZCompressEngineDictionary
	}

	private static class CodeWord {
		
		CodeWord(int code, char word) {
			this.code = code;
			this.setWord(word);
		}
		
		CodeWord() {}
		
		public String toString() {
			return String.format("%d%c", code, word);
		}
		
		void setWord(char word)
		{
			if (word > 0xFF && !_debugmode)
				throw new IllegalArgumentException();
			
			this.word = word;
		}
		
		// For debugging only
		boolean isEqual(CodeWord other) {
			return (word == other.word) && (code == other.code);
		}
		
		int code;
		char word;
	}
	
	private static LZCompressEngine compressEngine = LZCompressEngine.LZCompressEngineTrie;
	private static Trie rootNode = null;
	
	// For debugging
	private static ArrayList<CodeWord> 	_debug_codewordBlockFromCompressed;
	private static byte[]				_debug_compressedData;
	private static byte[]				_debug_decompressedData;
}
