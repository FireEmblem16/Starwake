

import java.nio.charset.Charset;

/**
 * Class help manipulating the bits. BitOperation has an internal buffer, once
 * it is full, the caller needs to extract its information before add more bits
 * to it.
 * 
 * @author Yan Deng
 *
 */
public class BitOperation {
	
	public BitOperation(int size)
	{	
		if (size % 2 == 1)
			++size; // Align to 16-bit
		
		buffer = new byte[size];
	}
	
	public BitOperation(byte[] inBuffer)
	{
		buffer = inBuffer;
	}
	
	/**
	 * Add one 8-bit character to the buffer, every bits counts
	 * @param c
	 */
	public void appendChar(char c) {
		appendByte((byte)((c & 0xFF00) >> 8));
		appendByte((byte)(c & 0xFF));
	}
	
	/**
	 * Add arbitrary number(less than 32) of bits to the buffer stored in 
	 * integer type, from LSB up to (length - 1) bit
	 * @param bits
	 * @param length
	 */
	public void appendBits(int bits, int length) {
		
		while (length > 8)
		{
			int x = (bits << (32 - length)) >>> 24;
			appendByte((byte)x);
			length -= 8;
		}
		
		if (length > 0)
		{		
			// Now we are appending extra 0s to the buffer, the offset needs to
			// be adjusted
			int x = (bits << (32 - length)) >>> 24;
			appendByte((byte)x);
			
			offset += length;
			
			if (offset >= 8)
				offset -= 8;
			else
				--index;
		}
	}
	
	public String toString() 
	{	
		String output = "";
		
		for (int i = 0; i < buffer.length / 2; ++i)
		{
			char c = 0x0000;
			
			c |= ((char)buffer[i * 2] & 0xFF) << 8;
			c |= ((char)buffer[i * 2 +1] & 0xFF);
			
			output += c;
		}
		return output;
	}
	
	
	public int readNextInt() {
		return readNextInt(32);
	}

	/**
	 * Read the next integer value from the byte buffer. Since bits are packed
	 * within the buffer and not aligned to 4-byte boundary. We need the extra
	 * information on how many bits are actually stored for this integer.
	 * @param bits
	 * @return
	 */
	public int readNextInt(int bits) {		

		int result = 0;
		int length = bits;
		int i = 3;
		
		while (length > 0)
		{
			byte b = nextByte();
						
			result |= ((b & 0xFF) << (i-- << 3));
			length -= 8;
		}
		
		if (length < 0)
		{
			offset += length;
			if (offset < 0)
			{
				offset += 8;
				--index;
			}
		}
		
		result >>>= (32 - bits);
		
		return result;		
	}	
	
	public char readNextChar() {
		byte bH = nextByte();
		byte bL = nextByte();
		return (char)(((bH & 0x00FF) << 8) + (bL & 0x00FF));
	}
	
	/**
	 * Read next 8-bit in sequence. This routine allow us to read byte not 
	 * aligned to the 8-bit boundary.  
	 * @return
	 */
	private byte nextByte() {
		
		if (index == buffer.length || (index == buffer.length - 1 && offset > 0))
			throw new IllegalStateException("Reach the end");
		
		byte b = (byte)((buffer[index] & 0xFF) << offset);
		
		if (offset > 0)
		{		
			b |= ((buffer[index + 1] & 0xFF) >>> (8 - offset));
		}
		++index;

		return b;
	}
	
	private void appendByte(byte b) {
		
		buffer[index] |= (b & 0xFF) >>> offset;
		
		if (offset > 0)
			buffer[index + 1] |= (b & 0xFF) << (8 - offset);
		
		++index;
	}
	
	private byte[] 	buffer;
	private int		index; // the index of the current byte block 
	private int 	offset; // offset bit to the current byte block
	
	protected int _debugGetOffset() { 
		return offset;
	}
}
