import java.nio.charset.Charset;
import java.util.ArrayList;

public class LZEncryption {
	
	public static void main(String args[]){
		
		LZEncryption tmp = new LZEncryption();
		String input = "aabaaabaaaaaabababbbbaba";
		String output = tmp.encode(input);
		
		//output = tmp.decode(output);
		System.out.println(output);
		
	}

	public String encode(String uncompressed){
		final Charset UTF_16 = Charset.forName("UTF-16");
		int bits;
		int previous = 0;
		
		Trie dictionary = new Trie();
		
		int currentIndex = 1;
		int lastWordIndex = 0;
		
		for(int i = 1; i <= uncompressed.length(); i++){
			
			String word = uncompressed.substring(previous, i);
			
			if(dictionary.contains(word)){
				if(i >= uncompressed.length()){
					lastWordIndex = dictionary.findIndex(word);
				}
			}else{
				dictionary.insertString(word, currentIndex);
				previous = i;
				currentIndex++;
			}
			
		}
		
		String retString = "";
		
		for(int j = 1; j <= dictionary.getSize(); j++){
			retString += "" + dictionary.find(j).toCodeWord();
		}
		
		if(lastWordIndex != 0){
			retString += "" + lastWordIndex;
		}
		
		bits = (int) Math.ceil(Math.log(dictionary.getSize()/ Math.log(2)));
	
		return retString;
	}
	
	public static String decode(String compressed){
		
		Trie dictionary = new Trie();
		
		String[] tokenized = compressed.split(" ");
		Character c;
		int pIndex = 0;
		int currentIndex = 1;
		String toInsert = "";
		String ret = "";
		
		for(String s : tokenized){
			
			if(s.length() == 2){
				pIndex = Integer.parseInt((s.substring(0,1)));
				c = s.charAt(1);
				
				//System.out.println(pIndex + "" + c);
				toInsert = dictionary.find(pIndex).toString() + c;
				dictionary.insertString(toInsert, currentIndex);
				//System.out.println(toInsert);
				currentIndex++;
				ret += toInsert;
				
			}else if(s.length() == 1){
				pIndex = Integer.parseInt((s.substring(0,1)));
				toInsert = dictionary.find(pIndex).toString();
				System.out.println(toInsert);
				ret += toInsert;
			}
			
			
		}
		
		
		return ret;
	}
}
