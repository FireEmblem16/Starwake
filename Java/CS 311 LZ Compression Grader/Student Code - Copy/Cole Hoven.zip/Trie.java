import java.util.ArrayList;

class trieNode{
	
	private ArrayList<trieNode> children;
	private Character character;
	private int prefixIndex;
	private trieNode parent;
	private boolean isRoot;
	
	public trieNode(Character c, int pIndex, trieNode _parent, boolean root){
		
		character = c;
		children = new ArrayList<trieNode>();
		prefixIndex = pIndex;
		parent = _parent;
		isRoot = root;
		
	}
	
	public Character getCharacter(){
		return this.character;
	}
	
	public int getPrefixIndex(){
		return this.prefixIndex;
	}
	
	public ArrayList<trieNode> getChildren(){
		return this.children;
	}
	
	public void addChild(trieNode node){
		this.children.add(node);
	}
	
	public trieNode getParent(){
		return this.parent;
	}
	
	public boolean isRoot(){
		return isRoot;
	}
	
	public boolean hasChildren(){
		return !(this.getChildren().size() == 0);
	}
	
	//Returns a string based on the prefix index
	public String toString(){
		
		trieNode current = this;
		String ret = "";
		while(!current.isRoot()){
			ret += current.character;
			current = current.parent;
		}
		
		ret = new StringBuffer(ret).reverse().toString();
		return ret;
	}
	
	public String toCodeWord(){
	
		return "" + this.getParent().getPrefixIndex() + character;
	}
}

public class Trie {

	private trieNode root;
	private int size;
	
	public Trie() {
		
		root = new trieNode((Character) '0' , 0, null, true);
		size = 0;
	}
	
	public int getSize(){
		return this.size;
	}
	
	public boolean contains(String s){
		
		trieNode current = root;
		boolean found = false;		
		
		for(int i = 0; i < s.length(); i++){
			found = false;
			
			if(!current.hasChildren()){
				return false;
			}
			for(trieNode child : current.getChildren()){
				if(child.getCharacter().compareTo( s.charAt(i)) == 0){
					current = child;
					found = true;
					break;
				}
			}
		}
		
		return found;
	}
	
	public void insertString(String s, int pIndex){
		
		trieNode current = this.root;
		boolean found = false;
		
		for(int i = 0; i < s.length(); i++){
			
			if(!current.hasChildren()){
				trieNode tmp = new trieNode(s.charAt(i), pIndex, current, false);
				current.addChild(tmp);
				current = tmp;
				continue;
			}
			else{
				for(trieNode child : current.getChildren()){
					found = false;
					if(child.getCharacter().compareTo( s.charAt(i)) == 0 ){
						current = child;
						found = true;
						break;
					}
					
				}
				
				if(!found){
					trieNode tmp = new trieNode(s.charAt(i), pIndex, current, false);
					current.addChild(tmp);
					current = tmp;
				}
				
				
			}
			
		}
		
		this.size++;
	}
	
	public void insertNode(trieNode node){
		
		node.getParent().addChild(node);
		this.size++;
	}
	
	public trieNode find(int pIndex){
		
		boolean found = false;
		ArrayList<trieNode> nextLevel = new ArrayList<trieNode>();
		ArrayList<trieNode> currentLevel;
		
		if(pIndex == 0){
			return this.root;
		}
		
		currentLevel = root.getChildren();
		
		while(!found){
			
			for(trieNode current : currentLevel){
				if(current.getPrefixIndex() == pIndex){
					return current;
				}else{
					for(trieNode child : current.getChildren()){
						nextLevel.add(child);
					}
				}	
			}
			
			currentLevel = nextLevel;
			nextLevel = new ArrayList<trieNode>();
		}
		
		return null;
	}
	
	public int findIndex(String s){
		
		trieNode current = root;
		int index = 0;
		
		for(int i = 0; i < s.length(); i++){
			index = 0;
			
			if(!current.hasChildren()){
				return 0;
			}
			for(trieNode child : current.getChildren()){
				if(child.getCharacter().compareTo( s.charAt(i)) == 0){
					current = child;
					index = current.getPrefixIndex();
					break;
				}
			}
		}
		
		return index;
	}
	
}
