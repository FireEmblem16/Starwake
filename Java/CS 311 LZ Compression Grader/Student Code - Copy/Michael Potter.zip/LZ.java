import java.util.ArrayList;


/**
 * For encoding and decoding string inputs using LZ compression and a trie dictionary
 * @author mjpotter
 */
public class LZ{
	
	private static trieDictionary dictionary;
	
	private LZ(){
		dictionary = new trieDictionary();
	}
	
	private static LZ main = new LZ();
	
	/**
	 * Print the current dictionary
	 */
	public static void printDictionary(){
		dictionary.printTree();
	}
	
	/**
	 * Fill the dictionary using a string
	 * @param string input string
	 * @return integer of number of nodes
	 */
	private static int fillEncodeDic(String string){
		String sequence = "";
		int index = 1;
		for(char c : string.toCharArray()){
			if(dictionary.findPrefix(sequence+Character.toString(c))){
				sequence = sequence+Character.toString(c);
			}else{
				dictionary.addPrefix(sequence+Character.toString(c), index);
				sequence = "";
				index++;
			}
		}
		return index;
	}
	
	/**
	 * Recursive function to find node and its parent index based on added index
	 * @param encoding arraylist of characters
	 * @param current the current node (called by root)
	 * @param index index we are searching for
	 * @return Array list of chars filled with prefix indexes and char values
	 */
	private static ArrayList<Character> getEncoding(ArrayList<Character> encoding, trieNode current, int index){
		if(current.index==index){
			encoding.add((char)current.parentI);
			encoding.add(current.C);
			return encoding;
		}else{
			for(trieNode child : current.children){
				encoding = getEncoding(encoding, child, index);
			}return encoding;
		}
	}
	
	/**
	 * Bit shifting and packing for encoding 
	 * @param input character arraylist from the dictionary
	 * @return encoded and packed string 
	 */
	private static String encodeShift(ArrayList<Character> input){
		
		int keylen = (int)Math.ceil((Math.log(dictionary.nodes+1))/(Math.log(2)));
		String fin = "";
		char[] chars = new char[input.size()];
		chars[0] = (char) (input.get(0)<<(16-keylen));
		int bShifted=keylen, bRemain=16-bShifted, curindex=1;
		boolean isFull;
		
		for(int i = 1; i<input.size(); i++){
			isFull=true;
			char c = input.get(i);
			char temp; 
			if(i%2==0){
				if(keylen<bRemain){
					temp = (char) (c<<(bRemain-keylen));
					bShifted += keylen;
					isFull=false;
				}else{
					temp = (char) (c>>(keylen-bRemain));
					bShifted = keylen-bRemain;
				}
			}else{
				temp = (char) (c>>bShifted);
			}
			chars[curindex-1] = (char) (chars[curindex-1]|temp);
			chars[curindex] = (char) (c<<(16-bShifted));
			bRemain = 16-bShifted;
			if(!isFull){
				char[] newchar = new char[chars.length-1];
				for(int j = 0; j<newchar.length; j++){
					newchar[j] = chars[j];
				}
				chars = newchar;
			}else{
				curindex++;
			}
		}
		char ilent = (char) (keylen>>16);
		char ilenb = (char) keylen;
		fin =fin + ilent + ilenb;
		for(char c : chars){
			fin += c;
		}
		return fin;
	}
	
	/**
	 * Encode a string using LZ compression 
	 * @param uncompressed string to encode
	 */
	public static String encode(String uncompressed){
		main = new LZ();//reset dictionary
		ArrayList<Character> sequence = new ArrayList<Character>();
		String encoded = "";
		if(uncompressed.length()>0){
			dictionary.nodes = fillEncodeDic(uncompressed);
			
			for(int i =1; i<= dictionary.nodes; i++){
				sequence = getEncoding(sequence, dictionary.root, i);
			}
			encoded = encodeShift(sequence);
		}else{
			encoded = Character.toString('\0') + Character.toString('\0');
		}
		
		return encoded;
	}
	
	/**
	 * Unpack the encoded string into a char list 
	 * @param input string to be unpacked
	 * @return array list of chars in decoded form (number , char)
	 */
	private static ArrayList<Character> shiftDecode(String input){
		ArrayList<Character> decoded = new ArrayList<Character>();
		char[] chars = input.toCharArray();
		int keylen = (chars[0]<<16 | chars[1]);
		int toShift = 16-keylen, nlen = keylen;
		char c1, c2;
		int ctype=2;
		c1 = (char) (chars[2]>>toShift);
		decoded.add(c1);
		for(int i = 2; i<(input.length()-1); i++){
			if(ctype==1){
				c1 = (char) (chars[i]<<nlen);
				if(nlen>(16-keylen)){
					c2 = (char) (chars[i+1]>>toShift);
					c1 = (char) (c1 | c2);
					c1 = (char) (c1>>(16-keylen));
					decoded.add(c1);
				}else{
					c1 = (char) (c1>>(16-keylen));
					decoded.add(c1);
					i--;
				}
				nlen = nlen+keylen;
				if(nlen>16) nlen = nlen-16;
				toShift = 16-nlen;
				ctype=2;
			}else if(ctype==2){
				c1 = (char) (chars[i]<<nlen);
				c2 = (char) (chars[i+1]>>toShift);
				c1 = (char) (c1 | c2);
				decoded.add(c1);
				ctype=1;
			}
			
		}
		return decoded;
	}
	
	/**
	 * Recursive function to find full prefix
	 * @param characters array list of characters in prefix
	 * @param current current node
	 * @param index desired ending index
	 * @return array list with the desired prefix
	 */
	private static ArrayList<Character> getPrefix(ArrayList<Character> characters, trieNode current, int index){
		if(current.index==0){
			return characters;
		}else{
			characters.add(current.C);
			ArrayList<trieNode> nodes = new ArrayList<trieNode>();
			nodes = getNode(nodes, dictionary.root, index);
			characters = getPrefix(characters,nodes.get(0),nodes.get(0).parentI);
			return characters;
		}
	}
	
	/**
	 * Recursive function to find specific node at index
	 * @param nodes arraylist of trieNode
	 * @param current current node
	 * @param index target index
	 * @return Arraylist of size 1 with desired node
	 */
	private static ArrayList<trieNode> getNode(ArrayList<trieNode> nodes, trieNode current, int index){
		if(current.index==index){
			nodes.add(current);
			return nodes;
		}else{
			for(trieNode child : current.children){
				nodes = getNode(nodes, child, index);
			}return nodes;
		}
	}
	
	/**
	 * Fill the trie dictionary and create output string
	 * @param input
	 * @return full output string
	 */
	private static String fillTrieDecode(ArrayList<Character> input){
		String sequence = "";
		String ret = "";
		int index = 1;
		for(int i = 0; i<input.size(); i+=2){
			int parentI = input.get(i);
			if(parentI==0){
				dictionary.addPrefix(Character.toString(input.get(i+1)), index);
				ret+= input.get(i+1);
				index++;
			}else{
				ArrayList<Character> prefix = new ArrayList<Character>();
				trieNode current = new trieNode(input.get(i+1),index,parentI);
				prefix = getPrefix(prefix,current,parentI);
				for(int j=(prefix.size()-1); j>=0; j--){
					sequence += prefix.get(j);
				}
				if(!dictionary.findPrefix(sequence)){
					dictionary.addPrefix(sequence, index);
					ret += sequence;
					index++;
				}
			}
			sequence = "";
		}
		return ret;
	}
	
	/**
	 * Decode a LZ compressed string
	 * @param compressed: string to decode
	 * @return decoded string
	 */
	public static String decode(String compressed){
		main = new LZ(); //reset dictionary
		String decoded = "";
		if(compressed.length()>2){
			ArrayList<Character> chars = shiftDecode(compressed);
			decoded = fillTrieDecode(chars);
		}
		return decoded;
	}
}