import java.util.LinkedList;
import java.util.Queue;


/**
 * Trie dictionary class for finding and adding words/prefixes
 * @author mjpotter
 */
public class trieDictionary{
	
	public int nodes;
	public trieNode root;
	
	public trieDictionary(){
		root = new trieNode('\0', 0, 0);
		nodes = 0;
	}
	
	/**
	 * Add a word or prefix to trie dictionary
	 * @param input string to add
	 * @param index prefix index
	 */
	public void addPrefix(String input, int index){
		if(findPrefix(input)) return;
		
		trieNode current = root;
		for(char c : input.toCharArray()){
			trieNode child = current.getChild(c);
			if(child != null) current = child;
			else{
				current.children.add(new trieNode(c,index,current.index));
				current = current.getChild(c);
			}
		}
		current.isPrefix=true;
	}
	
	/**
	 * Search through current dictionary
	 * @param search the desired string
	 * @return true if found, otherwise false
	 */
	public boolean findPrefix(String search){
		trieNode current = root;
		for(char c : search.toCharArray()){
			if(current.getChild(c) == null) return false;
			else current = current.getChild(c);
		}
		if(current.isPrefix) return true;
		return false;
	}
	
	/**
	 * Breadth-First printing of the tree to system.out
	 */
	public void printTree(){ 
		Queue<trieNode> queue = new LinkedList<trieNode>();
		queue.add(root);
		while(!queue.isEmpty()){
			trieNode current = queue.remove();
			String value;
			if(current.C=='\0') value = "null";
			else value = Character.toString(current.C);
			System.out.print(String.valueOf(current.parentI)+value+" ");
			for(trieNode child : current.children){
				queue.add(child);
			}
		}
	}

}