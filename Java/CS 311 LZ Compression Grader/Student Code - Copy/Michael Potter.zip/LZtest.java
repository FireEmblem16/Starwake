import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;


/**
 * Test class for the LZ compression
 * @author mjpotter
 */
public class LZtest{

	public static void main(String[] args){
		String get = LZ.encode("Do not meddle in the affairs of wizards, for they are subtle and quick to anger.");
		File f = new File("test.bin");
		try {
			FileOutputStream fs = new FileOutputStream(f);
			try {
				fs.write(get.getBytes("UTF-16BE"));
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		String out = LZ.decode(get);
		System.out.println(out);
	}

}