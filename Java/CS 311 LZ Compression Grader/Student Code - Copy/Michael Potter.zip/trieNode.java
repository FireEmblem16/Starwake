import java.util.LinkedList;

/**
* trieNode class
* each node has its 16-bit char, index, and list of child nodes
* @author mjpotter
*/
public class trieNode{
	LinkedList<trieNode> children;
	char C;
	int index;
	int parentI;
	boolean isPrefix;
	
	public trieNode(char in, int index,int p) {
		this.C = in;
		this.index = index;
		this.parentI = p;
		this.isPrefix = false;
		this.children = new LinkedList<trieNode>();
	}
	
	/**
	 * Get child based on char value
	 * @param in the char being searched
	 * @return the found child node, otherwise null
	 */
	public trieNode getChild(char in){
		if(children != null)
			for(trieNode child : children)
				if(child.C == in)
					return child;
		return null;
	}
}