
public class Tests
{
	//DISREGARD
	public static void main(String [] args)
	{
	
		{
			
			System.out.println(LZ.encode("aabaaabaaaaaabababbbb"));
			String testString = LZ.encode("aabaaabaaaaaabababbbb");
			System.out.println(LZ.decode(testString));

			
		}
	}


}
