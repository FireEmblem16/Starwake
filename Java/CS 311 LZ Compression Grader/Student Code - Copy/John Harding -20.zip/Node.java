
public class Node
{
	int prefix;
	Node parent;
	Node nextNode;
	Node[] childArray;
	char newChar;
	int index;

	public Node()
	{
		prefix = 0;
		// it doesn't matter what this is set to, it will be ignored in the root
		// node
		parent = null;
		newChar = 0;
		childArray = new Node[256];
		for (int i = 0; i < 256; i++)
		{
			childArray[i] = null;
		}

	}

	public Node(Node parentNode, char addChar, int counter)
	{
		parent = parentNode;
		nextNode = null;
		prefix = parentNode.index;
		index = counter;
		newChar = addChar;
		childArray = new Node[256];
		for (int i = 0; i < 256; i++)
		{
			childArray[i] = null;
		}

	}

	boolean addNode(Node parentNode, char addChar, int addIndex)
	{
		// links the two nodes together
		childArray[(int) addChar] = new Node(parentNode, addChar, addIndex);
		return true;

	}
	public static class Pair
	{
		int intVar;
		char charVar;
		boolean nullChar;
		
		public Pair(int a, char b)
		{
			intVar = a;
			charVar = b;
			nullChar = false;
		}
		public Pair(int a, char b, boolean isNull)
		{
			intVar = a;
			charVar = b;
			//if there is no char for the pair(basically only for the last substring)
			nullChar = isNull;
		}
		public int getInt()
		{
			return intVar;
		}
		public char getChar()
		{
			return charVar;
		}
		public boolean getBool()
		{
			return nullChar;
		}
	}
}
