
import Node.Pair;

import java.util.ArrayList;

public class Trie
{
	char prevChar;
	Node prevNode;
	Node indexerNode;
	// root node
	Node root;
	// subString start and end index
	//for additions done outside the constructor
	int addCounter;
	public Trie()
	{
		root = new Node();
		addCounter = 1;
	}
	public Trie(String inputString)
	{
		int subStart = 0;
		int subEnd = 0;
		int indexer = 0;
		// initialization
		// create root node and start indexer at 1
		root = new Node();
		indexerNode = root;

		indexer++;
		Node currentIndex;
		// when done parsing through all substrings
		while (subStart != inputString.length()	&& subEnd != inputString.length())
		{
			if (prefixChecker(inputString.substring(subStart, subEnd + 1)))
			{
				// find the longest substring that already exists
				subEnd++;
			}
			else
			{
				// special case substring is new with the root as the prefix
				if (subEnd == subStart)
				{
					
						root.addNode(root, inputString.charAt(subStart), indexer);
						currentIndex = prefixGetter(inputString.substring(subStart,	subEnd));

						//links 
						indexerNode.nextNode = currentIndex.childArray[inputString.charAt(subStart)];
						indexerNode = indexerNode.nextNode;
					
					// go to next substring
					indexer++;
					subStart++;
					subEnd++;
				}
				else
				{
					// figure out the index
					currentIndex = prefixGetter(inputString.substring(subStart,	subEnd));
					// add new node and link appropriately
					currentIndex.addNode(currentIndex, inputString.charAt(subEnd), indexer);
					
					indexerNode.nextNode = currentIndex.childArray[inputString.charAt(subEnd)];
					indexerNode = indexerNode.nextNode;
					
					indexer++;
					// subEnd + 1 points to new char so start the new substring
					// at subEnd + 2
					subStart = subEnd + 1;
					subEnd = subStart;
				}
			}
		}
		// checks if last substring where repeating is allowed
		if (subEnd == inputString.length())
		{
			////outputArray.add(new Pair(prefixGetter(inputString.substring(subStart, subEnd)).index, ' ', true));
		}
		addCounter = indexer;

	}
	public void decodeAddNode(int prefix, char newChar)
	{
		
		Node currentNode = root;
		for(int i = 0; i < prefix; i++)
		{
			currentNode = currentNode.nextNode;
		}
		
		currentNode.addNode(currentNode, newChar, addCounter);
		//if you go back to an old parent and make another child such as a for lambda and then b
		if(currentNode.nextNode == null)
		{
			currentNode.nextNode = currentNode.childArray[newChar];
		}
		else
		{
			prevNode.childArray[(int)prevChar].nextNode = currentNode.childArray[newChar];

		}
		addCounter++;
		prevNode = currentNode;
		prevChar =newChar;
	}

	public ArrayList<Pair> encodeOutputArray()
	{
		ArrayList<Pair> output = new ArrayList<Pair>();
		Node iteratorNode = root;
		while(iteratorNode.nextNode != null)
		{
			output.add(new Pair(iteratorNode.nextNode.parent.index, iteratorNode.nextNode.newChar));
			iteratorNode = iteratorNode.nextNode;
		}
		return output;
		
	}
	public String decodeOutputString()
	{
		ArrayList<String> outputBits = new ArrayList<String>();
		String output = "";
		Node decodeIterator = root;
		//special case for root
		output = output + String.valueOf(decodeIterator.nextNode.newChar);
		outputBits.add(String.valueOf(decodeIterator.nextNode.newChar));
		decodeIterator = decodeIterator.nextNode;
		while(decodeIterator.nextNode != null)
		{
			//parent is lambda(root)
			if(decodeIterator.nextNode.parent.index == 0)
			{
				output = output + String.valueOf(decodeIterator.nextNode.newChar);
				outputBits.add(String.valueOf(decodeIterator.nextNode.newChar));
				decodeIterator = decodeIterator.nextNode;
			}
			output = output + outputBits.get(decodeIterator.nextNode.parent.index - 1) + String.valueOf(decodeIterator.nextNode.newChar);
			outputBits.add((outputBits.get(decodeIterator.nextNode.parent.index - 1) + String.valueOf(decodeIterator.nextNode.newChar)));
			decodeIterator = decodeIterator.nextNode;
		}
		
		return output;
		
	}
	
	
	
	private boolean prefixChecker(String subString)
	{
		Node currentNode = root;
		for (int i = 0; i < subString.length(); i++)
		{
			// starts with first
			if (currentNode.childArray[subString.charAt(i)] != null)
			{
				// do nothing, keep on going
				currentNode = currentNode.childArray[subString.charAt(i)];
			}
			else
			{
				// prefix doesn't exist in the dictionary
				return false;
			}
		}
		return true;
	}

	private Node prefixGetter(String subString)
	{
		Node currentNode = root;
		for (int i = 0; i < subString.length(); i++)
		{
			// starts with first
			if (currentNode.childArray[subString.charAt(i)] != null)
			{
				// do nothing, keep on going
				currentNode = currentNode.childArray[subString.charAt(i)];
			}

		}
		return currentNode;
	}

}
