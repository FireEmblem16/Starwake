import java.lang.Math;

import Node.Pair;

import java.util.ArrayList;

public class LZ
{
	public static String encode(String uncompressed)
	{
		ArrayList<Pair> out = new ArrayList<Pair>();
		Trie compressTrie = new Trie(uncompressed);
		out = compressTrie.encodeOutputArray();
		
		int codewordLength = lengthToNumBits(uncompressed);
		//first four bits which show how big the codeword with be
		String outputString = intToBits(codewordLength, 4);
		for (int i = 0; i < out.size(); i++)
		{
			String tempIntString = intToBits(out.get(i).getInt(), codewordLength);
			String tempCharString;
			
			if(out.get(i).getBool() == true)
			{
				tempCharString = "";
			}
			else
			{
				tempCharString = intToBits((int)(out.get(i).getChar()), 16);
			}
			
			outputString = outputString.concat(tempIntString);
			outputString = outputString.concat(tempCharString);

		}
		//now we have to pad bits at the end so that this is a multiple of 16
		//math for figuring out how many filler bits we need
		int neededBits = ((codewordLength + 16) * out.size() + 4) % 16;
		for(int i = 0; i < neededBits; i++)
		{
			outputString = outputString.concat("0");
		}
		return outputString;
	}

	public static String decode(String compressed)
	{
 		String codewordString = compressed.substring(0, 4);
		String tempIndex;
		String tempChar;
		int codewordSize = Integer.parseInt(codewordString, 2);
		Trie decompressTrie = new Trie();
		
		int numCodeWords = (compressed.length() - 4) / (codewordSize + 16);
		int padderBits = (compressed.length() - (4 + (codewordSize + 16) * numCodeWords)); 
		for(int i = 4; i < compressed.length() - padderBits; i += (codewordSize + 16))
		{
			tempIndex = compressed.substring(i, i + codewordSize);
			tempChar = compressed.substring(i + codewordSize, i + codewordSize + 16);
			
			int currentIndex = Integer.parseInt(tempIndex, 2);
			char currentChar = (char)Integer.parseInt(tempChar, 2);
			decompressTrie.decodeAddNode(currentIndex, currentChar);
			
		}
		return decompressTrie.decodeOutputString();

		

	}

	
	
	
	
	// converts number of bits required
	static String intToBits(int input, int wordSize)
	{
		String output = "";
		//max size is 15 bit codewords : 1111
		for(int i = wordSize-1; i >= 0; i--)
		{
		// needs to be padded with 0s
		//this means there's a 1 in the i'th bit spot
			if ((input)/((int)(Math.pow(2, i))) != 0)
			{
				output = output.concat("1");
				input = input - (int)(Math.pow(2, i));
			}
			else
			{
				output = output.concat("0");
			}
			
		}	
		return output;
	}

	// converts string length to number of prefix bits
	static int lengthToNumBits(String str)
	{
		return (int) (Math.ceil(Math.log(str.length() + 1.0)));
	}
}