import java.util.ArrayList;


public class LZ {
	
	public static String encode(String uncompressed) throws Exception
	{
		if(uncompressed==null || uncompressed.length()==0)
		{
			char[] nullthing = new char[2];
			String returnNull = nullthing[0] + "" + nullthing[1];
			return returnNull;
		}

		
		//Use this to keep track of the encoded String in non-binary form, then convert it at the end
		ArrayList<TrieNode> nodeList = new ArrayList<TrieNode>();
		
		//The trie that will store the nodes for our encoded String
		Trie trie = new Trie();
		
		//keep track of how much of the string has been encoded
		int encodedTo = 0;
		
		for(int i=1;i<=uncompressed.length();i++)
		{
			//If the specified substring is not already in the trie, add it. If it is already in the trie the loop will add a child to it eventually
			String sub = uncompressed.substring(encodedTo, i);
			if(!trie.contains(sub))
			{
				encodedTo = i;
				nodeList.add(trie.add(sub));
			}
			//If the last part of the string has already been in the trie, we only need a number, no character (i.e. aabab = 0a1b2)
			else if(trie.contains(sub) && i==uncompressed.length())
			{
				nodeList.add(new TrieNode(null, -1, trie.getNode(sub)));
			}
		}
		
		//Use index to compute how many bits you need for the codeword
		int codeSize = 32 - Integer.numberOfLeadingZeros(trie.size());
		
		//compute the number of characters we will need for output
		int bits = 32 + (nodeList.size()*(16+codeSize));
		if(nodeList.get(nodeList.size()-1).getData()==null)//account for the last thing in the list not having a new character
			bits-=16;
		int characters = (int) Math.ceil(bits/16.00);
		
		//Construct a string of '0' and '1' chars to convert to binary
		String out = "";
		//32 bit integer for size of indexes
		for(int i=0; i<32-Integer.toBinaryString(codeSize).length();i++)
			out += 0;
		out += Integer.toBinaryString(codeSize);
		//numbers and letters
		for(TrieNode node: nodeList)
		{
			//add the number
			for(int i=0; i<codeSize-Integer.toBinaryString(node.getParent().getIndex()).length();i++)
				out += 0;
			out += Integer.toBinaryString(node.getParent().getIndex());
			//add the letter
			if(node.getData()!=null)
			{
				for(int i=0; i<16-Integer.toBinaryString(node.getData()).length();i++)
					out += 0;
				out += Integer.toBinaryString(node.getData());
			}
		}
		int addZeroes = 0;
		if(out.length()%16!=0)
			addZeroes = 16 - out.length()%16;
		
		for(int i=0;i<addZeroes;i++)
		{
			out+='0';
		}
	
//		//For testing the string in a form I can actually read
//		for(TrieNode node: nodeList)
//		{
//			System.out.print(node.getParent().getIndex());
//			if(node.getData()!=null)	
//				System.out.print(node.getData());
//			System.out.print(" ");
//		}
//		
		return FromBinary(out);
	}
	
	public static String decode(String compressed) throws Exception
	{
		if(compressed==null || compressed.length()<2)
			return "";
		
		//make the unreadable string into a string of 0's and 1's
		String readable = ToBinary(compressed);
		//Size of the indexes
		int codeSize = (compressed.charAt(0) << 16) | compressed.charAt(1);
		//The Trie that we will build as we decode
		Trie trie = new Trie();
		//The list of nodes that we will use to represent the final String
		ArrayList<TrieNode> nodes = new ArrayList<TrieNode>();
		//The string that will eventually be returned
		String decoded = "";
		
		//Get the indexes and characters from the rest of the String
		int counter = 32; //starts at 32 because we already handled the first 32 bits
		while(counter+codeSize<readable.length())
		{
			//get the index
			String num = readable.substring(counter, counter+codeSize);
			int index=0;
			for(int i=0;i<codeSize;i++)
			{
				index <<= 1;
				if(num.charAt(i)=='1')
					index |= 1;
			}
			counter+=codeSize;
			
			//get the letter
			if(counter+16<readable.length())
			{
				String ch = "";
				String charString = readable.substring(counter, counter+16);
				int charNum=0;
				for(int i=0;i<16;i++)
				{
					charNum <<= 1;
					if(charString.charAt(i)=='1')
						charNum |= 1;
				}
				ch += (char) charNum;
				counter+=16;
				
				//add a node to the Trie
				String data = "" + ch;
				if(index!=0) //Add the node if its parent is not the root
				{
					for(int i=0;i<nodes.size();i++)
					{
						if(nodes.get(i).getIndex()==index)
						{
							data = nodes.get(i).getString() + ch;
							break;
						}
					}
					if(data.length()>0 && data!=null)
					{
						TrieNode n = trie.add(data);
						nodes.add(n);
						decoded += n.getString();
					}
				}
				else //add the node if its parent is the root
				{
					if(data.length()>0 && data!=null)
					{
						nodes.add(trie.add(ch));
						decoded += data;
					}
				}
			}
			else if(index!=0)//There is no new character but there is a hanging index at the end of the input string
			{
				for(int i=0;i<nodes.size();i++)
				{
					if(nodes.get(i).getIndex()==index)
						nodes.add(nodes.get(i));
				}
				counter+=16;
			}
			else//index is 0 but it is only hanging zeroes
			{
				counter+=16;
			}
		}
		
		//get the size of the indexes from the first 32 bits
//		int codeSize = 0;
//		for(int i=0; i<32;i++)
//		{
//			if(readable.charAt(i)=='1')
//				codeSize+=Math.pow(2,32-i);
//		}
		
		
		return decoded;
	}
	
	/**
	 * The next two methods come from Don's email to the class. Thanks Don!
	 */
	public static String ToBinary(String str)
	{
		final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i++)
		{
			char c = str.charAt(i);
			
			for(int j = 0;j < 16;j++)
				if((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}
		
		return ret;
	}	

	public static String FromBinary(String str)
	{
		final char[] bits = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i += 16)
		{
			char c = 0x0000;
			
			for(int j = 0;j < 16;j++)
				if(str.charAt(i + j) == '1')
					c |= bits[j];
			
			ret += c;
		}
		
		return ret;
	}
	
	public static void changeBit(char[] chars, int index)
	{
		int charIndex = index / 16;
		int offset = index % 16;
		
		char mask=(char) (0b1000000000000000 >> offset);
		
		chars[charIndex] |= mask;
 	}
	
}
