

public class Trie {
	TrieNode root;
	int size = 1;
	
	//The constructor initializes the root node, it has no data and no parent, and an index of 0
	public Trie() {
		root = new TrieNode(null, 0, null);
	}
	
	/**
	 * Add a node to the trie
	 * @throws Exception
	 * Throws exception if the prefix of the string you are adding is not already in the tree 
	 * i.e. tree with only root and you add "abc" would throw an error. To be valid you would need to add "a", then "ab" then "abc"
	 */
	public TrieNode add(String str) throws Exception
	{
		TrieNode node = root;
		
		//loop will get you to the bottom of the trie
		for(int i=0;i<str.length()-1;i++)
		{
			node = node.getChild(str.charAt(i));
			if(node==null)
				throw new Exception("Attempted to add a string to the trie whose prefix was not in the trie");
		}
		//Add the new node to the trie
		TrieNode child = new TrieNode(str.charAt(str.length()-1), size, node);
		node.getChildren().add(child);
		size++;
		return child;
	}
	
	/**
	 * returns the index of a given substring, the entire string must be in the trie already
	 * @throws Exception 
	 */
	public int getIndex(String str) throws Exception
	{
		TrieNode node = root;
		
		//loop will get you to the bottom of the trie
		for(int i=0;i<str.length()-1;i++)
		{
			node = node.getChild(str.charAt(i));
			if(node==null)
				throw new Exception("Attempted to find a string that does not exist in the trie");
		}
		return node.getIndex();
	}
	
	/**
	 * Check if a trie contains a certain string
	 */
	public boolean contains(String str)
	{
		TrieNode node = root;
		//Travel down the tree until you find the string, return false if the child is ever null (that means that the prefix is not in the tree)
		for(int i=0;i<str.length();i++)
		{
			node = node.getChild(str.charAt(i));
			if(node==null)
				return false;
		}
		return true;
	}
	
	/**
	 * Get a node based on the String
	 */
	public TrieNode getNode(String str)
	{
		TrieNode node = root;
		//Travel down the tree until you find the string, return null if the string is not in the trie
		for(int i=0;i<str.length();i++)
		{
			node = node.getChild(str.charAt(i));
			if(node==null)
				return null;
		}
		return node;
	}
	
	public int size()
	{
		return size;
	}

}
