import java.util.ArrayList;

public class TrieNode {

	private Character data;
	private int index;
	private TrieNode parent;
	private ArrayList<TrieNode> children;

	TrieNode(Character data, int index, TrieNode parent) {
		this.data = data;
		this.setIndex(index);
		this.parent = parent;
		setChildren(new ArrayList<TrieNode>());
	}

	public Character getData() {
		return data;
	}

	public TrieNode getChild(char data) {
		for (int i = 0; i < getChildren().size(); i++) {
			if (getChildren().get(i).data == data)
				return getChildren().get(i);
		}
		return null;
	}
	
	public String getString(){
		String data = "" + this.data;
		TrieNode n = this.parent;
		while(n.index!=0)
		{
			data = n.data + data;
			n = n.parent;
		}
		return data;
	}

	@Override
	public boolean equals(Object other) {
		if (this.data == ((TrieNode) other).getData())
			return true;
		else
			return false;
	}

	public ArrayList<TrieNode> getChildren() {
		return children;
	}

	public void setChildren(ArrayList<TrieNode> children) {
		this.children = children;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}
	
	public TrieNode getParent() {
		return parent;
	}

}
