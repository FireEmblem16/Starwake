
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


public class LZ {
	private static Map<String, String> dictionary;
	public LZ(){
		
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter string to encode: ");
		String encoded = decode(scanner.nextLine());
		System.out.println(encoded);
		System.out.println("Enter actual binary string: ");
		String check = scanner.nextLine();
		System.out.println(check.equals(encoded));
		System.out.println(check.length());
		/*System.out.println("Please input e for encoding or d for decoding: ");
		if(scanner.nextLine().contains("e")){
			System.out.println("Enter string to encode: ");
			//test string: aabaaabaaaaaabababbbbaba
			String encoded = encode(scanner.nextLine());
			System.out.println(encoded);
		}
		else{
			System.out.println("Enter string to decode: ");
			String decoded = decode(scanner.nextLine());
			System.out.println(decoded);
		}*/
	}
	public static String encode(String uncompressed){
		dictionary = new HashMap<String, String>();
		int index = 1; 
		String currPhrase = "", encodedString = "";
		int codewordBits = (int)Math.ceil((Math.log10(countPhrases(uncompressed))/Math.log10(2)));
		for(int i = 0; i < 32 - Integer.toBinaryString(codewordBits).length(); i++){
			encodedString += "0";
		}
		encodedString += Integer.toBinaryString(codewordBits);
		//add lambda to the dictionary
		if(uncompressed.length() > 0){
		String lambdaIndex = String.format("%" + codewordBits + "s", "").replace(' ', '0');
		dictionary.put(lambdaIndex, "");
		}
		for(int i = 0; i < uncompressed.length(); i++){
			char currChar = uncompressed.charAt(i);
			String charBinary = String.format("%16s", Integer.toBinaryString((int)currChar)).replace(' ', '0');
			if(dictionary.containsValue(currPhrase + currChar)){
				//continue unless this is the last character
				currPhrase += uncompressed.charAt(i);
				if(i == uncompressed.length() - 1){
					//This is the last part of the string. 
					encodedString += findKey(dictionary, currPhrase );
				}
			}
			else{
				if(i != uncompressed.length() - 1){
				//get key from value
				String key = findKey(dictionary, currPhrase);
				//Add the last key and the current character to the dictionary
				String indexBinary = String.format("%" + codewordBits + "s", Integer.toBinaryString(index)).replace(' ', '0');
				//codeword bits is log2(index) not log2(length)
				dictionary.put(indexBinary,currPhrase + currChar);
				//dictionary.put(Integer.toBinaryString(index),currPhrase + currChar);
				encodedString += key + charBinary;
				currPhrase = "";
				index++;
				}
				else{
					//This is the last part of the string and the last char is
					//not in the HashMap.
					encodedString += findKey(dictionary, currPhrase) + charBinary;
				}
			}
			
		}
		String s = encodedString.replaceAll(" ", "");
		int paddedZeroes = 16 - s.length() % 16;
		if(paddedZeroes != 16){
			for(int i = 0; i < paddedZeroes; i++){
				encodedString += "0";
			}
		}
		
		
		return encodedString;
	}
	
	public static String decode(String compressed){
		String binaryCodewordLength = "", decodedString = "";
		for(int i = 0; i < 32; i++){
			binaryCodewordLength += compressed.charAt(i);
		}
		int codewordLength = Integer.parseInt(binaryCodewordLength, 2);
		int index = 1;
		if(codewordLength == 0) return "";
		String lambdaIndex = String.format("%" + codewordLength + "s", "").replace(' ', '0');
		dictionary = new HashMap<String, String>();
		dictionary.put(lambdaIndex, "");
		for(int i = 32; i < compressed.length(); i += codewordLength + 16){
			//get key for next phrase
			String phraseKey = "";
			for(int j = i; j < i + codewordLength; j++){
				phraseKey += compressed.charAt(j);
			}
			//get char for key
			String binaryChar = "", phraseChar = "";
			for(int k = i + codewordLength; k < i + codewordLength + 16; k++){
				if(k < compressed.length()){
					binaryChar += compressed.charAt(k);
				}
			}
			phraseChar += (char)Integer.parseInt(binaryChar, 2);
			//if the last character is all zeroes, then we must be at the end of the string
			if(Integer.parseInt(binaryChar, 2) == 0){
				return decodedString;
			}
			String phraseKeyBinary = String.format("%" + codewordLength + "s", Integer.toBinaryString(index)).replace(' ', '0');
			dictionary.put(phraseKeyBinary, phraseKey+phraseChar);
			decodedString += stringFromKey(dictionary, phraseKey) + phraseChar;
			//System.out.println(decodedString);
			++index;
		}
		return decodedString;
	}
	private static String stringFromKey(Map<String, String> dictionary,String key){
		String output = "";
		String newKey = "", prefKey = "";
		//if this is the lambda key then return an empty string
		if(key.replaceAll("0", "").equals("")) return "";
		newKey = dictionary.get(key);
		//get pref(key)
		for(int i = 0; i < newKey.length() - 1; i++){
			prefKey += dictionary.get(key).charAt(i);
		}
		
		output += stringFromKey(dictionary, prefKey) + newKey.charAt(newKey.length()-1);
		return output;
	}
	//source for findKey http://javarevisited.blogspot.com/2013/02/how-to-get-key-from-value-in-hashtable.html
	private static String findKey(Map<String, String> dictionary,String value){
		for(Map.Entry<String, String> entry: dictionary.entrySet()){
			if(value.equals(entry.getValue())){
				return entry.getKey();
			}
		}
		return "";
	}
	//This is just for getting the number of phrases in the uncompressed string. Kinda a bad way to do it, but I ran out of time
	private static int countPhrases(String uncompressed){
		int index = 1;
		Map<String, String> dict = new HashMap<String, String>();

		String currPhrase = "", encodedString = "";
		int codewordBits = (int)Math.round((Math.log10(uncompressed.length())/Math.log10(2)));
		for(int i = 0; i < 32 - Integer.toBinaryString(codewordBits).length(); i++){
			encodedString += "0";
		}
		//add lambda to the dict
		if(uncompressed.length() > 0){
		String lambdaIndex = String.format("%" + codewordBits + "s", "").replace(' ', '0');
		dict.put(lambdaIndex, "");
		}
		for(int i = 0; i < uncompressed.length(); i++){
			char currChar = uncompressed.charAt(i);
			String charBinary = String.format("%16s", Integer.toBinaryString((int)currChar)).replace(' ', '0');
			if(dict.containsValue(currPhrase + currChar)){
				//continue unless this is the last character
				currPhrase += uncompressed.charAt(i);
				if(i == uncompressed.length() - 1){
					//This is the last part of the string. 
					
				}
			}
			else{
				if(i != uncompressed.length() - 1){
				//get key from value
				String key = findKey(dict, currPhrase);
				//Add the last key and the current character to the dict
				String indexBinary = String.format("%" + codewordBits + "s", Integer.toBinaryString(index)).replace(' ', '0');
				//codeword bits is log2(index) not log2(length)
				dict.put(indexBinary,currPhrase + currChar);
				//dict.put(Integer.toBinaryString(index),currPhrase + currChar);
				currPhrase = "";
				index++;
				}
				else{
					//This is the last part of the string and the last char is
					//not in the HashMap.
					
				}
			}
		
		}
		return index;
	}
}
