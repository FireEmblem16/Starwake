import java.util.ArrayList;


/**
 * A mostly completed class for encoding and decoding LZ compressed stuff
 * @author Zach
 *
 */
public class LZ {
	
	/**
	 * 'Compresses' the given string into an LZ compressed form.
	 * @param string The string to be compressed
	 * @return A String of 1's and 0's representing the binary of the compressed string
	 */
	public static String encodeOld(String string){
		ArrayList<String> dictionary = new ArrayList<String>();
		dictionary.add("");
		String subString = "";
		String encoded = "";
		for(int i = 0; i<string.length();i++){
			if(dictionary.contains(subString + string.charAt(i))){
				subString = subString + string.charAt(i);
			}else{
				encoded = encoded + dictionary.indexOf(subString)+string.charAt(i);
				dictionary.add(subString+string.charAt(i));
				subString = "";
			}
		}
		if(!subString.equals("")){
			encoded = encoded + dictionary.indexOf(subString);
		}
		int codeWordSize = (int) Math.ceil(Math.log(dictionary.size() + 1)/Math.log(2));
		String output = intToBinary(codeWordSize,32);
		//Because I don't know a goodway to get codeword size on the first parse
		dictionary = new ArrayList<String>();
		dictionary.add("");
		subString = "";
		for(int i = 0; i<string.length();i++){
			if(dictionary.contains(subString + string.charAt(i))){
				subString = subString + string.charAt(i);
			}else{
				output = output + intToBinary(dictionary.indexOf(subString),codeWordSize)+asciiToBinary(string.charAt(i),16);
				dictionary.add(subString+string.charAt(i));
				subString = "";
			}
		}
		if(!subString.equals("")){
				output = output + intToBinary(dictionary.indexOf(subString),codeWordSize);
		}
		
		while(output.length()%16 != 0){
			output = output + "0";
		}
		
		return output;
	}
	
	/**
	 * Decodes an LZ compressed string of 1's and 0's to the original string
	 * @param string string of 1's and 0's to be decompressed
	 * @return the decompressed string
	 */
	public static String decodeOld(String string){
		ArrayList<String> dictionary = new ArrayList<String>();
		dictionary.add("");
		String output = "";
		int codeWordSize = binaryToInt(string.substring(0,32));
		for(int i=0; i<(string.length()-32)/(codeWordSize+16);i++){ //Get next codeowrd and letter.
			String substring = string.substring(32+i*(codeWordSize + 16),32+(i+1)*(codeWordSize + 16));
			int codeWord = binaryToInt(substring.substring(0,codeWordSize));
			String nextChar = "" + binaryToChar(substring.substring(codeWordSize,substring.length()));
			String decoded = dictionary.get(codeWord)+nextChar;
			dictionary.add(decoded);
			output = output+decoded;
		}
		return output;
	}
	
	//Code for converting between binary strings and their character/integer representations based off of code from http://www.coderanch.com/t/567086/java/java/Ascii-binary-binary-ascii
	/**
	 * converts a string of 0's and 1's to an int
	 * @param binary
	 * @return
	 */
	public static int binaryToInt(String binary){
		int val = 0;
		for(int i = 0; i<binary.length();i++){
			val <<= 1;
			if(binary.substring(i,i+1).equals("1")){
				val +=1;
			}

		}
		return val;
	}
	
	/**
	 * Converts a string of 1's and 0's to a character
	 * @param binary
	 * @return
	 */
	public static char binaryToChar(String binary){
		int val = 0;
		for(int i = 0; i<binary.length(); i++){
			val<<=1;
			if(binary.substring(i,i+1).equals("1")){
				val +=1;
			}
		}
		return (char) val;
	}
	
	/**
	 * Converts an integer to a string of 1's and 0's
	 * @param integer
	 * @param size
	 * @return
	 */
	public static String intToBinary(int integer, int size){
		StringBuilder binary = new StringBuilder();
		int val = integer;
		for(int i = 0; i<8; i++){
			binary.append((val & 128) == 0? 0:1);
			val <<=1;
		}
		//make binary string correct length
		while(binary.length() < size){
			binary.insert(0,0);
		}
		while(binary.length() > size){
			binary.deleteCharAt(0);
		}
		return binary.toString();
	}

	
	/**
	 * Converts a char to a string of 1's and 0's
	 * @param character
	 * @param size
	 * @return
	 */
	public static String asciiToBinary(char character, int size){
		byte bytes = (byte) character;
		StringBuilder binary = new StringBuilder();
		int val = bytes;
		for(int i = 0; i<8; i++){
			binary.append((val & 128) == 0? 0:1);
			val <<=1;
		}
		while(binary.length() < size){
			binary.insert(0,0);
		}
		while(binary.length() > size){
			binary.deleteCharAt(0);
		}
		return binary.toString();
	}
	
	public static String byteToBinary(char character){
		StringBuilder binary = new StringBuilder();
		int val = character;
		for (int i = 0; i<8; i++){
			binary.append((val&1) == 0? 0:1);
			val >>>= 1;
		}
		return binary.reverse().toString();
	}
	
	public static Byte binaryToByte(String binary){
		int val = 0;
		for(int i = 0; i<binary.length(); i++){
			val<<=1;
			
			if(binary.substring(i,i+1).equals("1")){
				val +=1;
			}
		}
		val &=0xFF;
		return  (byte) val;
	}
	public static String encode(String input){
		String halfway = encodeOld(input); //Because I don't feel like rewriting the code
		
		byte[] bytes = new byte[halfway.length()/8];
		for(int i = 0; i<halfway.length()/8;i++){
			bytes[i] = (binaryToByte(halfway.substring(i*8,(i+1)*8)));
		}
		return new String(bytes);
	}
	/**
	 * A semiworking piece of code. Need to fix code for getting string of 1's and 0's from the input string.
	 * @param input
	 * @return the decoded message
	 */
	public static String decode(String input){
		String halfway = "";
		StringBuilder sb = new StringBuilder();
		for(char character: input.toCharArray()){
			String adding = byteToBinary(character);
//			if(adding.equals("11111101")){
//				adding = "11110000";  //Hackery magic. I'm not really sure where things are coming from or where they go. Where did they come from, Cotton Eye Joe?
//			}
			sb.append(adding);
		}
		halfway = sb.toString();
//		System.out.println(halfway);
		return decodeOld(halfway);
	}
	
	//Test Code
	
//	public static void main(String[] args){	
//		System.out.println("");
////		System.out.println(binaryToInt("0110"));
////		System.out.println(binaryToChar("0000000001000100"));
////		System.out.println(asciiToBinary('D',16));
////		System.out.println(encodeOld("Do not meddle in the affairs of wizards, for they are subtle and quick to anger."));
//		System.out.println(encode("Do not meddle in the affairs of wizards, for they are subtle and quick to anger."));
////		System.out.println(encodeOld("The world is full of sugar!"));
////		System.out.println(encode("The world is full of sugar!"));
////		System.out.println("Decode:");
////		System.out.println(decodeOld("0000000000000000000000000000011000000000000000010001000000000000000001101111000000000000000010000000000000000000011011100000100000000001110100000011000000000110110100000000000000011001010000000000000001100100001000000000000110110000011100000000001000000000000000000001101001000100000000000010000000000000000000011101000000000000000001101000001010000000000110000100000000000000011001100100000000000001100001001011000000000111001000000000000000011100110000110000000001101111010000000000000010000000000000000000011101110010110000000001111010000000000000000110000100000000000000011100100010000000000001110011000000000000000010110000001100000000011001100000100000000001110010000011000000000111010000111000000000011001010000000000000001111001000011000000000110000101100100000000011001010000110000000001110011000000000000000111010100000000000000011000100011010000000001101100001111000000000110111000100000000000001000000000000000000001110001100100000000000110100100000000000000011000110000000000000001101011011110000000000110111110000100000000011011100000000000000001100111000111000000000111001000000000000000001011100000000000"));
////		System.out.println(decodeOld("000000000000000000000000000001100000000000000001101000000000000000000111010000001000000000011100000000000000000000111010000000000000000010111100010100000000011101110000000000000001110111000111000000000010111000000000000000011001100000000000000001101001000000000000000110110100100100000000011010010000000000000001100011000010000000000110100100000000000000011011110000000000000001101110000000000000000010111001000000000000011001010000100000000000101111000000000000000111001100001000000000011011110000000000000001110010000000000000000111100100010100000000001100100000000000000000110000000000000000000011011100000000000000001100110110100000000000111001000101000000000111010000000100000000011001010000000000000000101101000000000000000110001001011000000000011010010000000000000001100101001001000000000010110101011000000000011001010010100000000001100111010000000000000010110100111100000000011001100111110000000001110000100001000000000110111000110100000000011001010101000000000001110011011111000000000111010000011100000000011010010000000000000001101100010111000000"));
////		System.out.println(decodeOld("000000000000000000000000000001110000000000000000110100000000000000000001110100000001000000000011100000000000000000000111001100000000000000000111010000000000000000001011110000110000000000111011100000000000000001110111000100000000000001011100000000000000000110011100000000000000001101111000101100000000011001110000000000000000110110000000000000000001100101000000000000000001011100000000000000000110001100010110000000001101101000011000000000011100110001110000000000110000100000000000000001110010001000000000000011010000000000000000000011111100001000000000001101111000000000000000011101010010100000000000110001100011100000000001101001000000000000000011001000000000000000000011110100101010000000001110010001000100000000011001010000000000000000010110100000000000000001110000000010000000000011110010000000000000000110000101000000000000001101001000000000000000001100100000000000000000010011000000000000000001101001000101100000000011011100011100000000000011000101001010000000001100101000010000000000011100000000000000000000111011000111000000000000110010010010100000000011010010001110000000000011110100000000000000001010101000000000000000010101000000000000000000100011000111110000000000111000010010100000000011100010011100000000000110111000010110000000001110011000001000000000011000010001101000000000110011101001100000000001100001000000000000000001001010100100000000000011000000100000000000001110010010011000000000011101000100110000000000110001101110010000000000110010000000000000000001100000000000000000000110101000110000000000001110010010001000000000011100110000100000000000110100100100000000000000100101011101000000000011100000100010000000000111001000000000000000001101011000000000000000"));
////		System.out.println(decodeOld(encodeOld("Do not meddle in the affairs of wizards...")));
//		System.out.println(encodeOld("Do not meddle in the affairs of wizards, for they are subtle and quick to anger."));
//		System.out.println("Result: " + decode(encode("Do not meddle in the affairs of wizards, for they are subtle and quick to anger.")));
//
//	}

}

	
