
import java.util.LinkedList;
import java.util.Iterator;

/**
 * Trie Node Data structure class
 */

public class TriNode {
	/**
	 * Keep track of childer
	 */
	private LinkedList<TriNode> children;
	/**
	 * character of node
	 */
	private char character;
	/**
	 * keep track of position of node
	 */
	private int position;
	/**
	 * get parent of node which would be prefix
	 */
	private TriNode parent;

	/**
	 * Default constructer
	 */
	public TriNode(char character, int position) {
		this.children = new LinkedList<TriNode>();
		this.character = character;
		this.position = position;
		this.parent = null;
	}

	/**
	 * Get Childern of a node
	 */
	public LinkedList<TriNode> getChildren() {
		return children;
	}

	/**
	 * Add children
	 * 
	 * @return
	 */
	public void addChildren(TriNode node) {
		children.add(node);
	}

	/**
	 * Add character to children
	 * 
	 * @return
	 */
	public char getCharacter() {
		return character;

	}

	/**
	 * Set character
	 * 
	 * @param count
	 */
	public void setCharacter(char c) {
		this.character = c;
	}

	/**
	 * get position of TriNode
	 */
	public int getPosition() {
		return this.position;
	}

	/**
	 * Set position of TriNode
	 */
	public void setPosition(int position) {
		this.position = position;
	}

	/**
	 * get Parent of Trinode
	 */
	public TriNode getParent() {
		return parent;
	}

	/**
	 * set Parent of node.
	 */
	public void setParent(TriNode parent) {
		this.parent = parent;
	}

}
