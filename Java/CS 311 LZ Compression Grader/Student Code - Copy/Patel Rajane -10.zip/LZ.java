
import java.util.LinkedList;
import java.util.Scanner;

/**
 * LZ compression using Tri Tree with linkedlist Rajane Patel Cpre 311
 */
public class LZ {

	/**
	 * Private method for LZ
	 */
	private LZ() {

	}

	/**
	 * Encode data takes in uncompressed data;
	 */
	public static String encode(String uncompressed) {

		String input;
		Trie tri = new Trie();

		tri.setCount(uncompressed.length());

		Scanner in = new Scanner(uncompressed);
		in.useDelimiter("");

		if (uncompressed.length() == 0) 
			return "0000000000000000";
		
			while (in.hasNext()) {
				input = in.next();
				tri.setCount(tri.getCount() - 1);
				while (tri.search(input + "") && in.hasNext()) {
					input = input + in.next();
					tri.setCount(tri.getCount() - 1);
				}

			}

			return tri.getCompressed();
		} 
			

	

	/**
	 * Decode data
	 * 
	 * @param compressed
	 * @return decode
	 */
	public static String decode(String compressed) {

		Trie tri = new Trie();
		String output = tri.getdecode(compressed);
		return output;

	}

}
