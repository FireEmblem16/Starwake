import java.util.LinkedList;
import java.util.ListIterator;
/**
 * Trie Data Structure
 * @author Raj
 *
 */
public class Trie {

	/**
	 * root of tree
	 */
	private TriNode root;

	/**
	 * Size of Trie search tree
	 */
	private int size;
	/**
	 * Default constructer
	 */

	/**
	 * In Order phase input
	 */
	private LinkedList<TriNode> InOrder;

	/**
	 * Give out for compressed output;
	 */
	private String out;

	/**
	 * Default construct for output
	 */
	
	/**
	 * to get last code that could be in dictionary
	 */
	private int Countofmessage;
	
	/**
	 * last coding
	 */
	private TriNode lastNode; 
	
	public Trie() {
		this.root = new TriNode('\0', 0);
		this.InOrder = new LinkedList<TriNode>();
	}
	
	/**
	 * Return size of dictionary
	 * 
	 * @return size
	 */
	public int size() {
		return size;
	}

	/**
	 * Get root node start of dictionary
	 */
	public TriNode getRoot() {
		return root;
	}
  
	/**
	 * To keep track if last code needs to be added
	 * @param count
	 */
	public void setCount(int count){
		this.Countofmessage = count;
		
	}
	/**
	 * Get last count use to get last coding that may belong to diction
	 * @return  countofmessage
	 */
	public int getCount(){
		return this.Countofmessage;
	}
	
	/**
	 * Method to add to dictionary
	 */
	public void TriAdd(TriNode root, String word) {
		// check if in dictionary
		TriNode current = root;
		char[] characters = word.toCharArray();

		for (int i = 0; i < characters.length; i++) {
			current = root;

			if (current.getChildren().size() == 0) {

				TriNode newNode = new TriNode(characters[i], (size + 1));
				newNode.setParent(current);
				current.addChildren(newNode);
		
				// for printing out
				InOrder.add(newNode);
				size++;
			} else {
				// search
				for (TriNode node : current.getChildren()) {
					if (node.getCharacter() == characters[i]) {
						current = node;
						
					} else {
						TriNode newNode = new TriNode(characters[i], (size + 1));
						current.addChildren(newNode);
						newNode.setParent(current);
						InOrder.add(newNode);
						size++;
					
					
						break;
					} // end else
				}// end for

			} // end else

		}

	}

	/**
	 * Method to add only one character to dictionary
	 * used for testing
	 */
	public void TriAdd(TriNode root, char c) {

		TriNode current = root;
		
		if (current.getChildren().size() == 0) {

			TriNode newNode = new TriNode(c, (size + 1));
			newNode.setParent(current);
			current.addChildren(newNode);
			// for printing out
			InOrder.add(newNode);
		
			// current = newNode;
			size++;
		} else {

			for (TriNode node : current.getChildren()) {
				if (node.getCharacter() == c) {
				
					current = node;

				} else {

					TriNode newNode = new TriNode(c, (size + 1));
					current.addChildren(newNode);
					newNode.setParent(current);
					// for printing out
					InOrder.add(newNode);
					
					size++;
					break; 

				} // end else

			}// end for
			
			
			
		}
	}

	/**
	 * Search for prefix in the dictionary if not found add to dictionary
	 */
	public boolean search(String prefix) {

		TriNode current = this.root;
		char[] chars = prefix.toCharArray();
		int count = 0;
		// char lastC='';
		for (char c : chars) {
			if (current.getChildren().size() > 0) {
				for (TriNode node : current.getChildren()) {
					if (node.getCharacter() == c) {
						current = node;
						count++;
					}
				}
			} else {
				this.TriAdd(current, c );
				
				return false;

			}

		}
		
		// last node
		if(this.Countofmessage ==0 && count == prefix.length()){
			 lastNode = new TriNode(current.getCharacter(), current.getPosition());
			 lastNode.setParent(current.getParent());
			
		}		
		
		
		if (count == prefix.length()) {
			
			
			return true;

		} else {

			this.TriAdd(current, prefix);
			
			return false;
		}

	}

	/**
	 * Method to get compressed output
	 * 
	 * @return  out
	 */
	public String getCompressed() {
       
		// add last node if needed
		if(this.lastNode !=null)
		InOrder.add(this.lastNode);
		
		ListIterator iterator = InOrder.listIterator();

		int bits=Integer.toBinaryString(InOrder.size()).length();
		
		out = String.format("%32s", Integer.toBinaryString(bits)).replace(' ',
				'0');

		int prefix = 0;
		String pre = "";
		String suffix;
		String suf = "";
		String connect;
		String format = "%" + bits + "s";
		while (iterator.hasNext()) {

			TriNode newNode = (TriNode) iterator.next();
			prefix = newNode.getParent().getPosition();

			pre = String.format(format, Integer.toBinaryString(prefix));
			pre = pre.replace(' ', '0');
			suffix = this.ToBinary(newNode.getCharacter() + "");

			connect = pre + suffix;
			out = out + connect;
		}
		// pad even with 16 bits;
	    if(out.length()%16!=0){
		int adding = out.length() / 16;
		adding = 16 - (out.length()- adding*16);
	    
	    for(int j=0;j<adding;j++){
			out = out+"0";
		}
	    
	    }
		return out;
	}

	/**
	 * Function to decode
	 */
	public String getdecode(String message) {
		
		String out = "";
        String addletter;
		String tempS;
		// null case
		if(message.equals("0000000000000000"))
			return "";
		
        int prefixLenBits = Integer.parseInt(message.substring(0, 32),2);
	   
		message = message.substring(32);
        
		 int count = 0;
         String prefixS ;
		 while(message.length()>16){
         // parsing input
         tempS =message.substring(0, (prefixLenBits+16));	
         prefixS =tempS.substring(0,prefixLenBits);
        
         int prefix = Integer.parseInt(prefixS,2);
         addletter = tempS.substring(prefixLenBits);
         addletter = this.FromBinary(addletter);
         // adding to InOrder
         if(prefix== 0){
           this.search(addletter);
          }else{
            TriNode newNode = new TriNode(addletter.charAt(0),this.InOrder.size()+1);
        	newNode.setParent(InOrder.get(prefix-1));
        	InOrder.get(prefix-1).addChildren(newNode);
        	InOrder.add(newNode);
        	size++;
          }
         message= message.substring(prefixLenBits+16);
         
         }// end while 
        
         ListIterator iterator = InOrder.listIterator();
     	
         while (iterator.hasNext()) {
        	 TriNode newNode = (TriNode) iterator.next();
        	
        	 if(newNode.getParent().getPosition()==0){
        	 out = out+ newNode.getCharacter();
        	 }else{
        		 String add="";
        		 while(newNode.getParent()!=null){
        		 add = newNode.getCharacter()+add;
        		 newNode = newNode.getParent();
        		}
        		out = out + add;
        	 }
        		 
         }

		return out;

	}

	
	/**
	 * Method obtain from BlackBoard for converting to 16bit String
	 */
	public String ToBinary(String str) {
		final char[] masks = { 0x8000, 0x4000, 0x2000, 0x1000, 0x800, 0x400,
				0x200, 0x100, 0x80, 0x40, 0x20, 0x10, 0x8, 0x4, 0x2, 0x1 };
		String ret = "";

		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);

			for (int j = 0; j < 16; j++)
				if ((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}
		return ret;
	}
    /**
     * Method for obtaining string from binary
     * Method obtained from blackboard 
     */
	public String FromBinary(String str) {
		final char[] bits = { 0x8000, 0x4000, 0x2000, 0x1000, 0x800, 0x400,
				0x200, 0x100, 0x80, 0x40, 0x20, 0x10, 0x8, 0x4, 0x2, 0x1 };
		String ret = "";

		for (int i = 0; i < str.length(); i += 16) {
			char c = 0x0000;

			for (int j = 0; j < 16; j++)
				if (str.charAt(i + j) == '1')
					c |= bits[j];

			ret += c;
		}

		return ret;
	}

}
