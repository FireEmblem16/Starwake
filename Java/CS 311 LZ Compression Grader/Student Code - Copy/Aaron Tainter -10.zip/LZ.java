import java.util.ArrayList;


public final class LZ {
	private LZ(){
		
	}
	
	public static String encode(String uncompressed){
		
		Trie t = new Trie();
		String output = "";
		int i = 0;
		ArrayList<String> output2 = new ArrayList<String>();
		
		while(i<uncompressed.length()) {
			for (int j = i; j<uncompressed.length(); j++) {
				if (t.exists(uncompressed.substring(i, j+1))){
					if (j == uncompressed.length()-1) {
						output2.add(Integer.toString(t.getNodeIndex(uncompressed.substring(i, j+1))));
						i = uncompressed.length();
						break;
					}
				} else {
					t.addNode(uncompressed.substring(i, j+1));
					if (j!=i) {
						output2.add(Integer.toString(t.getNodeIndex(uncompressed.substring(i, j))));
						output2.add(Character.toString(uncompressed.charAt(j)));
						i=j+1;

					} else {
						output2.add("0");
						output2.add(Character.toString(uncompressed.charAt(j)));
						i++;
					}
					break;
					
				}
			}
		}
		
		int codewordLength = log(uncompressed.length() + 1, 2);
		String codewordLengthBinStr = Integer.toBinaryString(codewordLength);
		String zeros = "";
		
		for (i = 0; i<32-codewordLengthBinStr.length(); i++) {
			zeros += "0";
		}
		
		codewordLengthBinStr = zeros + codewordLengthBinStr;
		
		boolean codeWord = true;
		
		for (String s : output2) {
			if (codeWord) {
				int codewordInt = Integer.parseInt(s);
				String codewordIntStr = Integer.toBinaryString(codewordInt);
				 
				 while (codewordIntStr.length() < codewordLength) {
					 codewordIntStr = "0" + codewordIntStr;
				 }
				 
				output += codewordIntStr;
				codeWord = false;
			} else {
				output += ToBinary(s);
				codeWord = true;
			}
		}
		
		while (output.length() % 16 != 0) {
			output+="0";
		}
		
		return codewordLengthBinStr + output;
	}
	
	public static String decode(String compressed) {
		Trie t = new Trie();
		ArrayList<String> normalCompressed = new ArrayList<String>();
		String output = "";
		String chain = "";
		boolean index = true;
		int pos = 0;
		boolean codeWord = true;
		
		int codewordLength = Integer.parseInt(compressed.substring(0, 32), 2);
		pos = 32;
		
		while (pos<compressed.length()) {
			if (codeWord) {
				normalCompressed.add(
						Integer.toString(
								Integer.parseInt(
										compressed.substring(pos, pos + codewordLength),2)));
				codeWord = false;
				pos += codewordLength;
			} else {
				if (compressed.length()-pos < 16) {
					break;
				}
				normalCompressed.add(
						FromBinary(
								compressed.substring(pos, pos+16)));
	
				codeWord = true;
				pos += 16;
			}
		}
		
		
		for (String value : normalCompressed) {
			if (index) {
				
				chain = t.getIndexChain(Integer.parseInt(value));
				output += chain;
				index = false;
			} else {
				t.addNode(chain + value);
				output+=value;
				index = true;
			}
		}
		
		return output;
	}
	
	public static String ToBinary(String str)
	{
		final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i++)
		{
			char c = str.charAt(i);
			
			for(int j = 0;j < 16;j++)
				if((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}
		
		return ret;
	}	

	public static String FromBinary(String str)
	{
		final char[] bits = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i += 16)
		{
			char c = 0x0000;
			
			for(int j = 0;j < 16;j++)
				if(str.charAt(i + j) == '1')
					c |= bits[j];
			
			ret += c;
		}
		
		return ret;
	}
	
	static int log(int x, int base)
	{
	    return (int) Math.ceil((Math.log(x) / Math.log(base)));
	}
	
}
