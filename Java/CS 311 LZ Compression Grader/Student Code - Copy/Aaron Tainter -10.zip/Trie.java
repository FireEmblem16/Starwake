import java.util.ArrayList;
import java.util.HashMap;

import javax.management.RuntimeErrorException;



public class Trie {
	public class Node {
		String value;
		int index;
		Node parent;
		ArrayList<Node> children;
		
		public Node(String value, int index, Node parent) {
			this.value = value;
			this.index = index;
			this.parent = parent;
			children = new ArrayList<Node>();
		}
		
		public void addChild(Node n) {

			children.add(n);
			return;
		} 
		
		public ArrayList<Node> getChildren() {
			return children;
		}
		
		public String getValue() {
			return value;
		}
		
		public int getIndex(){
			return index;
		}
	}
	
	HashMap<Integer,Node> nodes;
	Node root;
	int numNodes;
	
	public Trie() {
		//create root
		this.root = new Node("lambda", 0, null);
		nodes = new HashMap<Integer, Node>();
		nodes.put(0, root);
		
		numNodes = 0;
	}
	
	public boolean exists(String chain) {
		String[] search = chain.split("");
		Node curr = root;
		ArrayList<Node> nextChildren = curr.children;
		boolean foundChild = false;
		
		for (String searchChar : search) {
			foundChild = false;
			
			for (Node child : nextChildren) {

				if (child.getValue().equals(searchChar)) {
					curr = child;
					nextChildren = curr.children;
					foundChild = true;
					break;
				}
			}
			
			if (!foundChild) {
				return false;
			}
			
		}
		
		return true;
	}
	
	public Node getIndex(int index) {
		return nodes.get(index);
	}
	
	public String getIndexChain(int index){
		Node n = getIndex(index);
		String output = n.value;
		
		if (n.parent == null) {
			return "";
		}
		
		while (!n.parent.value.equals("lambda")) {
			n = n.parent;
			output+=n.value;
		}
		
		output = new StringBuilder(output).reverse().toString();
		return output;
	}
	
	public int getNodeIndex(String chain) {
		
		Node curr = root;
		boolean foundChild = false;
		ArrayList<Node> nextChildren = curr.children;
		
		for (int i = 0; i<chain.length(); i++) {
			foundChild = false;
			for (Node child : nextChildren) {
				if (child.getValue().equals(chain.substring(i, i+1))){
					curr = child;
					nextChildren = curr.children;
					foundChild = true;
					break;
				}
			}
			
			if (!foundChild&&chain.length()!=1) {
				throw new RuntimeException("Can't find chain");
			}
		}
		
		return curr.index;
	}
	
	public void addNode(String chain) {
		
		String[] search = chain.split("");
		Node curr = root;
		ArrayList<Node> nextChildren = curr.children;
		boolean foundNode = false;
		int i=0;
		
		for (String searchChar : search) {
			foundNode = false;
			if (i == search.length -1 || search.length == 1) {
				numNodes++;
				Node myNode = new Node(searchChar, numNodes, curr);
				nodes.put(numNodes, myNode);
				nextChildren.add(myNode);
				return;
			}
			
			for (Node child : nextChildren) {
				if (child.getValue().equals(searchChar)) {
					curr = child;
					nextChildren = curr.children;
					foundNode = true;
					i++;
					break;
					
				}
			}
			
			
		}
		
		throw new RuntimeException("Trying to add child to node that does not exist");
	}
	
	public int getNumNodes() {
		return numNodes;
	}
	
}
