
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub   aabaaabaaaaaabababbbbaba
		String out = LZ.encode("This is a test of a random string.");
		System.out.println(out);
		System.out.println(LZ.decode(out));
	}

}
