package Compressor.Codewords;

import java.util.ArrayList;
import java.util.Stack;

public class Codewords extends ArrayList<Codeword> {
    int maxParentIndex;

    public Codewords() {
        super();
    }

    public Codewords(String compressed) {
        super();
        decode(compressed);
    }

    @Override
    public boolean add(Codeword e) {
        if (e.parentIndex > maxParentIndex) {
            maxParentIndex = e.parentIndex;
        }
        return super.add(e);
    }

    @Override
    public String toString() {
        String result = "";
        for (Codeword cw : this) {
            result += getCodewordString(cw);
        }
        return result;
    }

    public String getCodewordString(Codeword cw) {
        // Create the codeword stack using parent codewords
        Stack<Codeword> cws = new Stack<Codeword>();
        while (cw.parentIndex > 0) {
            cws.push(cw);
            cw = this.get(cw.parentIndex - 1);
        }

        // Go back through the stack to create the string
        String parentString = "";
        parentString += (cw.data == null ? "" : cw.data);
        while (!cws.isEmpty()) {
            cw = cws.pop();
            parentString += (cw.data == null ? "" : cw.data);
        }

        return parentString;
    }

    public String encode() {
        int unitSize = 0;
        // Using maxParentIndex is much more efficient
        // int indexSize = maxParentIndex;
        int indexSize = this.size() + 1;
        if (indexSize > 0) {
            unitSize = (int) Math.ceil(Math.log(indexSize) / Math.log(2));
        }

        CodewordEncoder encoder = new CodewordEncoder(unitSize);
        for (Codeword cw : this) {
            encoder.addIndex(cw.parentIndex);
            if (cw.data != null) {
                encoder.addChar(cw.data);
            }
        }
        return encoder.toString();
    }

    public void decode(String compressed) {
        CodewordDecoder decoder = new CodewordDecoder(compressed);
        Codeword cw = decoder.readCodeword();
        while (cw != null) {
            this.add(cw);
            if (cw.data == null) {
                break;
            }
            cw = decoder.readCodeword();
        }
    }
}
