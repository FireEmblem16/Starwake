package Compressor.Codewords;

import Compressor.Bitcoder.BitEncoder;
import Compressor.Bitcoder.Bitmask;
import Compressor.Bitcoder.Bitwise;

import java.nio.ByteOrder;

public class CodewordEncoder extends BitEncoder {
    public static final int NUM_SIZE_BITS = 32;
    public static final ByteOrder DEFAULT_ENDIANNESS = ByteOrder.BIG_ENDIAN;

    private Bitmask indexMask;
    private Bitmask charMask;
    private ByteOrder indexEndianness;
    private ByteOrder charEndianness;

    public CodewordEncoder(int unitSize) {
        this(unitSize, DEFAULT_ENDIANNESS, DEFAULT_ENDIANNESS, DEFAULT_ENDIANNESS);
    }

    public CodewordEncoder(int unitSize, ByteOrder sizeEndianness, ByteOrder indexEndianness, ByteOrder charEndianness) {
        super();

        // Prepare mask and endianness data for codewords
        indexMask = new Bitmask(unitSize);
        charMask = new Bitmask(Character.SIZE);
        this.indexEndianness = indexEndianness;
        this.charEndianness = charEndianness;

        // Prepend the 32-bit size data
        byte[] sizeBytes = Bitwise.intToBytes(unitSize, sizeEndianness);
        int numChars = NUM_SIZE_BITS / Character.SIZE;
        for (int i = 0; i < numChars; i++) {
            bitstring += Bitwise.bytesToChar(sizeBytes[2 * i], sizeBytes[2 * i + 1]);
        }
    }

    public void addIndex(int val) {
        add(val, indexMask, indexEndianness);
    }

    public void addChar(char val) {
        add(val, charMask, charEndianness);
    }
}
