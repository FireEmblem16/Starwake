package Compressor.Codewords;

import Compressor.Bitcoder.Bitmask;
import Compressor.Bitcoder.Bitwise;

import java.nio.ByteOrder;

public class CodewordDecoder {
    private String compressed;
    private int indexSize;

    private int bitPos;

    public CodewordDecoder(String compressed) {
        this(compressed, CodewordEncoder.DEFAULT_ENDIANNESS, CodewordEncoder.DEFAULT_ENDIANNESS, CodewordEncoder.DEFAULT_ENDIANNESS);
    }

    public CodewordDecoder(String compressed, ByteOrder sizeEndianness, ByteOrder indexEndianness, ByteOrder charEndianness) {
        this.compressed = compressed;
        indexSize = Bitwise.charsToInt(compressed.charAt(0), compressed.charAt(1), sizeEndianness);
        bitPos = CodewordEncoder.NUM_SIZE_BITS;
    }

    public Codeword readCodeword() {
        int index;
        try {
            index = readIndex();
        } catch(IndexOutOfBoundsException e) {
            return null;
        }

        Character ch;
        try {
            ch = readChar();
        } catch(IndexOutOfBoundsException e) {
            ch = null;
        }

        return new Codeword(index, ch);
    }

    private int readIndex() throws IndexOutOfBoundsException {
        int remainingBits = compressed.length() * Character.SIZE - bitPos;
        if (indexSize > remainingBits || remainingBits == 0) {
            // End of the compressed string
            throw new IndexOutOfBoundsException();
        }

        int numBits = indexSize;
        int result = 0x00000000;
        while (numBits > 0) {
            // Get working char
            int chPos = bitPos / Character.SIZE;
            char ch = compressed.charAt(chPos);

            // Create mask for index bits
            int maskOffset = Character.SIZE * (chPos + 1) - bitPos - numBits;
            Bitmask mask = new Bitmask(numBits, maskOffset);

            // Number of bits remaining
            int numMaskedBits = mask.getSize();
            numBits -= numMaskedBits;
            bitPos += numMaskedBits;

            // Mask out the index bits and shift into place
            int maskedVal = mask.mask(ch);
            maskedVal = Bitwise.shiftRight(maskedVal, maskOffset);
            result = result | maskedVal;
        }
        return result;
    }

    private char readChar() throws IndexOutOfBoundsException {
        int remainingBits = compressed.length() * Character.SIZE - bitPos;
        if (Character.SIZE > remainingBits || remainingBits == 0) {
            // End of the compressed string
            throw new IndexOutOfBoundsException();
        }

        int numBits = Character.SIZE;
        char result = 0x0000;
        while (numBits > 0) {
            // Get working char
            int chPos = bitPos / Character.SIZE;
            char ch = compressed.charAt(chPos);

            // Create mask for index bits
            int maskOffset = Character.SIZE * (chPos + 1) - bitPos - numBits;
            Bitmask mask = new Bitmask(numBits, maskOffset);

            // Number of bits remaining
            int numMaskedBits = mask.getSize();
            numBits -= numMaskedBits;
            bitPos += numMaskedBits;

            // Mask out the index bits and shift into place
            char maskedVal = (char) mask.mask(ch);
            maskedVal = (char) Bitwise.shiftRight(maskedVal, maskOffset);
            result = (char) (result | maskedVal);
        }
        return result;
    }
}
