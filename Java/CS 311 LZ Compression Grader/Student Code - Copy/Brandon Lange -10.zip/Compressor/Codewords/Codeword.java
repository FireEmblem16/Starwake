package Compressor.Codewords;

public class Codeword {
    public final int parentIndex;
    public final Character data;

    public Codeword(int parentIndex, Character data) {
        this.parentIndex = parentIndex;
        this.data = data;
    }
}
