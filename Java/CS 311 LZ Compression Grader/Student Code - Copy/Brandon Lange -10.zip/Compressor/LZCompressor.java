package Compressor;

import Compressor.Codewords.Codewords;

public abstract class LZCompressor {
    public Codewords codewords;

    public LZCompressor(String uncompressed) {
        codewords = new Codewords();
    }

    public abstract String encode();
}
