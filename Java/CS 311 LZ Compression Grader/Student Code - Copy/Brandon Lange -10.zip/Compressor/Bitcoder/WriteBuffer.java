package Compressor.Bitcoder;

import java.nio.ByteOrder;

public class WriteBuffer {
    public static final char EMPTY_BUFFER = 0x00;

    private byte buffer1;
    private byte buffer2;
    private int bitIndex;

    public WriteBuffer() {
        reset();
    }

    public String add(int val, int numBits, ByteOrder endianness) {
        // Convert value to bytes
        byte[] bytes = Bitwise.intToBytes(val, endianness);
        int numBytes = (int) Math.ceil((1.0 * numBits) / Byte.SIZE);

        // Get the working position in the byte array
        String result = "";
        int start = (endianness.equals(ByteOrder.BIG_ENDIAN) ? bytes.length - numBytes : 0);
        int end = (endianness.equals(ByteOrder.BIG_ENDIAN) ? bytes.length : numBytes);

        // Add 'head' bits to buffer
        int headBits = numBits % Byte.SIZE;
        if (headBits != 0) {
            byte b = (byte) (bytes[start] << (Byte.SIZE - headBits));
            result += addToBuffer(b, headBits);
            start += 1;
        }

        // Add remaining bytes to buffer
        for (int i = start; i < end; i++) {
            result += addToBuffer(bytes[i], Byte.SIZE);
        }

        return result;
    }

    private String addToBuffer(byte b, int numBits) {
        String result = "";
        while (numBits > 0) {
            // Check working byte
            if (bitIndex < 8) {
                // Get position in byte
                int bufferIndex = bitIndex;
                int availableBits = Byte.SIZE - bufferIndex;

                // Mask data into place
                buffer1 = (byte) (buffer1 | (b >> bufferIndex));

                // Modify position data
                bitIndex = Math.min(bufferIndex + numBits, Byte.SIZE);
                numBits -= availableBits;
                b = (byte) (b << availableBits);

                if (numBits <= 0) {
                    break;
                }
            }

            if (bitIndex >= 8) {
                // Get position in byte
                int bufferIndex = bitIndex - Byte.SIZE;
                int availableBits = Byte.SIZE - bufferIndex;

                // Mask data into place
                buffer2 = (byte) (buffer2 | (b >> bufferIndex));

                // Modify position data
                bitIndex = bitIndex + numBits;
                if (bitIndex >= 2 * Byte.SIZE) {
                    result += toChar();
                    reset();
                }

                numBits -= availableBits;
                b = (byte) (b << availableBits);
            }
        }
        return result;
    }

    public boolean isEmpty() {
        return bitIndex == 0;
    }

    public char toChar() {
        return Bitwise.bytesToChar(buffer1, buffer2);
    }

    private void reset() {
        buffer1 = EMPTY_BUFFER;
        buffer2 = EMPTY_BUFFER;
        bitIndex = 0;
    }
}
