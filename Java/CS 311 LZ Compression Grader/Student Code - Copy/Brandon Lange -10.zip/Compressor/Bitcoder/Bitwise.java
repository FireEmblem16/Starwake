package Compressor.Bitcoder;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class Bitwise {
    public static int shiftLeft(int val, int shift) {
        return (shift > 0 ? val << shift : val >> (-1 * shift));
    }

    public static int shiftRight(int val, int shift) {
        return (shift > 0 ? val >> shift : val << (-1 * shift));
    }

    public static int charsToInt(char ch1, char ch2, ByteOrder endianness) {
        byte[] ch1bytes = charToBytes(ch1, endianness);
        byte[] ch2bytes = charToBytes(ch2, endianness);
        if (endianness.equals(ByteOrder.BIG_ENDIAN)) {
            return bytesToInt(ch1bytes[0], ch1bytes[1], ch2bytes[0], ch2bytes[1]);
        }
        return bytesToInt(ch2bytes[0], ch2bytes[1], ch1bytes[0], ch1bytes[1]);
    }

    public static byte[] intToBytes(int val, ByteOrder endianness) {
        ByteBuffer buffer = ByteBuffer.allocate(Integer.SIZE / Byte.SIZE);
        buffer.order(endianness);
        buffer.putInt(val);
        return buffer.array();
    }

    public static byte[] charToBytes(char val, ByteOrder endianness) {
        ByteBuffer buffer = ByteBuffer.allocate(Character.SIZE / Byte.SIZE);
        buffer.order(endianness);
        buffer.putChar(val);
        return buffer.array();
    }

    public static int bytesToInt(byte b1, byte b2, byte b3, byte b4) {
        return (b1 << (Byte.SIZE * 3)) | (b2 << (Byte.SIZE * 2)) | (b3 << Byte.SIZE) | b4;
    }

    public static char bytesToChar(byte b1, byte b2) {
        return (char) (((char) (b1 << Byte.SIZE) & 0xFF00) | ((char) b2 & 0x00FF));
    }
}
