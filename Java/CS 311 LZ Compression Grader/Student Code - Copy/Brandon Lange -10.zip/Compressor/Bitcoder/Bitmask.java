package Compressor.Bitcoder;

public class Bitmask {
    private int size;
    private int mask;

    public Bitmask(int size) {
        this(size, 0);
    }

    public Bitmask(int size, int offset) {
        if (size < 0 || size > Integer.SIZE) {
            throw new IllegalArgumentException("Size must be between 0 and " + Integer.SIZE);
        }

        if (offset < -size || offset > Integer.SIZE - size) {
            throw new IllegalArgumentException("Offset must be between " + -size + " and " + (Integer.SIZE - size) + " for size " + size);
        }

        this.size = size + (offset < 0 ? offset : 0);
        mask = (Integer.MAX_VALUE >> (Integer.SIZE - size - 1));
        mask = Bitwise.shiftLeft(mask, offset);
    }

    public int mask(int val) {
        return val & mask;
    }

    public int getSize() {
        return size;
    }
}
