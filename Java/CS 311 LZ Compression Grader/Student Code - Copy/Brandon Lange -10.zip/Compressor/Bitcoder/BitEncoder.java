package Compressor.Bitcoder;

import java.nio.ByteOrder;

public class BitEncoder {
    private WriteBuffer buffer;
    protected String bitstring;

    public BitEncoder() {
        buffer = new WriteBuffer();
        bitstring = "";
    }

    @Override
    public String toString() {
        return bitstring + (buffer.isEmpty() ? "" : buffer.toChar());
    }

    public void add(int val, Bitmask mask, ByteOrder endianness) {
        bitstring += buffer.add(mask.mask(val), mask.getSize(), endianness);
    }
}
