package Compressor.Trie;

import Compressor.Codewords.Codeword;
import Compressor.LZCompressor;

public class Trie extends LZCompressor {
    public TrieNode<Character> root;

    public Trie(String uncompressed) {
        super(uncompressed);
        root = new TrieNode<Character>(0, null);

        // Create tree
        TrieNode<Character> parent = root;
        for (char ch : uncompressed.toCharArray()) {
            TrieNode<Character> child = parent.getChildByData(ch);
            if (child != null) {
                parent = child;
                continue;
            }
            createNode(parent, ch);
            parent = root;
        }

        // Hanging node
        if (parent != root) {
            createNode(parent, null);
        }
    }

    public String encode() {
        return codewords.encode();
    }

    private void createNode(TrieNode<Character> parent, Character ch) {
        parent.addChild(codewords.size() + 1, ch);
        int parentIndex = parent.getIndex();
        codewords.add(new Codeword(parentIndex, ch));
    }
}
