package Compressor.Trie;

import java.util.ArrayList;

public class TrieNode <Type extends Comparable> {
    private int index;
    private Type data;
    private ArrayList<TrieNode> children;

    public TrieNode(int parentIndex, Type data) {
        this.index = parentIndex;
        this.data = data;
        children = new ArrayList<TrieNode>();
    }

    public Type getData() {
        return data;
    }

    public int getIndex() {
        return index;
    }

    public void addChild(int parentIndex, Type data) {
        children.add(new TrieNode<Type>(parentIndex, data));
    }

    protected TrieNode<Type> getChildByData(Type data) {
        for (TrieNode child : children) {
            if (child.getData().compareTo(data) == 0) {
                return child;
            }
        }
        return null;
    }
}
