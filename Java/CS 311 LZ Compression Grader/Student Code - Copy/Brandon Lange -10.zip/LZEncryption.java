import Compressor.Codewords.Codewords;
import Compressor.Trie.Trie;

/**
 * @author Branden Lange
 */
public class LZEncryption {
    public static String encode(String uncompressed) {
        return new Trie(uncompressed).encode();
    }

    public static String decode(String compressed) {
        return new Codewords(compressed).toString();
    }
}
