import Compressor.Codewords.Codeword;
import Compressor.Trie.Trie;
import Compressor.Utils;

public class LZTester {
    public static void main(String [] args) {
//        String testString = "";
//        String testString = "ab";
        String testString = "aabaaabaaaaaabababbbbaba";
//        String testString = "The world is full of sugar!";
//        String testString = "Sugar! Sugar! Sugar! Sugar! Sugar! Sugar!";
//        String testString = "Lorem ipsum dolor sit amet, has consul accusam consetetur at, forensibus definitionem eos ad, deleniti appellantur interpretaris ut has. Solet legimus inermis duo no, ea duo laudem denique mediocrem. Et vero oporteat ius, ex vel timeam delenit verterem, eu assum disputationi quo. Sit ei quod falli decore, at eros dicit nobis pro.\n\n" +
//             "Duo no epicuri detraxit. Nam et brute oratio signiferumque, incorrupte mediocritatem cum ea. Vis falli detraxit mediocritatem ei. Facer apeirian facilisi ne duo, ne has clita dicant inermis. Te modo inimicus suscipiantur vim, ea eos accumsan suavitate voluptaria.\n\n" +
//             "Quo ut bonorum partiendo. Ad ceteros explicari dissentias nam, vix partem graecis no. Ius ipsum conceptam ut, ad his laudem ullamcorper. Veri option consulatu his ut, et case clita recteque ius. Ei duo tritani commune reprehendunt, delenit dolorem postulant vel ea, vel nihil epicurei adipiscing in.\n\n" +
//             "Ornatus mentitum inciderint ut vis, ea eum iisque eruditi conceptam. Quodsi ornatus cu eum, an explicari delicatissimi vel, appetere perpetua pro cu. Impetus virtute civibus ne mei, has omnium fabulas in. Sit ea vitae cotidieque, no consul minimum dissentiunt mea, labitur veritus qualisque et ius. Natum similique adipiscing ex cum. Mea an eius epicuri reprimique, docendi efficiendi cum ne, sint reprimique nam ne. Cu accusam sententiae vis.\n\n" +
//             "Ius falli mnesarchum ex, adhuc pertinax eu nam, et iisque docendi vulputate eam. Wisi doming commodo vix eu, postea atomorum an his, est ad adhuc justo causae. Eirmod explicari ullamcorper vix eu. Tale clita qui te, liber evertitur an eam, decore definitiones quo ad. An elitr prodesset has, vel vide mucius elaboraret ei. Cu usu novum necessitatibus, te mel omnis recteque.";

        Trie trie = new Trie(testString);

        String encoded = trie.encode();
        System.out.println("'" + Utils.toBinary(encoded) + "'");
        System.out.println();

        for (Codeword cw : trie.codewords) {
            if (cw.data == null) {
                System.out.println(cw.parentIndex);
                continue;
            }
            System.out.println("" + cw.parentIndex + ", " + cw.data + " (" + (int) cw.data + ")");
        }
        System.out.println();

        String decoded = LZEncryption.decode(encoded);
        System.out.println("'" + decoded + "'");
        System.out.println();
    }
}
