import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

// cs311, hw#4, tmuhr
/* for turn in: test cases tripped out (and hopefully only test cases lol) */

public class LZEncryption {

		
	public static String encode(String uncompressed) {
		return encodeTrie(uncompressed);
	}
	
	public static String decode(String compressed) {
		return decodeTrie(compressed);
	}
	
	private static String encodeTrie(String uncompressed) {
		// masks copy-pasted from Don's email
		final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};

		Trie dict = new Trie();
		List<Integer> codewords = new ArrayList<Integer>();
		String letters = "";
		byte[] compressed;
		
		// build Trie
		String subStr = "";
		for (int i = 0; i < uncompressed.length(); i++) {
			subStr += uncompressed.charAt(i);
			if(!dict.contains(subStr)) {
				dict.addPhrase(subStr);
				codewords.add(dict.getCodewordForPhrase(subStr.substring(0, subStr.length() - 1)));
				letters += subStr.charAt(subStr.length() - 1);
				subStr = "";
			}
		}
		// add possible last codeword
		if (!subStr.equals(""))
			codewords.add(dict.getCodewordForPhrase(subStr));
		
		// number of bits need to represent the codewords
		int numBits = (int) Math.ceil(Math.log(dict.getMaxIndex())/Math.log(2));
		// handle case of empty string
		if (dict.getMaxIndex() == 0)
			numBits = 0;
		
		int bitsNeeded = 32 + (16 * letters.length()) + (codewords.size() * numBits);
		compressed = new byte[(int) Math.ceil(bitsNeeded / 16.0) * 2];
		
		// put the int at the start
		byte theInt[] = ByteBuffer.allocate(4).putInt(numBits).array();
		for (int i=0; i < 4; i++) {
			compressed[i] |= theInt[i];
		}
		
		int lastBitIndex = -1;
		for (int i = 0, bitIndex = 32; i < letters.length() && bitIndex < bitsNeeded; i++, lastBitIndex = bitIndex) {
			int currentCodeword = codewords.get(i);
			for (int j = 0; j < numBits; j++) {
				if ((currentCodeword & masks[(masks.length - numBits) + j]) > 0) {
					compressed[bitIndex/8] |= masks[8 + bitIndex%8];
				}
				bitIndex++;
			}
			char currentLetter = letters.charAt(i);
			for (int j = 0; j < 16; j++) {
				if ((currentLetter & masks[j]) > 0)
					compressed[bitIndex/8] |= masks[8 + bitIndex%8];
				bitIndex++;
			}
		}
		
		if (codewords.size() > letters.length()) {
			int currentCodeword = codewords.get(codewords.size() - 1);
			for (int j = 0; j < numBits; j++) {
				if ((currentCodeword & masks[(masks.length - numBits) + j]) > 0) {
					compressed[lastBitIndex/8] |= masks[8 + lastBitIndex%8];
				}
				lastBitIndex++;
			}
		}
		
		// work around for String constructor barfing on certain characters
		if (numBits > 8) {
			String ret = "";
			for (int i = 0; i < compressed.length; i++) {
				byte b = compressed[i];
				for (int j = 0; j < 8; j++) {
					if ((b & masks[8 + j]) == 0)
						ret += "0";
					else
						ret += "1";
				}
			}
			return FromBinary(ret);
		}
		
		try {
			return new String(compressed, "UTF-16");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return "ERROR";
	}
	
	private static String decodeTrie(String compressed) {
		// masks copy-pasted from Don's email
		final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		
		String uncompressed = "";
		Trie dict = new Trie();
		int numBits = 0;
		
		if (compressed.length() < 2)
			return "";
		
		numBits |= compressed.charAt(0);
		numBits <<= 16;
		numBits |= compressed.charAt(1);
		
		// now do codewords and letters
		int codeword = 0;
		char letter = 0x0000;
		for (int i = 2, counter = 0; i < compressed.length(); i++) {
			char c = compressed.charAt(i);
			// go through each bit
			for (int j = 0; j < 16; j++) {
				if ((masks[j] & c) > 0) {
					// OR in the bit
					if (counter < numBits) {
						codeword |= masks[(masks.length - numBits) + counter];
					}
					else {
						letter |= masks[counter - numBits];
					}
				}
				counter++;
				// reset the counter and clear the vars if necessary
				if (counter > numBits + 15) {
					String prefix = dict.getPhraseForCodeword(codeword);
					if (prefix != null) {
					uncompressed += prefix + letter;
					dict.addPhrase(prefix + letter);}
					counter = 0;
					codeword = 0x00000000;
					letter = 0x0000;
				} 
			}
		}
		// add on possible trailing codeword
		if (codeword > 0)
			uncompressed += dict.getPhraseForCodeword(codeword);
		
		return uncompressed;
	}
	
	// From Don's email
	public static String ToBinary(String str)
	{
		final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i++)
		{
			char c = str.charAt(i);
			
			for(int j = 0;j < 16;j++)
				if((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}
		
		return ret;
	}

	// From Don's email
	public static String FromBinary(String str)
	{
		final char[] bits = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i += 16)
		{
			char c = 0x0000;
			
			for(int j = 0;j < 16;j++)
				if(str.charAt(i + j) == '1')
					c |= bits[j];
			
			ret += c;
		}
		
		return ret;
	}

	public static class Trie {
		protected class TrieNode {
			int index;
			String letter;
			TrieNode parent;
			ArrayList<TrieNode> children = new ArrayList<TrieNode>();
			public int getIndex() {
				return index;
			}
			public void setIndex(int index) {
				this.index = index;
			}
			public String getLetter() {
				return letter;
			}
			public void setLetter(String letter) {
				this.letter = letter;
			}
			public TrieNode(String newLetter, int cw, TrieNode newParent) {index = cw; this.letter = newLetter; parent = newParent; }
			public void addChild(String str, int ind) {
				if (str.length() == 1) {
					for (TrieNode t : children) {
						if (t.getLetter().equals(str))
							return;
					}
					children.add(new TrieNode(str, ind, this));
				} else if (str.length() > 1) {
					for (TrieNode t : children) {
						if (t.getLetter().equals(Character.toString(str.charAt(0)))) {
							if (str.length() == 2)
								t.addChild(Character.toString(str.charAt(1)), ind);
							else
								t.addChild(str.substring(1, str.length()), ind);
							return;
						}
					}
				}
			}
			public TrieNode findChild(String str) {
				for (TrieNode t : children)
					if (t.getLetter().equals(str))
						return t;
				return null;
			}
			public TrieNode findChild(int ind) {
				if (this.index == ind) {
					return this;
				}
				TrieNode temp = null;
				for (TrieNode t : children) {
					temp = t.findChild(ind);
					if (temp != null)
						return temp;
				}
				return temp;
			}
			public String getString() {
				String ret = letter;
				if (parent != null)
					ret = parent.getString() + ret;
				
				return ret;
			}
		}
		
		int maxIndex = 0;
		TrieNode root = new TrieNode("", 0, null);
		
		public int getMaxIndex() {return maxIndex;};
		
		public void addPhrase(String phrase) {
			if (phrase.length() == 0)
				return;
			
			if (phrase.length() > 0)
				root.addChild(phrase, ++maxIndex);
		}
		
		public boolean contains(String phrase) {
			if (phrase.equals(""))
				return true;
			TrieNode t = root;
			for (int i = 0; i < phrase.length(); i++) {
				char c = phrase.charAt(i);
				t = t.findChild(Character.toString(c));
				if (t == null)
					return false;
			}
			return true; 
		}
		
		public int getCodewordForPhrase(String phrase) {
			TrieNode t = root;
			if (phrase.length() == 0)
				return 0;
			
			for (int i = 0; i < phrase.length(); i++) {
				char c = phrase.charAt(i);
				t = t.findChild(Character.toString(c));
				if (t == null)
					break;
			}
			return t.index;
		}
		
		public String getPhraseForCodeword(int cw) {
			if (cw < 1 || cw > maxIndex)
				return "";

			TrieNode t = root.findChild(cw);
			if (t != null) {
				return t.getString();
			}
			
			return null;
			
		}
	}	
}

