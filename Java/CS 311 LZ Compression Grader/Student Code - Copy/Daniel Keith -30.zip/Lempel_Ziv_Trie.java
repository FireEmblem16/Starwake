//Author: Daniel Keith - Com S 311 - Section 4

//README:
//This code is incomplete when compressing it has problems with indexing the correct number with the new char added to the Trie Tree which is sent to the output. 
//The problem happens due to node contain the same char sometimes share the same ID which causes the  index to assign incorrect values to the compression. 

//HOW TO:
//To change the string the code runs go the the Main method at the bottom of this program and change the input string to the new string
import static java.lang.System.out;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Lempel_Ziv_Trie {
	
	//global variables
	static TrieNode index[] = new TrieNode[200];//to store node address for encoding and decoding
	static int jj =0,t =0,node_val =0;
	static TrieNode seg_end;
	static TrieNode seg_end2;
	
	//used to create an empty TrieNode 
	static TrieNode create(){
		return(new TrieNode('\0'));
	}
	
	//inserts the segment in to the Trie tree
	static void insert(TrieNode start, String seg){
		
		TrieNode seg_end_tmp;
		int k = seg.length();
	
		//convert seg to a array of char better searching
		char[] chars = seg.toCharArray();
		TrieNode current_node = start;
		
		int offset = 97; // is the accii value of a
		for(int i =0; i< k; i++){
			if(chars[i] < 97 ){
				offset = 5;
			}
			else{
				offset = 97;
			}
			if(current_node.compressed[chars[i]-offset] == null){
				
				//assigning a char to the current node must be empty to happen
				current_node.compressed[chars[i]-offset] = new TrieNode(chars[i]);
				
				//assigns each node a integer for better reference
				index[jj] = current_node;
				jj++;
				
				
			}
			
			//holds last node address
			seg_end_tmp = current_node;
			
			
			//selecting the next node to test
			current_node = current_node.compressed[chars[i]-offset];
			
			//holds end segment if next node is going to be null
			if(current_node.compressed[chars[i]-offset] == null){
				seg_end = seg_end_tmp;
			}
			//find index number for last node address before a null
			if((current_node.compressed[chars[i]-offset] == null)){
				for(t = jj; t >0; t--){
					if(index[t] == seg_end){
						node_val = t;
						
					}
				}
			}
			
		}
		//assigned true once 
		current_node.isSegment = true;
	}
	
	static boolean match(TrieNode start, String segment){
		
		int offset = 97;
		int k = segment.length();
		//convert segment to a array of char better searching
		char[] chars = segment.toCharArray();
		TrieNode current = start;
		
		
		int i;
		//check to see if each element of the string segment exists in the Trie tree
		for(i=0; i<k; i++){
			if(chars[i] < 97 ){
				offset = 5;
			}
			else{
				offset = 97;
			}
				if(current.compressed[chars[i]-offset] == null){
					return false;
				}
				
				current = current.compressed[chars[i]-offset];
				
		}
		
		if(i == 1 && current == null){
			return false;
		}
			
		return true;
	}
	
	
	
	static String encode(String uncompressed){
		//create the initial 
		TrieNode library = create();
		
		//output of the system
		String output = " ";
		
		//initial look at string before compression
		System.out.println(uncompressed);
		
		//runs till the whole of uncompressed is processed
		int i =0;int j =0;
		while(i < uncompressed.length()){ // stops once array has been sorted
			
			boolean matched = false;
			String temp_s = "";
			char temp_c;
			
			//sets up compare of a single char
			temp_c = uncompressed.charAt(i);
			temp_s += temp_c;
			i++;
			
			//checks to see if segment currently exists in the tree
			matched = match(library,temp_s);
			if(matched == false){
				insert(library, temp_s);
				//need index store and add to output here**
				output += 0 + temp_s;
			}
			while((matched == true) && (i < uncompressed.length())){
				temp_c = uncompressed.charAt(i);
				temp_s += temp_c;
				matched = match(library,temp_s);
				if(matched == false){
					String str_temp = "";
					str_temp += temp_c;
					insert(library, temp_s);
					//need index store and add to output here**
					output += node_val + str_temp;
				}
				//used prevent out of bound errors
				if(i < uncompressed.length()){
					i++;
				}
				else if((i <= (uncompressed.length()))&& (matched == true)){
					insert(library, temp_s);
					//need to output to string here**
					output += node_val;
				}
			}
			System.out.println(output);
		}
		return output;
	}
	
		
	
	static String decode(String uncompressed){
		String input = uncompressed;
		
		 jj =0;t =0;node_val =0;
		 
		
		//create the initial 
		TrieNode library = create();
				
		//output of the system
		String output = " ";
				
		//initial look at string before compression
		System.out.println(uncompressed);
		
		int ii =0;
		char[] segments = new char[100];
		
		String[] lib = new String[255];// holds the combinations of chars
		System.out.println(uncompressed);
		int i =0;int j =1;int start =0;
		while(i < uncompressed.length()){ // stops once array has been sorted
			
			int result = 0; int equals_count =0;
			char temp_c;char num = 0;int k =0;char[] tmp_num = new char[30];
			String temp_s = "";
			
			//sets up compare of a single char
			if(start == 0){
				num = uncompressed.charAt(i);
				i++;
			}
			while(num != 48 && start == 0){
				num = uncompressed.charAt(i);
				i++;
				if(num == 48){
					i--;
					start = 1;
				}
			}
			
			num = uncompressed.charAt(i);
			tmp_num[k] = num;
			i++;
			temp_c = uncompressed.charAt(i);
			i++;
			
			int flag =0;
			while((temp_c <= 57 && temp_c >= 48) && i <= uncompressed.length() && flag == 0){
				k++;
				num = temp_c;
				tmp_num[k] = num;
				if(i == uncompressed.length()){
					flag =1;
				}
		
				if(i < uncompressed.length()){
					temp_c = uncompressed.charAt(i);
					i++;
				}
			}
			int jjj = chartoint(tmp_num);
			temp_s += temp_c;
			if((jjj == 0 && temp_s != null) && i < uncompressed.length()){
				lib[j] = temp_s;
				j++;
				output += temp_s;
			}
			else if((temp_s != null)&& i < uncompressed.length()){
				lib[j] = lib[jjj] + temp_s;
				j++;
				output += lib[jjj] + temp_s;
			}
			else{
				output += lib[jjj];
			
			}
			System.out.println(output);
			
		
	
		}
	return output;
	}
	static int chartoint(char[] val){
			int  i =0;
			int out =0;
			
			while(val[i] <= 57 && val[i] >=48){
				i++;
			}
			int j = 1;
			while(j <= i){
				
				if(j == 1){
					out = (val[i-j] - 48);
				}
				else{
					out += (val[i-j] -48)*(10*(j-1));
				}
				j++;
			}
		return out;
	}
	
	public static void main(String[] args){
		String input = "aaabbbaabbaaabbaabaaaaaaaaahello world how are you?";
		String output = encode(input);
		System.out.println(output);
		String decodeds = decode(output);
		}
	
	
}
class TrieNode{

	char seg;
	TrieNode[] compressed;
	boolean isSegment;

	public TrieNode(char seg){
		this.seg = seg;
		compressed = new TrieNode[256];
		this.isSegment = isSegment;
	}
}

