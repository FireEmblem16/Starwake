
import static java.lang.System.out;

public class LZ {
	
	public static void main(String[] args){
	String input = "aaabbbaabbaaabbaabaaaaaaaaahello world how are you?";
	String output = encode(input);
	System.out.println(output);
	String decoded = decode(output);
	System.out.println(decoded);
	}
	
	public static String encode(String uncompressed){
		String output = " ";
		String[] lib = new String[255];// holds the combinations of chars
		System.out.println(uncompressed);
		int i =0;int j =0;
		while(i < uncompressed.length()){ // stops once array has been sorted
			
			int result = 0; int equals_count =0;
			String temp_s = "";
			char temp_c;
			
			//sets up compare of a single char
			temp_c = uncompressed.charAt(i);
			temp_s += temp_c;
			i++;
			
			int jj = j;
			int temp_j = 0; int loop_flag = 0; String str_temp = "";int flag = 0;
			while((jj > 0) && (flag == 0)){ // loops through library of combination to find a close match or add to the library
				String lib_temp = "";
				
				//check current chars against the library
				lib_temp = lib[jj];
				result = temp_s.compareTo(lib_temp);
				
				
				//check to see how many library string match the current segment
				if(result == 0){
					equals_count++;
					temp_j = jj;
					//prevents overflow
					if(i < uncompressed.length()){
						temp_c = uncompressed.charAt(i);
						i++;
						loop_flag = 1;
					}
					else{
						flag = 1;
					}
					temp_s += temp_c;	
					jj = j + 1;
				}
				
				jj--;
			}
			 str_temp += temp_c;
			if(equals_count == 0 && loop_flag == 0){
				j++;
				lib[j] = temp_s;
				output += 0 + str_temp; //should add 0a or 0b for initial first use chars	
			}
			if((loop_flag == 1) && (flag == 0)){
				j++;
				lib[j] = temp_s;
				output += temp_j + str_temp; //should add ja or jb for initial first use chars	
			}
			if(flag == 1){
				output += temp_j; //should add ja or jb for initial first use chars	
			}
			System.out.println(output);
		}
		
		return output;
	}
	
	public static String decode(String uncompressed){
		String input = uncompressed;
		String output = "";
		String[] lib = new String[255];// holds the combinations of chars
		System.out.println(uncompressed);
		int i =0;int j =1;int start =0;
		
		//sorts throught the compressed string and uncompresses it
		while(i < uncompressed.length()){ // stops once array has been sorted
			
			int result = 0; int equals_count =0;
			char temp_c;char num = 0;int k =0;char[] tmp_num = new char[30];
			String temp_s = "";
			
			//sets up compare of a single char
			if(start == 0){
				num = uncompressed.charAt(i);
				i++;
			}
			while(num != 48 && start == 0){
				num = uncompressed.charAt(i);
				i++;
				if(num == 48){
					i--;
					start = 1;
				}
			}
			
			//gets index number of the string
			num = uncompressed.charAt(i);
			tmp_num[k] = num;
			i++;
			//gets the char paired with index number
			temp_c = uncompressed.charAt(i);
			i++;
			
			int flag =0;
			//if number is more than a single digit this loop places all number in a array to be convert later and fixes the char to a alphabet character
			while((temp_c <= 57 && temp_c >= 48) && i <= uncompressed.length() && flag == 0){
				k++;
				num = temp_c;
				tmp_num[k] = num;
				if(i == uncompressed.length()){
					flag =1;
				}
		
				if(i < uncompressed.length()){
					temp_c = uncompressed.charAt(i);
					i++;
				}
			}
			//convert char number array to a integer value
			int jj = chartoint(tmp_num);
			temp_s += temp_c;
			//fills the dictionary of values to decode and also adds to uncompressed output as dictionary is added to.
			if((jj == 0 && temp_s != null) && i < uncompressed.length()){
				lib[j] = temp_s;
				j++;
				output += temp_s;
			}
			else if((temp_s != null)&& i < uncompressed.length()){
				lib[j] = lib[jj] + temp_s;
				j++;
				output += lib[jj] + temp_s;
			}
			else{
				output += lib[jj];
			
			}
			System.out.println(output);
			
		
	
		}
	return output;
	}
	public static int chartoint(char[] val){
			int  i =0;
			int out =0;
			
			//find length of number
			while(val[i] <= 57 && val[i] >=48){
				i++;
			}
			int j = 1;
			//converts char number values to correct number values
			while(j <= i){
				
				if(j == 1){
					out = (val[i-j] - 48);
				}
				else{
					out += (val[i-j] -48)*(10*(j-1));
				}
				j++;
			}
		return out;
	}
}


