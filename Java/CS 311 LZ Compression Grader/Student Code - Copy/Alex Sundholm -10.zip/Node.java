import java.util.ArrayList;

/**
 * Node class used in LZ Encryption Algorithm.  Organized as a tree.
 * @author AlexSundholm
 *
 */
public class Node {
	
	
	private  Node parent = null;
	private  ArrayList<Node> children;
	private  int key;
	private  char value;
	private  int prefix;
	
	/**
	 * Basic Constructor.  Used for a head node.
	 */
	public Node()
	{
		children = new ArrayList<Node>();
		parent = null;
		key = 0;
	}
	
	/**
	 * Used to construct nodes that have determined parents
	 * @param node
	 */
	public Node(Node node)
	{
		parent = node;
		children = new ArrayList<Node>();
		prefix = parent.GetKey();
	
	}
	
	/**
	 * Returns an arraylist of the current node's children
	 * @return
	 */
	public ArrayList<Node> GetChildren()
	{
		return children;
	}
	
	/**
	 * printing method used in testing. displays a lot of info for the current node
	 */
	public void PrintInfo()
	{
		System.out.println("key " + key + "  value " + value);
		System.out.println("Parent " + parent.GetKey() + " " + parent.GetValue());
	}
	
	/**
	 * returns current node's parent node
	 * @return
	 */
	public Node GetParent()
	{
		return parent;
	}
	
	/**
	 * adds a child to the current node
	 * @param node
	 */
	public void AddChild(Node node)
	{
		children.add(node);
	}
	
	/**
	 * gets a child from a certain position in the arraylist
	 * @param kid
	 * @return
	 */
	public Node GetChild(int kid)
	{
		return children.get(kid);
	}
	
	/**
	 * sets the parent node of the current node
	 * @param node
	 */
	public void SetParent(Node node)
	{
		parent = node;
	}
	
	/**
	 * sets the key of the current node - use to determine prefixes
	 * @param inte
	 */
	public void SetKey(int inte)
	{
		key = inte;
	}
	
	/**
	 * returns the key of the current node
	 * @return
	 */
	public int GetKey()
	{
		return key;
	}

	/**
	 * returns the prefix of the current node
	 * @return
	 */
	public int GetPrefix()
	{
		return prefix;
	}
	
	/**
	 * sets the value of the current node
	 * @param string
	 */
	public void SetValue(char string)
	{
		value = string;	
	}
	
	/**
	 * returns the value of the current node
	 * @return
	 */
	public char GetValue()
	{
		return value;
	}
	
}
