import java.util.ArrayList;


/**
 * Lempel-Ziv Compression/Encryption Algorithm.  Includes encode and decode methods
 * 
 * 
 * @author AlexSundholm
 *
 */

public class LZEncryption {
	
	/**
	 * Constructor for a non-instantiable class - no code needed
	 */
	private LZEncryption() {
		//no code needed
	}

	
	/**
	 * Method used to encode a string using the Lempel-Ziv Compression Algorithm.  
	 * Accepts a single string as input and outputs an encoded binary string.
	 * 
	 * @param string
	 * @return
	 */
	public static String encode(String string) {
		//variables
		String result1 = "";
		String tempstr = "";
		Node head = new Node();
		Node temp = head;
		int x = 1;
		ArrayList<Integer> prefixes = new ArrayList<Integer>();
		ArrayList<Character> values = new ArrayList<Character>();
		
		// n=> number of bits needed
		int	n = (int) Math.ceil(Math.log(string.length() + 1)/Math.log(2));
		
		//adding values
		for(int i = 0; i < string.length(); i++)
		{
			//checks to see if the node is already a child
			if(CheckChildren(temp, string.charAt(i)) > (-1))
			{
				temp = temp.GetChild(CheckChildren(temp, string.charAt(i)));
			}
			else
			{
				//make child node
				Node node = new Node(temp);
				//add child to node
				temp.AddChild(node);
				//set node key
				node.SetKey(x);
				x++;
				//set node value
				node.SetValue(string.charAt(i));
				//if done, reset temp to head
				temp = head;
				//add values to arrays for processing
				prefixes.add(node.GetPrefix());
				values.add(node.GetValue());
			}
		}
		//process arrays to create binary string
		for(int i = 0; i < prefixes.size(); i++)
		{
			//gets the binary of the value in array prefixes
			tempstr = Integer.toBinaryString(prefixes.get(i));
			//adds 0's to string
			while(tempstr.length() < n) tempstr = "0" + tempstr;
			result1 = result1 + tempstr + "00000000" + AsciiToBinary(values.get(i));
		}
		//binary of number of bits per prefix
		String binary = Integer.toBinaryString(n);
		//add zeros to the front of the string
		while(binary.length() < 32) binary = "0" + binary;
		
		//append the first 4 bytes with the rest of the encoding
		result1 = binary + result1;
		//pad the end with 0's
		while(result1.length() % 16 != 0) result1 += "0";

		return result1;
	}
	
	
	/**
	 * Method used to decode a Lempel-Ziv encoded binary string.  Takes a single
	 * encoded string as input and returns the decoded string.  Note that this 
	 * method assumes the strings were formatted correctly
	 * 
	 * @param string
	 * @return
	 */
	public static String decode(String string)
	{
		//variables
		String str = "";
		String results = "";
		int keep = 0;
		ArrayList<Integer> prefixes = new ArrayList<Integer>();
		ArrayList<Character> values = new ArrayList<Character>();
		prefixes.add(-1);	//added to act as root node
		values.add(null);	//added to act as root node
		//first 32 bits of string
		String pres = string.substring(0, 32);
		//parse into a number
		int preint = Integer.parseInt(pres, 2);
		//tracker for string traversal
		int tracker = 32;
		
		while(tracker + preint + 16 < string.length())
		{
			//adds the prefix then increments tracker
			prefixes.add(Integer.parseInt(string.substring(tracker, tracker + preint), 2));
			tracker += preint;
			//adds the value then increments tracker
			values.add((char)Integer.parseInt(string.substring(tracker, tracker + 16), 2));
			tracker += 16;
		}
		//keep is a variable to hold the prefixes for traversal.  starts at first node - not the head
		keep = prefixes.get(1);
		
		for(int i = 1; i < prefixes.size(); i++)
		{
			//add value to str - temp variable
			str += values.get(i);
			//keep = prefix of node
			keep = prefixes.get(i);
			//head element has value -1 - signal to end
			while(prefixes.get(keep) != -1)
			{
				str = values.get(keep) + str;
				keep = prefixes.get(keep);
			}
			//append str to results
			results = results + str;
			//reset str
			str = "";
		}
		
		return results;
	}
	
	/**
	 * This is a helper method used to check whether or not a given
	 * node has a desired child or not.  Returns the index the child
	 * is stored in if true, else returns integer value -1
	 * @param node
	 * @param letter
	 * @return
	 */
	private static int CheckChildren(Node node, char letter)
	{
		ArrayList<Node> array = node.GetChildren();
		
		for(int i = 0; i < array.size(); i++)
		{
			if(array.get(i).GetValue() == letter) return i;
		}
		return -1;
	}

	
	/**
	 * Converts a char value into a binary string
	 * @param string
	 * @return
	 */
	public static String AsciiToBinary(char string){  
		String string1 = "" + string;
        byte[] bytes = string1.getBytes();  
        StringBuilder binary = new StringBuilder();  
        for (byte b : bytes)  
        {  
           int val = b;  
           for (int i = 0; i < 8; i++)  
           {  
              binary.append((val & 128) == 0 ? 0 : 1);  
              val <<= 1;  
           }   
        }  
        return binary.toString();  
  } 
}
