import java.util.ArrayList;

import javax.xml.bind.DatatypeConverter;

public class LZ {
	public static String encode(String toCompress)
	{
		LzDict dict = new LzDict();
		String ret = "";
		// for the entire string.
		for(int i=0; i < toCompress.length();) {
			// search from i until you find something not
			// in the Dictionary. Add to dictionary and output
			int lastIndex = 0;
			int j;
			for(j=i+1; j < toCompress.length() + 1; j++) {
				String parsedString = toCompress.substring(i, j);
				//System.out.println(parsedString);
				int index = dict.indexOf(parsedString);
				//System.out.println(index);
				if(index < 0) {
					// add to dictionary
					dict.insert(parsedString);
					
					// append output
					ret += (char)lastIndex;
					ret += parsedString.charAt(parsedString.length()-1);
					break;
				}
				else
					lastIndex = index;
			}
			i = j;
		}
		return ret;
	}
	
	public static String decode(String toDecode)
	{
		String ret = "";
		ArrayList<String> dict = new ArrayList<String>();
		dict.add("");
		
		for(int i=0; i < toDecode.length(); i+=2) {
			String entry = dict.get(toDecode.charAt(i)) + toDecode.charAt(i+1);
			dict.add(entry);
			ret += entry;
		}
		return ret;
	}
	
	public static void main(String[] args) {
		String compressed = LZ.encode("Do not meddle in the affairs of wizards, for they are subtle and quick to anger.");
		for(int i=0; i < compressed.length(); i++)
			System.out.println(compressed.substring(i,i+1));
		System.out.println(LZ.decode(compressed));
	}
}
