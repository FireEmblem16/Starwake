
public class BinaryStringTree {
	private class Node {
		Node left;
		Node right;
		String entry;
		int index;
	}
	
	Node root;
	int currentIndex;
	
	public BinaryStringTree()
	{
		root = null;
		currentIndex = 1;
	}
	
	private void rInsert(Node toInsert, Node currentNode)
	{
		int compareResult = toInsert.entry.compareTo(currentNode.entry); 
		if(compareResult < 0) {
			if(currentNode.left == null)
				currentNode.left = toInsert;
			else
				rInsert(toInsert, currentNode.left);
		}
		else if(compareResult > 0) {
			if(currentNode.right == null)
				currentNode.right = toInsert;
			else
				rInsert(toInsert, currentNode.right);
		}
	}
	
	private Boolean rHas(String key, Node currentNode)
	{
		if(currentNode == null)
			return false;
		
		int compareResult = key.compareTo(currentNode.entry); 
		if(compareResult < 0) {
			return rHas(key, currentNode.left);
		}
		else if(compareResult > 0) {
			return rHas(key, currentNode.right);
		}
		return true;
	}
	
	private int rGetIndex(String key, Node currentNode)
	{
		if(currentNode == null)
			return -1;
		
		int compareResult = key.compareTo(currentNode.entry); 
		if(compareResult < 0) {
			return rGetIndex(key, currentNode.left);
		}
		else if(compareResult > 0) {
			return rGetIndex(key, currentNode.right);
		}
		return currentNode.index;
	}
	
	public void insert(String entry)
	{
		Node insertion = new Node();
		insertion.entry = entry;
		insertion.left = null;
		insertion.right = null;
		insertion.index = currentIndex++;

		if(root == null)
			root = insertion;
		else
			rInsert(insertion, root);
	}
	
	public Boolean has(String key)
	{
		return rHas(key, root);
	}
	
	public int getIndex(String key)
	{
		return rGetIndex(key, root);
	}
}
