
public class LzDict {
	BinaryStringTree tree;
	
	public LzDict()
	{
		tree = new BinaryStringTree();
	}
	
	public void insert(String entry)
	{
		tree.insert(entry);
	}
	
	public int indexOf(String entry)
	{
		return tree.getIndex(entry);
	}
}
