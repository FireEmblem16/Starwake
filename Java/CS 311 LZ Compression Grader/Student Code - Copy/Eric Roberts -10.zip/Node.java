/**
 * @author Eric Roberts
 */
import java.util.ArrayList;

public class Node
{
	//The index of the node in the dictionary.
	private Integer index;
	//The symbol that this node represents in the Trie structure.
	private Character symbol;
	
	//The parent of the node.
	private Node parent;
	//The list of children of the node.
	private ArrayList<Node> children;
	
	/**
	 * Constructs a new node with a given index and character value.
	 * @param theIndex The index in the trie of the node.
	 * @param theCharacter The character that is reperesented by the node in the trie.
	 */
	public Node(Integer theIndex, Character theCharacter)
	{
		index = theIndex;
		symbol = theCharacter;
		parent = null;
		children = null;
	}
	
	/**
	 * Returns the index of the node.
	 * @return The index of the node.
	 */
	public Integer getIndex()
	{
		return index;
	}
	
	/**
	 * Returns the symbol that the node represents in the trie.
	 * @return The symbol the node represents.
	 */
	public Character getCharacter()
	{
		return symbol;
	}
	
	/**
	 * Returns the parent of the node.
	 * @return The parent of the node.
	 */
	public Node getParent()
	{
		return parent;
	}
	
	/**
	 * Sets the parent of the node.
	 * @param theParent The node to be set as the parent of the calling Node.
	 */
	public void setParent(Node theParent)
	{
		parent = theParent;
	}
	
	/**
	 * Adds a child to the calling Node.
	 * @param newChild The child to be added.
	 */
	public void addChild(Node newChild)
	{
		if(children == null)
		{
			children = new ArrayList<Node>();
		}
		newChild.setParent(this);
		children.add(newChild);
	}
	
	/**
	 * Returns whether or not the Node has a child with the specified symbol.
	 * @param symbol The symbol that is being looked for as a member of a child.
	 * @return True if calling Node has a child with the specified symbol, False otherwise.
	 */
	public boolean hasChild(Character symbol)
	{
		if(!this.hasChildren())
		{
			return false;
		}
		else
		{
			for(int i = 0; i < children.size(); i++)
			{
				if(children.get(i).getCharacter().equals(symbol))
				{
					return true;
				}
			}
		}
		
		return false;
	}
	
	/**
	 * Returns the child of the calling Node containing the specified symbol.
	 * @param symbol The symbol being looked for as a member of a child.
	 * @return The child Node containing the specified symbol, null if such a child does not exist.
	 */
	public Node getChild(Character symbol)
	{
		if(this.hasChildren())
		{
			Node currentChild;
			
			for(int i = 0; i < children.size(); i++)
			{
				currentChild = children.get(i);
				if(currentChild.getCharacter().equals(symbol))
				{
					return currentChild;
				}
			}
		}
		
		return null;
	}
	
	/**
	 * Returns whether or not the Node has any children.
	 * @return True if the calling Node has children, False otherwise.
	 */
	public boolean hasChildren()
	{
		return !(children == null);
	}
	
	/**
	 * Returns the phrase represented by the calling Node in the trie.
	 * @return The phrase represented by the calling Node in the trie.
	 */
	public String getPhrase()
	{
		String toReturn = "";
		Node currentNode = this;
		
		while(currentNode.getParent() != null)
		{
			toReturn = currentNode.getCharacter() + toReturn;
			currentNode = currentNode.getParent();
		}
		
		return toReturn;
	}
	
	public Node findNodeByIndex(Integer index)
	{
		Node toReturn = null;
		
		if(index.equals(this.index))
		{
			toReturn = this;
		}
		else if(this.hasChildren())
		{
			int i = 0;
			Node currentChildValue = null;
			
			while(currentChildValue == null && i < this.children.size())
			{
				currentChildValue = children.get(i).findNodeByIndex(index);
				i++;
			}
			toReturn = currentChildValue;
		}
		
		return toReturn;
	}
	
}