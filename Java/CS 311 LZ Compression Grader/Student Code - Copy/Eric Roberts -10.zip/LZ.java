import java.util.Scanner;
/*
 * author: Eric Roberts
 * 
 * 
 * References: The methods given on blackboard in the conversion.txt file have been included and used here.
 */
public class LZ
{
	
	private static TrieDictionary myDictionary = new TrieDictionary();
	
	/**
	 * Encodes a sequence of characters into codewords and then into a binary string with a number of bits that is a multiple of 16
	 * @param uncompressed The uncompressed string to encode and compress
	 * @return The encoded and compressed version of the input string
	 */
	public static String encode(String uncompressed)
	{
		String outputString = "";
		
		//The position of the beginning of the current scan
		int position = 0;
		//The offset from the position of the beginning of the current scan
		int offset = 1;
		//The current subphrase
		String subPhrase;
		//Scan input string until a previously unfound phrase is found
		
		//While the input string has not been completely scanned, continue scanning and running the LZ compression algorithm
		while(position + offset <= uncompressed.length())
		{
			int index;
			subPhrase = uncompressed.substring(position, position + offset).toString();
			String lastChar = "";
			while((position + offset <= uncompressed.length()) && myDictionary.containsValue(subPhrase))
			{
				subPhrase = uncompressed.substring(position, position + offset);
				
				if((position + offset <= uncompressed.length()) && myDictionary.containsValue(subPhrase))
				{
					offset++;
				}
			}
			
			//Add new phrase to dictionary
			//If the phrase is not in the dictionary, get the index of it's fullest prefix and the last character of the phrase. Build a codeword by concatenating these two and add the codeword to the output string.
			if(!myDictionary.containsValue(subPhrase))
			{
				myDictionary.put(myDictionary.size(), subPhrase);
				lastChar += subPhrase.charAt(subPhrase.length() - 1);
				
				if(subPhrase.length() > 1)
				{
					index = myDictionary.getIndex(subPhrase.substring(0, subPhrase.length() - 1));
				}
				else
				{
					index = myDictionary.getIndex("");
				}
			}
			//This accounts for the case that the last phrase is already in the dictionary, and only an index needs to be written as the last codeword
			else
			{
				index = myDictionary.getIndex(subPhrase);
			}
			
			//find index in dictionary of the fullest prefix of the new phrase
			//build a codeword of the form "index + lastChar" and add this codeword to the codeword sequence
			//outputString += "M";
			outputString += " ";
			outputString += index;
			outputString += " ";
			//if the last codeword is only an index
			if(!lastChar.equals(""))
			{
				//outputString += lastChar;
				outputString += forceNBits(Integer.toBinaryString(lastChar.charAt(0)), 16);
				outputString += " ";
			}
			
			
			position = position + offset;
			offset = 1;
		}
		
		
		
		
		
		outputString = binaryOutputFromCodewords(outputString);
		outputString = FromBinary(outputString);
		
		
		return outputString;
	}
	
	/**
	 * Takes in a string with a number of bits that is a multiple of 16, and uncompresses the string.
	 * @param compressed The compressed string to uncompress
	 * @return An uncompressed version of the input string.
	 */
	public static String decode(String compressed)
	{
		String outputString = "";
		//The string of 0s and 1s from the input
		String binaryInput = ToBinary(compressed);
		//the number of bits that represents each index
		int numBits = Integer.parseInt(binaryInput.substring(0, 32), 2);
		//The section of the input that is the phrases
		String phrases = binaryInput.substring(32);
		//The codeword sequence extracted from the binary string
		outputString = codeWordsFromBinary(phrases, numBits);
		
		
		myDictionary.clear();
		
		
		return outputString;
	}
	
	/**
	 * This method will take in a string of codewords and convert it to a string of "0"s and "1"s
	 * @param codewordSequence The sequence of code words
	 * @return A string of "0"s and "1"s that represent the given codeword sequence
	 */
	public static String binaryOutputFromCodewords(String codewordSequence)
	{
		String toReturn = "";
		int numBits = (int) Math.ceil(Math.log10((double)myDictionary.size())/Math.log10(2.0));
		
		toReturn += forceNBits(Integer.toBinaryString(numBits), 32);
		
		
		Scanner codeScanner = new Scanner(codewordSequence);
		
		while(codeScanner.hasNext())
		{
					toReturn += forceNBits(Integer.toBinaryString(codeScanner.nextInt()), numBits);
					
					if(codeScanner.hasNext())
					{
						toReturn += codeScanner.next();
					}
		}
		
		toReturn = pad16(toReturn);
		
		return toReturn;
	}
	
	
	/**
	 * Takes in a String of "0"s and "1"s and the number of bits that will represent an index
	 * @param binary The string of "0"s and "1"s
	 * @param numBits The number of bits that will represent and index.
	 * @return The sequence of codewords represented by the string of "0"s and "1"s.
	 */
	private static String codeWordsFromBinary(String binary, int numBits)
	{
		//The string to be built into the sequence of code words
		String outputString = "";
		//The string of "0"s and "1"s that is manipulated and codewords extracted from
		String source = binary;
		//The number of remaining bits in the binary string
		int remaining = source.length();
		
		
		//While there are at least enough bits left for there to be a "numBits" length index and a 16 bit character extracted,
		//Extract them.
		while(remaining >= numBits + 16)
		{
			String newPhrase = "";
			//Extract index
			String indexString = source.substring(0, numBits);
			int theIndex = Integer.valueOf(indexString, 2).intValue();
			//Redefine source without extracted index
			source = source.substring(numBits);
			//Extract character
			String charString = source.substring(0, 16);
			char theCharacter = (char) Integer.valueOf(charString, 2).intValue();
			//Redefine source without extracted character
			source = source.substring(16);
			//Redefine the remaining number of bits based on the newly redefined source string
			remaining = source.length();
			
			//Add the index and character to the codeWordString
			newPhrase += myDictionary.get(theIndex);
			newPhrase += theCharacter;
			
			myDictionary.put(myDictionary.size(), newPhrase);
			outputString += newPhrase;
		}
		
		//If at the end there are enough bits for an index, but not both an index and a character, only extract an index, add it to the codeWordString and finish
		if(remaining >= numBits && remaining < numBits + 16)
		{
			String newPhrase = "";
			int theIndex = Integer.valueOf(source.substring(0, numBits), 2);
			source = source.substring(numBits);
			remaining = source.length();
			
			newPhrase += myDictionary.get(theIndex);
			
			outputString += newPhrase;
		}		
		
		return outputString;
	}
	
	/**
	 * Forces a string of bits to be a given length of bits
	 * @param binary The string to force to numBits bits
	 * @param numBits The number of bits the input string will be truncated to
	 * @return The input string in the given number of bits
	 */
	private static String forceNBits(String binary, int numBits)
	{
		String toReturn = binary;
		
		if(binary.length() < numBits)
		{
			for(int i = 0; i < (numBits - binary.length()); i++)
			{
				toReturn = "0" + toReturn;
			}
		}
		
		return toReturn;
	}
	
	/**
	 * Pads the end of a string to a multiple of 16 bits
	 * @param toPad The string to be padded with zeroes
	 * @return The newly padded string with a number of bits which is a multiple of 16
	 */
	private static String pad16(String toPad)
	{
		String toReturn = toPad;
		int zerosToAdd = 16 - (toPad.length()%16);
		
		if(toPad.length()%16 != 0)
		{
			for(int i = 0; i < zerosToAdd; i++)
			{
				toReturn += "0";
			}
		}
		
		return toReturn;
	}
	
	/**
	 * This is from the conversion.txt file provided on blackboard.
	 * @param str The string of "0"s and "1"s to be converted into actual underlying binary
	 * @return The string whos underlying binary is matched by the input string of "0"s and "1"s
	 */
	public static String FromBinary(String str)
	{
		final char[] bits = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i += 16)
		{
			char c = 0x0000;
			
			for(int j = 0; j < 16; j++)
				if(str.charAt(i + j) == '1')
					c |= bits[j];
			
			ret += c;
		}
		
		return ret;
	}
	
	/**
	 * Takes in a String and converts the underlying binary into a string of "0"s and "1"s
	 * @param str The string to be converted to a string of "0"s and "1"s
	 * @return A string of "0"s and "1"s representing the underlying binary of the input string
	 */
	public static String ToBinary(String str)
	{
		final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i++)
		{
			char c = str.charAt(i);
			
			for(int j = 0;j < 16;j++)
				if((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}
		
		return ret;
	}
	
	public static void main(String[] args)
	{
		
		
		//Should output "0a0b1a2b1b3"
		String testString1 = "abaabbabaa";
		//Should output "0b0a1b2a1a5a3a3b"
		String testString2 = "babbaababaabbabbb";
		String testString3 = "Do not meddle in the affairs of wizards, for they are subtle and quick to anger.";
		
		
		
		String outputString1;
		String outputString2;
		String outputString3;
		
		
		
		String wizardOutPut = "0000000000000000000000000000011000000000000000010001000000000000000001101111000000000000000010000000000000000000011011100000100000000001110100000011000000000110110100000000000000011001010000000000000001100100001000000000000110110000011100000000001000000000000000000001101001000100000000000010000000000000000000011101000000000000000001101000001010000000000110000100000000000000011001100100000000000001100001001011000000000111001000000000000000011100110000110000000001101111010000000000000010000000000000000000011101110010110000000001111010000000000000000110000100000000000000011100100010000000000001110011000000000000000010110000001100000000011001100000100000000001110010000011000000000111010000111000000000011001010000000000000001111001000011000000000110000101100100000000011001010000110000000001110011000000000000000111010100000000000000011000100011010000000001101100001111000000000110111000100000000000001000000000000000000001110001100100000000000110100100000000000000011000110000000000000001101011011110000000000110111110000100000000011011100000000000000001100111000111000000000111001000000000000000001011100000000000";
		
		
		
		outputString1 = LZ.encode(testString1);
		outputString2 = LZ.encode(testString2);
		outputString3 = LZ.encode(testString3);
		

		System.out.println(outputString1);
		System.out.println(outputString2);
		System.out.println(outputString3);
		
		System.out.println(wizardOutPut);
		boolean please = outputString3.equals(wizardOutPut);
		System.out.println(please);
		
		
		System.out.println("outputString3: " + outputString3);
		System.out.println(LZ.decode(outputString1));
		System.out.println(LZ.decode(outputString2));
		String finalState = LZ.decode(outputString3);
		System.out.println("Final State: " + finalState);
	}
}