/**
 * @author Eric Roberts
 */
import java.util.Collection;
import java.util.Map;
import java.util.Set;

public class TrieDictionary implements Map<Integer, String>
{
	private Node rootNode;
	private int numNodes;
	
	public TrieDictionary()
	{
		rootNode = new Node(new Integer(0), null);
		numNodes = 1;
	}
	
	
	@Override
	public void clear()
	{
		rootNode = new Node(new Integer(0), null);
		numNodes = 1;
	}
	
	
	/**
	 * Returns whether or not the Trie contains a given index.
	 * @return True if 
	 */
	@Override
	public boolean containsKey(Object key)
	{
		boolean toReturn = false;
		Node nodeAtIndex = rootNode.findNodeByIndex((Integer) key);
		
		if(nodeAtIndex != null)
		{
			toReturn = true;
		}
		
		return toReturn;
	}
	
	/**
	 * Returns whether or not the Trie contains a given phrase.
	 * @return True if the Trie contains the given phrase, False otherwise.
	 */
	@Override
	public boolean containsValue(Object value)
	{

		
		boolean toReturn = false;
		String phrase = (String) value;
		char[] theChars = phrase.toCharArray();
		Node currentNode = rootNode;
		
		if(phrase.equals(""))
		{
			return true;
		}
		
		for(int i = 0; i < theChars.length; i++)
		{
			if(currentNode.hasChild(theChars[i]))
			{
				currentNode = currentNode.getChild(theChars[i]);
			}
			else
			{
				break;
			}
			
			if(i == theChars.length - 1)
			{
				toReturn = true;
			}
		}
		
		
		return toReturn;
	}
	
	/**
	 * Returns the index of the given phrase if it is in the Trie.
	 * @param phrase The phrase for which an index is requested
	 * @return The index of the given phrase. Null if the phrase is not in the Trie.
	 */
	public Integer getIndex(String phrase)
	{
		Integer toReturn = null;
		char[] theChars = phrase.toCharArray();
		Node currentNode = rootNode;
		
		if(phrase.equals(""))
		{
			return new Integer(0);
		}
		
		for(int i = 0; i < theChars.length; i++)
		{
			if(currentNode.hasChild(theChars[i]))
			{
				currentNode = currentNode.getChild(theChars[i]);
			}
			else
			{
				break;
			}
			
			if((i == theChars.length - 1) && currentNode.getCharacter() == theChars[theChars.length - 1])
			{
				toReturn = currentNode.getIndex();
			}
		}
		
		
		return toReturn;
	}
	
	
	@Override
	public String get(Object key)
	{
		String toReturn = null;
		Node nodeAtIndex = rootNode.findNodeByIndex((Integer) key);
		
		if(nodeAtIndex != null)
		{
			toReturn = nodeAtIndex.getPhrase();
		}
		
		return toReturn;
	}
	
	/**
	 * Returns whether or not the Trie contains only the empty string root node.
	 * @return True if the only Node is the emtyString root Node, false otherwise.
	 */
	@Override
	public boolean isEmpty()
	{
		return (numNodes == 1);
	}
	
	/**
	 * Returns the number of phrases in the Trie. (Number of Nodes)
	 * @return The number of phrases in the Trie. (Number of Nodes)
	 */
	@Override
	public int size()
	{
		return numNodes;
	}
	
	/**
	 * Traverses the Trie and adds a node to add the string if necessary
	 */
	@Override
	public String put(Integer key, String value)
	{
		char[] characters = value.toCharArray();
		
		Node currentNode = rootNode;
		
		for(int i = 0; i < characters.length - 1; i++)
		{
			currentNode = currentNode.getChild(characters[i]);
		}
		
		currentNode.addChild(new Node(key, new Character(characters[characters.length - 1])));
		
		numNodes++;
		
		return null;
	}
	
	
	@Override
	public void putAll(Map<? extends Integer, ? extends String> m) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public Set<java.util.Map.Entry<Integer, String>> entrySet() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String remove(Object key) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	@Override
	public Collection<String> values() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public Set<Integer> keySet()
	{
		return null;
	}
}
