import java.util.BitSet;
import java.lang.NumberFormatException;
import java.lang.StringIndexOutOfBoundsException;
/*
 * @author Andrew Smith
 * A class implementing the LZ78 version of Lempel-Ziv string compression.
 */
public class LZ {
	/*
	 * LZ is non-instantiable
	 */
	private LZ()
	{
		//empty
	}

	/*
	 * Given an input string, will produce the compressed version of that string.
	 * @param uncompressed The uncompressed string to be encoded with LZ78.
	 * @returns A bitstring which is the compressed version of the supplied uncompressed string.
	 */
	public static String encode(String uncompressed)
	{
		Trie trie = new Trie();
		TrieNode current = trie.root();
		
		int trieSize = 1; //trieSize is used to keep track of the number of elements in the trie
		
		int uclen = uncompressed.length();
		int ucpos = 0;
		int phraseLength = 1;

		/* First pass: We build the trie by extending the phrase under consideration one character at a time
		 and seeing if that phrase is represented by a path from the root.  If not, we add the final character
		 to the path we are currently following and return to the root, resetting the phrase */
		while(ucpos + phraseLength <= uclen)
		{
			String phrase = uncompressed.substring(ucpos,ucpos + phraseLength);
			if(current.childAt((int) phrase.charAt(phraseLength - 1)) != null)
			{
				current = current.childAt((int) phrase.charAt(phraseLength - 1));
				phraseLength++;
			} else {
				trie.add(current, Character.toString(phrase.charAt(phraseLength - 1)));
				current = trie.root();
				trieSize++;
				ucpos = ucpos + phraseLength;
				phraseLength = 1;

			}
		}

		/* log_2(n+1) where n is the number of items in the trie will tell us how many bits each index takes */
		
		int maxBits = (int) Math.ceil(Math.log(trieSize + 1)/Math.log(2)); // for whatever reason, the Math class doesn't have a pre-built log2 method
		
		
		LZBitString bits = new LZBitString(maxBits); //LZBitString is a class representing a bitstring (surprise surprise).
		/* At this point, our bitstring is a 32-bit representation of the number of bits in each index (i.e., maxbits)

		/* We will always want to have the compressed string start with the index of the empty set (i.e., 0) plus the first character of the string (if any) */
		
		bits.append(numToBinString(0, maxBits));
		
		


		/* Second walk down the trie.  This time, we grow each phrase, finding the codeword by following the path
		down from root as far as we can, then writing the index of the parent node followed by the value at the
		current node. */
		trie = new Trie();
		current = trie.root();

		/* We treat the first character of uncompressed specially in case our input is the empty string */
		try {
			bits.append(numToBinString(uncompressed.charAt(0), 16));
		} catch (StringIndexOutOfBoundsException e)
		{
			return bits.toString(); //There's no character at position 0 iff uncompressed is empty
		}
		
		ucpos = 1; //We already wrote the first character
		trie.add(current, Character.toString(uncompressed.charAt(0))); //but we didn't add it to the trie
		
		phraseLength = 1;

		
		
		while(ucpos + phraseLength <= uclen)
		{
			String phrase = uncompressed.substring(ucpos, ucpos + phraseLength);
			int childNum = (int) phrase.charAt(phraseLength - 1);

			if(current.childAt (childNum) != null)
			{
				current = current.childAt(childNum);
				
				phraseLength++;
				

			} else {
				trie.add(current, Character.toString(phrase.charAt(phraseLength - 1)));

				int indexToAppend = current.index();
				bits.append(numToBinString(indexToAppend, maxBits));
				char charToAppend = phrase.charAt(phraseLength - 1);
				int numToAppend = (int) charToAppend;
				bits.append(numToBinString(numToAppend, 16));
				current = trie.root();
				ucpos = ucpos + phraseLength;
				phraseLength = 1;
			}
		}

		if(current != trie.root())
		{
			bits.append(numToBinString(current.index(), maxBits));
		} //This happened if the final phrase already existed in the trie; if that's the case we only need to append the index of the final phrase
		
		String result = bits.toString();

		return result;
	}

	/*
	 * Given a properly compressed input string, will produce the original uncompressed version of the string.
	 * @param compressed a string which has been properly compressed using this version of LZ78.
	 * @returns the original, uncompressed version of the supplied string.
	 */
	public static String decode(String compressed)
	{
		//We're going to turn compressed into a string consisting of 0s and 1s
		byte[] cBytes = compressed.getBytes();
		StringBuilder compBuilder = new StringBuilder();
		for(int i = 0; i < cBytes.length; i++)
		{
			
			if(cBytes[i] < 0)
			{
				//Must compute 2's complement of that byte
				cBytes[i] = (byte) ~(((128 + cBytes[i]) - 1));
				
			}
			compBuilder.append(numToBinString((int)cBytes[i], 8));
		}

		String comp = compBuilder.toString();

		// Now we determine how many bits are in the indices and start rebuilding the trie.

		int numBits = Integer.parseInt(comp.substring(0,32), 2);

		Trie trie = new Trie();
		TrieNode current = trie.root();
		StringBuilder result = new StringBuilder();
		int strpos = 32;
		int strlen = comp.length();

		while(strpos < strlen)
		{
			if(strpos + numBits <= strlen)
			{
				String indexString = comp.substring(strpos, strpos + numBits);
				strpos += numBits;
				int nodeIndex = Integer.parseInt(indexString,2);
				current = trie.nodeAtIndex(nodeIndex);
				StringBuilder walkBuilder = new StringBuilder();
				while(current != trie.root())
				{
					walkBuilder.append(current.value());
					current = current.parent();
				}
				walkBuilder.reverse();
				result.append(walkBuilder.toString());

				if(strpos + 16 <= strlen)
				{
					String characterToAppend = Character.toString((char)Integer.parseInt(comp.substring(strpos, strpos + 16),2));
					result.append(characterToAppend);
					trie.add(current, characterToAppend);
					strpos+=16;
				}
			}

			
		}

		return result.toString(); //TODO
	}

	/*
	 * Given a length value and an integer <code>i</code> less than that value, will return a binary string representing <code>i</code> in that many bits.
	 * @param i the positive integer to be represented in binary
	 * @param maxIndex the largest value that a call to this function will need to represent, necessary for determining the number of bits to use
	 * @returns a bitstring representing <code>i</code> in as few bits as possible
	 */
	private static String numToBinString(int i, int maxLength)
	{
		//Careful, there's no error checking here;
		//close deadlines make for sloppy programmers.

		String tail = Integer.toBinaryString(i);
		int headlength = maxLength - tail.length();
		if(headlength <= 0)
		{
			return tail;
		}
		char[] head = new char[headlength];

		for(int j = 0; j < headlength; j++)
		{
			head[j] = '0';
		}
		return (new String(head) + tail);
	}

	
	
	
	
}