import java.util.HashMap;

/**
 * @author Andrew Smith
 * A class to model the nodes of the trie specified in the <code>Trie</code> class.  Supports the minimum necessary operations to implement Lempel-Ziv compression.
 */
public class TrieNode {

	/*
	 * The index of the node.
	 */
	private int index;

	/*
	 * The character this node represents, as a 1-character string.
	 */
	private String value;
	
	/*
	 * The parent node of this node.
	 */
	private TrieNode parent;
	
	/*
	 * The children of this node.
	 */
	private HashMap<Integer,TrieNode> children;
	

	/*
	 * Constructs a new node with the specified index and parent.
	 * @param index the index of the node.
	 * @param parent the parent of the node.
	 */
	public TrieNode(int index, TrieNode parent, String value)
	{
		this.index = index;
		this.parent = parent;
		this.value = value;
		children = new HashMap<Integer,TrieNode>(65536);
	}

	/*
	 * Returns the index of this node.
	 * @returns the index of this node in the trie.
	 */
	public int index()
	{
		return index;
	}

	/*
	 * Returns the parent node of this node.
	 * @returns the unique parent node of this node.
	 */
	public TrieNode parent()
	{
		return parent;
	}

	/*
	 * Adds a child to this trie at the specified index.
	 * @param indexOfChild the index at which to add this child (i.e., a value from 0-255 representing the character for the child).
	 * @param nodeIndex the node index of the child to be added.
	 */
	public void addChild(int indexOfChild, int nodeIndex, String value)
	{
		TrieNode child = new TrieNode(nodeIndex, this, value);
		children.put(indexOfChild, child);

	}

	/*
	 * Returns the child at the specified index.
	 * @param i the index of the child to return
	 * @returns the child at the specified index
	 */
	public TrieNode childAt(int i)
	{
		return children.get(i);
	}

	public String value()
	{
		return this.value;
	}

	protected TrieNode nodeAtIndexRec(int index)
	{
		if(this.index==index) return this;

		for(TrieNode c : children.values())
		{
			return c.nodeAtIndexRec(index);
		}

		return null;
	}
}