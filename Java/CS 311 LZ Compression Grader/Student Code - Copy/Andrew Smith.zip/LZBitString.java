import java.util.BitSet;
import java.lang.NumberFormatException;

/*
 * @author Drew Smith
 * Represents a bitstring with methods useful for implementing Lempel-Ziv.  The underlying structure is a BitSet, which is a vector of bits which grows as needed.  As the BitSet class
 * does not have a size method that accounts for trailing zeros, LZBitString stores the length including trailing zeros. */
public class LZBitString {

	/* The length of the bitstring, including trailing zeros. */
	private int length;
	
	/* The underlying BitSet */
	private BitSet mySet;
	
	/* Public constructor which initializes a bitstring to be initially of size 32, where these 32 bits represent the specified positive integer.
	 * @param first32 the positive integer that the first 32 bits of the bitstring should represent
	 * @returns A newly constructed bitstring.
	 */
	public LZBitString(int first32)
	{
		
		length = 32;
		String first32string = Integer.toString(first32, 2); //guaranteed to be positive so no worries
		mySet = new BitSet(32);
		for(int i =0; i < first32string.length(); i++)
		{
			if(first32string.charAt(i) == '1')
			{
				mySet.set(32 - first32string.length() + i);
			}
		}
	}



	public void append(String s)
	{
		for (int i = 0; i < s.length(); i++)
		{
			if(s.charAt(i) == '1')
			{
				mySet.set(this.length + i);
			}
		}
		this.length += s.length();
	}

	public String toString()
	{
		//Pad out to a multiple of 16
		int residue = this.length % 16;
		for(int i = 0; i < (16 - residue); i++)
		{
			append("0");
		}

		
		int numBytes = this.length / 8;
		
		StringBuilder builder = new StringBuilder();
		//fill the builder with 0s
		for(int i = 0; i < this.length; i++)
		{
			builder.append('0');
		}

		for(int i = mySet.nextSetBit(0); i>=0; i = mySet.nextSetBit(i+1))
		{
			builder.setCharAt(i,'1');
		}

		// after this all appropriate bits have been set to 1

		//Now allocate a byte array
		byte[] stringBytes = new byte[numBytes];

		//Go through our string, 8 at a time, and parse bytes from it
		for(int i = 0; i < numBytes; i++)
		{
			String ithByteString = builder.substring(i*8, 8*(i+1));
			try {
				stringBytes[i] = Byte.parseByte(ithByteString, 2);
			} catch (NumberFormatException e)
			{
				stringBytes[i] = (byte)  (Integer.parseInt(ithByteString, 2) - 128);
				/* This isn't right, I know.  In fact, it produces the correct 7 trailing bits, but while there should be a 1 in the first place there's a 0.
				 * If I can't figure it out in the next 40 minutes, it stays like this and I throw myself on the grader's mercy.  The commented code below OUGHT to work,
				 * but damned if it doesn't make my output 4/3 the size it should be.
				 */

				// stringBytes[i] = (byte)(Integer.parseInt(ithByteString, 2) - 128);
				// stringBytes[i] |= (byte)0x80;
			}


		}

		String result = new String(stringBytes);
		return result;


	}

	public BitSet getBitSet()
	{
		return mySet;
	}

	public String toReadableString() {
		//Pad out to a multiple of 16
		int residue = this.length % 16;
		for(int i = 0; i < (16 - residue); i++)
		{
			append("0");
		}

		
		int numBytes = this.length / 8;
		
		StringBuilder builder = new StringBuilder();
		//fill the builder with 0s
		for(int i = 0; i < this.length; i++)
		{
			builder.append('0');
		}

		

		for(int i = mySet.nextSetBit(0); i>=0; i = mySet.nextSetBit(i+1))
		{
			builder.setCharAt(i,'1');
		}

		String result = builder.toString();
		return result;
	

	}

	

}