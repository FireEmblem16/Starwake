/**
 * @author Andrew Smith
 * This class represents a trie, with only the minimum operations needed to implement Lempel-Ziv compression.  The trie is 256-ary (each node may have up to 256 children).  We do this so that the path from the root to any given node will uniquely represent a string (using 8-bit characters).
 */

public class Trie {
	
	/*
	 * The index of the next node to be added.
	 */
	private int index;
	
	/*
	 * The root node of the trie.
	 */
	private TrieNode root;

	/*
	 * Constructs a trie with the node representing the empty string as the root.  For our purposes, the empty-string node will always be root.
	 */
	public Trie()
	{
		index = 0;
		root = new TrieNode(index, null, "");
		index++;
	}
	/*
	 * Adds a node to the trie as a child of the specified node.  The new node has value <code>value</code>.  Note that if <code>value</code> has multiple characters, only the first is considered.
	 * @param addTo the node which will be the parent of the new node.
	 * @param value the value of the newly-added node.
	 */
	public void add(TrieNode addTo, String value)
	{
		char c = value.charAt(0); 
		int indexOfChild = (int) c;
		addTo.addChild(indexOfChild, this.index, value);
		this.index++;
	}

	/*
	 * Gives the root of this trie.
	 * @returns the root node of the trie.
	 */
	public TrieNode root()
	{
		return this.root;
	}

	public TrieNode nodeAtIndex(int index)
	{
		if(index == 0) return this.root;
		else
		{
			return root.nodeAtIndexRec(index);
			
		}
	}

	
}