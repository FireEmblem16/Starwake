
import java.util.ArrayList;

/**
 * 
 * @author pbenzoni
 * Implements A a single node in a trie
 * based on http://exceptional-code.blogspot.com/2011/07/coding-up-trie-prefix-tree.html
 */
public class TrieNode {
	char letter;
	int nodeIndex;
	int parentIndex;
	ArrayList<TrieNode> children;
	
	TrieNode(char inLetter, int nodeIndex, int parentIndex){
		this.letter = inLetter;
		children = new ArrayList<TrieNode>();
		this.nodeIndex = nodeIndex;
		this.parentIndex = parentIndex;
	}
	
	//sets a node as parent to the given NewChild
	public void setChild(TrieNode newChild){
		children.add(newChild);
	}
	
	//If there is a child with value x, return it!
	public TrieNode getChild(char childValue){
		TrieNode childToReturn = null;
		for (int i = 0; i < children.size(); i++) {
		    if(children.get(i).getValue() == childValue){
		        childToReturn = children.get(i);
		    }
		}
		return childToReturn;
	}
	
	//checks the children array to see if this child exists
	public boolean checkForChild(char valueToInsert){
		boolean childFound = false;
		for (int i = 0; i < children.size(); i++) {
		    if(children.get(i).getValue() == valueToInsert){
		        childFound = true;
		    }
		}
		return childFound;
	}
	
	//return current node's index
	public int getNodeIndex(){
		return nodeIndex;
	}
	
	//return current node's parent's index
	public int getParentIndex(){
		return parentIndex;
	}
	
	//return the character held at current node
	public char getValue(){
		return letter;
	}
	
}
