import java.lang.Math;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.soap.Node;

public class Trie {
	static private int trieSize;//start at 1 b/c null is always going to be first character
	static ArrayList<TrieNode> trieNodeList = new ArrayList<TrieNode>();
	static TrieNode trueRoot;
	static String originalString;
	static int tailPath;
	static int prefixLength;
	
	Trie(){
		trueRoot = new TrieNode('\0', 0, 0);
		trieNodeList.add(trueRoot);
		prefixLength = 0; 
		trieSize = 1;
	}
	
	
	/*
	 * Inserts a string into the trie.
	 */
	static void insertStringIntoTrie(TrieNode root, String str, int previousIndex){
		
		originalString = str;
		
		char[] charArr = str.toCharArray();
		
		TrieNode currentNode = root;
		
		//iterates through the string, adding nodes as needed to create a Trie
		for(int i = 0; i < str.length(); i++){
			//if a node already exists for this letter, move down a level
			if(currentNode.checkForChild(charArr[i]) == true){
				currentNode = currentNode.getChild(charArr[i]);
				if(i==charArr.length-1)
					tailPath = currentNode.getNodeIndex();
					
			}
			//If no node exists for this letter, add a leaf for it
			else
			{
				TrieNode newTrieLeaf = new TrieNode(charArr[i], trieSize++, currentNode.getNodeIndex());
				currentNode.setChild(newTrieLeaf);
				trieNodeList.add(newTrieLeaf);
				System.out.println("Inserted " + currentNode.getChild(charArr[i]).getValue() + 
						" at index " + currentNode.getChild(charArr[i]).getNodeIndex() + 
						" with parent " + currentNode.getChild(charArr[i]).getParentIndex());
				currentNode = trueRoot;
				
			}
			
		}
		System.out.println("Encoding Complete!");
		
	}
	
	//return the overall root of the tree
	public TrieNode getRootNode(){
		return trueRoot;
	}
	//return the string from whence this trie originated
	public String getOriginalString(){
		return originalString;
	}
	//Calculate and return Prefix Length
	public int getSetPrefixLength(){
		prefixLength = Integer.SIZE-Integer.numberOfLeadingZeros(trieSize);
		return prefixLength;
	}
	//return Prefix Length
	public int getPrefixLength(){
		return prefixLength;
	}
	//set Prefix Length - used for from compressed strings
	public void setPrefixLength(int PL){
		prefixLength = PL;
	}
	//a simple string output - something like 0a1b1a2a3a3b4b0b8b4
	public String toStringSimple(){
		StringBuilder compString = new StringBuilder();
		//print out basic compressed string, start at 1 b/c null isn't needed
		for(int i = 1; i<trieNodeList.size(); i++)
		{
			compString.append(trieNodeList.get(i).getParentIndex());
			compString.append(trieNodeList.get(i).getValue());
		}
		compString.append(tailPath);
		return compString.toString();
	}
	
	//Creates a binary representation of a given trie
	public String toStringComplex(){
		int prefixLength = getSetPrefixLength();
		StringBuilder binString = new StringBuilder();
		//Difference between length of prefix needed and actual; prefix int
		int bitDifference = 0;
		
		//append size of codeword (4 bytes - prefixLength) + prefixlength's leading zeros in bin rep + prefix in bin
		if(trieSize==1)
			binString = appendLeadingZeros(binString, 32); 
		else{
			bitDifference = 32 - Integer.toBinaryString(prefixLength).length();
			binString = appendLeadingZeros(binString, bitDifference); //size of codeword - 
			binString.append(Integer.toBinaryString(prefixLength));
		}

		
		//For each item, first append the leading zeros, then prefix, then character
		for(int i = 1 ; i < trieNodeList.size(); i++)
		{
			bitDifference=0;
			String binPrefix = Integer.toBinaryString(trieNodeList.get(i).getParentIndex());
			String binChar = Integer.toBinaryString((int)trieNodeList.get(i).getValue());
			bitDifference = prefixLength - binPrefix.length();
			
			//appends leading zeros
			binString = appendLeadingZeros(binString, bitDifference);
			
			//appends prefix
			binString.append(binPrefix);
			
			//appends character and it's leading zeros
			bitDifference = Character.SIZE - binChar.length();
			binString = appendLeadingZeros(binString, bitDifference);
			binString.append(binChar);
		}
		
		//Add leading zeros, then add the tail
		bitDifference = prefixLength - Integer.toBinaryString(tailPath).length();
		binString = appendLeadingZeros(binString, bitDifference);
		binString.append(Integer.toBinaryString(tailPath));
		
		//calculate and append ending zeros, when needed
		if(binString.toString().length() % 16 != 0){
			bitDifference = 16 - binString.toString().length() % 16;
			binString = appendLeadingZeros(binString, bitDifference);
		}
		
		System.out.println(binString.toString());
		return FromBinary(binString.toString());
		
	}
	
	//Adds as many leading zeros as requested via stringbuilder
	public StringBuilder appendLeadingZeros(StringBuilder SB, int numberToAppend){
		for(int i = 0; i<numberToAppend; i++){
			SB.append('0');
		}
		return SB;
	}
	
	
	//Courtesy of Donald Nye, for Bin <-> BinStr conversion
	public static String ToBinary(String str)
	{
		final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i++)
		{
			char c = str.charAt(i);
			
			for(int j = 0;j < 16;j++)
				if((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}
		
		return ret;
	}	
	
	//courtesy of Donald Nye, for Bin <-> BinStr conversion
	public static String FromBinary(String str)
	{
		final char[] bits = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0; i < str.length();i += 16)
		{
			char c = 0x0000;
			
			for(int j = 0;j < 16;j++)
				if(str.charAt(i + j) == '1')
					c |= bits[j];
			
			ret += c;
		}
		
		return ret;
	}

	//Builds a tree from a list of prefixes and values
	public void buildTrie(ArrayList<Integer> prefixList, ArrayList<Character> valueList) {
		
		StringBuilder originalBuilder = new StringBuilder();
		
		Iterator<Integer> pIter = prefixList.iterator();
		Iterator<Character> vIter = valueList.iterator();
		//builds the tree from prefixes and values
		while(vIter.hasNext()){
			char value = vIter.next();
			int parent = pIter.next();
			
			TrieNode newTrieNode = new TrieNode(value, trieSize, parent);
			trieNodeList.add(newTrieNode);
			trieSize++;
			
			//append phrase to full string
			originalBuilder.append(traverseToRoot(newTrieNode));
			
		}
		
		//sets the suffix to the last "prefix"
		if(pIter.hasNext()){
			tailPath = pIter.next();
			originalBuilder.append(traverseToRoot(trieNodeList.get(tailPath)));
		}
		originalString = originalBuilder.toString();
		
	}

	//traverses from a node to the overall root of a tree, returning values encountered
	private String traverseToRoot(TrieNode currentNode) {
		
		StringBuilder phraseBuilder = new StringBuilder();
		
		while(currentNode.getNodeIndex() != 0){ //Traverses back up in reverse order
			phraseBuilder.append(currentNode.getValue());
			currentNode = trieNodeList.get(currentNode.getParentIndex()+1);
		}
		
		//reverse phrase to get correct order, stringify and return
		return phraseBuilder.reverse().toString();
		
	}



	
}
