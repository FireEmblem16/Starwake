
import java.util.ArrayList;
import java.util.HashMap;

public class LZ {

	private LZ(){
		
	}
	//encodes a compressed string into the LZ format
	public static String encode(String uncompressed){
		Trie lzTrie = new Trie();
		lzTrie.insertStringIntoTrie(lzTrie.getRootNode(), uncompressed, 0);
		System.out.println(lzTrie.toStringSimple());
		return lzTrie.toStringComplex();
	}
	//encodes a compressed string into the LZ format
	public static String decode(String compressed){
		Trie lzTrie = new Trie();
		lzTrie = buildTrieFromCompressed(compressed);
		return lzTrie.getOriginalString();
	}

	//Creates a trie from a compressed string
	private static Trie buildTrieFromCompressed(String compressed){
		String binString = Trie.ToBinary(compressed);
		Trie lzTrie = new Trie();
		
		//gets the prefix length
		lzTrie.setPrefixLength(Integer.parseInt(binString.substring(0,32), 2));
		int cursor = 32;
			
		ArrayList<Integer> prefixList = new ArrayList<Integer>();
		ArrayList<Character> valueList = new ArrayList<Character>();
		
		while(true){
			//Pulls the prefix from the binary string, adds it to the stack of prefixes
			prefixList.add(Integer.parseInt(binString.substring(cursor, cursor+lzTrie.getPrefixLength()), 2));
			cursor+=lzTrie.getPrefixLength();
			
			if(cursor+16 < binString.length()){
				//Pulls the value from the binary string, adds it to the stack of values
				valueList.add((char)Integer.parseInt(binString.substring(cursor, cursor+16), 2));
				cursor+=16;
			}
			else 
				break;
			
		}
		 
		lzTrie.buildTrie(prefixList, valueList);
		
		return lzTrie;		
	}
}
