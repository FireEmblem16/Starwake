import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

public class test {

	public static void main(String[] args) throws IOException {
	/*
		Scanner inputScanner = new Scanner(System.in);
		System.out.println("Enter String to encode: ");
		String inStr = inputScanner.nextLine();
		
		System.out.println("Compressed string");
		String compressed = LZ.encode(inStr);
		//String semicompressed = LZ.toStringSimple(inStr);
		
		System.out.println(compressed);
		*/
		/*InputStream in = new FileInputStream(new File("C:/Users/Peter Benzoni/Documents/COM S 311/lz/src/lzCompress/wizards.bin"));
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        StringBuilder out = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            out.append(line);
        }
        reader.close();
		
	    String compressed = out.toString();*/
		 String compressed = "Fake";
		String decompressed = LZ.decode(compressed);
		System.out.println(decompressed);
	}
}
