import java.util.ArrayList;
import java.util.List;

class TrieDictionary {
	public Node root = new Node();
	// first node of tree
	public String codewords;
	public String word;
	int count;

	// -------------------------------------------------------------
	public TrieDictionary() // constructor
	{
		root.iData = 0;
		root.data = '0';
		root.children = new ArrayList<Node>();
	} // no nodes in tree yet
	// -------------------------------------------------------------

	public Node find(char value) // find node with a given value
	{
		Node current = root; // start at root
		int i = 0;
		boolean flag = true;
		while (current.data != value && i < current.children.size()) {
			if (value == current.children.get(i).data) {
				// s = "" + current.children.get(i).data;
				current = current.children.get(i);
				flag = true;
				i = 0;

			} else {
				flag = false;
			}
			i++;
		}
		if (flag == false) {
			return null;
		}
		return current; // found it
	} // end find()

	public Node find(int key) // find node with a given value
	{
		Node current = root; // start at root
		int i = 0;
		boolean flag = true;
		while (current.iData != key && current.children != null
				&& i < current.children.size()) {
			if (key == current.children.get(i).iData) {
				// s = "" + current.children.get(i).data;
				current = current.children.get(i);
				flag = true;
				i = 0;

			} else {
				flag = false;
			}
			i++;
		}
		if (flag == false) {
			return null;
		}
		return current; // found it
	} // end find()

	public String parseCodeWord(String str, TrieDictionary t) {
		String message = "";
		Node temp = new Node();
		int j = 0;
		int l = 0;
		temp = root;
		message += str;

		message = t.word;

		return message;
	}

	public String parser(String str) {
		codewords = "";
		Node first = new Node();
		first.iData = 1;
		first.data = str.charAt(0);
		first.parent = root;
		root.children.add(first);
		first.children = new ArrayList<Node>();
		codewords = codewords + root.iData + first.data;
		count = 1;
		word = str;
		boolean flag = false;
		for (int i = 1; i < str.length(); i++) {
			Node parent = new Node();
			Node values = new Node();
			parent = find(str.charAt(i));
			if (parent == null) {

				values.iData = i + 1;
				values.data = str.charAt(i);
				values.parent = root;
				root.children.add(values);
				values.children = new ArrayList<Node>();
				codewords = codewords + values.parent.iData + values.data;
				count++;

			} else {
				while (true) {
					int j = i;
					for (int k = 0; k <= parent.children.size(); k++) {
						try {
							if ((parent.children.size() == 0)
									|| (!(parent.children.get(k).data == (str
											.charAt(j + 1))))) {
								flag = true;
							} else if ((parent.children.get(k).data == (str
									.charAt(j + 1)))) {
								flag = false;
								break;
							}
						} catch (IndexOutOfBoundsException E) {
							break;
						}
					}
					if (flag) {
						values.iData = count + 1;
						values.data = str.charAt(j + 1);
						values.parent = parent;
						parent.children.add(values);
						values.children = new ArrayList<Node>();
						codewords = codewords + values.parent.iData
								+ values.data;
						i++;
						count++;
						break;
					} else {

						i++;

						Node current = parent; // start at root
						int l = 0;

						while (current.data != str.charAt(j + 1)
								&& l < current.children.size()) {
							if (str.charAt(j + 1) == current.children.get(l).data) {
								// s = "" + current.children.get(i).data;
								current = current.children.get(l);

								l = 0;

							}
							l++;
						}
						parent = current;

					}
				}

			}
		}
		return codewords;

	}

	class Node {
		public int iData;
		public char data;
		public Node parent;
		public ArrayList<Node> children;

		public void displayNode() // display ourself
		{
			System.out.print('{');
			System.out.print(iData);
			System.out.print(", ");
			System.out.print(data);
			System.out.print("} ");
		}
	} // end class Node

	public static void main(String[] args) {

		//TrieDictionary t = new TrieDictionary();
		// t.parser("abcabadabc");
		// t.parser("aabaaabaaaaaabababbbbaba");
		// System.out.println(t.codewords);
		// Node n =t.searchWholeTrie(7);

	}

}
