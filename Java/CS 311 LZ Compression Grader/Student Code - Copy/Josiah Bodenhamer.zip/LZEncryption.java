import java.lang.Math;
import java.lang.Integer;

public class LZEncryption {

//	public static void main(String[] args) {
//		LZEncryption l = new LZEncryption();
//		String compressed;
//		String uncompressed;
//		compressed = l.encode("The world is full of sugar!");
//		l.decode(compressed);
//		// compressed = l.encode("abcabadabc");
//		// uncompressed = l.decode(compressed);
//
//	}

	public static TrieDictionary complete = new TrieDictionary();

	public LZEncryption() {

	}

	public static String encode(String uncompressed) {
		TrieDictionary t = new TrieDictionary();
		int numBits = 0;
		String codeWords;
		String BinaryEncoding;
		String s = "";
		String ret = "";
		codeWords = t.parser(uncompressed);
		complete = t;
		numBits = (int) Math.ceil((double) (Log(t.count, 2) + 1));
		s += Integer.toBinaryString(numBits);
		int size = s.length();
		StringBuilder sb = new StringBuilder(s);
		for (int j = 0; j < 32 - size; j++) {
			sb.insert(0, "0");
		}
		s = sb.toString();

		BinaryEncoding = s + ToBinary(codeWords);
		return BinaryEncoding;

	}

	public static String decode(String compressed) {
		TrieDictionary t = new TrieDictionary();
		String decoding = "";
		String numBits = "";
		numBits = compressed.substring(0, 31);
		StringBuilder sb = new StringBuilder(compressed);
		sb.delete(0, 32);
		compressed = sb.toString();
		decoding = FromBinary(compressed);
		return t.parseCodeWord(decoding, complete);

	}

	// base of code taken from Donald Nye Via Blackboard
	public static String ToBinary(String str) {
		final char[] masks = { 0x8000, 0x4000, 0x2000, 0x1000, 0x800, 0x400,
				0x200, 0x100, 0x80, 0x40, 0x20, 0x10, 0x8, 0x4, 0x2, 0x1 };
		final char[] masks2 = { 0x00, 0x8, 0x4, 0x2, 0x1 };
		String ret = "";

		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			for (int k = 0; k < 5; k++) {
				if ((c & masks2[k]) == 0)
					ret += "0";

				else if (k >= 1) {
					ret += "1";
				}

			}
			i++;
			c = str.charAt(i);
			for (int j = 0; j < 16; j++)
				if ((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}

		return ret;
	}

	// Base of code taken from Donald Nye via Blackboard
	public static String FromBinary(String str) {
		final char[] bits = { 0x8000, 0x4000, 0x2000, 0x1000, 0x800, 0x400,
				0x200, 0x100, 0x80, 0x40, 0x20, 0x10, 0x8, 0x4, 0x2, 0x1 };
		final char[] bits2 = { 0x00, 0x8, 0x4, 0x2, 0x1 };
		String ret = "";
		boolean flag = false;
		int count = 0;
		for (int i = 0; i < str.length(); i = 16) {
			char c = 0x0000;
			for (int k = 0; k < 5; k++) {
				if (i == 0) {

					if (str.charAt(k) == '1') {
						c |= bits2[k];
						flag = true;
					}
				} else {
					if (str.charAt(k + 16) == '1') {
						c |= bits2[k];
						if (k == 0) {
							ret += "16";
						} else if (k == 1) {
							ret += "8";
						} else if (k == 2) {
							ret += "4";
						} else if (k == 3) {
							ret += "2";
						} else if (k == 4) {
							ret += "1";
						}
						flag = true;
					}
				}

			}
			if (flag == false) {
				ret += "0";
			}

			StringBuilder sb = new StringBuilder(str);
			if (i == 0) {
				sb.delete(0, (5));
			} else {
				sb.delete(0, (5 + 16));
			}
			c = 0x0000;
			str = sb.toString();
			for (int j = 0; j < 16; j++)
				if (str.charAt(j) == '1')
					c |= bits[j];

			ret += c;
			count++;
		}

		return ret;
	}

	public static int Log(int x, int base) {
		return (int) (Math.log(x) / Math.log(base));
	}

}
