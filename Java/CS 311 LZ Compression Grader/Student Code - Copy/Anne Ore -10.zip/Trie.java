

import java.util.ArrayList;

//@author Anne Ore

public class Trie {

	public Node root = null;
	private int size;
	
	class Node {
		Character key = null;
		int value = 0; // this is the index that it has been added
		ArrayList<Node> children = new ArrayList<Node>();
		
		public Node(Character content, int index) {
			this.key = content;
			this.value = index;
		}
		
		public String toString() {
			if (key == null) return "root";
			return key + " -" + value + "-";
		}
	}
	
	public Trie() {
		root = new Node(null, 0);
		size = 0;
	}
	
	// returns parent of added node
	public Node add(String contents, int index) {
		Node cur = root;
		
		Node parent = root;
		
		while (contents.length() > 0) {
			
			boolean foundMatch = false;
			
			for (int j = 0; j < cur.children.size(); j++) {
				if ((cur.children.get(j)).key == contents.charAt(0)) {
					parent = cur;
					cur = cur.children.get(j);
					contents = contents.substring(1);
					foundMatch = true;
				}
			}
			
			if (!foundMatch) {
				cur.children.add(new Node(contents.charAt(0), index));
				size++;
				contents = contents.substring(1);
				parent = cur;
				cur = cur.children.get(cur.children.size() - 1);
			}
			
		}
		
		return parent;
	}
	
	public int size() {
		return size;
	}
	
	// returns value of node thats already in trie
	public int getVal(String contents) {
		if (!contains(contents)) return -1;
		
		Node cur = root;
		
		while (contents.length() > 0) {
						
			for (int j = 0; j < cur.children.size(); j++) {
				if ((cur.children.get(j)).key == contents.charAt(0)) {
					cur = cur.children.get(j);
					contents = contents.substring(1);
				}
			}
			
		}
		
		return cur.value;
	}
	
	
	public boolean contains(String str) {
		Node cur = root;
		
		boolean foundMatch = false;
		
		while (str.length() > 0) {
			
			foundMatch = false;
			
			for (int j = 0; j < cur.children.size(); j++) {
				if (str.charAt(0) == cur.children.get(j).key) {
					cur = cur.children.get(j);
					foundMatch = true;
					str = str.substring(1);
					break;
				}
			}
			// if "break" is hit, go here
			if (!foundMatch) {
				return false;
			}
		}
		
		return true;
	}
	
	public String toString() {
		return toStringRecursive(root);
	}
	
	private String toStringRecursive(Node cur) {
		if (cur.children.size() == 0) return cur.toString();
		else {
			String str = cur.toString() + " (";
			
			for (int i = 0; i < cur.children.size(); i++) {
				str += toStringRecursive(cur.children.get(i));
				if (i != cur.children.size() - 1) {
					str += " ";
				}
			}
			
			str += ")";
			
			return str;
		}
	}

}
