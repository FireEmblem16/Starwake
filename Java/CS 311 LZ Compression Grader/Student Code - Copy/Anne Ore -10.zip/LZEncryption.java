import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

// @author Anne Ore

public class LZEncryption {

	public static String encode(String uncompressed) throws FileNotFoundException, UnsupportedEncodingException {
		ArrayList<String> compressedList = new ArrayList<String>();

		Trie dictionary = new Trie();
		String phrase = "";
		
		int index = 1;
		
		// this skips the very last character
		while (uncompressed.length() > 0) {
			// if the phrase is already in the dictionary, keep adding to the phrase
			if (dictionary.contains(phrase)) {
				phrase += uncompressed.charAt(0);
				uncompressed = uncompressed.substring(1);
				if (uncompressed.length() == 0) {
					if (dictionary.contains(phrase)) {
						// if this matches a previous element exactly
						compressedList.add("" + dictionary.getVal(phrase));
					} else {
						Trie.Node result = dictionary.add(phrase, index);
						
						compressedList.add("" + result.value);
						compressedList.add("" + phrase.charAt(phrase.length() - 1));
					}
				}
			} else {
				Trie.Node result = dictionary.add(phrase, index);
				
				compressedList.add("" + result.value);
				compressedList.add("" + phrase.charAt(phrase.length() - 1));
				
				index++;
				phrase = "";
			}
		}
				
		return toBinary(compressedList);
	}
	
	private static String toBinary(ArrayList<String> codewords) {
		// Even indices are the associated number. Odd indices are
		// the associated additional character. 
		
		int size = (int) Math.ceil((double) codewords.size() / 2);
		
		int indexSize = (int) Math.ceil(Math.log(size + 1) / Math.log(2));
				
		int index = 0; // bit index!
		
		String result = "";
		
		char firstSegment = (char) (0x0000 | (indexSize & 0xFF00));
		char secondSegment = (char) (0x0000 | (indexSize & 0x00FF));
		
		result += firstSegment;
		result += secondSegment;
		
		if ((firstSegment | secondSegment) == 0) return result;
		
		char segment = 0x0000;
		
		for (int i = 0; i < codewords.size(); i++) {
						
			if (i % 2 == 0) { // it's a value
				
				String indexStr = Integer.toBinaryString(Integer.parseInt(codewords.get(i)));
				while (indexStr.length() < indexSize) {
					indexStr = "0" + indexStr; 
				}
				
				for (int j = 0; j < indexSize; j++) {
					if (indexStr.charAt(j) == '1') {
						segment |= (1 << (16 - (index % 16) - 1));
					}
										
					index++;
					
					if (index % 16 == 0) {
						// time to load it into the result
						result += segment;
						segment = 0x0000;
					}
				}
								
			} else { // it's the character that goes with it				
				String valStr = Integer.toBinaryString(codewords.get(i).charAt(0));
				while (valStr.length() < 16) {
					valStr = "0" + valStr; 
				}
				
				for (int k = 0; k < 16; k++) {
					if (valStr.charAt(k) == '1') {
						segment |= (1 << (16 - (index % 16) - 1));
					}
					
					index++;
					if (index % 16 == 0) {
						result += segment;
						segment = 0x0000;
					}
				}
			}
		}
		
		result += segment;
		
		return result;
	}	
	
	public static String decode(String compressed) {				
		char firstchunk = compressed.charAt(0);
		char secondchunk = compressed.charAt(1);
				
		int indexSize = (firstchunk << 15) | secondchunk;
		
		ArrayList<String> uncompressedList = new ArrayList<String>();
				
		boolean grabNum = true; // the next thing to grab is number
			
		String uncompressed = "";
		
		String compressedString = Binary.ToBinary(compressed);
		
		compressedString = compressedString.substring(32);
		
		while (compressedString.length() > 0) {
			if (grabNum) {
				
				if (compressedString.length() < indexSize) {
					break;
				}
				
				String num = compressedString.substring(0, indexSize);
				
				while (num.length() < 16) {
					num = "0" + num;
				}
				
				uncompressedList.add("" + Integer.parseInt(num, 2));
				
				compressedString = compressedString.substring(indexSize);
				
				grabNum = false;
			} else {
				if (compressedString.length() < 16) {
					break;
				}
				
				String value = compressedString.substring(0, 16);
				
				uncompressedList.add(Binary.FromBinary(value));
				
				compressedString = compressedString.substring(16);
				
				grabNum = true;
			}
		}
						
		ArrayList<String> dictionary = new ArrayList<String>();
		
		dictionary.add("");
		
		while (uncompressedList.size() > 1) {
			String element = dictionary.get(Integer.parseInt(uncompressedList.get(0))) + uncompressedList.get(1); 
			uncompressed += element;
						
			dictionary.add(element);
			
			uncompressedList.remove(0);
			uncompressedList.remove(0);
		}
		
		if (uncompressedList.size() == 1) { // one left
			uncompressed += dictionary.get(Integer.parseInt(uncompressedList.get(0)));
		}
		
		return uncompressed;
	}
		
}
