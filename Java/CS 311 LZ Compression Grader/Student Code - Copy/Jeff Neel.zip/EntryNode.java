

/**
 * An interface for describing basic getter functionality for a node
 * 
 * @author Jeff Neel
 * 
 */
public interface EntryNode<Character, K> {

	/**
	 * Returns the parent node of this node. If there is no parent node,
	 * <code>null</code> is returned.
	 * 
	 * @return
	 */
	public EntryNode<Character, K> parent();

	/**
	 * 
	 * <p>
	 * Returns the child node of this node. If a node has multiple children,
	 * then this returns the left-most child. E.g.,
	 * </p>
	 * 
	 * <pre>
	 *          Parent
	 *            |
	 * null <-> Child <-> Sibling <-> Sibling ...
	 * </pre>
	 * <p>
	 * If there is no child node, <code>null</code> is returned.
	 * </p>
	 * 
	 * @return
	 */
	public EntryNode<Character, K> child();

	/**
	/**
	 * Returns the next sibling of this node. If there is no next sibling,
	 * <code>null</code> is returned.
	 * 
	 * @return
	 */
	public EntryNode<Character, K> next();

	/**
	 * Returns the previous sibling of this node. If there is no previous
	 * sibling, <code>null</code> is returned.
	 * 
	 * @return
	 */
	public EntryNode<Character,K> prev();

	/**
	 * Returns the (non-null) key for this node.
	 * 
	 * @return
	 */
	public char Value();
	public  int Key();

}