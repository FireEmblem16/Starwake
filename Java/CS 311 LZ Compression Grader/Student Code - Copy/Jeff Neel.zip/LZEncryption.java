import java.util.Scanner;


public class LZEncryption
{


	public static String encode(String uncompressed)
	{
		if (uncompressed=="")
		{
			return FromBinary("00000000000000000000000000000000");
		}
		Dictionary dict=new Dictionary(); 
		int length=uncompressed.length();
		String copyOfUncompressed=uncompressed;
		Scanner copy=new Scanner(copyOfUncompressed);
		Scanner s=new Scanner(uncompressed);
		s.useDelimiter("");
		copy.useDelimiter("");
		String encodeing="";

		int index=0;
		/**
		 * create data structure to get an index count 
		*/
		Dictionary dictForCount=new Dictionary();
		String phase=copy.next();
		while(copy.hasNext())
		{
			if(dictForCount.InDictionary(phase))
			{
				phase=phase+copy.next();
			}
			else
			{
				if(copy.hasNext())
				{
					dictForCount.add(phase,index);
					index++;
					phase="";
				}

			}
		}
		int numOfPhases=index;
		int numberOfBits=(int) Math.ceil(Math.log(numOfPhases)/Math.log(2));
		

		index=0;
		phase="";
		/**
		 * adds the phases to the dictionary
		 */
		encodeing=encodeing+String.format("%32s", Integer.toBinaryString(numberOfBits)).replace(' ','0');
		
		while(s.hasNext())
		{
			if(dict.InDictionary(phase))
			{
				phase=phase+s.next();
			}
			else
			{
				if(s.hasNext())
				{
					int indexCode=dict.valueOfCodeword(phase.substring(0, phase.length()-1));
					encodeing=encodeing+""+
					String.format("%"+numberOfBits+"s", Integer.toBinaryString(indexCode)).replace(' ','0')
					+""+String.format("%16s", Integer.toBinaryString((int)phase.charAt(phase.length()-1))).replace(' ','0');
					index++;
					dict.add(phase,index);
					phase="";
				}

			}
		}
		if(dict.InDictionary(phase)) 
		{
			int indexCode=dict.valueOfCodeword(phase);
			encodeing=encodeing+""+String.format("%"+numberOfBits+"s", Integer.toBinaryString(indexCode)).replace(' ','0');

		}
		else
		{
			int indexCode=dict.valueOfCodeword(phase.substring(0, phase.length()-1));
			encodeing=encodeing+""+String.format("%"+numberOfBits+"s", Integer.toBinaryString(indexCode)).replace(' ','0')+
					""+String.format("%16s", Integer.toBinaryString((int)phase.charAt(phase.length()-1))).replace(' ','0');
		}
		//encode last part of the 
		
		while(encodeing.length()%16!=0)
		{
			encodeing=encodeing+"0";
		}
		return FromBinary(encodeing);
		
	}
	public static String decode(String compressed)
	{

		String[] arr=new String[10000];
		arr[0]="";
		String compressedDecoded=ToBinary(compressed);
		if (compressedDecoded.equals("00000000000000000000000000000000"))
		{
			return("");
		}
		Dictionary dict=new Dictionary();
		Scanner s=new Scanner(compressedDecoded);
		s.useDelimiter("");
		String first32Bits ="";
		int bitpos=0;
		int i=0;
		boolean firsttime=true;
		int index=1;
		String character="";
		String out="";
		int numbits=0;
		while(compressedDecoded.length()>16)
		{
			if (firsttime==true)
			{
				first32Bits=compressedDecoded.substring(0, 32);
				compressedDecoded=compressedDecoded.substring(32);
			}
			firsttime=false;
			 numbits = Integer.parseInt(first32Bits, 2);
			String stringprefixindex="";
			//get next numbits
			stringprefixindex=compressedDecoded.substring(0, numbits);
			compressedDecoded=compressedDecoded.substring(numbits);
			
			int prefixindex = Integer.parseInt(stringprefixindex, 2);

			String binchar="";
				
			binchar=compressedDecoded.substring(0,16);
			compressedDecoded=compressedDecoded.substring(16);
			int intvalue=Integer.parseInt(binchar.substring(8), 2);
			character = new Character((char) intvalue ).toString();
			

			
			
			String prefix=arr[prefixindex];
			arr[index]=prefix+character;	
			out=out+prefix+character;
			dict.add(prefix+character, index);
			index++;			
		}
		if(Integer.parseInt(compressedDecoded, 2)!=0)
		{
			int intvalue=Integer.parseInt(compressedDecoded.substring(0, numbits), 2);
			String prefix=arr[intvalue];
			out=out+prefix;

		}
		return out;
		
	}
	// code don gave
	public static String ToBinary(String str)
	{
		final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i++)
		{
			char c = str.charAt(i);
			
			for(int j = 0;j < 16;j++)
				if((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}
		
		return ret;
	}	
	// code don gave

	public static String FromBinary(String str)
	{
		final char[] bits = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i += 16)
		{
			char c = 0x0000;
			
			for(int j = 0;j < 16;j++)
				if(str.charAt(i + j) == '1')
					c |= bits[j];
			
			ret += c;
		}
		
		return ret;
	}
}


	