



public class Dictionary<Character, K> {

	public Node root=new Node('\0', 0);
	
	protected class Node implements EntryNode<Character,K> {
		private Node child; // link to the first child node
		private Node parent; // link to the parent node
		private Node prev; // link to the previous sibling
		private Node next; // link to the next sibling
		private char value; // the key for this node
		private int id; // the key for this node

		public Node(char c,int ID) {
			id=ID;
			value=  c;
			child = null;
			parent = null;
			prev = null;
			next = null;
		}
	@Override
	public EntryNode<Character, K> parent() {
		if(parent==null)
			return null;
			return parent;
	}

	@Override
	public EntryNode<Character,K> child() {
		if(child==null)return null;
		return child;
	}

	@Override
	public EntryNode<Character,K> next() {
		if(next==null)return null;
		return next;
	}

	@Override
	public EntryNode<Character,K> prev() {
		if(prev==null)return null;
		return prev;
	}
	@Override
	public  char Value() {
		return  value;
	}
	@Override
	public  int Key() {
		return  id;
	}
	
	}
	//add s a new node to the trie
	public boolean add(String s, int index) {
		if (s.equals(null))return false;
		Node current=root;
		for(int i=0;i<s.length();i++)
		{
			if (contains(current,(int)s.charAt(i)))
			{
				current= current.child;
				while((int) current.value!=(int)s.charAt(i))
				{
					current=current.next;
				}
			}
			else 
				{
				
				Node newNode = new Node(s.charAt(i),index);
				
				if(current.child==null)
				{
					current.child=newNode;
					newNode.parent=current;
					current=newNode;
				}
				else
				{
					current=current.child;
					while(current.next!=null)
					{
						current=current.next;
					}
					current.next=newNode;
					newNode.prev=current;
					newNode.parent=current.parent;
					current=newNode;
				}
				break;
		}}
		
		
		return true;
		
		
	}
	//returns true if a given node has a child that contains the char with a given ascii encodeing
	private boolean contains(Node n,int asciiValue) {
		if (n.child()==null) return false;
		Node current=n.child;
		if ((int) current.value==asciiValue) return true;
		while(current.next!=null)
		{
			current=current.next;
			if ((int) current.value==asciiValue) return true;
		}
		return false;
	}
	// returns true if a given string is in the dictionary
	public boolean InDictionary(String s)
	{
		Node current=root;
		for(int i=0;i<s.length();i++)
		{
			if(contains(current,(int)s.charAt(i)))
			{
				current=current.child;
				while(current.Value()!=(int)s.charAt(i))
				{
					current=current.next;
				}
			}
			else
			{
				//System.out.println(s+" is not in the dictionary");
				return false;
			}
		}
		//System.out.println(s+" is in the dictionary");
		return true;
		
	}
	// returns the value of a codeword given by string s
	public int valueOfCodeword(String s)
	{
		
		Node current=root;
		for(int i=0;i<s.length();i++)
		{
			if(contains(current,(int)s.charAt(i)))
			{
				current=current.child;
				while(current.Value()!=(int)s.charAt(i))
				{
					current=current.next;
				}
			}
			else
			{
				return root.id;
			}
		}
		return current.id;
		
	}
	
	}
	


