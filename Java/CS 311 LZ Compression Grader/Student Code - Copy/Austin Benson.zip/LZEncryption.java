import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author Austin Benson
 * COM S 311 - HW4
 * LZW Compression
 * Lathrop
 * Due 10/22/14
 */
public class LZEncryption 
{
	/**
	 * Number of bits to write to the compressed string
	 */
	private static final int NUM_BITS_PER_OUTPUT_CHAR = 16;
	
	/**
	 * Number of bits to read in the compressed string
	 */
	private static final int NUM_BITS_TO_USE_IN_CHAR = 16;
	
	private LZEncryption()
	{
	}
	
	/**
	 * Compresses an input string of raw text to a compressed output string
	 * @param uncompressed a raw input string
	 * @return a string containing the compressed output
	 */
	public static String encode(String uncompressed)
	{
		//Return an empty string
		if (uncompressed == null || uncompressed.length() == 0)
		{
			return new String(new char[2]);
		}

		ArrayList<Integer> codeWords = new ArrayList<Integer>();
		ArrayList<Character> charList = new ArrayList<Character>();

		LZWTrie dictionary = new LZWTrie();
		int codeWordIndex = 0;
		
		int strLength = uncompressed.length();
		
		for (int i = 0; i<strLength; i++)
		{
			Node current = dictionary.getRoot();
			while (i<strLength && current.getChildren().containsKey((char)(uncompressed.charAt(i) % 256)))
			{
				current = current.getChildren().get((char)(uncompressed.charAt(i) % 256));
				i++;
			}
			
			if (i < strLength)
			{
				//If this is not the final word, add a new code word and output it.
				codeWordIndex++;
				codeWords.add(current.codeWord);
				charList.add((char)(uncompressed.charAt(i) % 256));
				current.addChild((char)(uncompressed.charAt(i) % 256), codeWordIndex);
			}
			else
			{
				codeWords.add(current.codeWord);
			}
		}
		
		int numBitsInCodeWord = (int) Math.ceil((Math.log(codeWordIndex+1)) / Math.log(2));
		char[] packed = packBits(charList, codeWords, numBitsInCodeWord);
		return new String(packed);
	}
	
	/**
	 * Decodes a properly encoded LZW String.
	 * @param compressed a properly encoded LZW String
	 * @return The uncompressed version of the LZW String
	 */
	public static String decode(String compressed)
	{
		if (compressed == null || compressed.length() == 0)
		{
			return "";
		}
		
		char[] input = compressed.toCharArray();
		StringBuilder outputString = new StringBuilder();
		LZWTrie dictionary = new LZWTrie();
		
		//This will lookup the codeword in the dictionary without needed to traverse the entire dictionary
		HashMap<Integer, Node> lookup = new HashMap<Integer, Node>();
		lookup.put(0, dictionary.root);
		
		int numBitsPerCodeWord = (int)getBitsFromCharArray(input, 0, 15, 32);
		
		int charIndex = 2;
		int startBit = NUM_BITS_TO_USE_IN_CHAR-1;
		
		int numBitsLeftToRead = input.length*NUM_BITS_TO_USE_IN_CHAR - 32;
		
		int codeWordCount = 1;
		
		//While still words left in the compressed string
		while (numBitsLeftToRead >= (numBitsPerCodeWord + NUM_BITS_PER_OUTPUT_CHAR))
		{
			int codeWord = (int)getBitsFromCharArray(input, charIndex, startBit, numBitsPerCodeWord);
			startBit -= numBitsPerCodeWord;
			numBitsLeftToRead -= numBitsPerCodeWord;
			
			//Set the next read point
			while (startBit < 0)
			{
				startBit += NUM_BITS_TO_USE_IN_CHAR;
				charIndex++;
			}
			
			char charToAdd = (char)getBitsFromCharArray(input, charIndex, startBit, NUM_BITS_PER_OUTPUT_CHAR);
			startBit -= NUM_BITS_PER_OUTPUT_CHAR;
			numBitsLeftToRead -= NUM_BITS_PER_OUTPUT_CHAR;	
			
			//Set the next read point
			while (startBit < 0)
			{
				startBit += NUM_BITS_TO_USE_IN_CHAR;
				charIndex++;
			}
			
			//Insert the new code word into the dictionary
			Node parentNode = lookup.get(codeWord);
			Node newlyAdded = parentNode.addChild(charToAdd, codeWordCount);
			lookup.put(codeWordCount, newlyAdded);

			outputString.append(newlyAdded.stringToRoot());
			codeWordCount++;
		}
		
		//Read Any Extra Trailing Items
		if (numBitsLeftToRead >= numBitsPerCodeWord)
		{
			int codeWord = (int)getBitsFromCharArray(input, charIndex, startBit, numBitsPerCodeWord);
			outputString.append(lookup.get(codeWord).stringToRoot());
		}
		
		return outputString.toString();
	}
	
	/**
	 * Compresses an Array of characters and codewords into a more compressed output
	 * @param charList a list of the characters in the LZW compression
	 * @param codeWords a list of the code words in the LZW compression
	 * @param numBitsPerCodeWord The number of bits in the code word
	 * @return a packed character array of bits
	 */
	private static char[] packBits(ArrayList<Character> charList, ArrayList<Integer> codeWords, int numBitsPerCodeWord)
	{
		int totalBitsNeeded = codeWords.size()*numBitsPerCodeWord + charList.size()*NUM_BITS_TO_USE_IN_CHAR;
		if (totalBitsNeeded % 16 != 0)
		{
			// The number of bits needed should be a multiple of 16
			totalBitsNeeded += 16 - (totalBitsNeeded % 16); 
		}
		
		char[] output = new char[2 + (totalBitsNeeded/NUM_BITS_TO_USE_IN_CHAR)];
		
		//Pack the first 32-bits as the number of bits in the code word
		output[0] = (char) (numBitsPerCodeWord >> 16);
		output[1] = (char) (numBitsPerCodeWord);
		
		//Initial Values
		int bitInChar = NUM_BITS_TO_USE_IN_CHAR - 1;
		int charIndex = 2;
		
		while(!charList.isEmpty() && !codeWords.isEmpty())
		{
			//Add a code word to the output
			int codeWord = codeWords.remove(0);
			for (int i = numBitsPerCodeWord - 1; i>=0; i--)
			{
				//-> Start left end, move to right end
				//if bit is set given position, then set bit.
				if ((codeWord & (1 << i)) > 0)
				{
					setBitInCharArray(output, charIndex, bitInChar);
				}
				bitInChar--;
				if (bitInChar < 0)
				{
					bitInChar += NUM_BITS_TO_USE_IN_CHAR;
					charIndex++;
				}
			}
			
			char charToAdd = charList.remove(0);
			
			//Now write out 8 bits of the given character
			for (int i = NUM_BITS_PER_OUTPUT_CHAR - 1; i>=0; i--)
			{
				//-> Start left end, move to right end. if bit is set given position, then set bit.
				if ((charToAdd & (1 << i)) > 0)
				{
					setBitInCharArray(output, charIndex, bitInChar);
				}
				bitInChar--;
				if (bitInChar < 0)
				{
					bitInChar += NUM_BITS_TO_USE_IN_CHAR;
					charIndex++;
				}
			}
		}
		
		if (!codeWords.isEmpty())
		{
			//Add a code word to the output
			int codeWord = codeWords.remove(0);
			for (int i = numBitsPerCodeWord - 1; i>=0; i--)
			{
				//-> Start left end, move to right end. if bit is set given position, then set bit.
				if ((codeWord & (1 << i)) > 0)
				{
					setBitInCharArray(output, charIndex, bitInChar);
				}
				bitInChar--;
				if (bitInChar < 0)
				{
					bitInChar += NUM_BITS_TO_USE_IN_CHAR;
					charIndex++;
				}
			}
		}
		
		return output;
	}
	
	/**
	 * Setting bit 7 would set the left-most bit, setting bit 0 would set the right-most bit
	 * @param arr
	 * @param charIndex
	 * @param bitNum
	 */
	private static void setBitInCharArray(char[] arr, int charIndex, int bitNum)
	{
		arr[charIndex] |= (1 << bitNum);
	}
	
	/**
	 * Return a certain number of bits from the character array
	 * @param arr the character array from which to read the bits
	 * @param charIndex The index of the character in the character array to read bits from
	 * @param startBit the starting bit in the array to read bits from
	 * @param numBitsToRead the number of bits to read
	 * @return a long containing the bits which can then be cast to the desired size
	 */
	private static long getBitsFromCharArray(char[] arr, int charIndex, int startBit, int numBitsToRead)
	{
		long output = 0;
		int numBitsRead = 0;
		
		while (numBitsRead < numBitsToRead)
		{
			output <<= 1;
			if ((arr[charIndex] & (1 << startBit)) > 0)
			{
				output |= 1;
			}
			startBit--;
			if (startBit < 0)
			{
				charIndex++;
				startBit = NUM_BITS_TO_USE_IN_CHAR + startBit;
			}
			numBitsRead++;
		}
		
		return output;
	}
	
	/**
	 * A simple node representation.
	 */
	private static class Node
	{
		private int codeWord;
		private char value;
		private Node parentNode;
		private HashMap<Character, Node> children;
		
		/**
		 * @param codeWord the code word of this node
		 * @param value the character corresponding to this node.
		 * @param parentNode the parent node of this node
		 */
		private Node(int codeWord, char value, Node parentNode)
		{
			this.children = new HashMap<Character, Node>();
			this.codeWord = codeWord;
			this.value = value;
			this.parentNode = parentNode;
		}
		
		/**
		 * @param codeWord the code word of this node
		 * @param parentNode the parent node of this node
		 */
		private Node(int codeWord, Node parentNode)
		{
			this.children = new HashMap<Character, Node>();
			this.codeWord = codeWord;
			this.parentNode = parentNode;
		}
		
		/**
		 * @return A hashmap containing all of this nodes' children
		 */
		public HashMap<Character, Node> getChildren()
		{
			return children;
		}
		
		/**
		 * Adds a child to the given node
		 * @param toAdd the character to add
		 * @param codeWord the number of the code word corresponding to this node
		 * @return The newly created child node
		 */
		public Node addChild(char toAdd, int codeWord)
		{
			children.put(toAdd, new Node(codeWord, toAdd, this));
			return children.get(toAdd);
		}
		
		/**
		 * @return A String containing all elements from this node back to the root.
		 */
		public String stringToRoot()
		{
			StringBuilder output = new StringBuilder();
			Node current = this;
			
			while (current.parentNode != null)
			{
				output.insert(0, current.value);
				current = current.parentNode;
			}
			
			return output.toString();
		}
	}
	
	/**
	 * A class simple class representation of an LZW Trie
	 */
	private static class LZWTrie 
	{
		private Node root;
		
		public LZWTrie()
		{
			this.root = new Node(0, null);
		}
		
		public Node getRoot() 
		{
			return root;
		}
	}
}