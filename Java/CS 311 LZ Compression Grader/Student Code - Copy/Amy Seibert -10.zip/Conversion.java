// Amy Seibert
// ComS 311

public class Conversion
{

	public static String IntToOneZero(Integer num, int bits)
	{
		String character = num.toString();
		if (character == null || character.length() == 0)
		{
			return "";
		} else
		{
			String ret = "";
			char mask = 0x0001;
			for (int i = 0; i < bits; i++)
			{
				if ((mask & (num)) != 0)
				{
					ret += "1";
				} else
				{
					ret += "0";
				}
				mask *= 2;
			}
			String revRet = ReverseBinaryString(ret);
			return revRet;
		}
	}

	public static String CharToOneZero(String character, int bits)
	{
		if (character == null || character.length() == 0)
		{
			return "";
		} else if (character.length() > 1)
		{
			System.out.println("Error in character length");
			return "";
		} else
		{
			String ret = "";
			char mask = 0x8000;
			for (int i = 0; i < bits; i++)
			{
				if ((mask & (character.charAt(0))) != 0)
				{
					ret += "1";
				} else
				{
					ret += "0";
				}
				mask /= 2;
			}
			return ret;
		}
	}

	public static String ReverseBinaryString(String string)
	{
		String ret = "";
		for (int i = 0; i < string.length(); i++)
		{
			if (string.charAt(string.length() - 1 - i) == '1')
				ret += "1";
			else
				ret += "0";

		}
		return ret;
	}

	public static String StringToBinary(String string)
	{
		String ret = "";
		int stringIndex = 0;
		char cur;
		char mask;
		while (stringIndex < string.length())
		{
			cur = 0x0000;
			mask = 0x8000;
			for (int i = 0; i < 16; i++)
			{
				if (string.charAt(stringIndex) != '0')
				{
					cur = (char) (cur | mask);
				}
				stringIndex++;
				mask /= 2;
			}
			ret += cur;
		}
		return ret;
	}

	public static Integer StringToInt(String substring, Integer num)
	{
		if (substring == null || substring.length() != num)
		{
			return 0;
		} else
		{
			Integer ret = 0;
			for (int i = 0; i < num; i++)
			{
				if (substring.charAt(i) != '0')
				{
					ret += (int) Math.pow(2, num - 1 - i);
				}
			}
			return ret;
		}

	}

	public static String BinaryToString(String string)
	{
		String ret = "";
		int binaryIndex = 0;
		char mask;
		while (binaryIndex < string.length())
		{
			mask = 0x8000;
			for (int i = 0; i < 16; i++)
			{
				if ((string.charAt(binaryIndex) & mask) != 0)
				{
					ret += "1";
				} else
				{
					ret += "0";
				}
				mask /= 2;
			}
			binaryIndex++;
		}

		return ret;
	}
}
