// Amy Seibert
// ComS 311

import java.util.ArrayList;

public class LZ
{
	private Trie trie;

	public LZ(String string)
	{
		trie = new Trie();
		trie.addString(string);
	}

	public static String encode(String uncompressed)
	{
		String string = "";
		LZ lz = new LZ(uncompressed);
		Integer numNode = lz.trie.tree.size();
		// First 4 bytes are ceil(log(uncompressed.length()+1))
		// then ceil(log(uncompressed.length()+1)) index of prefix then 16 bit
		// character for each node
		string += lz.toString(numNode);
		// pad with 0 to make it a multiple of 16
		int zerosToAdd = 16 - string.length() % 16;
		while (zerosToAdd != 16 && zerosToAdd > 0)
		{
			string += "0";
			zerosToAdd--;
		}
		return Conversion.StringToBinary(string);
	}

	public static String decode(String compressed)
	{
		compressed = Conversion.BinaryToString(compressed);
		// First 4 bytes are ceil(log(uncompressed.length()+1))
		Integer prefixBits = Conversion.StringToInt(
				compressed.substring(0, 32), 32);
		if (prefixBits.equals(0))
		{
			return "";
		}
		Integer index = 32;
		Integer sizeChunk = prefixBits + 16;
		LZ lz = new LZ("");
		// then ceil(log(uncompressed.length()+1)) index of prefix then 16 bit
		// character for each node
		while (index + sizeChunk < compressed.length())
		{
			lz.addNode(
					Conversion.StringToInt(
							compressed.substring(index, index + prefixBits),
							prefixBits), Conversion.StringToBinary(compressed
							.substring(index + prefixBits, index + sizeChunk)));
			index += sizeChunk;
		}
		// Get last node if it is a copy of another prefix
		if (index + sizeChunk >= compressed.length()
				&& index + prefixBits < compressed.length())
		{
			lz.addNode(
					Conversion.StringToInt(
							compressed.substring(index, index + prefixBits),
							prefixBits), "");
		}

		return lz.trie.toString();
	}

	private void addNode(Integer prefix, String character)
	{
		trie.addNode(prefix, character);
	}

	private class Trie
	{
		private ArrayList<Node> tree;

		private Trie()
		{
			tree = new ArrayList<Node>();
		}

		public void addNode(Integer prefix, String character)
		{
			tree.add(new Node(character, prefix));
		}

		private void addString(String string)
		{
			String copyString = string;
			Element element;
			Integer subStringIndex = 0;
			if (tree.size() == 0)
				tree.add(new Node("", 0));
			while (copyString.length() != 0)
			{
				element = findPrefix(copyString);
				if (element.charIndex != null)
				{
					tree.add(new Node(string.charAt(element.charIndex
							+ subStringIndex)
							+ "", element.prefix));
					tree.get(element.prefix).children.add(tree.size() - 1);
				} else
				{
					tree.add(new Node("", element.prefix));
					tree.get(element.prefix).children.add(tree.size() - 1);
					break;
				}
				subStringIndex = element.charIndex + subStringIndex + 1;
				copyString = string.substring(subStringIndex);
			}
		}

		private Element findPrefix(String string)
		{
			if (!tree.isEmpty()) // Add the first Node if the tree is empty
			{
				Integer prefixIndex = 0;
				Integer charIndex = 0;
				ArrayList<Integer> children = new ArrayList<Integer>();
				while (prefixIndex < tree.size())
				{
					// Make sure this is not the last part of the string
					if (charIndex > string.length() - 1)
					{
						return new Element(prefixIndex, null);
					}
					// Get children
					children = tree.get(prefixIndex).children;
					if (children.isEmpty())
					{
						return new Element(prefixIndex, charIndex);
					}
					boolean childMatched = false;
					for (int i = 0; i < children.size(); i++)
					{
						if (tree.get(children.get(i)).value.charAt(0) == string
								.charAt(charIndex))// if the next character in
													// the string matches the
													// value of that child make
													// that one the new index
						{
							prefixIndex = children.get(i);
							charIndex++;
							childMatched = true;
							break;
						}
					}
					// if none of the children match return the index
					if (!childMatched)
					{
						return new Element(prefixIndex, charIndex);
					}
				}
			}
			return new Element(0, 0);
		}

		@Override
		public String toString()
		{
			String ret = "";
			for (int i = 0; i < tree.size(); i++)
			{
				ret += (tree.get(i).toString());
			}
			return ret;
		}

		private String toString(int size)
		{
			String ret = "";
			ret += Conversion.IntToOneZero(
					(int) Math.ceil(Math.log(size) / Math.log(2)), 32);
			if (tree.size() > 1)
			{
				for (int i = 1; i < tree.size(); i++)
				{
					ret += (tree.get(i).toString(size));
				}
			}
			return ret;
		}

		private class Element
		{
			private Integer prefix;
			private Integer charIndex;

			private Element(Integer pre, Integer index)
			{
				prefix = pre;
				charIndex = index;
			}
		}

		private class Node
		{
			private String value;
			private Integer prefix;
			private ArrayList<Integer> children;

			private Node(String character, Integer index)
			{
				if (character.length() > 1)
				{
					System.out.println("Problem!!!!");
				}
				value = character;
				prefix = index;
				children = new ArrayList<Integer>();
			}

			private String getValue()
			{
				if (prefix.equals(new Integer(0)))
				{
					return value;
				}
				String prefixValue = tree.get(prefix).getValue();
				return prefixValue + value;
			}

			@Override
			public String toString()
			{
				return getValue();
			}

			public String toString(int size)
			{
				int prefixBits = (int) Math.ceil(Math.log(size) / Math.log(2));
				return Conversion.IntToOneZero(prefix, prefixBits)
						+ Conversion.CharToOneZero(value, 16);
			}
		}
	}

	@Override
	public String toString()
	{
		return trie.toString();
	}

	public String toString(int size)
	{
		return trie.toString(size);
	}

}
