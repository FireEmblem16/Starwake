import java.util.HashMap;
import java.util.Map;

/**
 * A trie node representing a dictionary entry for LZ compression.
 * 
 * @author Richard
 */
public class TrieNode {
	
	//2^16 children are possible, but less than ~26 is likely.
	private Map<Character, TrieNode> children = new HashMap<Character, TrieNode>();
	private char character; //character appended to parent word
	private int index, parent; //index of self, index of parent
	private char[] word; //full word
	
	/**
	 * Create a new trie node
	 * @param index index of current node
	 * @param character
	 * @param parent parent node
	 */
	public TrieNode(int index, char character, TrieNode parent) {
		this.index = index;
		this.character = character;
		if (parent != null) {
			this.parent = parent.index;
			this.word = new char[parent.word.length+1];
			System.arraycopy(parent.word, 0, this.word, 0, parent.word.length);
			this.word[parent.word.length] =  character;
		} else {
			this.word = new char[0];
		}
	}
	
	/**
	 * Get index of this dictionary entry
	 * @return
	 */
	public int getIndex() {
		return this.index;
	}
	
	/**
	 * get index of parent dictionary entry
	 * @return
	 */
	public int getParent() {
		return this.parent;
	}
	
	/**
	 * get character appended to parent word
	 * @return
	 */
	public char getCharacter() {
		return this.character;
	}
	
	/**
	 * get this dictionary entry's word
	 * @return
	 */
	public char[] getWord() {
		return word;
	}

	/**
	 * check for child of this node that appends the specified character
	 * @param letter appended by child to this entry's word
	 * @return true if child exists
	 */
	public boolean hasChild(char letter) {
		return (null != children.get(new Character(letter)));
	}
	
	/**
	 * get child of this node that appends the specified character to the word
	 * @param letter to append
	 * @return TrieNode of specified child
	 */
	public TrieNode getChild(char letter) {
		return children.get(new Character(letter));
	}
	
	/**
	 * Add (or replace) a child to this node. If a node that appends the same character
	 * already exists, it is replaced.
	 * @param child
	 */
	public void setChild(TrieNode child) {
		children.put(new Character(child.character), child);
	}
	
	/**
	 * Print out the trie dictionary entries in vaguely readable format. Meant for debugging.
	 * @return
	 */
	public String getPrettyStructure() {
		return prettyStructure(0);
	}
	
	/**
	 * Print out the trie dictionary entries in vaguely readable format. Meant for debugging.
	 * @param depth how many levels to indent the output
	 * @return
	 */
	private String prettyStructure(int depth) {
		String indent = "";
		for (int i=0; i<depth; i++)
			indent += "  ";
		String result = indent + "-" + String.valueOf(index) +  new String(word) + "\n";
		for (TrieNode child: children.values()) {
			result += child.prettyStructure(depth+1); //indent children nodes
		}
		return result;
	}
}
