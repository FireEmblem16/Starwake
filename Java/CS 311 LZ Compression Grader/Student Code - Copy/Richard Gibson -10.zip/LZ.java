import java.util.ArrayList;
import java.util.List;

/**
 * Encodes and decodes strings using LZ compression. See assignment for full specs.
 * 
 * @author Richard
 *
 */
public class LZ {
	
	/* 16 bits is REQUIRED for compatibility with the assignment.
	 * 
	 * It will break if the input characters use more than the specified number of bits.
	 * 16 is recommended, but 7 or 8 bits seems to work on mundane,
	 * human-readable, alphanumeric text.
	 * (In ASCII, >=128 is various uncommonly used symbols.)
	 * 
	 * Note that this /does/ affect output size, and encodings with different 
	 * numbers of bits are not compatible with each other.
	 */

	// Some handy constants for bit packing.
	private static final int CHARBITS = 16;
	private static final int CHARMASK = (1 << CHARBITS) - 1;
	
	private LZ() {} //non-instantiable
	
	/**
	 * Compress a string using LZ compression. See assignment for output format details.
	 * @param uncompressed String to compress
	 * @return encoded/compressed result
	 */
	public static String encode(String uncompressed) {
		TrieNode trie = new TrieNode(0, (char) 0, null);
		List<TrieNode> nodes = new ArrayList<TrieNode>(); //maps to nodes by index (easier than traversing tree in O(n) to find index)
		nodes.add(trie);
		int index = 1;
		
		//create trie as we parse the input string
		TrieNode current = trie;
		for (int i=0; i<uncompressed.length(); i++) {
			char letter = uncompressed.charAt(i);
			if (current.hasChild(letter)) {
				current = current.getChild(letter);
			} else {
				//make new node in trie
				TrieNode newNode = new TrieNode(index, uncompressed.charAt(i), current);
				nodes.add(newNode);
				current.setChild(newNode);
				
				//start over with new word
				index++;
				current = trie;
			}
		}
		//determine index for any trailing word. (index 0 is always empty string)
		int finalCode = 0;
		if (current != trie) {
			//trailing word
			finalCode = current.getIndex();
		}

//		System.err.println(trie.getPrettyStructure());
		
		//determine bits needed for index and each dictionary entry
		int indexBits = new Double(Math.ceil(Math.log(index)/Math.log(2))).intValue();
		int wordBits =  indexBits + CHARBITS;
		
		//determine total number of bits/bytes needed
		int resultsize = (nodes.size()-1) * (wordBits); //bits for dictionary
		if (finalCode != 0) {
			resultsize += (indexBits); //extra for trailing index
		}
		resultsize = 4 + (resultsize+7)/8; //convert to bytes (rounding up), plus 4 bytes for dictionary's size header
		
		//create array for output bytes
		byte[] result = new byte[resultsize];
		
		//write header for index bits
		result[0] = (byte) (indexBits >>> 24);
		result[1] = (byte) (indexBits >>> 16);
		result[2] = (byte) (indexBits >>> 8);
		result[3] = (byte) indexBits;
		int resultindex = 4; //current writing position
		
		//write dictionary
		long buffer = 0;
		int bufferbits = 0;
		for (int i=1; i<nodes.size(); i++) {
			//write node onto buffer
			TrieNode node = nodes.get(i);
			int codeWord = (node.getParent() << CHARBITS) | node.getCharacter();
			buffer = (buffer << (wordBits)) | codeWord;
			bufferbits += wordBits;
			//pack buffer bits into bytes
			while (bufferbits >= 8) {
				result[resultindex] = (byte) (buffer >> (bufferbits-8) & 255);
				resultindex++;
				bufferbits -= 8;
			}
		}
		//insert index for last word
		if (finalCode != 0) {
			buffer = (buffer << (indexBits)) | finalCode;
			bufferbits += indexBits;
			//pack bits
			while (bufferbits >= 8) {
				result[resultindex] = (byte) (buffer >> (bufferbits-8) & 255);
				resultindex++;
				bufferbits -= 8;
			}
		}
		//flush buffer with last padded byte if needed
		if (bufferbits != 0) {
			assert (bufferbits < 8); //else much fail
			result[resultindex] = (byte) ((buffer << (8-bufferbits)) & 255);
		}
		
		
		//mash bytes into Java 16-bit strings
		String javaString = "";
		for (int i=0; i<result.length; i+=2) {
			char newChar = (char) ((int) result[i] << 8);
			if (i+1 < result.length) {
				 newChar |= ((int) result[i+1]) & 255;
			} //else leave zeroes
			javaString += newChar;
		}
		return javaString;
	}
	
	/**
	 * Decodes an LZ-compressed string. Compatible with compressed output from
	 * itself and other (correct) assignment implementations.
	 * @param compressed LZ-compressed string
	 * @return decoded string
	 */
	public static String decode(String compressed) {
		String result = ""; //for decoded result
		
		//unpack string into byte array
		byte[] data = new byte[compressed.length()*2];
		for (int i=0; i<compressed.length(); i++) {
			char c = compressed.charAt(i);
			data[i*2] = (byte) (c >> 8);
			data[i*2+1] = (byte) (c & 255);
		}
		
		//read header for number of bits in index
		int indexBits = data[0];
		indexBits <<= 24;
		indexBits += data[1];
		indexBits <<= 16;
		indexBits += data[2];
		indexBits <<= 8;
		indexBits += data[3];
		int wordBits = indexBits + CHARBITS;
		
		//create empty dictionary
		TrieNode trie = new TrieNode(0, (char) 0, null);
		List<TrieNode> nodes = new ArrayList<TrieNode>(); //maps to nodes by index (easier than traversing tree in O(n) to find index)
		nodes.add(trie);
		
		//parse nodes
		long wordmask = (1L << wordBits) - 1;
		long buffer = 0;
		int bufferBits = 0;
		for (int i=4; i<data.length; i++) {
			//unpack byte onto buffer
			buffer = (buffer << 8) | (data[i] & 255L);
			bufferBits += 8;
			
			//read dictionary entries from the buffer
			while (bufferBits >= wordBits) {
				long bits = (buffer >>> (bufferBits-wordBits) & wordmask);
				char character = (char) (bits & CHARMASK);
				int parent = (int) (bits >>> CHARBITS);
				TrieNode newNode = new TrieNode(nodes.size(), character, nodes.get(parent));
				nodes.add(newNode);
				nodes.get(parent).setChild(newNode);
				result += new String(newNode.getWord());
				bufferBits -= wordBits;
			}
		}
		//look for trailing index
		if (bufferBits >= indexBits) {
			int finalCode = (int) ((buffer >> (bufferBits-indexBits)) & ((1 << indexBits) - 1));
			result += new String(nodes.get(finalCode).getWord());
		}
		
//		System.err.println(trie.getPrettyStructure());
		return result;
	}
}
