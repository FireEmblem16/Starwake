
public class Node {
	
	private Node[] children = new Node[256];
	private int[] childrenPositions = new int[256];
	private Node parent;
	private int codeWord;
	private char character;
	private int numberOfChildren = 0;
	
	public Node(Node parent, int codeWord){
		this.codeWord = codeWord;
		this.parent = parent;
	}
	
	public Node addChild(int codeWord, int value){
		Node child = new Node(this, codeWord);
		this.children[value] = child;
		this.childrenPositions[this.numberOfChildren] = value;
		this.numberOfChildren += 1;
		return child;
	}
	public Node addChild(int codeWord, char character){
		int characterAscii = (int) character;
		return addChild(codeWord, characterAscii);
	}
	
	public Node getChild(int value){
		return children[value];
	}
	
	public Node getChild(char character){
		int characterAscii = (int) character;
		return getChild(characterAscii);
	}
	
	public Node getParent(){
		return parent;
	}
	
	public int getCodeWord(){
		return codeWord;
	}
	public char getCharacter(){
		return this.character;
	}
	public void setCharacter(char character){
		this.character = character;
	}
	public int getNumberOfChildren(){
		return this.numberOfChildren;
	}
	public int[] getChildrenPositions(){
		return this.childrenPositions;
	}
	public String getDecodedString(){
		String decodedString = "" + this.character;
		Node parent = this.parent;
		while (parent != null){
			decodedString = parent.character + decodedString;
			parent = parent.getParent();
		}
		return decodedString;
	}
	

}
