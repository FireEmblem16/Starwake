import java.util.ArrayList;


public class LZ {

	/**
	 * @param args
	 */
//  Uncomment this to test code
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		String compressed = encode("Sugar! Sugar! Sugar! Sugar! Sugar! Sugar! Sugar! Sugar!");
//		System.out.println(compressed);
//		System.out.println(decode(compressed));
//	}
	private LZ(){
		
	}
	
	public static String encode(String uncompressed){
		
		ArrayList<Phrase> phrases = getPhrasesForEncoding(uncompressed);
		String compressed = getCompressedString(phrases);		
		return compressed;
		
	}
	
	
	public static String decode(String compressed){
		String uncompressed = "";
		String strSize = compressed.substring(0, 32);
		int size = Integer.parseInt(strSize, 2);
		int codeWord;
		Node root = new Node(null, 0);
		Node[] arr = new Node[(int) Math.pow(2, size)];
		arr[0] = root;
		for (int i=32; i<compressed.length()-size-16;i++){
			codeWord = Integer.parseInt(compressed.substring(i, i+size), 2);
			char character = FromBinary(compressed.substring(i+size, i+size+16)).charAt(0);
			Node node = findNode(codeWord, arr);
			Node child = node.addChild(codeWord, character);
			arr[(i-32)/(16+size)+1] = child;
			child.setCharacter(character);
			uncompressed += node.getDecodedString();
			uncompressed += FromBinary(compressed.substring(i+size, i+size+16));
			i = i+size+15;
		}
		return uncompressed;

	}
	//Decoding Helpers
	private static Node findNode(int codeWord, Node[] arr){
		return arr[codeWord];
	}
	//Encoding Helpers
	private static ArrayList<Phrase> getPhrasesForEncoding(String uncompressed){
		Node root = new Node(null, 0);
		Node position = root;
		ArrayList<Phrase> phrases = new ArrayList<Phrase>();
		int codeWord = 1;
		for (int i=0; i<uncompressed.length(); i++){
			position = root;
			for (int j=i; j<uncompressed.length(); j++){
				Node child = position.getChild(uncompressed.charAt(j));
				if (child == null){
					position.addChild(codeWord, uncompressed.charAt(j));
					Phrase phrase = new Phrase(position.getCodeWord(), uncompressed.charAt(j));
					phrases.add(phrase);
					codeWord++;
					i = j;
					break;
				}
				else {
					if (j == uncompressed.length() - 1){
						position = position.getChild(uncompressed.charAt(j));
						Phrase phrase = new Phrase(position.getCodeWord(), '\0');
						phrases.add(phrase);
						codeWord++;
						i = j;
					}
					position = child;
				}
			}
		}
		return phrases;
	}
	private static String getCompressedString(ArrayList<Phrase> phrases){
		String compressed = "";
		int size = (int) Math.ceil(Math.log(phrases.size()+1)/Math.log(2));
		compressed = String.format("%32s", Integer.toBinaryString(size)).replace(' ', '0');
		for (int i=0; i<phrases.size(); i++){
			Phrase phrase = phrases.get(i);
			String format = "%xs".replace("x", Integer.toString(size));
			String binaryCodeWord = String.format(format, Integer.toBinaryString(phrase.getCodeWord())).replace(' ', '0');
			compressed += binaryCodeWord + ToBinary(Character.toString(phrase.getCharacter()));
		}
		int padding = compressed.length() % 16;
		if (padding != 0){
			for (int i=0; i<16-padding;i++){
				compressed += "0";
			}
		}
		return compressed;
	}
	
	private static String ToBinary(String str)
	{
		//From Don Nye
		final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i++)
		{
			char c = str.charAt(i);
			
			for(int j = 0;j < 16;j++)
				if((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}
		
		return ret;
	}	

	private static String FromBinary(String str)
	{
		//From Don Nye
		final char[] bits = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i += 16)
		{
			char c = 0x0000;
			
			for(int j = 0;j < 16;j++)
				if(str.charAt(i + j) == '1')
					c |= bits[j];
			
			ret += c;
		}
		
		return ret;
	}
	

}
