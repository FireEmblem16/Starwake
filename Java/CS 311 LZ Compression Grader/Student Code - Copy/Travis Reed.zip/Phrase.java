
public class Phrase {
	private int codeWord;
	private char character;

	public Phrase(int codeWord, char character){
		this.codeWord = codeWord;
		this.character = character;
	}
	
	public char getCharacter(){
		return this.character;
	}
	
	public int getCodeWord(){
		return this.codeWord;
	}
	
}
