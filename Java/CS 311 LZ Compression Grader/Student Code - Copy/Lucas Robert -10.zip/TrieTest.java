
public class TrieTest {
	public static void main(String[] args){
		int before = 5;
		System.out.println(before);
		int after = before & 00000000000000000000000011111111;
		System.out.println(after);
	}
}
