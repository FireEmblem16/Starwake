
public class trie {
	
	private trieNode root;
	int numNodes;
	 
   public trie()
   {
	   numNodes = 1;
	   root = new trieNode(' ',numNodes,0);
   }
   
   //Used to build the trie
   //adds a string to the trie by building it and creating
   //nodes when a new sequence starts
   public trieNode insert(String word){
	   trieNode inserted = root.insert(numNodes, 0, word);
	   numNodes++;
	   return inserted;
   }
   
   //searches the trie for the string and returns the trieNode
   //that contains the last character of the string
   public trieNode search(String string){
	  trieNode nodeFound = root.search(string);
	  return nodeFound;	
   }
   
   //Calls the trieNode contain() method to check if the trie contains the string
   public boolean contain(String string){
	   boolean contain = root.contain(string);
	   return contain;
   }
   
   //Returns the number of nodes in order to calculate the index
   public int getNumNodes(){
	   return numNodes;
   }
   
   public String addDecode(int cw,char character){
	   String string = root.addDecode(cw,character,numNodes);
	   return string;
   }
}
