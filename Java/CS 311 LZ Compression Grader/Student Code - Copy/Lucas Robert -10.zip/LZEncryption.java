import java.util.ArrayList;


public final class LZEncryption {
	//private constructor to make the class non-instantiable
	private LZEncryption(){
	}
	
	//Given a string
	//Check if first character(phrase) is in the trie
	//if not then add to the trie
	//if it is then check if the next character(next larger phrase) is in the trie under the first character
	//repeat for rest of characters
	//This will build the trie
	public static String encode(String uncompressed){
		//creates my trie data structure
		trie trie = new trie();
		String output = "";	//empty string to hold the compressed output
		//string to represent the compressed output
		String finalOutput = "";
		int lastParentCodeword = 0;
		//Not sure if this is acceptable but it is the easiest way for me
		//This arraylist will hold every node that has been inserted
		//This makes it easy for me to get their codewords and parent codewords for when I build the finalOutput string
		ArrayList<trieNode> nodes = new ArrayList<trieNode>();
		
		//if the string entered is empty, returns output right away
		//increases efficiency of algorithm
		if(uncompressed == ""){
			return "00000000000000000000000000000000";
		}
		//Used to build the trie data structure with inputed string
		for(int i =0; i < uncompressed.length();i++){
			if(trie.contain(uncompressed.substring(0,i+1)) == false){
				trieNode node = trie.insert(uncompressed.substring(0, i+1));
				output = output + Integer.toString(node.parentCodeword) + node.content;
				nodes.add(node);
			}
			//last phrase
			else if(trie.contain(uncompressed.substring(0,i+1)) && (i+1) == uncompressed.length()){
				trieNode node = trie.search(uncompressed.substring(0,i+1));
				lastParentCodeword = node.parentCodeword;
				output = output + Integer.toString(node.codeword);
			}
		}
		//time for the binary conversion and formatting of out string
		//first part of output string: index represented with 4 bytes
		//get index by using the total number of nodes or phrases
		int numNodes = trie.getNumNodes();
		//converts the numNodes to binary and counts how many bits it takes to represent it
		int indexBits = Integer.toBinaryString(numNodes).length();
		//first three bytes of zero
		String firstFourBytes = "000000000000000000000000";
		//Adds remainig missing zeroes until the index bits
		for(int i =0; i < 8-indexBits;i++){
			firstFourBytes = firstFourBytes + "0";
		}
		//adds the last bits which are represented by the index bits
		firstFourBytes = firstFourBytes + indexBits;
		finalOutput = firstFourBytes;
		//Leading output finished now need indexes and chars for each phrase
		for(int i =0; i < nodes.size();i++){
			trieNode node = nodes.get(i);
			String unpaddedIndex = Integer.toBinaryString(node.parentCodeword);
			String index = addZeroToFront(unpaddedIndex,indexBits);
			String unpaddedChar = Integer.toBinaryString(node.content);
			String character = addZeroToFront(unpaddedChar,16);
			finalOutput = finalOutput + index + character;
		}
		finalOutput = finalOutput +  Integer.toString(lastParentCodeword);
		int correctLength = 16 - (finalOutput.length()%16);
		String zeros = addZeroToFront(correctLength);
		return finalOutput + zeros;
	}
	
	public static String decode(String compressed){
		trie trie = new trie();
		String finalOutput = "";
		//the first four bytes of the string; represents the number of index bits
		String fourBytes = compressed.substring(0,32);
		//parse this to get the number of bits
		int index = Integer.parseInt(fourBytes, 2);
		//rest of the compressed string is indexes and chars
		compressed = compressed.substring(32);
		//loop through the string and retrieve each index and phrase
		for(int i =0; i+index +16 < compressed.length();i += index + 16){
			String firstPart = compressed.substring(i,i+index + 16);
			int cw = Integer.parseInt(firstPart.substring(0,index),2);
			char character = (char)(Integer.parseInt(firstPart.substring(index, index +16),2));
			//recursively add indexes and chars to the final output
			finalOutput = finalOutput + trie.addDecode(cw,character);
		}		
		return finalOutput;
		
	}
	
	//used to add zeroes to the front
	public static String addZeroToFront(String string, int indexSize){
		String paddedString = "";
		int len = string.length();
		for(int i =0; i < indexSize - len;i++){
			paddedString = paddedString + "0";
		}
		paddedString = paddedString + string;
		return paddedString;
	}
	
	//used to add zeroes to the front
	public static String addZeroToFront(int num){
		String string ="";
		for(int i=0; i < num; i++){
			string+="0";
		}
		return string;
	}
}

//Notes
/*
 * Receive a string of characters, could possibly be an empty string
 * Get binary representation of each character of the string
 * Each character of the string should be represented in a 16 bit
 * How do you get the size of index?	 
 */

