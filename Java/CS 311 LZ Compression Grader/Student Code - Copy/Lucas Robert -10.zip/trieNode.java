import java.util.LinkedList;

//required methods
//insert
//search
//contain
public class trieNode {
	
	char content; 						//current character
    int codeword; 
    int parentCodeword;  
    LinkedList<trieNode> childList;
    
    public trieNode(char c, int cw, int pcw)
    {
        childList = new LinkedList<trieNode>();
        content = c;
        parentCodeword = pcw;
        codeword = cw;
    }
    
    int nextCodeword = 0;
    public trieNode insert(int cw, int pcw, String string){
    	char currentChar = string.charAt(0); //first char of string
    	String smallerWord = string.substring(1);
    	//if the string is only one character or the last character to be added; it adds it
    	if(string.length() == 1){
    		for(int i =0; i < childList.size(); i++){
    			trieNode child = childList.get(i);
    			if(child.content == currentChar){
    				//returns the child because the last char in the string is already in the trie
    				//therefor you return the current node which is the last one for this string
    				return child;
    			}
    		}
    	}
    	//if there are going to be more phrases to add
    	if(string.length() >1){
    		for(int i =0; i < childList.size();i++){
    			trieNode child = childList.get(i);
    			if(child.content == currentChar){
    				trieNode recChild = child.insert(cw, codeword, string); //codeword in the insert is the parent node's codeword
    				return recChild;
    			}
    		}
    	}
    	//only gets to this if its the last character in the string but isN't in the trie yet
    	trieNode node = new trieNode(currentChar,cw,codeword);
    	childList.add(node);
    	return node;
    }
    
    //Searches for the node that contained the last character of the provided string
    //if not found returns null
    public trieNode search(String string){
    	String smallerWord = string.substring(1);
    	for(int i = 0; i < childList.size(); i++){
    		if(childList.get(i).content == string.charAt(0)){
    			if(!smallerWord.equals("")){
    				return childList.get(i).search(smallerWord);
    			}
    			else{
    				return childList.get(i);
    			}
    		}
    	}
    	return null;
    }
    
    //checks the node to see if it contains the provided string
    public boolean contain(String string){
    	trieNode contain = search(string);
    	if(contain == null){
    		return false;
    	}
    	else{
    		return true;
    	}
    }
    
    //used in decode adds nodes to the trie
    public String addDecode(int cw, char character, int numNodes){
    	String string = "";
    	if(character == this.codeword){
    		trieNode node = new trieNode(character, cw , numNodes);
    		this.childList.add(node);
    		string = string + this.content + node.content;
    		return string;
    	}
    	else{
    		for(int i =0; i < childList.size();i++){
    			trieNode node = childList.get(i);
    			string = node.addDecode(cw, character, numNodes);
    			if(string != null){
    				String ret = "";
    				ret = ret + this.content + string;
    				return ret;
    			}
    		}
    	}
    	return null;
    }
    
}
