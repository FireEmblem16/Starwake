import java.util.*;
import java.io.*;

public class LZtrie{
	private Node root;
	private static class Node{
		int index;
		char character;
		private Node parent = null;
		private  ArrayList<Node> children = null;
	
		Node(){
		}
		
		Node(int index, char character){
			this.index = index;
			this.character = character;
		}
		
		Node(int index, char character, Node parent){
			this.index = index;
			this.character = character;
			this.parent = parent;
		}
		
		public int getIndex(){
			return(this.index);
		}
		
		public void setIndex(int Index){
			this.index = Index;
		}
	
		public char getChar(){
			return(this.character);
		}
		
		public void setChar(char Char){
			this.character = Char;
		}
		
		public Node getParent(){
			return(this.parent);
		}
		
		public void setParent(Node Parent){
			this.parent = Parent;
		}
	}
	
	public void LZtrie(){
		root = new Node(0,'\0');
	}
	
	public int size(){
		return(size(root)-1);
	}
	
	private int size(Node node){
		if (node == null){
			return(0);
		} else {
			if (node.children == null){
				return(1);
			} else {
				int childrenSize = 0;
				for (int i=0; i < node.children.size(); i++){
					childrenSize = childrenSize + size(node.children.get(i));
				}
				return(1 + childrenSize);
			}
		}	
	}
	
	public boolean containsStr(String str){
		return(containsStr(root, str));
	}
	
	private boolean containsStr(Node node, String str){
		if (str.isEmpty()){
			return(true);
		} else {
			if (node.children == null || node.children.isEmpty()){
				return(false);
			} else {
				for (int i=0; i < node.children.size(); i++){
					if (node.children.get(i).getChar() == str.charAt(0)){
						return(containsStr(node.children.get(i), str.substring(1)));
					}
				}
				return(false);
			}
		}
	}
	
	public void addStr(int Index, String str){
		addStr(root, Index, str);
	}
	
	private void addStr(Node node, int Index, String str){
		if (str.length() == 1){
			int i=0;
			if (node.children == null){
				node.children = new ArrayList<Node>();
			}
			for (i=0; i < node.children.size(); i++){
				if (node.children.get(i).getChar() == str.charAt(0)){
					Node newEndNode = new Node(Index, '\0', node.children.get(i));
					if (node.children.get(i).children == null){
						node.children.get(i).children = new ArrayList<Node>();
					}
					node.children.get(i).children.add(newEndNode);
					break;
				}
			}
			if (i == node.children.size()){
				Node newNode = new Node(Index, str.charAt(0), node);
				node.children.add(newNode);
			}
		} else {
			for (int j=0; j < node.children.size(); j++){
				if (node.children.get(j).getChar() == str.charAt(0)){
					addStr(node.children.get(j), Index, str.substring(1));
				}
			}
		}
	}
	
	public void printNodes(){
		printNodes(root);
	}
	
	private void printNodes(Node node){
		if (node == null){
		} else {
			if (node.getParent() == null){
				if (node.children != null){
					for (int i=0; i < node.children.size(); i++){
						printNodes(node.children.get(i));
					}
				}
			} else {
				System.out.println("index = " + node.getIndex() + "\t" + "char = " + node.getChar() + "\t" + "code = " + node.getParent().getIndex() + node.getChar());
				if (node.children != null){
					for (int i=0; i < node.children.size(); i++){
						printNodes(node.children.get(i));
					}
				}
			}
		}
	}
	
	public Node find(int Index){
		if (root == null)
			return(null);
		return(find(root, Index));
	}
	
	private Node find(Node node, int Index){
		Node newNode = new Node();
		if (node.getIndex() == Index){
			return(node);
		} else {
			if (node.children != null){
				for (int i=0; i < node.children.size(); i++){
					newNode = find(node.children.get(i), Index);
					if(newNode != null) {
						return(newNode);	
					}
				}
			}
		}
		return(null);
	}
	
 	public String CodeWords(){
		int index = 1, codeWordsSize = 0, indexBitSize = 0;
		String sizeFormat, sizeBinStr, codeWords, paddingFormat, paddingStr;
		Node newNode = new Node();
		codeWordsSize = size();
		indexBitSize = (int)Math.ceil(Math.log((double)(codeWordsSize + 1)) / Math.log(2.0));
		sizeFormat = "%" + Integer.toString(32) + "s";
		sizeBinStr = String.format(sizeFormat, Integer.toBinaryString(indexBitSize)).replace(' ', '0');
		codeWords = sizeBinStr;
		for (index = 1; index <= codeWordsSize; index++){
			newNode = find(index);
			codeWords = codeWords + codeWord(codeWordsSize, newNode.getParent().getIndex(), newNode.getChar());
		}
		paddingFormat = "%" + Integer.toString(16 - ((codeWordsSize * indexBitSize) % 16)) + "s";
		paddingStr = String.format(paddingFormat, Integer.toBinaryString(0)).replace(' ', '0');
		codeWords = codeWords + paddingStr;
		return (codeWords);
	}
	
	private String codeWord(int size, int index, char character){
		int indexBitSize = 0;
		String indexFormat, charFormat, indexBinStr, charBinStr;
		indexBitSize = (int)Math.ceil(Math.log((double)(size + 1)) / Math.log(2.0));
		indexFormat = "%" + Integer.toString(indexBitSize) + "s";
		indexBinStr = String.format(indexFormat, Integer.toBinaryString(index)).replace(' ', '0');
		if (character != '\0'){
			charFormat = "%" + Integer.toString(16) + "s";
			charBinStr = String.format(charFormat, Integer.toBinaryString(character)).replace(' ', '0');
		} else {
			charBinStr = "";
		}
		return (indexBinStr + charBinStr);
	}
	
	public void addNode(int preIndex, int index, char character){
		addNode(root, preIndex, index, character);
	}
	
	private void addNode(Node root, int preIndex, int index, char character){
		Node newParentNode = new Node();
		newParentNode = find(root, preIndex);
		Node newNode = new Node(index, character, newParentNode);
		if (newParentNode.children == null){
			newParentNode.children = new ArrayList<Node>();
		}
		newParentNode.children.add(newNode);	
	}
	
	public String Phrases(){
		int index = 1, codeWordsSize = 0;
		Node newNode = new Node();
		String phrase = "";
		codeWordsSize = size();
		for (index = 1; index <= codeWordsSize; index++){
			newNode = find(index);
			phrase = phrase + onePhrase(newNode);
		}
		return(phrase);
	}
	
	private String onePhrase(Node node){
		Node newNode = node;
		char character;
		String onePhrase = "";
		while (newNode.getIndex() != 0){
			character = newNode.getChar();
			onePhrase = character + onePhrase;
			newNode = newNode.getParent();
		}
		//System.out.println(onePhrase);
		return(onePhrase);
	}
	
}
