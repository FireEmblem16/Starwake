import java.util.*;
import java.io.*;

public class LZEncryption
{
	public static String decode(String compressed)
	{
		LZtrie LZdict = new LZtrie();
		LZdict.LZtrie();
		String str = compressed, zeroStr, uncompressed = "", indexStr, charStr;
		int index = 0, preIndex = 0, codeLength, charLength, codeIndex = 32;
		char character;
		if (str.length() >= 32){
			codeLength = Integer.parseInt(str.substring(0,32), 2);
		} else {
			return ("");
		}
		charLength = 16;
		zeroStr = String.format("%32s", Integer.toBinaryString(0)).replace(' ', '0');
		if (str.length() == 32 && str.equals(zeroStr)){
			return ("");
		} 
		while (codeIndex < str.length()){
			indexStr = str.substring(codeIndex, codeIndex + codeLength);
			preIndex = Integer.parseInt(indexStr, 2);
			index = index + 1;
			if (codeIndex + codeLength <= str.length() - charLength){
				charStr = str.substring(codeIndex + codeLength, codeIndex + codeLength + charLength);
				character = Character.toChars(Integer.parseInt(charStr, 2))[0];
			} else {
				character = '\0';
			}
			//System.out.println(index + character);
			LZdict.addNode(preIndex, index, character);
			codeIndex = codeIndex + codeLength + charLength;
			
		}
		//LZdict.printNodes(); 
		uncompressed = LZdict.Phrases();
		System.out.println(uncompressed);
		return (uncompressed);
	}
	
	
	public static String encode(String uncompressed)
	{
		LZtrie LZdict = new LZtrie();
		LZdict.LZtrie();
		String str = uncompressed, phrase, prefix, sizeFormat, sizeBinStr, compressed, result, test;		
		int index = 0, charIndex = 0, size;
		if (str.length() == 0)
		{
			return (String.format("%32s", Integer.toBinaryString(0)).replace(' ', '0'));
		} 
		while(charIndex < str.length())
		{
			prefix = "";
			phrase = "" + str.charAt(charIndex);
			while (LZdict.containsStr(phrase) && (charIndex < str.length() - 1))
			{
				prefix = phrase;
				charIndex = charIndex + 1;
				phrase = phrase + str.charAt(charIndex);
			}
			index = index + 1; 			
			LZdict.addStr(index, phrase);
			charIndex = charIndex + 1;
		}
		//size = LZdict.size();
		//System.out.println("size = " + size);
		//LZdict.printNodes(); 
		compressed = LZdict.CodeWords();
		System.out.println(compressed);
		return (compressed);
	}
	
}





