import java.io.IOException;

/* Referenced help
*
http://stackoverflow.com/questions/4173951/string-to-binary-output-in-java
*
http://www.mathworks.com/matlabcentral/answers/131845-how-i-can-convert-binary-128-bit-to-decimal
*
http://www.tutorialspoint.com/java/java_basic_operators.htm
*
http://en.wikipedia.org/wiki/Two's_complement
*/


public class LZEncryption {

	static String input = "The world is full of sugar!";
	static String input2 = "aaabbbabababab";
	static String output = "00000000000000000000000000000101000000000000001010100000000000000001101000000000000000001100101000000000000000100000000000000000001110111000000000000001101111000000000000001110010000000000000001101100000000000000001100100001000000000001101001000000000000001110011001000000000001100110000000000000001110101010000000000001101100001000000000001101111000000000000001100110001000000000001110011011010000000001100111000000000000001100001001110000000000100001000000000000";
	static Trie dictionary;
	
	
	private LZEncryption(String words){
		dictionary = new Trie();
	}
	
	
	public static void main(String[] args) throws IOException{
//		LZEncryption n = new LZEncryption(input);
//		dictionary.add(input);
//		System.out.println(dictionary.add(input));
//		System.out.println(dictionary.entry.get(0));
		 encode(input);
	}
	
	
	public static String encode(String uncompressed) throws IOException{
		
		String dm = "";
		
		byte[] bytes = uncompressed.getBytes();
		StringBuilder binary = new StringBuilder();
		for (byte b : bytes){
			int val = b;
			for (int i = 0; i < 16; i++){
				binary.append((val & 128) == 0 ? 0 : 1);
				val <<= 1;
			}
			binary.append(' ');
		}
		System.out.println("'" + uncompressed + "' to binary: " + binary);
		return dm = "'" + uncompressed + "' to binary: " + binary;
	}
	
	
	public static String decode(String compressed){
		
		
		return null;
	}
	
	
	//Following was provided by TA's of cs311
	public static String ToBinary(String str)
	{
		final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i++)
		{
			char c = str.charAt(i);
			
			for(int j = 0;j < 16;j++)
				if((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}
		
		return ret;
	}	

	public static String FromBinary(String str)
	{
		final char[] bits = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i += 16)
		{
			char c = 0x0000;
			
			for(int j = 0;j < 16;j++)
				if(str.charAt(i + j) == '1')
					c |= bits[j];
			
			ret += c;
		}
		
		return ret;
	}
	
}