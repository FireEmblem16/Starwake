import java.util.ArrayList;
import java.util.List;

public class Trie{
    protected List<Node> entry = new ArrayList<Node>();
    protected Node root;
    protected String[] e;
    protected String x = "";
    protected boolean multiple = false;   
    
    /**
     * Constructor that adds all the words
     */
    public Trie() {
    	root = new Node();
    	root.data = ' ';
    	entry.add(root);
    }

    /**
     * - adds the letters to the trie
     */
    public boolean add(String words) {
    	boolean added = false;
    	if(words.contains(" ")){
    		System.out.println("here");
//    		e = words.replace(" ", "");
    		e = words.split(" ");
    		multiple = true;
    	}
    	e[0] = words;
    	System.out.println("here");
    	for(int i = 0; i < e.length; i++){
    		for(int j = 0; j <= e[i].length(); j++){
    			for(int h = 0; h <= root.Child.length; h++){
	    			System.out.println("here2");
	    			if(e.length == 0){
	    				System.out.println("here3");
	    				root.data = ' ';
	    				root.Parent = null;
	    				entry.add(root);
	    				
	    				added = true;
	    			}else if(root.Child[h].data == e[i].charAt(j)){
	    				System.out.println("here4");
		    			root.Child[h].Child[j].data = e[i].charAt(j+1);
		    			
		    			added = true;
		    		}else{
		    			System.out.println("here6");
		    			root.Child[h+1].data = e[i].charAt(j);
		    			
		    			added = true;
		    		}
	    			entry.add(root.Child[i]);
    			}
    		}
    	}
    	
    	return added;
    	
    }

    /* Not yet complete!
     * 
     * public Node cursive(Node u, String i) {
        Node r = new Node();
        
    	if(i.isEmpty()){
        	r = u;
        }else{
        	for(int n = 0; n < u.Child.length; n ++){
        		if(u.Child[n].data == i.charAt(n)){
        			r = cursive(u.Child[], n+1);
        		}
        	}
        }
    	
    	return r;
    }*/
    
}


class Node{
	Node Parent;
	Node[] Child;
	char data;
}