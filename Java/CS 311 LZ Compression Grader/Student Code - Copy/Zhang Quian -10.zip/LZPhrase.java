
public class LZPhrase
{
	private int prefixIndex;
	private char character;
	
	public LZPhrase(int prefix, char character)
	{
		this.prefixIndex = prefix;
		this.character = character;
	}
	
	public int getPrefix()
	{
		return this.prefixIndex;
	}
	
	public char getCharacter()
	{
		return this.character;
	}
}
