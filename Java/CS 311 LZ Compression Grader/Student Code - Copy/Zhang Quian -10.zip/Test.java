

public class Test
{
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		String uncompressed = "The world is full of sugar!";
		String compressed = LZ.encode(uncompressed);
		
		System.out.println(compressed);
		System.out.println(LZ.decode("00000000000000000000000000010000000000000000000000000000011100000000000000000001"));
	}
}
