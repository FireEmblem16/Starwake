import java.util.ArrayList;

public class LZTrie implements LZDictionary<Integer, String>
{	
	private LZTrieNode root;
	private ArrayList<String> values;
	private ArrayList<LZTrieNode> nodes;
	public final static int ALPHA_SIZE = 256; //8-bit characters
	
	public LZTrie() {
		this.root = new LZTrieNode();
		values = new ArrayList<String>();
		nodes = new ArrayList<LZTrieNode>();
		nodes.add(root);
		values.add("");
	}
	
	public LZTrieNode getRoot()
	{
		return root;
	}

	@Override
	public void put(Integer key, String value)
	{
		values.add(value);
		LZTrieNode cur = root;
		int end = 0;
		while(end < value.length() && cur.getChildren()[value.charAt(end)] != null)
		{
			cur = cur.getChildren()[value.charAt(end)];
			end++;
		}
		if(end == value.length())
		{
			nodes.add(new LZTrieNode(cur.getIndex(), key.intValue(), null));
		}
		else
		{
			cur.getChildren()[value.charAt(end)] = new LZTrieNode(cur.getIndex(), key.intValue(), Character.valueOf(value.charAt(end)));
			nodes.add(cur.getChildren()[value.charAt(end)]);
		}
	}

	@Override
	public String get(Integer key)
	{
		// TODO Auto-generated method stub
		return values.get(key.intValue());
	}
	
	public ArrayList<LZTrieNode> getNodes()
	{
		return nodes;
	}
	
	public ArrayList<String> getValues()
	{
		return values;
	}
}
