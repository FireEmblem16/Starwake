

public class LZTrieNode
{
	private int prefixCode;
	private int index;
	private Character extension;
	private LZTrieNode[] children;
	public LZTrieNode(int prefixCode, int index, Character extension)
	{
		this.prefixCode = prefixCode;
		this.index = index;
		children = new LZTrieNode[LZTrie.ALPHA_SIZE]; 
		this.extension = extension;
	}
	public LZTrieNode()
	{
		this.prefixCode = -1;
		this.index = 0;
		this.children = new LZTrieNode[LZTrie.ALPHA_SIZE];
		this.extension = null;
	}
	
	public int getIndex()
	{
		return index;
	}
	
	public int getPrefixCode()
	{
		return prefixCode;
	}
	
	public Character getExtension()
	{
		return extension;
	}
	
	public LZTrieNode[] getChildren()
	{
		return children;
	}
}
