import java.util.ArrayList;

public class LZ
{
	public static String encode(String uncompressed)
	{
		if(uncompressed.length() == 0)
		{
			return "00000000000000000000000000000000";
		}
		LZTrie trie = new LZTrie();
		int begin = 0;
		int index = 1;
		while(begin < uncompressed.length())
		{
			LZTrieNode cur = trie.getRoot();
			int end = begin;
			while(end < uncompressed.length() && cur.getChildren()[uncompressed.charAt(end)] != null)
			{
				cur = cur.getChildren()[uncompressed.charAt(end)];
				end++;
			}
			if(end == uncompressed.length()) 
			{
				trie.put(Integer.valueOf(index), trie.get(Integer.valueOf(cur.getIndex())));
			}
			else 
			{
				trie.put(Integer.valueOf(index), uncompressed.substring(begin, end + 1));
			}
			begin = end + 1;
			index++;
		}
		ArrayList<LZTrieNode> nodes = trie.getNodes();
		int size = (int)Math.round(Math.ceil(Math.log(nodes.size()) / Math.log(2)));
		String output = "";
		for(int i = 0; i < 32 - Integer.toBinaryString(size).length(); i++)
		{
			output += "0";
		}
		output += Integer.toBinaryString(size);
		for(LZTrieNode n : nodes)
		{
			if(n.getPrefixCode() != -1) {
				for(int i = 0; i < size - Integer.toBinaryString(n.getPrefixCode()).length(); i++)
				{
					output += "0";
				}
				if(n.getExtension() == null) {
					output += Integer.toBinaryString(n.getPrefixCode());
				}
				else {
					output += Integer.toBinaryString(n.getPrefixCode());
					output += LZUtility.ToBinary("" + n.getExtension().charValue());
				}
			}
		}
		int remainder = 16 - (output.length() % 16);
		for(int i = 0; i < remainder; i++)
		{
			output += "0";
		}
		return output;
	}
	
	public static String decode(String compressed)
	{
		if(compressed.length() < 32)
			return "";
		int codeSize = Integer.parseInt(compressed.substring(0, 32), 2);
		if(codeSize == 0)
			return "";

		LZTrie trie = new LZTrie();
		int begin = 32;
		int offset = codeSize + 16;
		int index = 1;
		while(begin + offset < compressed.length())
		{
			int code = Integer.parseInt(compressed.substring(begin, begin + codeSize), 2);
			char extension = LZUtility.FromBinary(compressed.substring(begin + codeSize, begin + offset)).charAt(0);
			String prefix = trie.get(code);
			trie.put(index, prefix + extension);
			begin = begin + offset;
			index++;
		}
		if(compressed.length() - begin >= codeSize)
		{
			int code = Integer.parseInt(compressed.substring(begin, begin + codeSize), 2);
			String prefix = trie.get(code);
			trie.put(index, prefix);
		}
		
		String output = "";
		ArrayList<String> values = trie.getValues();
		for(String s : values)
		{
			output += s;
		}
		return output;
	}
}
