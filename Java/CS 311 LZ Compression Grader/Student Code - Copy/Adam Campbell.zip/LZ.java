

import java.util.ArrayList;
import java.util.List;

/** 
 * A class to do LZ things 
 * @author Adam Campbell 
 */
public class LZ {
	private LZ() {
		// Thou shalt not instantiate
	}
	
	/** A class to hold a code point (dictionary index & char) */
	private static class CodePoint {
		protected int dicIndex;
		private char endChar;
		
		public CodePoint(int dicIndex, char endChar) {
			this.dicIndex = dicIndex;
			this.endChar = endChar;
		}
		
		public String toString(int codewordSize) {
			return Util.intToPaddedBinary(dicIndex, codewordSize) + Util.intToPaddedBinary(endChar, 16);
		}
	}
	
	/** A final code point, with just an index */
	private static class FinalCodePoint extends CodePoint { 
		public FinalCodePoint(int dicIndex) {
			super(dicIndex, '\0');
		}
		
		@Override 
		public String toString(int codewordSize) {
			return Util.intToPaddedBinary(dicIndex, codewordSize);
		}
	}
	
	/** Encode a string using LZ */
	public static String encode(String uncompressed) {
		// List of code points
		List<CodePoint> codePoints = new ArrayList<>();
		
		// Our dictionary
		LZDictionary dic = new Trie(256);
		
		// A stringbuilder to build up phrases
		StringBuilder phrase = new StringBuilder();
		
		// Go through each char and look for phrases
		for (int i=0; i < uncompressed.length(); i++) {
			char c = uncompressed.charAt(i);
			phrase.append(c);
			
			// A phrase occurs when we have something not already in the dictionary
			if (!dic.containsPhrase(phrase.toString())) {
				// add the new phrase
				dic.addPhrase(phrase.toString());
				
				// emit the code point for this phrase
				String prefix = phrase.toString().substring(0, phrase.toString().length() - 1);
				int index = dic.getIndex(prefix);
				codePoints.add(new CodePoint(index, c));
				
				// Reset the phrase builder
				phrase = new StringBuilder();
			}
		}
		
		// If our final phrase is already in the dictionary, merely emit its index
		if (phrase.length() > 0 && dic.containsPhrase(phrase.toString())) {
			codePoints.add(new FinalCodePoint(dic.getIndex(phrase.toString())));
		}
		
		// Compute the codeword size & append it to the result
		int codewordSize = (int)Math.ceil(Math.log(dic.size() + 1)/Math.log(2));
		StringBuilder result = new StringBuilder();
		result.append((char)(codewordSize >> 16));
		result.append((char)(codewordSize & 0xFFFF));

		// Add each codepoint to a binary string 
		StringBuilder codepointString = new StringBuilder();
		for (CodePoint cp : codePoints) {
			codepointString.append(cp.toString(codewordSize));
		}

		// Make sure it's a multiple of 16 bits
		while (codepointString.length() % 16 != 0) {
			codepointString.append("0");
		}
		
		// Convert the binary string to actual binary and add to the result
		for (int i=0; i < codepointString.length(); i += 16) {
			char c = 0;
			for (int j=0; j < 16; j++) {
				if (codepointString.charAt(i + j) == '1') {
					c |= (1 << (15 - j));
				}
			}
			
			result.append(c);
		}
		
		// Hooray
		return result.toString();
	}
	
	/** Decode a string using LZ */
	public static String decode(String compressed) {
		StringBuilder result = new StringBuilder();
		LZDictionary dic = new Trie(256);
		
		int codewordSize = (compressed.charAt(0) << 16) | compressed.charAt(1);
		int bitNum=32;
		while (bitNum + codewordSize <= 16 * compressed.length()) {
			int index = 0;
			for(int j=0; j < codewordSize; j++) {
				// Get the bitNum'th bit in the compressed string
				byte b = (byte)((compressed.charAt(bitNum / 16) >> (15 - (bitNum % 16))) & 0x01);
				if (b == 1) {
					index |= (1 << (codewordSize - 1 - j));
				}
				bitNum++;
			}
			
			// Try to read the char after the codeword
			char c = 0x0000;
			boolean readWholeChar = true;
			for (int j=0; j < 16; j++) {
				// If we went too far, we were just reading padding - ignore
				if (bitNum == 16 * compressed.length()) {
					readWholeChar = false;
					break;
				}
				
				// Get the bitnum'th bit
				byte b = (byte)((compressed.charAt(bitNum / 16) >> (15 - (bitNum % 16))) & 0x01);
				if (b == 1) {
					c |= (1 << (15 - j));
				}
				bitNum++;
			}
			
			// If we read a char, emit the phrase and add it to the dictionary
			if (readWholeChar) {
				String newPhrase = dic.getPhrase(index) + c;
				result.append(newPhrase);
				dic.addPhrase(newPhrase);
			} 
			
			else {
				String newPhrase = dic.getPhrase(index);
				result.append(newPhrase);
			}
		}
		
		return result.toString();
	}
}
