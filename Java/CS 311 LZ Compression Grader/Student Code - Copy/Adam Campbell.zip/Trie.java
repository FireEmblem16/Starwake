

/** 
 * A trie class fulfilling our Dictionary role
 * @author Adam Campbell
 */
public class Trie implements LZDictionary {
	// Root of the trie
	private Node root;
	
	// Number of children of each node
	private int radix;
	
	// Counter for the index (insertion order)
	private int dictionaryIndexCounter;
	
	// The number of nodes in the trie, not including the root
	private int size;

	/** A node in the trie */
	private class Node {
		private int dictionaryIndex; // order index it was added
		private Node[] children; // children of the node

		public Node() {
			this.dictionaryIndex = dictionaryIndexCounter++;
			this.children = new Node[radix];
		}
	}

	public Trie(int radix) {
		// If n is a power of 2, then (n & -n) == n
		if(radix <= 1 || (radix & -radix) != radix){
			throw new IllegalArgumentException("Radix must be 2^n, n >= 1");
		}

		this.radix = radix;
		this.root = new Node();
		this.size = 0;
	}

	@Override
	public boolean containsPhrase(String phrase){
		Node current = root;

		// Iterate through every character in the phrase
		for(int i = 0; i < phrase.length(); i++){
			char c = phrase.charAt(i);

			if(current.children[getChildIndex(c)] == null){
				// The string must not be in the trie 
				return false;
			}
			
			current = current.children[getChildIndex(c)];
		}
		
		// We reached the end of the string so it's in the trie
		return true;
	}

	@Override
	public void addPhrase(String phrase){
		Node current = root;

		// Iterate through every character in the phrase
		for(int i = 0; i < phrase.length(); i++){
			char c = phrase.charAt(i);

			if(current.children[getChildIndex(c)] == null){
				// found an empty spot for the phrase
				Node newNode = new Node();
				current.children[getChildIndex(c)] = newNode;
				size++;
			}

			current = current.children[getChildIndex(c)];
		}
	}

	@Override
	public int getIndex(String phrase){
		Node current = root;

		// Iterate through every character in the phrase
		for(int i = 0; i < phrase.length(); i++){
			char c = phrase.charAt(i);

			if(current.children[getChildIndex(c)] == null){
				// Oops, phrase doesn't exist
				throw new IllegalArgumentException("Phrase \"" + phrase + "\" doesn't occur in this trie.");
			}

			current = current.children[getChildIndex(c)];
		}

		return current.dictionaryIndex;
	}
	
	@Override
	public String getPhrase(int index){
		if (index < 0 || index >= dictionaryIndexCounter) {
			throw new IllegalArgumentException("Error: index \"" + index + "\" does not exist");
		}
		
		return getPhraseRec(root, "", index);
	}
	
	private String getPhraseRec(Node node, String acc, int index) {
		/* DFS index search using recursive accumulation */
		
		// Found a matching index, return the accumulated string 
		if (node.dictionaryIndex == index) {
			return acc;
		}
		
		// Else check all the children. If a child has it, accumulate and return
		for (int i=0; i < node.children.length; i++) {
			if (node.children[i] != null) { 
				String phrase = getPhraseRec(node.children[i], acc + getCharFromIndex(i), index);
				if (phrase != null) {
					return phrase;
				}
			}
		}
		
		// No index found anywhere, return null
		return null;
	}
	
	@Override
	public int size() {
		return size;
	}

	private int getChildIndex(char c){
		// we know radix is 2^n, so just get the lower n bits of c
		return c & (radix - 1);
	}
	
	private char getCharFromIndex(int index) {
		return (char) index;
	}

	// Print the trie for debugging purposes
	private void printTrie(String s, Node node, int offset){
		for(int i = 0; i < offset; i++){
			System.out.print(" ");
		}
		System.out.println(s);

		for(int i = 0; i < node.children.length; i++){
			if(node.children[i] != null){
				printTrie("" + (char) i, node.children[i], offset + 2);
			}
		}
	}

	// Print the trie for debugging purposes
	public void printTrie(){
		System.out.print("[root]");
		printTrie("", root, 0);
	}
}
