

/**
 * Util stuff
 * @author Adam Campbell
 */
public class Util {
	public static String intToPaddedBinary(int value, int size){
		String ret = Integer.toBinaryString(value);
		while(ret.length() < size){
			ret = "0" + ret;
		}

		return ret;
	}
}
