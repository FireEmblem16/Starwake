Adam Campbell
Com S 311 - HW4
Lempel-Ziv String Compression
2014-10-22


All classes are in the default package. LZ.java contains the encode() and decode() methods as per the spec, LZDictionary.java specifies the interface for a dictionary to be used by LZ, Trie.java contains the implementation of LZDictionary using a trie data structure, and Util.java contains static utility methods.