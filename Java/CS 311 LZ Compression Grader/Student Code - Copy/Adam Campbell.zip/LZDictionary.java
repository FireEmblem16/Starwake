

/** Dictionary to be used in compression/decompression */
public interface LZDictionary {
	// Is this phrase in the dictionary?
	boolean containsPhrase(String phrase);
	
	// Add a phrase to the dictionary
	void addPhrase(String phrase);
	
	// Get the index (insertion order) of this phrase
	int getIndex(String phrase);
	
	// Get the phrase for a certain index
	String getPhrase(int index);
	
	// How many phrases are in the dictionary
	int size();
}
