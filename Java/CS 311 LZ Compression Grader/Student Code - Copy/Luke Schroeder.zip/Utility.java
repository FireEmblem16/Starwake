/*
 * implementation of a trie data structure
 *
 * @author Luke Schroeder
 */
public final class Utility {
    public static String convertString(String s){
        String ret = "";
        for (int i = 0; i < s.length(); i += 8) {
            ret += (char) Long.parseLong(s.substring(i, i + 8), 2);
        }
        return ret;
    }

    public static String pad(String s, int size){
        if(s.length() == size){
            return s;
        } else if(s.length() > size) {
            return s.substring(s.length() - size);
        } else {
            StringBuilder ret = new StringBuilder(s);
            while(ret.length() < size){
                ret.insert(0, "0");
            }
            return ret.toString();
        }
    }

    public static String pad(String s){
        while(s.length() % 16 != 0){
            s+="0";
        }
        return s;
    }

    // Modified from Donald Nye's blackboard announcement
    public static String ToBinary(String str)
    {
        final char[] masks = {0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
        String ret = "";

        for(int i = 0;i < str.length();i++)
        {
            char c = str.charAt(i);

            for(int j = 0;j < 8;j++)
                if((c & masks[j]) == 0)
                    ret += "0";
                else
                    ret += "1";
        }

        return ret;
    }

}
