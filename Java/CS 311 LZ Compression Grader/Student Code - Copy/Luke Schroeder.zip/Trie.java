import java.util.ArrayList;

import java.util.Collections;

import java.lang.IllegalArgumentException;

/*
 * implementation of a trie data structure
 *
 * @author Luke Schroeder
 */
public class Trie extends Dictionary {
    // reference to the head of the trie
    private Node head;

    private int size;

    public Trie(){
        // create the λ prefix
        this.head = new Node(null, 0);

        this.size = 0;
    }

    public void add(String s){
        Node parent = this.head;

        for(int i = 0; i < s.length() - 1; i++){
            int index = (int)s.charAt(i);
            parent = parent.children.get(index);
        }

        char last = s.charAt(s.length() - 1);
        parent.children.set((int)last, new Node(parent, ++this.size));
    }

    public void add(int index, int dir){
        Node parent = this.head;

        if(0 == index){
            this.add("" + (char)dir);
        } else {
            ArrayList<Node> arr = new ArrayList<Node>();
            gather(arr, this.head);
            Collections.sort(arr);
            this.add(arr.get(index).toString() + (char)dir);
        }
    }

    public boolean contains(String s){
        Node parent = this.head;
        for(int i = 0; i < s.length(); i++){
            int index = (int)s.charAt(i);
            parent = parent.children.get(index);
            if(null == parent) return false;
        }
        return true;
    }

    public String toString(ArrayList<String> parsed){
        StringBuilder codeword = new StringBuilder();
        int size = (int)Math.ceil(Math.log(parsed.size() + 1) / Math.log(2));
        codeword.append(Utility.pad(Integer.toBinaryString(size), 32));
        for(int i = 0; i < parsed.size() - 1; i++){
            codeword.append(this.head.get(parsed.get(i).toCharArray(), size, false));
        }
        int length = parsed.size() - 1;
        codeword.append(this.head.get(parsed.get(length).toCharArray(), size, this.contains(parsed.get(length))));
        return Utility.convertString(Utility.pad(codeword.toString()));
    }

    private int load(String compressed){
        // the ToBinary method is not working correctly, causing incorrect data
        // to be generated which give rise to exceptions
        // I have attempted to rectify these issues via modifications to the
        // provided ToBinary method
        String data = Utility.ToBinary(compressed);
        int size = Integer.parseInt(data.substring(0, 32), 2);
        int length = (data.length() - 32) / (size + 16);
        for(int i = 0; i < length; i++){
            int start = 32 + i * (size + 16);
            int index = Integer.parseInt(data.substring(start, start + size), 2);
            int dir = Integer.parseInt(data.substring(start + size, start + size + 16), 2);
            System.out.println(index);
            System.out.println(dir);
            System.out.println((char)dir);
            this.add(index, dir);
        }
        int trail = -1;
        return trail;
    }

    public String toPlaintext(String compressed){
        int trail = this.load(compressed);
        return this.head.traverse(trail);
    }

    /*
     * Data structure to persist the trie's contents
     */
    private final class Node implements Comparable<Node>{
        // reference to the node's parent, null if node is the head
        public Node parent;

        public int index;

        // list for the node's children, capacity of 256 for ASCII characters
        public ArrayList<Node> children;

        public Node(Node parent, int index){
            this.children = new ArrayList<Node>(Collections.nCopies(256, (Node)null));
            this.index = index;
        }

        public String get(char[] in, int size, boolean trail){
            // this only should be called on head
            if(null != this.parent) throw new IllegalArgumentException();
            Node n = this;
            for(int i = 0; i < in.length - 1; i++) {
                n = n.children.get((int)in[i]);
            }
            StringBuilder out = new StringBuilder();
            if(!trail) {
                String index = Integer.toBinaryString(n.index);
                index = Utility.pad(index, size);
                out.append(index);
                out.append(Utility.pad(Integer.toBinaryString(in[in.length - 1]), 16));
            } else {
                n = n.children.get((int)in[in.length - 1]);
                String index = Integer.toBinaryString(n.index);
                index = Utility.pad(index, size);
                out.append(index);
            }
            return out.toString();
        }

        public int compareTo(Node n){
            return this.index - n.index;
        }

        public String traverse(int trail){
            // this only should be called on head
            if(null != this.parent) throw new IllegalArgumentException();
            String ret = "";
            ArrayList<Node> arr = new ArrayList<Node>();
            gather(arr, this);
            Collections.sort(arr);
            for(Node n : arr){
                ret += arr.toString();
            }
            if(-1 != trail){
                ret += arr.get(trail).toString();
            }
            return ret;
        }

        public String toString(Node n){
            String ret = "";
            while(null != n.parent){
                ret += (char)n.index;
                n = n.parent;
            }
            return ret;
        }
    }

    public static void gather(ArrayList<Node> arr, Node n){
        for(Node c : n.children){
            if(null != c){
                arr.add(c);
                gather(arr, c);
            }
        }
    }
}

