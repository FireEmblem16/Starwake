import java.util.ArrayList;

/*
 * @author  Luke Schroeder
 */
public class LZ {
    // Private c'tor for non-instantiable class
    private LZ(){
        // TODO
    }

    /*
     * Compress a supplied string using the LZ78 compression algorithm
     *
     * @param   uncompressed    The data to be compressed.
     * @return  The compressed data.
     */
    public static String encode(String uncompressed){
        Trie t = new Trie();
        ArrayList parsed = new ArrayList<String>();
        for(int i = 0; i < uncompressed.length();){
            boolean added = false;
            for(int j = i + 1; !added; j++){
                String s = uncompressed.substring(i, j);
                if(!t.contains(s)){
                    t.add(s);
                    parsed.add(s);
                    added = true;
                    i = j;
                } else if(j == uncompressed.length()){
                    parsed.add(s);
                    added = true;
                    i = j;
                }
            }
        }
        return t.toString(parsed);
    }

    /*
     * Decompress string copmressed by LZ78 compression algorithm
     *
     * @param   compressed    The data to be decompressed.
     * @return  The uncompressed data.
     */
    public static String decode(String compressed){
        Trie t = new Trie();
        return t.toPlaintext(compressed);
    }
}
