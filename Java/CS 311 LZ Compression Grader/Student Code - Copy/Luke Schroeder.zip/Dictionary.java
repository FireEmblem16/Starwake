import java.util.ArrayList;

/*
 * superclass for storing dictionaries for LZ compression
 *
 * @author Luke Schroeder
 */
public abstract class Dictionary {
    /*
     * Add the argument to the dictionary.
     * It is assumed the the prefix of s already has been added.
     *
     * @param   s   Element to be added to the dictionary
     */
    abstract public void add(String s);

    /*
     * @return  True if the dictionary contains the string s, false otherwise
     */
    abstract public boolean contains(String s);

    /*
     * Display the contents of the dictionary.
     *
     * @param   the parsed uncompressed input
     * @return  Stringified version of the dictionary's contents
     */
    abstract public String toString(ArrayList<String> parsed);

    /*
     * Load the contents of a compressed string into the dictionary.
     * It is assumed that the input is valid.
     *
     * @param   compressed
     */
    abstract public String toPlaintext(String compressed);
}
