package lzzip;

public class LZ {
	
	public static void main(String[] args) {
		System.out.println(decode("00000000000000000000000000000101000000000000001010100000000000000001101000000000000000001100101000000000000000100000000000000000001110111000000000000001101111000000000000001110010000000000000001101100000000000000001100100001000000000001101001000000000000001110011001000000000001100110000000000000001110101010000000000001101100001000000000001101111000000000000001100110001000000000001110011011010000000001100111000000000000001100001001110000000000100001000000000000"));
		System.out.println(decode(encode("The world is full of sugar!")));
		System.out.println(decode("0000000000000000000000000000010100000000000000101001100000000000000111010100000000000000110011100000000000000110000100000000000000111001000000000000000010000100000000000000010000000001000000000111010100011000000000110000100101000000000010000100111000000000101001100010000000000110011100100000000000111001000110000000000010000001000000000000110011101101000000000010000101011000000000111010101001000000000111001001110000000000101001101100000000000110000101010000000000010000001111000000000110000110101000000000101001110100000000000111001000110000"));
		System.out.println(decode(encode("Sugar! Sugar! Sugar! Sugar! Sugar! Sugar! Sugar! Sugar!")));
	}
	
	private LZ() {
		
	}
	
	public static String encode(String uncompressed) {
		if(uncompressed.equals("")) return "00000000000000000000000000000000";
		
		Trie root = new Trie("", 0, -1);
		Trie[] ordered = new Trie[uncompressed.length() + 5];
		ordered[0] = root;
		
		ordered = Parse(uncompressed, ordered);
		int index = 0;
		while(ordered[index] != null) {
			index++;
		}
		
		return Compressor(index, ordered);
	}
	
	private static String Compressor(int index, Trie[] ordered) {
		int f = (int) Math.ceil(Math.log(index + 1)/Math.log(2));

		String compr = "";
		String first = Integer.toBinaryString(f);
		
		for(int i = 0; i < (32 - first.length()); i++) {
			compr += "0";
		}
		
		compr += first;
		
		for(int i = 1; i < index; i++) {
			for(int j = 0; j < (5 - Integer.toBinaryString(ordered[i].prev).length()); j++) {
				compr += "0";
			}
			compr += Integer.toBinaryString(ordered[i].prev);
			
			for(int j = 0; j < (16 - ToBinary(ordered[i].code).length()); i++) {
				compr += "0";
			}
			compr += ToBinary(ordered[i].code);
		}
		while(compr.length() % 16 != 0) {
			compr += "0";
		}
		
		return compr;
	}

	public static String decode(String compressed) {
		String uncompr = compressed;
		
		if(uncompr.equals("00000000000000000000000000000000")) return "";
		
		int indexSize = Integer.parseInt(uncompr.substring(0, 32), 2);
		
		Trie root = new Trie("", 0, -1);
		Trie[] ordered = new Trie[compressed.length()];
		Trie cur = root;
		int index = 1;
		
		uncompr = uncompr.substring(32);
		while(uncompr.length() >= indexSize) {
			if(uncompr.length() >= indexSize + 16 && cur.children[Integer.parseInt(uncompr.substring(indexSize, indexSize + 16), 2)] == null) {
				cur.children[Integer.parseInt(uncompr.substring(indexSize, indexSize + 16), 2)] = new Trie(String.valueOf((char) Integer.parseInt(uncompr.substring(indexSize, indexSize + 16), 2)), index, Integer.parseInt(uncompr.substring(0, indexSize), 2));
				ordered[index] = cur.children[Integer.parseInt(uncompr.substring(indexSize, indexSize + 16), 2)];
				uncompr = uncompr.substring(indexSize + 16);
				index ++;
				cur = root;
			}
			else if(uncompr.length() <= indexSize + 16) {
//				ordered[index] = ordered[Integer.parseInt(uncompr.substring(0, indexSize))];
//				ordered[index].code = "";
				break;
			}
			else {
				cur = cur.children[Integer.parseInt(uncompr.substring(indexSize, indexSize + 16), 2)];
			}
		}
		
		return TrieToString(ordered);
	}
	
	static String TrieToString(Trie[] ordered) {
		String uncompr = "";
		
		for(int i = 1; ordered[i] != null; i ++) {
			String tmp = "";
			int x = i;
			while(ordered[x] != null && ordered[x].prev != 0) {
				tmp += ordered[ordered[x].prev].code;
				x = ordered[x].prev;
			}
			uncompr += new StringBuilder(tmp).reverse().toString();
			uncompr += ordered[i].code;
		}
		
		return uncompr;
	}

	/*
	 * The following were distributed by Don Nye
	 */
	public static String ToBinary(String str)
	{
		final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i++)
		{
			char c = str.charAt(i);
			
			for(int j = 0;j < 16;j++)
				if((c & masks[j]) == 0)
					ret += "0";
				else
					ret += "1";
		}
		
		return ret;
	}	

	public static String FromBinary(String str)
	{
		final char[] bits = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
		String ret = "";
		
		for(int i = 0;i < str.length();i += 16)
		{
			char c = 0x0000;
			
			for(int j = 0;j < 16;j++)
				if(str.charAt(i + j) == '1')
					c |= bits[j];
			
			ret += c;
		}
		
		return ret;
	}
	
	/*
     * This is my stuff again
     */
	public static Trie[] Parse(String str, Trie[] ordered) {
		int index = 1;
		
		for(int i = 0; i < str.length(); i++) {
			Trie cur = ordered[0];
			int count = cur.index;
			while(i < str.length() && cur.children[str.toCharArray()[i]] != null) {
				cur = cur.children[str.toCharArray()[i]];
				count = cur.index;
				i++;
			}
			if(i >= str.length()) {
				break;
			}
			ordered[count].AddNode(ordered[count], String.valueOf(str.charAt(i)), index);
			ordered[index] = ordered[count].children[str.charAt(i)];
			index++;
		}
		//System.out.println("index:" + index);
		return ordered;
//		Trie[] ord = ordered;
//		int index = 1;
//		
//		for(int i = 0; i < str.length(); i++) {
//			Trie cur = ord[0];
//			int x = i;
//			int addStartInd = x;
//			
//			while(cur != null) {	
//				if(Trie.Search(cur, String.valueOf(str.charAt(i))) == true) {
//					if(addStartInd != x) addStartInd = i;
//					cur = cur.children[(int) str.charAt(i)];
//					i++;
//				}
//				else {
//					cur.AddNode(cur, str.substring(addStartInd, i), index);
//					ord[index] = cur.children[(int) str.charAt(i)];
//					index++;
//					break;
//				}
//			}	
//		}
//		return ord;
		}
}

class Trie {
	String code;
	Trie[] children;
	int index;
	int prev;
	
	Trie(String code, int index, int prev) {
		this.code = code;
		children = new Trie[256];
		this.prev = prev;
		this.index = index;
	}
	
	public void AddNode(Trie root, String str, int index) {
		Trie cur = root;
		int len = str.length();
		char[] ans = str.toCharArray();
		
		for(int i = 0; i < len; i++) {
			if(cur.children[ans[i]] == null) {
				cur.children[ans[i]] = new Trie(String.valueOf(ans[i]), index, root.index);
				cur = cur.children[ans[i]];
			}
		}
	}
	
	public static boolean Search(Trie root, String str) {
		char[] ans = str.toCharArray();
		int len = str.length();
		Trie cur = root;
		
		int i;
		for(i = 0; i < len; i++) {
			if(cur == null) return false;
			
			cur = cur.children[ans[i]];
		}
		
		return true;		
	}
}

