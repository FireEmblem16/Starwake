import java.util.ArrayList;

/**
 * Created with IntelliJ IDEA.
 * User: cale
 * Date: 10/20/14
 * Time: 11:25 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LZDict {

    public int add(String s);
    public int add(int prevIndex, char c);
    public boolean contains(String s);
    public String getString(int i);
    public char getChar(int i);
    public int size();

    int indexOf(String string);
    int getParentIndex(int index);
}
