import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created with IntelliJ IDEA.
 * User: cale
 * Date: 10/13/14
 * Time: 11:21 PM
 * To change this template use File | Settings | File Templates.
 */
public class Trie implements LZDict {
    class Node {
        Character value;
        HashMap<Character,Node> subnodes;
        Node parent;

        public Node(Character value, Node parent) {
            this.value = value;
            this.parent = parent;
            subnodes = new HashMap<Character, Node>();
        }

        public String toString() {
            return "Node(" + value + parent + ")";
        }
    }

    Node root = new Node(null, null); // the null string representing lambda

    ArrayList<Node> nodeList = new ArrayList<Node>();


    public Trie () {
        nodeList.add(root);
    }

    public int add(String s) {
        if (s.equals("")) return 0;
        int i = 0;
        Character c = s.charAt(i);
        Node prevNode = root;
        if (prevNode.subnodes != null) {
            while (prevNode.subnodes.containsKey(c) && i < s.length()) {
                prevNode = prevNode.subnodes.get(c);
                i++;
                c = s.charAt(i);
            }
        }
        c = s.charAt(i);
        Node newNode = new Node(c, prevNode);
        prevNode.subnodes.put(c, newNode);
        prevNode = newNode;
        nodeList.add(prevNode);
        return nodeList.size() - 1;
    }

    public boolean contains(String s) {
        String currString = "";
        if (s.equals("")) return true;
        int charCount = 0;
        Node currNode = root;
        while (s.contains(currString) && charCount < s.length()) {
            char currChar = s.charAt(charCount);
            if (currNode.subnodes.containsKey(currChar)) {
                currNode = currNode.subnodes.get(currChar);
                charCount++;
                currString = currString + currChar;
            } else return false;
        }
        return true;
    }

    @Override
    public String getString(int i) {
        String s = "";
        Node leaf = nodeList.get(i);
        while (leaf.parent != null) {
            s = leaf.value + s;
            leaf = leaf.parent;
        }
        return s;
    }

    @Override
    public char getChar(int i) {

        return nodeList.get(i).value;
    }

    @Override
    public int size() {
        return nodeList.size();
    }

    @Override
    public int indexOf(String string) {
        return nodeList.indexOf(string);
    }

    @Override
    public int add(int prevIndex, char c) {
        Node prevNode;
        if (prevIndex == 0) prevNode = root;
        else prevNode = nodeList.get(prevIndex);
        Node newNode = new Node(c, prevNode);
        prevNode.subnodes.put(c, newNode);
        nodeList.add(newNode);
        return nodeList.indexOf(newNode);
    }

    @Override
    public int getParentIndex(int index) {
        return nodeList.indexOf(nodeList.get(index).parent);
    }
}
