import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: cale
 * Date: 10/22/14
 * Time: 11:52 AM
 * To change this template use File | Settings | File Templates.
 */
public class LZTest {

    String binWizard = "0000000000000000000000000000011000000000000000010001000000000000000001101111000000000000000010000000000000000000011011100000100000000001110100000011000000000110110100000000000000011001010000000000000001100100001000000000000110110000011100000000001000000000000000000001101001000100000000000010000000000000000000011101000000000000000001101000001010000000000110000100000000000000011001100100000000000001100001001011000000000111001000000000000000011100110000110000000001101111010000000000000010000000000000000000011101110010110000000001111010000000000000000110000100000000000000011100100010000000000001110011000000000000000010110000001100000000011001100000100000000001110010000011000000000111010000111000000000011001010000000000000001111001000011000000000110000101100100000000011001010000110000000001110011000000000000000111010100000000000000011000100011010000000001101100001111000000000110111000100000000000001000000000000000000001110001100100000000000110100100000000000000011000110000000000000001101011011110000000000110111110000100000000011011100000000000000001100111000111000000000111001000000000000000001011100000000000";
    @Test
    public void testEncode() throws Exception {
        String result = ToBinary(LZ.encode("Do not meddle in the affairs of wizards, for they are subtle and quick to anger."));
        System.out.println(result);
        assert binWizard.equals(result);
    }

    @Test
    public void testDecode() throws Exception {
        String result = LZ.decode(FromBinary(binWizard));
        assert result.equals("Do not meddle in the affairs of wizards, for they are subtle and quick to anger.");
    }

    /*
    The following is from conversion.txt, sent out via email/BlackBoard from Donald Nye on Oct 8.
     */

    public static String ToBinary(String str)
    {
        final char[] masks = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
        String ret = "";

        for(int i = 0;i < str.length();i++)
        {
            char c = str.charAt(i);

            for(int j = 0;j < 16;j++)
                if((c & masks[j]) == 0)
                    ret += "0";
                else
                    ret += "1";
        }

        return ret;
    }

    public static String FromBinary(String str)
    {
        final char[] bits = {0x8000,0x4000,0x2000,0x1000,0x800,0x400,0x200,0x100,0x80,0x40,0x20,0x10,0x8,0x4,0x2,0x1};
        String ret = "";

        for(int i = 0;i < str.length();i += 16)
        {
            char c = 0x0000;

            for(int j = 0;j < 16;j++)
                if(str.charAt(i + j) == '1')
                    c |= bits[j];

            ret += c;
        }

        return ret;
    }

}
