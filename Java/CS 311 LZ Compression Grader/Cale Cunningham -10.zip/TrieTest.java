import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: cale
 * Date: 10/22/14
 * Time: 11:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class TrieTest {
    @Test
    public void testAdd() throws Exception {
        Trie trie = new Trie();

        trie.add("a");
        trie.add("aa");

        assert trie.nodeList.toString().equals("[Node(nullnull), Node(aNode(nullnull)), Node(aNode(aNode(nullnull)))]");
    }

    @Test
    public void testContains() throws Exception {
        Trie trie = new Trie();

        trie.add("a");
        trie.add("aa");

        assert trie.contains("a") == true;
        assert trie.contains("aa") == true;
        assert trie.contains("b") == false;
        assert trie.contains("") == true;
    }

    @Test
    public void testGetString() throws Exception {
        Trie trie = new Trie();

        trie.add("a");
        trie.add("aa");
        trie.add("ab");

        assert trie.getString(0).equals("");
        assert trie.getString(1).equals("a");
        assert trie.getString(3).equals("ab");
    }

    @Test
    public void testGetChar() throws Exception {

    }

    @Test
    public void testIndexOf() throws Exception {

    }

    @Test
    public void testAdd2() throws Exception {

    }

    @Test
    public void testGetParentIndex() throws Exception {

    }
}
