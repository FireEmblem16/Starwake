import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.BitSet;

/**
 * Created with IntelliJ IDEA.
 * User: cale250
 * Date: 10/13/14
 * Time: 9:51 PM
 *
 */
public class LZ {

    private LZ() {}

    public static String encode(String uncompressed) {
        LZDict dict = new Trie();
        int i = 0; // string iterator value
        while (i < uncompressed.length()) {
            int j = i;
            while (dict.contains(uncompressed.substring(i, j)) && (i + (j - i) < uncompressed.length())) {
                j++;
            }
            dict.add(uncompressed.substring(i, j));
            i = j;
        }
        int bitSize = (int) Math.ceil(Math.log(dict.size())/Math.log(2));
        String finalString = packData(dict, bitSize);

        byte[] bytes = ByteBuffer.allocate(4).putInt(bitSize).array(); // http://stackoverflow.com/questions/2183240/java-integer-to-byte-array
        finalString = new String(bytes) + finalString;
        return finalString;
    }

    public static String decode(String compressed) {
        LZDict dict = new Trie();
        return unpackData(dict, compressed);
    }

    private static String packData(LZDict dict, int bitSize) {
        String bitString = "";
        int ptr = 0;
        for (int i = 1; i < dict.size(); i++) {
            int index = dict.getParentIndex(i);
            String indexString = Integer.toString(index, 2);
            if (indexString.length() < bitSize) {
                for (int m = 0; m < (bitSize - indexString.length()); i++) indexString = "0" + indexString;
            }
            bitString = bitString + indexString;
            try {
                char c = dict.getChar(i);
                String charString = "" + c;
                String binaryChar = LZTest.ToBinary(charString);
                bitString = bitString + binaryChar;
            } catch (IndexOutOfBoundsException e) {
                bitString = bitString + "";
            }
        }

        if (bitString.length() % 16 != 0) {
            int toAdd =  16 - (bitString.length() % 16);
            for (int n = 0; n < toAdd; n++) {
                bitString = bitString + "0";
            }
        }

        return LZTest.FromBinary(bitString);
    }

    private static String unpackData(LZDict dict, String compressed) {
        byte[] data = compressed.getBytes();
        String binString = LZTest.ToBinary(compressed);
        int bitLength = Integer.parseInt(binString.substring(0, 32), 2); // should be using unsigned here, but I doubt we're compiling with Java 8 right now and I don't want to mess with it
        //System.out.println("Bit Length = " + bitLength);
        //System.out.println("Binary String Length = " + binString.length());
        //System.out.println(binString);
        int i = 32;
        boolean done = false;
        while (i < binString.length() && !done) {
            String indString = binString.substring(i, i + bitLength);
            int index = Integer.parseInt(indString, 2);
            //System.out.println(index);
            if (binString.length() > i + bitLength + 16) {
                String charString = binString.substring(i + bitLength, i + bitLength + 16);
                char c = LZTest.FromBinary(charString).charAt(0);
                //System.out.println(c);
                i = i + bitLength + 16;
                //System.out.println(i);
                dict.add(index, c);
            } else {
                done = true;
                dict.add(index, (char) 0);
            }
        }

        String s = "";
        for (int j = 0; j < dict.size() - 1; j++) {
            s = s + dict.getString(j);
            //System.out.println(s);
        }
        return s;
    }

}
