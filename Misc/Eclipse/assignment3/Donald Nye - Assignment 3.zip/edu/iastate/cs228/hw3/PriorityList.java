package edu.iastate.cs228.hw3;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * Manages a doubly linked list of objects of type [E].
 * Provides priority levels for the list so that objects
 * with the same priority may be added, removed, iterated
 * over, etc... as a sublist of the whole list as if it
 * were a list of its own.
 * @author Donald Nye
 */
public class PriorityList<E> implements List<E>, IPriorityList<E>
{
	/**
	 * Creates a new PriorityList with the ability to have
	 * [priority_levels] number of priority levels from 0
	 * to [priority_levels] - 1.
	 * @author Donald Nye
	 * @throws IllegalArgumentException - if [priority_levels] is
	 * less than one.
	 */
	public PriorityList(int priority_levels)
	{
		head = new Node(null, null, null);
		tail = head;
		size = 0;
		
		if(priority_levels < 1)
			throw new IllegalArgumentException();
		
		p_ptr = (PriorityPointer<E>[])Array.newInstance(PriorityPointer.class, priority_levels);
		
		for(int i = 0; i < priority_levels; i++)
			p_ptr[i] = new PriorityPointer<E>(null,0);
		
		return;
	}
	
	@Override public boolean add(E e)
	{
		tail.setNext(new Node<E>(null, tail, e));
		tail = tail.getNext();
		size++;
		
		for(int i = p_ptr.length - 1; i >= 0; i--)
			if(p_ptr[i].start != null)
			{
				p_ptr[i].size++;
				break;
			}
			else if(i == 0)
			{
				p_ptr[0].start = tail;
				p_ptr[0].size = 1;
			}
		
		return true;
	}

	@Override public void add(int index, E element)
	{
		if(index < 0 || index > size)
			throw new IndexOutOfBoundsException();
		
		int i = 0;
		int p_index = i;
		int sum = 0;
		int last_sum = sum;
		
		while(i < p_ptr.length && sum <= index)
		{
			last_sum = sum;
			sum += p_ptr[i].size;
			
			if(p_ptr[i++].size > 0)
				p_index = i - 1;
		}
		
		if(index < (last_sum + sum - 1) >> 2 || p_index == p_ptr.length - 1 || p_index == i - 1)
		{
			Node<E> node = p_ptr[p_index].start;
			p_ptr[p_index].size++;
			size++;
			
			for(int j = 0; j < index - last_sum; j++)
				node = node.getNext();
			
			node.getPrevious().setNext(new Node<E>(node, node.getPrevious(), element));
			node.setPrevious(node.getPrevious().getNext());
			
			if(index - last_sum == 0)
				p_ptr[p_index].start = node.getPrevious();
		}
		else if(index == size)
			add(element);
		else
		{
			Node<E> node = p_ptr[i - 1].start;
			p_ptr[i - 1].size++;
			size++;
			
			for(int j = 0; j <= sum - index - 1; j++)
				node = node.getPrevious();
			
			node.getPrevious().setNext(new Node<E>(node, node.getPrevious(), element));
			node.setPrevious(node.getPrevious().getNext());
		}
		
		if(tail.getNext() != null)
			tail = tail.getNext();
		
		return;
	}

	@Override public boolean addAll(Collection<? extends E> c)
	{
		Iterator<? extends E> iter = c.iterator();
		boolean ret = false;
		
		while(iter.hasNext())
			if(ret)
				add(iter.next());
			else
				ret = add(iter.next());
		
		return ret;
	}

	@Override public boolean addAll(int index, Collection<? extends E> c)
	{
		Iterator<? extends E> iter = c.iterator(); 
		
		for(int i = index; iter.hasNext(); i++)
			add(i, iter.next());
		
		return true;
	}

	@Override public void clear()
	{
		head = new Node(null,null,null);
		size = 0;
		
		for(int i = 0; i < p_ptr.length; i++)
			p_ptr[i] = new PriorityPointer<E>(null,0);
		
		tail = head;
		
		return;
	}

	@Override public boolean contains(Object o)
	{
		Node<E> c = head;
		
		while(c.getNext() != null)
		{
			c = c.getNext();
			
			if(c.getValue() == o || o != null && o.equals(c.getValue()))
				return true;
		}
		
		return false;
	}

	/**
	 * Throws an UnsupportedOperationException.
	 */
	@Override public boolean containsAll(Collection c)
	{
		throw new UnsupportedOperationException();
	}

	@Override public E get(int index)
	{
		if(index >= size || index < 0)
			throw new IndexOutOfBoundsException();
		
		int i = 0;
		int sum = 0;
		
		for(; sum <= index; i++)
			sum += p_ptr[i].size;
		
		Node<E> c = p_ptr[--i].start;
		sum -= p_ptr[i].size;
		
		for(; sum < index; sum++)
			c = c.getNext();
		
		return c.getValue();
	}

	@Override public int indexOf(Object o)
	{
		Node<E> c = head;
		
		for(int i = 0; c.getNext() != null; i++)
		{
			c = c.getNext();
			
			if(c.getValue() == o || o != null && o.equals(c.getValue()))
				return i;
		}
		
		return -1;
	}

	@Override public boolean isEmpty()
	{
		return head.getNext() == null;
	}

	@Override public Iterator<E> iterator()
	{
		return new PriorityListIterator(-1);
	}

	/**
	 * Throws an UnsupportedOperationException.
	 */
	@Override public int lastIndexOf(Object o)
	{
		throw new UnsupportedOperationException();
	}

	@Override public ListIterator<E> listIterator()
	{
		return new PriorityListIterator(-1);
	}

	@Override public ListIterator<E> listIterator(int index)
	{
		if(index < 0 || index > size)
			throw new IndexOutOfBoundsException();
		
		return new PriorityListIterator(-1,index);
	}

	@Override public boolean remove(Object o)
	{
		Node<E> c = head;
		
		for(int i = 0; c.getNext() != null; i++)
		{
			c = c.getNext();
			
			if(c.getValue() == o || o != null && o.equals(c.getValue()))
			{
				int j = 0;
				
				for(int sum = -1; j < p_ptr.length && sum < i; j++)
					sum += p_ptr[j].size;
				
				p_ptr[--j].size--;
				
				if(p_ptr[j].start == c)
					if(p_ptr[j].size == 0)
						p_ptr[j].start = null;
					else
						p_ptr[j].start = p_ptr[j].start.getNext();
				
				c.getPrevious().setNext(c.getNext());
				
				if(c.getNext() != null)
					c.getNext().setPrevious(c.getPrevious());
				
				size--;
				return true;
			}
		}
		
		return false;
	}

	@Override public E remove(int index)
	{
		if(index < 0 || index >= size)
			throw new IndexOutOfBoundsException();
		
		Node<E> c = head.getNext();
		
		for(int i = 0; i < index; i++)
			c = c.getNext();
		
		int j = 0;
		
		for(int sum = -1; j < p_ptr.length && sum < index; j++)
			sum += p_ptr[j].size;
		
		p_ptr[--j].size--;
		
		if(p_ptr[j].start == c)
			if(p_ptr[j].size == 0)
				p_ptr[j].start = null;
			else
				p_ptr[j].start = p_ptr[j].start.getNext();
		
		c.getPrevious().setNext(c.getNext());
		
		if(c.getNext() != null)
			c.getNext().setPrevious(c.getPrevious());
		
		size--;
		return c.getValue();
	}

	/**
	 * Throws an UnsupportedOperationException.
	 */
	@Override public boolean removeAll(Collection c)
	{
		throw new UnsupportedOperationException();
	}

	/**
	 * Throws an UnsupportedOperationException.
	 */
	@Override public boolean retainAll(Collection c)
	{
		throw new UnsupportedOperationException();
	}

	@Override public E set(int index, E element)
	{
		if(index < 0 || index >= size)
			throw new IndexOutOfBoundsException();
		
		Node<E> c = head.getNext();
		
		for(int i = 0; i < index; i++)
			c = c.getNext();
		
		E ret = c.getValue();
		c.setValue(element);
		
		return ret;
	}

	@Override public int size()
	{
		return size;
	}

	/**
	 * Throws an UnsupportedOperationException.
	 */
	@Override public List subList(int fromIndex, int toIndex)
	{
		throw new UnsupportedOperationException();
	}
	
	/**
	 * Throws an UnsupportedOperationException.
	 */
	@Override public E[] toArray()
	{
		throw new UnsupportedOperationException();
	}

	/**
	 * Throws an UnsupportedOperationException.
	 */
	@Override public E[] toArray(Object[] a)
	{
		throw new UnsupportedOperationException();
	}

	@Override public void addWithPriority(int priority, E item)
	{
		if(priority > p_ptr.length - 1 || priority < 0)
			throw new IllegalArgumentException();
		
		Node<E> prev = null;
		Node<E> next = null;
		
		for(int i = priority + 1; i < p_ptr.length; i++)
			if(p_ptr[i].start != null)
			{
				next = p_ptr[i].start;
				break;
			}
			
		if(next == null)
			prev = tail;
		else
			prev = next.getPrevious();
		
		Node<E> new_node = new Node(next, prev, item);
		
		if(p_ptr[priority].start == null)
			p_ptr[priority].start = new_node;
		
		prev.setNext(new_node);
		
		if(next != null)
			next.setPrevious(new_node);
		else
			tail = new_node;
		
		p_ptr[priority].size++;
		size++;
		
		return;
	}

	@Override public int getMaxPriority()
	{
		return p_ptr.length - 1;
	}

	@Override public ListIterator<E> iteratorWithPriority(int priority)
	{
		if(priority > p_ptr.length - 1 || priority < 0)
			throw new IllegalArgumentException();
		
		return new PriorityListIterator(priority);
	}

	@Override public E removeWithPriority(int priority)
	{
		if(priority > p_ptr.length - 1 || priority < 0)
			throw new IllegalArgumentException();
		
		if(p_ptr[priority].start == null)
			throw new NoSuchElementException();
		
		E ret = p_ptr[priority].start.getValue();
		p_ptr[priority].size--;
		size--;
		
		if(p_ptr[priority].size == 0)
		{
			p_ptr[priority].start.getPrevious().setNext(p_ptr[priority].start.getNext());
			
			if(p_ptr[priority].start.getNext() != null)
				p_ptr[priority].start.getNext().setPrevious(p_ptr[priority].start.getPrevious());
			
			if(tail == p_ptr[priority].start)
				tail = p_ptr[priority].start.getPrevious();
			
			p_ptr[priority].start = null;
		}
		else
		{
			p_ptr[priority].start.getPrevious().setNext(p_ptr[priority].start.getNext());
			p_ptr[priority].start.getNext().setPrevious(p_ptr[priority].start.getPrevious());
			p_ptr[priority].start = p_ptr[priority].start.getNext();
		}
		
		return ret;
	}

	@Override public int sizeWithPriority(int priority)
	{
		if(priority > p_ptr.length - 1 || priority < 0)
			throw new IllegalArgumentException();
		
		return p_ptr[priority].size;
	}
	
	/**
	 * Contains a pointer forward and backwards in the LinkedList.
	 * Also has some data.
	 * @author Donald Nye
	 */
	private class Node<E>
	{
		/**
		 * Constructs a new Node.
		 * @param n
		 * The Node after this Node.
		 * @param p
		 * The Node before this Node.
		 * @param val
		 * The value of this Node.
		 */
		public Node(Node n, Node p, E val)
		{
			next = n;
			prev = p;
			data = val;
			
			return;
		}
		
		/**
		 * Returns the Node after this Node.
		 */
		public Node<E> getNext()
		{
			return next;
		}
		
		/**
		 * Returns the Node before this Node.
		 */
		public Node<E> getPrevious()
		{
			return prev;
		}
		
		/**
		 * Returns the value of this Node.
		 */
		public E getValue()
		{
			return data;
		}
		
		/**
		 * Sets the next Node after this Node.
		 * @param n
		 * The new Node after this Node.
		 */
		public void setNext(Node<E> n)
		{
			next = n;
			return;
		}
		
		/**
		 * Sets the previous Node before this Node.
		 * @param p
		 * The next Node before this Node.
		 */
		public void setPrevious(Node<E> p)
		{
			prev = p;
			return;
		}
		
		/**
		 * Sets the value stored in this Node.
		 * @param val
		 * The new value of this Node.
		 */
		public void setValue(E val)
		{
			data = val;
			return;
		}
		
		/**
		 * The next Node in the list.
		 */
		private Node<E> next;
		
		/**
		 * The previous Node in the list.
		 */
		private Node<E> prev;
		
		/**
		 * The data of this Node.
		 */
		private E data;
	}
	
	/**
	 * Contains data for a priority.
	 */
	private class PriorityPointer<E>
	{
		/**
		 * Initializes this PriorityPointer that starts at [first] and
		 * has [len] elements.
		 * @param first
		 * The start of this sublist.
		 * @param len
		 * The length of this sublist.
		 */
		public PriorityPointer(Node<E> first, int len)
		{
			start = first;
			size = len;
		}
		
		/**
		 * The pointer to the first node.
		 */
		public Node<E> start;
		
		/**
		 * The number of nodes we have for this sublist.
		 */
		public int size;
	}
	
	/**
	 * Iterates through a PriorityList.
	 * @author Donald Nye
	 */
	private class PriorityListIterator implements ListIterator<E>
	{
		/**
		 * Creates an Iterator to go through a PriorityList's elements that
		 * have priority [priority]. If [priority] is negative then the entire
		 * list is iterated through.
		 */
		public PriorityListIterator(int priority)
		{
			if(priority < 0)
				c = head;
			else
			{
				c = p_ptr[priority].start;
				
				if(c != null)
					c = c.getPrevious();
			}
			
			index = 0;
			flag = 0;
			this.priority = priority;
			
			return;
		}
		
		/**
		 * Creates an Iterator to go through a PriorityList's elements that
		 * have priority [priority]. If [priority] is negative then the entire
		 * list is iterated through. Starts iteration at [index] into the list.
		 */
		public PriorityListIterator(int priority, int index)
		{
			if(priority < 0)
			{
				if(index > size)
					throw new IndexOutOfBoundsException();
			}
			else if(priority > p_ptr.length - 1)
				throw new IndexOutOfBoundsException();
			else if(index > p_ptr[priority].size)
				throw new IndexOutOfBoundsException();
			
			int i = 0;
			int sum = 0;
			
			for(; sum < index; i++)
				sum += p_ptr[i].size;
			
			Node<E> c = p_ptr[--i].start;
			sum -= p_ptr[i].size;
			
			for(; sum < index - 1; sum++)
				c = c.getNext();
			
			this.c = c;
			
			this.index = index;
			flag = 0;
			this.priority = priority;
			
			return;
		}
		
		@Override public void add(E e)
		{
			if(flag == 0)
				return;
			
			if(priority > -1)
			{
				int s = index;
				
				for(int i = 0; i < priority; i++)
					s += p_ptr[i].size;
				
				if(index == p_ptr[priority].size)
					PriorityList.this.addWithPriority(priority, e);
				else
					PriorityList.this.add(s, e);
				
				c = c.getNext();
				index++;
				
				flag = 0;
				return;
			}
			
			if(index == size)
			{
				PriorityList.this.add(e);
				
				c = c.getNext();
				index++;
				
				flag = 0;
				return;
			}
			
			for(int i = 0, sum = 0; i < size; i++)
			{
				sum += p_ptr[i].size;
				
				if(index == sum)
				{
					PriorityList.this.addWithPriority(i, e);
					break;
				}
				else if(index < sum)
				{
					PriorityList.this.add(index, e);
					break;
				}
			}
			
			c = c.getNext();
			index++;
			
			flag = 0;
			return;
		}

		@Override public boolean hasNext()
		{
			if(priority == -1 && c == tail || priority > -1 && index >= p_ptr[priority].size)
				return false;
			
			return true;
		}

		@Override public boolean hasPrevious()
		{
			if(priority == -1 && c == head || index <= 0)
				return false;
			
			return true;
		}

		@Override public E next()
		{
			if(!hasNext())
				throw new NoSuchElementException();
			
			flag = 2;
			
			c = c.getNext();
			index++;
			
			return c.getValue();
		}

		@Override public int nextIndex()
		{
			if(hasNext())
				return index;
			
			if(priority > -1)
				return p_ptr[priority].size;
			
			return size;
		}

		@Override public E previous()
		{
			if(!hasPrevious())
				throw new NoSuchElementException();
			
			flag = 1;
			
			c = c.getPrevious();
			index--;
			
			return c.getNext().getValue();
		}
		
		@Override public int previousIndex()
		{
			if(hasPrevious())
				return index - 1;
			
			return -1;
		}

		@Override public void remove()
		{
			if(flag == 0)
				return;
			
			if(priority > -1)
			{
				if(flag == 2)
				{
					c = c.getPrevious();
					index--;
				}
				
				int s = index;
				
				for(int i = 0; i < priority; i++)
					s += p_ptr[i].size;
				
				PriorityList.this.remove(s);
				
				flag = 0;
				return;
			}
			
			if(flag == 2)
			{
				c = c.getPrevious();
				index--;
			}
			
			PriorityList.this.remove(index);
			
			flag = 0;
			return;
		}

		@Override public void set(E e)
		{
			if(c == null)
				throw new IllegalStateException();
			
			c.setValue(e);
			return;
		}
		
		/**
		 * Provides a flag to indicate that remove or add has been
		 * called but next or previous has not yet been.
		 */
		private int flag;
		
		/**
		 * The index of the next Node.
		 */
		private int index;
		
		/**
		 * Contains a pointer to the Node at [index] - 1.
		 */
		private Node<E> c;
		
		/**
		 * The priority that this ListIterator iterates through. It priority
		 * is less than zero it iterates throught he entire list.
		 */
		private int priority;
	}
	
	/**
	 * A dummy node that contains the first node of the List.
	 */
	private Node<E> head;
	
	/**
	 * A variable of convenience to speed up code execution in large lists.
	 */
	private Node<E> tail;
	
	/**
	 * Contains the number of values stored in this PriorityList.
	 */
	private int size;

	/**
	 * Contains the pointers to priority levels in the list.
	 */
	private PriorityPointer<E>[] p_ptr;
}